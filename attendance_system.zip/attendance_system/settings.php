<?php
session_start();
require_once 'db.php';

// Check if coordinator
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'coordinator' || !$_SESSION['campus_id']) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['full_name'];
$campus_id = $_SESSION['campus_id'];

// Get campus info
$stmt = $conn->prepare("SELECT * FROM campuses WHERE campus_id = ?");
$stmt->bind_param("i", $campus_id);
$stmt->execute();
$campus = $stmt->get_result()->fetch_assoc();

// Initialize messages
$success_message = '';
$error_message = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    // Update Profile Settings
    if ($action === 'update_profile') {
        $full_name = trim($_POST['full_name']);
        $email = trim($_POST['email']);
        $phone = trim($_POST['phone']);
        
        if (empty($full_name)) {
            $error_message = 'Full name is required.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error_message = 'Please enter a valid email address.';
        } else {
            $stmt = $conn->prepare("UPDATE coordinators SET full_name = ?, email = ?, phone = ? WHERE coordinator_id = ?");
            $stmt->bind_param("sssi", $full_name, $email, $phone, $user_id);
            
            if ($stmt->execute()) {
                $_SESSION['full_name'] = $full_name;
                $user_name = $full_name;
                $success_message = 'Profile updated successfully!';
            } else {
                $error_message = 'Failed to update profile. Please try again.';
            }
        }
    }
    
    // Change Password
    elseif ($action === 'change_password') {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        // Verify current password
        $stmt = $conn->prepare("SELECT password FROM coordinators WHERE coordinator_id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        
        if (!password_verify($current_password, $result['password'])) {
            $error_message = 'Current password is incorrect.';
        } elseif ($new_password !== $confirm_password) {
            $error_message = 'New passwords do not match.';
        } elseif (strlen($new_password) < 6) {
            $error_message = 'New password must be at least 6 characters long.';
        } else {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE coordinators SET password = ? WHERE coordinator_id = ?");
            $stmt->bind_param("si", $hashed_password, $user_id);
            
            if ($stmt->execute()) {
                $success_message = 'Password changed successfully!';
            } else {
                $error_message = 'Failed to change password. Please try again.';
            }
        }
    }
    
    // Update Campus Settings
    elseif ($action === 'update_campus') {
        $campus_name = trim($_POST['campus_name']);
        $address = trim($_POST['address']);
        $phone = trim($_POST['campus_phone']);
        $email = trim($_POST['campus_email']);
        $timezone = $_POST['timezone'];
        
        if (empty($campus_name)) {
            $error_message = 'Campus name is required.';
        } else {
            $stmt = $conn->prepare("UPDATE campuses SET campus_name = ?, address = ?, phone = ?, email = ?, timezone = ?, updated_at = NOW() WHERE campus_id = ?");
            $stmt->bind_param("sssssi", $campus_name, $address, $phone, $email, $timezone, $campus_id);
            
            if ($stmt->execute()) {
                $campus['campus_name'] = $campus_name;
                $campus['address'] = $address;
                $campus['phone'] = $phone;
                $campus['email'] = $email;
                $campus['timezone'] = $timezone;
                $success_message = 'Campus settings updated successfully!';
            } else {
                $error_message = 'Failed to update campus settings. Please try again.';
            }
        }
    }
    
    // Update System Settings
    elseif ($action === 'update_system') {
        $late_threshold = intval($_POST['late_threshold']);
        $absence_fine = floatval($_POST['absence_fine']);
        $qr_code_size = intval($_POST['qr_code_size']);
        $enable_email_notifications = isset($_POST['enable_email_notifications']) ? 1 : 0;
        $enable_sms_notifications = isset($_POST['enable_sms_notifications']) ? 1 : 0;
        
        // Save to database or session
        $_SESSION['settings'] = [
            'late_threshold' => $late_threshold,
            'absence_fine' => $absence_fine,
            'qr_code_size' => $qr_code_size,
            'enable_email_notifications' => $enable_email_notifications,
            'enable_sms_notifications' => $enable_sms_notifications
        ];
        
        $success_message = 'System settings updated successfully!';
    }
    
    // Generate New API Key
    elseif ($action === 'generate_api_key') {
        $api_key = bin2hex(random_bytes(32));
        $stmt = $conn->prepare("UPDATE coordinators SET api_key = ? WHERE coordinator_id = ?");
        $stmt->bind_param("si", $api_key, $user_id);
        
        if ($stmt->execute()) {
            $success_message = 'New API key generated successfully!';
        } else {
            $error_message = 'Failed to generate API key. Please try again.';
        }
    }
}

// Get coordinator details
$stmt = $conn->prepare("SELECT * FROM coordinators WHERE coordinator_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$coordinator = $stmt->get_result()->fetch_assoc();

// Get existing API key
$api_key = $coordinator['api_key'] ?? '';

// Timezone options
$timezones = [
    'Asia/Manila' => 'Philippines Time (UTC+8)',
    'UTC' => 'Coordinated Universal Time (UTC)',
    'America/New_York' => 'Eastern Time (UTC-5)',
    'America/Los_Angeles' => 'Pacific Time (UTC-8)',
    'Europe/London' => 'London Time (UTC+0)',
    'Europe/Paris' => 'Paris Time (UTC+1)',
    'Asia/Tokyo' => 'Tokyo Time (UTC+9)',
    'Australia/Sydney' => 'Sydney Time (UTC+10)'
];

// Default system settings
$system_settings = $_SESSION['settings'] ?? [
    'late_threshold' => 15,
    'absence_fine' => 100.00,
    'qr_code_size' => 200,
    'enable_email_notifications' => 1,
    'enable_sms_notifications' => 0
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Settings | Multi-Campus Attendance System</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { 
            font-family: 'Segoe UI', 'Inter', system-ui, -apple-system, sans-serif; 
        }
        .gradient-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .settings-nav {
            scrollbar-width: thin;
            scrollbar-color: #cbd5e0 #f7fafc;
        }
        .settings-nav::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }
        .settings-nav::-webkit-scrollbar-track {
            background: #f7fafc;
            border-radius: 3px;
        }
        .settings-nav::-webkit-scrollbar-thumb {
            background: #cbd5e0;
            border-radius: 3px;
        }
        .settings-nav::-webkit-scrollbar-thumb:hover {
            background: #a0aec0;
        }
        .tab-active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }
        .setting-card {
            transition: all 0.3s ease;
        }
        .setting-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1);
        }
        input[type="checkbox"] {
            appearance: none;
            width: 20px;
            height: 20px;
            border: 2px solid #d1d5db;
            border-radius: 4px;
            background: white;
            cursor: pointer;
            position: relative;
            transition: all 0.2s;
        }
        input[type="checkbox"]:checked {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-color: transparent;
        }
        input[type="checkbox"]:checked::after {
            content: '✓';
            position: absolute;
            color: white;
            font-size: 14px;
            font-weight: bold;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }
        input[type="range"] {
            -webkit-appearance: none;
            width: 100%;
            height: 8px;
            border-radius: 4px;
            background: #e5e7eb;
            outline: none;
        }
        input[type="range"]::-webkit-slider-thumb {
            -webkit-appearance: none;
            appearance: none;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            cursor: pointer;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
        }
        input[type="range"]::-moz-range-thumb {
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            cursor: pointer;
            border: none;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
        }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">

<!-- Header -->
<header class="gradient-header text-white shadow-lg">
    <div class="container mx-auto px-4 py-4">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div class="flex items-center gap-3">
                <a href="dashboard.php" class="text-white hover:text-gray-200">
                    <i class="fas fa-arrow-left text-xl"></i>
                </a>
                <div>
                    <h1 class="text-2xl font-bold">System Settings</h1>
                    <p class="text-purple-200 text-sm"><?php echo htmlspecialchars($campus['campus_name']); ?> Campus</p>
                </div>
            </div>
            <div class="flex items-center gap-4">
                <a href="dashboard.php" class="bg-white/20 backdrop-blur-sm hover:bg-white/30 px-4 py-2 rounded-lg transition-all">
                    <i class="fas fa-tachometer-alt mr-2"></i>Dashboard
                </a>
            </div>
        </div>
    </div>
</header>

<main class="container mx-auto px-4 py-8">
    <!-- Messages -->
    <?php if ($success_message): ?>
        <div class="mb-6 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg animate-in">
            <div class="flex items-center">
                <i class="fas fa-check-circle mr-3 text-green-600"></i>
                <span><?php echo htmlspecialchars($success_message); ?></span>
            </div>
        </div>
    <?php endif; ?>
    
    <?php if ($error_message): ?>
        <div class="mb-6 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg animate-in">
            <div class="flex items-center">
                <i class="fas fa-exclamation-circle mr-3 text-red-600"></i>
                <span><?php echo htmlspecialchars($error_message); ?></span>
            </div>
        </div>
    <?php endif; ?>
    
    <div class="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <!-- Settings Navigation -->
        <div class="lg:col-span-1">
            <div class="bg-white rounded-2xl shadow-lg border sticky top-8">
                <div class="p-6 border-b">
                    <h3 class="text-lg font-bold text-gray-900 flex items-center">
                        <i class="fas fa-sliders-h text-blue-600 mr-3"></i>
                        Settings Menu
                    </h3>
                </div>
                <nav class="settings-nav overflow-y-auto max-h-[calc(100vh-200px)]">
                    <ul class="space-y-1 p-2">
                        <li>
                            <a href="#profile" 
                               onclick="showTab('profile')" 
                               id="tab-profile"
                               class="flex items-center px-4 py-3 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors tab-active">
                                <i class="fas fa-user-circle text-blue-500 mr-3 w-6 text-center"></i>
                                <span>Profile Settings</span>
                            </a>
                        </li>
                        <li>
                            <a href="#password" 
                               onclick="showTab('password')" 
                               id="tab-password"
                               class="flex items-center px-4 py-3 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors">
                                <i class="fas fa-lock text-green-500 mr-3 w-6 text-center"></i>
                                <span>Password & Security</span>
                            </a>
                        </li>
                        <li>
                            <a href="#campus" 
                               onclick="showTab('campus')" 
                               id="tab-campus"
                               class="flex items-center px-4 py-3 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors">
                                <i class="fas fa-school text-purple-500 mr-3 w-6 text-center"></i>
                                <span>Campus Settings</span>
                            </a>
                        </li>
                        <li>
                            <a href="#system" 
                               onclick="showTab('system')" 
                               id="tab-system"
                               class="flex items-center px-4 py-3 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors">
                                <i class="fas fa-cogs text-yellow-500 mr-3 w-6 text-center"></i>
                                <span>System Settings</span>
                            </a>
                        </li>
                        <li>
                            <a href="#notifications" 
                               onclick="showTab('notifications')" 
                               id="tab-notifications"
                               class="flex items-center px-4 py-3 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors">
                                <i class="fas fa-bell text-red-500 mr-3 w-6 text-center"></i>
                                <span>Notifications</span>
                            </a>
                        </li>
                        <li>
                            <a href="#api" 
                               onclick="showTab('api')" 
                               id="tab-api"
                               class="flex items-center px-4 py-3 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors">
                                <i class="fas fa-key text-indigo-500 mr-3 w-6 text-center"></i>
                                <span>API Settings</span>
                            </a>
                        </li>
                        <li>
                            <a href="#about" 
                               onclick="showTab('about')" 
                               id="tab-about"
                               class="flex items-center px-4 py-3 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors">
                                <i class="fas fa-info-circle text-gray-500 mr-3 w-6 text-center"></i>
                                <span>About & Help</span>
                            </a>
                        </li>
                    </ul>
                </nav>
                <div class="p-4 border-t bg-gray-50">
                    <div class="text-center">
                        <p class="text-xs text-gray-500">
                            <i class="fas fa-shield-alt mr-1"></i>
                            Settings are saved automatically
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Settings Content -->
        <div class="lg:col-span-3">
            <!-- Profile Settings -->
            <div id="content-profile" class="setting-content">
                <div class="bg-white rounded-2xl shadow-lg p-6 border setting-card">
                    <h2 class="text-xl font-bold text-gray-900 mb-6 flex items-center">
                        <i class="fas fa-user-circle text-blue-600 mr-3"></i>
                        Profile Settings
                    </h2>
                    
                    <form method="POST" action="" class="space-y-6">
                        <input type="hidden" name="action" value="update_profile">
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    <i class="fas fa-user text-blue-500 mr-2"></i>
                                    Full Name *
                                </label>
                                <input type="text" 
                                       name="full_name" 
                                       value="<?php echo htmlspecialchars($coordinator['full_name'] ?? $user_name); ?>"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                                       required>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    <i class="fas fa-envelope text-purple-500 mr-2"></i>
                                    Email Address *
                                </label>
                                <input type="email" 
                                       name="email" 
                                       value="<?php echo htmlspecialchars($coordinator['email'] ?? ''); ?>"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                                       required>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    <i class="fas fa-phone text-green-500 mr-2"></i>
                                    Phone Number
                                </label>
                                <input type="tel" 
                                       name="phone" 
                                       value="<?php echo htmlspecialchars($coordinator['phone'] ?? ''); ?>"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                                       placeholder="+63 912 345 6789">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    <i class="fas fa-id-card text-yellow-500 mr-2"></i>
                                    Coordinator ID
                                </label>
                                <input type="text" 
                                       value="<?php echo htmlspecialchars($coordinator['username'] ?? $_SESSION['username'] ?? ''); ?>"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg bg-gray-50 cursor-not-allowed"
                                       disabled>
                                <p class="text-xs text-gray-500 mt-1">Coordinator ID cannot be changed</p>
                            </div>
                        </div>
                        
                        <div class="pt-6 border-t">
                            <div class="flex justify-between items-center">
                                <div>
                                    <p class="text-sm text-gray-600">Last updated: 
                                        <?php echo !empty($coordinator['updated_at']) ? date('F j, Y \a\t h:i A', strtotime($coordinator['updated_at'])) : 'Never'; ?>
                                    </p>
                                </div>
                                <button type="submit" 
                                        class="px-6 py-3 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-lg hover:from-blue-600 hover:to-blue-700 transition-all font-medium">
                                    <i class="fas fa-save mr-2"></i>Save Changes
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Password & Security -->
            <div id="content-password" class="setting-content hidden">
                <div class="bg-white rounded-2xl shadow-lg p-6 border setting-card">
                    <h2 class="text-xl font-bold text-gray-900 mb-6 flex items-center">
                        <i class="fas fa-lock text-green-600 mr-3"></i>
                        Password & Security
                    </h2>
                    
                    <form method="POST" action="" class="space-y-6">
                        <input type="hidden" name="action" value="change_password">
                        
                        <div class="space-y-6">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    <i class="fas fa-lock text-blue-500 mr-2"></i>
                                    Current Password *
                                </label>
                                <input type="password" 
                                       name="current_password" 
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                                       required>
                            </div>
                            
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">
                                        <i class="fas fa-key text-green-500 mr-2"></i>
                                        New Password *
                                    </label>
                                    <input type="password" 
                                           name="new_password" 
                                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                                           required
                                           minlength="6">
                                    <p class="text-xs text-gray-500 mt-1">Minimum 6 characters</p>
                                </div>
                                
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">
                                        <i class="fas fa-key text-purple-500 mr-2"></i>
                                        Confirm New Password *
                                    </label>
                                    <input type="password" 
                                           name="confirm_password" 
                                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                                           required
                                           minlength="6">
                                </div>
                            </div>
                        </div>
                        
                        <div class="pt-6 border-t">
                            <div class="flex justify-between items-center">
                                <div>
                                    <p class="text-sm text-gray-600">
                                        <i class="fas fa-shield-alt mr-2 text-green-600"></i>
                                        Last password change: 
                                        <?php echo !empty($coordinator['password_changed_at']) ? date('F j, Y', strtotime($coordinator['password_changed_at'])) : 'Never'; ?>
                                    </p>
                                </div>
                                <button type="submit" 
                                        class="px-6 py-3 bg-gradient-to-r from-green-500 to-green-600 text-white rounded-lg hover:from-green-600 hover:to-green-700 transition-all font-medium">
                                    <i class="fas fa-key mr-2"></i>Change Password
                                </button>
                            </div>
                        </div>
                    </form>
                    
                    <!-- Security Tips -->
                    <div class="mt-8 pt-8 border-t">
                        <h3 class="text-lg font-medium text-gray-900 mb-4 flex items-center">
                            <i class="fas fa-shield-alt text-yellow-600 mr-3"></i>
                            Security Tips
                        </h3>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                                <div class="flex items-start">
                                    <i class="fas fa-check-circle text-blue-600 mt-1 mr-3"></i>
                                    <div>
                                        <h4 class="font-medium text-blue-900">Use Strong Passwords</h4>
                                        <p class="text-sm text-blue-700 mt-1">Combine letters, numbers, and special characters.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="bg-green-50 border border-green-200 rounded-lg p-4">
                                <div class="flex items-start">
                                    <i class="fas fa-sync-alt text-green-600 mt-1 mr-3"></i>
                                    <div>
                                        <h4 class="font-medium text-green-900">Regular Updates</h4>
                                        <p class="text-sm text-green-700 mt-1">Change your password every 3-6 months.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Campus Settings -->
            <div id="content-campus" class="setting-content hidden">
                <div class="bg-white rounded-2xl shadow-lg p-6 border setting-card">
                    <h2 class="text-xl font-bold text-gray-900 mb-6 flex items-center">
                        <i class="fas fa-school text-purple-600 mr-3"></i>
                        Campus Settings
                    </h2>
                    
                    <form method="POST" action="" class="space-y-6">
                        <input type="hidden" name="action" value="update_campus">
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div class="md:col-span-2">
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    <i class="fas fa-university text-blue-500 mr-2"></i>
                                    Campus Name *
                                </label>
                                <input type="text" 
                                       name="campus_name" 
                                       value="<?php echo htmlspecialchars($campus['campus_name']); ?>"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                                       required>
                            </div>
                            
                            <div class="md:col-span-2">
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    <i class="fas fa-map-marker-alt text-red-500 mr-2"></i>
                                    Address
                                </label>
                                <textarea name="address" 
                                          rows="3"
                                          class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"><?php echo htmlspecialchars($campus['address'] ?? ''); ?></textarea>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    <i class="fas fa-phone text-green-500 mr-2"></i>
                                    Campus Phone
                                </label>
                                <input type="tel" 
                                       name="campus_phone" 
                                       value="<?php echo htmlspecialchars($campus['phone'] ?? ''); ?>"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                                       placeholder="+63 2 123 4567">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    <i class="fas fa-envelope text-purple-500 mr-2"></i>
                                    Campus Email
                                </label>
                                <input type="email" 
                                       name="campus_email" 
                                       value="<?php echo htmlspecialchars($campus['email'] ?? ''); ?>"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                                       placeholder="campus@university.edu">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    <i class="fas fa-clock text-yellow-500 mr-2"></i>
                                    Timezone
                                </label>
                                <select name="timezone" 
                                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all">
                                    <?php foreach ($timezones as $tz => $label): ?>
                                        <option value="<?php echo $tz; ?>" 
                                            <?php echo ($campus['timezone'] ?? 'Asia/Manila') == $tz ? 'selected' : ''; ?>>
                                            <?php echo $label; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    <i class="fas fa-calendar text-indigo-500 mr-2"></i>
                                    Created Date
                                </label>
                                <input type="text" 
                                       value="<?php echo !empty($campus['created_at']) ? date('F j, Y', strtotime($campus['created_at'])) : 'N/A'; ?>"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg bg-gray-50 cursor-not-allowed"
                                       disabled>
                            </div>
                        </div>
                        
                        <div class="pt-6 border-t">
                            <div class="flex justify-between items-center">
                                <div>
                                    <p class="text-sm text-gray-600">Campus ID: <?php echo $campus_id; ?></p>
                                </div>
                                <button type="submit" 
                                        class="px-6 py-3 bg-gradient-to-r from-purple-500 to-purple-600 text-white rounded-lg hover:from-purple-600 hover:to-purple-700 transition-all font-medium">
                                    <i class="fas fa-save mr-2"></i>Update Campus
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- System Settings -->
            <div id="content-system" class="setting-content hidden">
                <div class="bg-white rounded-2xl shadow-lg p-6 border setting-card">
                    <h2 class="text-xl font-bold text-gray-900 mb-6 flex items-center">
                        <i class="fas fa-cogs text-yellow-600 mr-3"></i>
                        System Settings
                    </h2>
                    
                    <form method="POST" action="" class="space-y-6">
                        <input type="hidden" name="action" value="update_system">
                        
                        <div class="space-y-6">
                            <!-- Attendance Settings -->
                            <div class="border-b pb-6">
                                <h3 class="text-lg font-medium text-gray-900 mb-4 flex items-center">
                                    <i class="fas fa-user-clock text-blue-600 mr-3"></i>
                                    Attendance Settings
                                </h3>
                                
                                <div class="space-y-4">
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">
                                            Late Attendance Threshold (minutes)
                                        </label>
                                        <div class="flex items-center space-x-4">
                                            <input type="range" 
                                                   name="late_threshold" 
                                                   min="1" 
                                                   max="60" 
                                                   value="<?php echo $system_settings['late_threshold']; ?>"
                                                   class="flex-1"
                                                   oninput="updateLateThreshold(this.value)">
                                            <span id="lateThresholdValue" class="text-lg font-bold text-blue-600 min-w-[40px]">
                                                <?php echo $system_settings['late_threshold']; ?>
                                            </span>
                                            <span class="text-gray-500">min</span>
                                        </div>
                                        <p class="text-xs text-gray-500 mt-2">Students arriving after this time will be marked as "Late"</p>
                                    </div>
                                    
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">
                                            Default Fine for Absence (₱)
                                        </label>
                                        <div class="relative">
                                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                                <span class="text-gray-500">₱</span>
                                            </div>
                                            <input type="number" 
                                                   name="absence_fine" 
                                                   value="<?php echo number_format($system_settings['absence_fine'], 2); ?>"
                                                   step="0.01"
                                                   min="0"
                                                   max="10000"
                                                   class="w-full pl-8 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all">
                                        </div>
                                        <p class="text-xs text-gray-500 mt-2">Default fine amount for mandatory activity absences</p>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- QR Code Settings -->
                            <div class="border-b pb-6">
                                <h3 class="text-lg font-medium text-gray-900 mb-4 flex items-center">
                                    <i class="fas fa-qrcode text-green-600 mr-3"></i>
                                    QR Code Settings
                                </h3>
                                
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">
                                        QR Code Size (pixels)
                                    </label>
                                    <div class="flex items-center space-x-4">
                                        <input type="range" 
                                               name="qr_code_size" 
                                               min="100" 
                                               max="500" 
                                               step="10"
                                               value="<?php echo $system_settings['qr_code_size']; ?>"
                                               class="flex-1"
                                               oninput="updateQrSize(this.value)">
                                        <span id="qrSizeValue" class="text-lg font-bold text-green-600 min-w-[50px]">
                                            <?php echo $system_settings['qr_code_size']; ?>
                                        </span>
                                        <span class="text-gray-500">px</span>
                                    </div>
                                    <p class="text-xs text-gray-500 mt-2">Size of generated QR codes for students</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="pt-6 border-t">
                            <div class="flex justify-between items-center">
                                <div>
                                    <p class="text-sm text-gray-600">
                                        <i class="fas fa-info-circle mr-2"></i>
                                        These settings affect system-wide behavior
                                    </p>
                                </div>
                                <button type="submit" 
                                        class="px-6 py-3 bg-gradient-to-r from-yellow-500 to-yellow-600 text-white rounded-lg hover:from-yellow-600 hover:to-yellow-700 transition-all font-medium">
                                    <i class="fas fa-save mr-2"></i>Save System Settings
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Notification Settings -->
            <div id="content-notifications" class="setting-content hidden">
                <div class="bg-white rounded-2xl shadow-lg p-6 border setting-card">
                    <h2 class="text-xl font-bold text-gray-900 mb-6 flex items-center">
                        <i class="fas fa-bell text-red-600 mr-3"></i>
                        Notification Settings
                    </h2>
                    
                    <form method="POST" action="" class="space-y-6">
                        <input type="hidden" name="action" value="update_system">
                        
                        <div class="space-y-6">
                            <!-- Email Notifications -->
                            <div class="border-b pb-6">
                                <h3 class="text-lg font-medium text-gray-900 mb-4 flex items-center">
                                    <i class="fas fa-envelope text-blue-600 mr-3"></i>
                                    Email Notifications
                                </h3>
                                
                                <div class="space-y-4">
                                    <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                                        <div class="flex items-center">
                                            <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mr-4">
                                                <i class="fas fa-envelope text-blue-600"></i>
                                            </div>
                                            <div>
                                                <h4 class="font-medium text-gray-900">Enable Email Notifications</h4>
                                                <p class="text-sm text-gray-600">Receive notifications via email</p>
                                            </div>
                                        </div>
                                        <label class="relative inline-flex items-center cursor-pointer">
                                            <input type="checkbox" 
                                                   name="enable_email_notifications" 
                                                   value="1"
                                                   class="sr-only peer"
                                                   <?php echo $system_settings['enable_email_notifications'] ? 'checked' : ''; ?>>
                                            <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                                        </label>
                                    </div>
                                    
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">
                                            Notification Email Address
                                        </label>
                                        <input type="email" 
                                               value="<?php echo htmlspecialchars($coordinator['email'] ?? ''); ?>"
                                               class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                                               placeholder="your-email@example.com">
                                        <p class="text-xs text-gray-500 mt-2">Notifications will be sent to this email address</p>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- SMS Notifications -->
                            <div class="pb-6">
                                <h3 class="text-lg font-medium text-gray-900 mb-4 flex items-center">
                                    <i class="fas fa-sms text-green-600 mr-3"></i>
                                    SMS Notifications
                                </h3>
                                
                                <div class="space-y-4">
                                    <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                                        <div class="flex items-center">
                                            <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mr-4">
                                                <i class="fas fa-sms text-green-600"></i>
                                            </div>
                                            <div>
                                                <h4 class="font-medium text-gray-900">Enable SMS Notifications</h4>
                                                <p class="text-sm text-gray-600">Receive notifications via SMS (requires SMS credits)</p>
                                            </div>
                                        </div>
                                        <label class="relative inline-flex items-center cursor-pointer">
                                            <input type="checkbox" 
                                                   name="enable_sms_notifications" 
                                                   value="1"
                                                   class="sr-only peer"
                                                   <?php echo $system_settings['enable_sms_notifications'] ? 'checked' : ''; ?>>
                                            <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
                                        </label>
                                    </div>
                                    
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">
                                            Mobile Number for SMS
                                        </label>
                                        <input type="tel" 
                                               value="<?php echo htmlspecialchars($coordinator['phone'] ?? ''); ?>"
                                               class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                                               placeholder="+63 912 345 6789">
                                        <p class="text-xs text-gray-500 mt-2">SMS notifications will be sent to this number</p>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Notification Types -->
                            <div class="border-t pt-6">
                                <h3 class="text-lg font-medium text-gray-900 mb-4 flex items-center">
                                    <i class="fas fa-bell text-purple-600 mr-3"></i>
                                    Notification Preferences
                                </h3>
                                
                                <div class="space-y-3">
                                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                                        <div>
                                            <h4 class="font-medium text-gray-900">New Activity Created</h4>
                                            <p class="text-sm text-gray-600">When a new activity is scheduled</p>
                                        </div>
                                        <input type="checkbox" checked class="w-5 h-5">
                                    </div>
                                    
                                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                                        <div>
                                            <h4 class="font-medium text-gray-900">Attendance Reports</h4>
                                            <p class="text-sm text-gray-600">Daily attendance summary reports</p>
                                        </div>
                                        <input type="checkbox" checked class="w-5 h-5">
                                    </div>
                                    
                                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                                        <div>
                                            <h4 class="font-medium text-gray-900">System Alerts</h4>
                                            <p class="text-sm text-gray-600">Important system updates and alerts</p>
                                        </div>
                                        <input type="checkbox" checked class="w-5 h-5">
                                    </div>
                                    
                                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                                        <div>
                                            <h4 class="font-medium text-gray-900">Fine Notifications</h4>
                                            <p class="text-sm text-gray-600">When students receive fines</p>
                                        </div>
                                        <input type="checkbox" class="w-5 h-5">
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="pt-6 border-t">
                            <button type="submit" 
                                    class="w-full px-6 py-3 bg-gradient-to-r from-red-500 to-red-600 text-white rounded-lg hover:from-red-600 hover:to-red-700 transition-all font-medium">
                                <i class="fas fa-save mr-2"></i>Save Notification Settings
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- API Settings -->
            <div id="content-api" class="setting-content hidden">
                <div class="bg-white rounded-2xl shadow-lg p-6 border setting-card">
                    <h2 class="text-xl font-bold text-gray-900 mb-6 flex items-center">
                        <i class="fas fa-key text-indigo-600 mr-3"></i>
                        API Settings
                    </h2>
                    
                    <div class="space-y-6">
                        <!-- Current API Key -->
                        <div class="bg-gradient-to-br from-indigo-50 to-purple-50 border border-indigo-200 rounded-xl p-6">
                            <h3 class="text-lg font-medium text-gray-900 mb-4 flex items-center">
                                <i class="fas fa-key text-indigo-600 mr-3"></i>
                                Current API Key
                            </h3>
                            
                            <?php if ($api_key): ?>
                                <div class="relative">
                                    <input type="text" 
                                           id="apiKeyInput"
                                           value="<?php echo htmlspecialchars($api_key); ?>"
                                           class="w-full px-4 py-3 border border-gray-300 rounded-lg bg-gray-50 font-mono text-sm"
                                           readonly>
                                    <button onclick="copyApiKey()" 
                                            class="absolute right-2 top-1/2 transform -translate-y-1/2 px-3 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700 transition-colors">
                                        <i class="fas fa-copy"></i>
                                    </button>
                                </div>
                                <p class="text-xs text-gray-600 mt-2 flex items-center">
                                    <i class="fas fa-info-circle mr-2"></i>
                                    Keep this key secure. It provides access to your campus data.
                                </p>
                            <?php else: ?>
                                <div class="text-center py-4">
                                    <p class="text-gray-600 mb-4">No API key generated yet.</p>
                                    <form method="POST" action="" class="inline-block">
                                        <input type="hidden" name="action" value="generate_api_key">
                                        <button type="submit" 
                                                class="px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors">
                                            <i class="fas fa-plus-circle mr-2"></i>Generate API Key
                                        </button>
                                    </form>
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <!-- API Documentation -->
                        <div class="border-t pt-6">
                            <h3 class="text-lg font-medium text-gray-900 mb-4 flex items-center">
                                <i class="fas fa-book text-blue-600 mr-3"></i>
                                API Documentation
                            </h3>
                            
                            <div class="space-y-4">
                                <div class="bg-gray-50 rounded-lg p-4">
                                    <h4 class="font-medium text-gray-900 mb-2">Base URL</h4>
                                    <code class="text-sm bg-white px-3 py-2 rounded border font-mono block">
                                        <?php echo 'https://' . $_SERVER['HTTP_HOST'] . '/api/'; ?>
                                    </code>
                                </div>
                                
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div class="bg-gray-50 rounded-lg p-4">
                                        <h4 class="font-medium text-gray-900 mb-2">Headers</h4>
                                        <pre class="text-sm bg-white p-3 rounded border font-mono overflow-x-auto">
X-API-Key: <?php echo $api_key ? 'your_api_key_here' : 'API_KEY_REQUIRED'; ?>
Content-Type: application/json</pre>
                                    </div>
                                    
                                    <div class="bg-gray-50 rounded-lg p-4">
                                        <h4 class="font-medium text-gray-900 mb-2">Example Request</h4>
                                        <pre class="text-sm bg-white p-3 rounded border font-mono overflow-x-auto">
GET /api/attendance
Headers: {
    "X-API-Key": "your_api_key",
    "Content-Type": "application/json"
}</pre>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Regenerate API Key -->
                        <div class="border-t pt-6">
                            <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                                <div class="flex items-start">
                                    <i class="fas fa-exclamation-triangle text-yellow-600 mt-1 mr-3"></i>
                                    <div>
                                        <h4 class="font-medium text-yellow-900">Regenerate API Key</h4>
                                        <p class="text-sm text-yellow-700 mt-1">
                                            Generating a new API key will invalidate the current key. 
                                            Any applications using the old key will stop working.
                                        </p>
                                    </div>
                                </div>
                                <div class="mt-4">
                                    <form method="POST" action="" onsubmit="return confirm('Are you sure? This will invalidate your current API key.')">
                                        <input type="hidden" name="action" value="generate_api_key">
                                        <button type="submit" 
                                                class="px-6 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
                                            <i class="fas fa-sync-alt mr-2"></i>Regenerate API Key
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- About & Help -->
            <div id="content-about" class="setting-content hidden">
                <div class="bg-white rounded-2xl shadow-lg p-6 border setting-card">
                    <h2 class="text-xl font-bold text-gray-900 mb-6 flex items-center">
                        <i class="fas fa-info-circle text-gray-600 mr-3"></i>
                        About & Help
                    </h2>
                    
                    <div class="space-y-8">
                        <!-- System Information -->
                        <div>
                            <h3 class="text-lg font-medium text-gray-900 mb-4 flex items-center">
                                <i class="fas fa-server text-blue-600 mr-3"></i>
                                System Information
                            </h3>
                            
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div class="bg-gray-50 rounded-lg p-4">
                                    <div class="flex items-center justify-between mb-3">
                                        <span class="text-sm font-medium text-gray-700">System Version</span>
                                        <span class="px-2 py-1 bg-blue-100 text-blue-800 text-xs font-semibold rounded-full">v2.0.1</span>
                                    </div>
                                    <div class="text-sm text-gray-600">
                                        Multi-Campus Attendance System
                                    </div>
                                </div>
                                
                                <div class="bg-gray-50 rounded-lg p-4">
                                    <div class="flex items-center justify-between mb-3">
                                        <span class="text-sm font-medium text-gray-700">PHP Version</span>
                                        <span class="text-sm font-bold text-gray-900"><?php echo phpversion(); ?></span>
                                    </div>
                                    <div class="text-sm text-gray-600">
                                        Server: <?php echo $_SERVER['SERVER_SOFTWARE'] ?? 'N/A'; ?>
                                    </div>
                                </div>
                                
                                <div class="bg-gray-50 rounded-lg p-4">
                                    <div class="flex items-center justify-between mb-3">
                                        <span class="text-sm font-medium text-gray-700">Database</span>
                                        <span class="text-sm font-bold text-gray-900">MySQL</span>
                                    </div>
                                    <div class="text-sm text-gray-600">
                                        Status: <?php echo $conn->ping() ? 'Connected' : 'Disconnected'; ?>
                                    </div>
                                </div>
                                
                                <div class="bg-gray-50 rounded-lg p-4">
                                    <div class="flex items-center justify-between mb-3">
                                        <span class="text-sm font-medium text-gray-700">Last Updated</span>
                                        <span class="text-sm font-bold text-gray-900"><?php echo date('Y-m-d'); ?></span>
                                    </div>
                                    <div class="text-sm text-gray-600">
                                        Copyright © <?php echo date('Y'); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Help & Support -->
                        <div class="border-t pt-6">
                            <h3 class="text-lg font-medium text-gray-900 mb-4 flex items-center">
                                <i class="fas fa-life-ring text-green-600 mr-3"></i>
                                Help & Support
                            </h3>
                            
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <a href="#" class="bg-gray-50 hover:bg-gray-100 rounded-lg p-4 transition-colors">
                                    <div class="flex items-center mb-3">
                                        <div class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                                            <i class="fas fa-book text-blue-600"></i>
                                        </div>
                                        <h4 class="font-medium text-gray-900">User Guide</h4>
                                    </div>
                                    <p class="text-sm text-gray-600">Complete system documentation and user manual</p>
                                </a>
                                
                                <a href="#" class="bg-gray-50 hover:bg-gray-100 rounded-lg p-4 transition-colors">
                                    <div class="flex items-center mb-3">
                                        <div class="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center mr-3">
                                            <i class="fas fa-video text-green-600"></i>
                                        </div>
                                        <h4 class="font-medium text-gray-900">Video Tutorials</h4>
                                    </div>
                                    <p class="text-sm text-gray-600">Step-by-step video guides for common tasks</p>
                                </a>
                                
                                <a href="#" class="bg-gray-50 hover:bg-gray-100 rounded-lg p-4 transition-colors">
                                    <div class="flex items-center mb-3">
                                        <div class="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center mr-3">
                                            <i class="fas fa-headset text-red-600"></i>
                                        </div>
                                        <h4 class="font-medium text-gray-900">Contact Support</h4>
                                    </div>
                                    <p class="text-sm text-gray-600">Get help from our technical support team</p>
                                </a>
                            </div>
                        </div>
                        
                        <!-- Quick Links -->
                        <div class="border-t pt-6">
                            <h3 class="text-lg font-medium text-gray-900 mb-4 flex items-center">
                                <i class="fas fa-link text-purple-600 mr-3"></i>
                                Quick Links
                            </h3>
                            
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div class="space-y-2">
                                    <a href="dashboard.php" class="flex items-center text-blue-600 hover:text-blue-800">
                                        <i class="fas fa-tachometer-alt mr-3"></i>
                                        Dashboard Overview
                                    </a>
                                    <a href="attendance_log.php" class="flex items-center text-green-600 hover:text-green-800">
                                        <i class="fas fa-list-alt mr-3"></i>
                                        Attendance Log
                                    </a>
                                    <a href="students.php" class="flex items-center text-purple-600 hover:text-purple-800">
                                        <i class="fas fa-users mr-3"></i>
                                        Student Management
                                    </a>
                                </div>
                                <div class="space-y-2">
                                    <a href="activities.php" class="flex items-center text-yellow-600 hover:text-yellow-800">
                                        <i class="fas fa-calendar-alt mr-3"></i>
                                        Activity Management
                                    </a>
                                    <a href="fines.php" class="flex items-center text-red-600 hover:text-red-800">
                                        <i class="fas fa-money-bill-wave mr-3"></i>
                                        Fines Management
                                    </a>
                                    <a href="attendance_report.php" class="flex items-center text-indigo-600 hover:text-indigo-800">
                                        <i class="fas fa-chart-bar mr-3"></i>
                                        Reports & Analytics
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                        <!-- System Status -->
                        <div class="border-t pt-6">
                            <h3 class="text-lg font-medium text-gray-900 mb-4 flex items-center">
                                <i class="fas fa-heartbeat text-red-600 mr-3"></i>
                                System Status
                            </h3>
                            
                            <div class="space-y-3">
                                <div class="flex items-center justify-between">
                                    <div class="flex items-center">
                                        <div class="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
                                        <span class="text-sm text-gray-700">Database Connection</span>
                                    </div>
                                    <span class="text-sm font-medium text-green-600">Active</span>
                                </div>
                                
                                <div class="flex items-center justify-between">
                                    <div class="flex items-center">
                                        <div class="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
                                        <span class="text-sm text-gray-700">File System</span>
                                    </div>
                                    <span class="text-sm font-medium text-green-600">Writable</span>
                                </div>
                                
                                <div class="flex items-center justify-between">
                                    <div class="flex items-center">
                                        <div class="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
                                        <span class="text-sm text-gray-700">Session Management</span>
                                    </div>
                                    <span class="text-sm font-medium text-green-600">Active</span>
                                </div>
                                
                                <div class="flex items-center justify-between">
                                    <div class="flex items-center">
                                        <div class="w-3 h-3 bg-yellow-500 rounded-full mr-3"></div>
                                        <span class="text-sm text-gray-700">Backup Status</span>
                                    </div>
                                    <span class="text-sm font-medium text-yellow-600">Pending</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<!-- Footer -->
<footer class="bg-white border-t mt-8">
    <div class="container mx-auto px-4 py-6">
        <div class="text-center">
            <p class="text-gray-600">
                <i class="fas fa-school mr-2"></i>
                <?php echo htmlspecialchars($campus['campus_name']); ?> Campus • System Settings
            </p>
            <p class="text-sm text-gray-500 mt-2">
                <i class="far fa-copyright mr-1"></i> <?php echo date('Y'); ?> Multi-Campus Attendance System v2.0
            </p>
        </div>
    </div>
</footer>

<script>
// Tab navigation
function showTab(tabName) {
    // Hide all content
    document.querySelectorAll('.setting-content').forEach(content => {
        content.classList.add('hidden');
    });
    
    // Remove active class from all tabs
    document.querySelectorAll('.settings-nav a').forEach(tab => {
        tab.classList.remove('tab-active');
        tab.classList.add('text-gray-700', 'hover:bg-gray-100');
    });
    
    // Show selected content
    document.getElementById('content-' + tabName).classList.remove('hidden');
    
    // Set active tab
    const activeTab = document.getElementById('tab-' + tabName);
    activeTab.classList.add('tab-active');
    activeTab.classList.remove('text-gray-700', 'hover:bg-gray-100');
    
    // Update URL hash without scrolling
    history.replaceState(null, null, '#' + tabName);
}

// Initialize based on URL hash
document.addEventListener('DOMContentLoaded', function() {
    const hash = window.location.hash.substring(1);
    const validTabs = ['profile', 'password', 'campus', 'system', 'notifications', 'api', 'about'];
    
    if (validTabs.includes(hash)) {
        showTab(hash);
    } else {
        showTab('profile');
    }
    
    // Initialize range sliders
    updateLateThreshold(<?php echo $system_settings['late_threshold']; ?>);
    updateQrSize(<?php echo $system_settings['qr_code_size']; ?>);
});

// Range slider updates
function updateLateThreshold(value) {
    document.getElementById('lateThresholdValue').textContent = value;
}

function updateQrSize(value) {
    document.getElementById('qrSizeValue').textContent = value;
}

// Copy API key to clipboard
function copyApiKey() {
    const apiKeyInput = document.getElementById('apiKeyInput');
    apiKeyInput.select();
    apiKeyInput.setSelectionRange(0, 99999); // For mobile devices
    
    try {
        const successful = document.execCommand('copy');
        if (successful) {
            // Show success message
            const button = event.target.closest('button');
            const originalHtml = button.innerHTML;
            button.innerHTML = '<i class="fas fa-check"></i>';
            button.classList.remove('bg-indigo-600');
            button.classList.add('bg-green-600');
            
            setTimeout(() => {
                button.innerHTML = originalHtml;
                button.classList.remove('bg-green-600');
                button.classList.add('bg-indigo-600');
            }, 2000);
        }
    } catch (err) {
        console.error('Failed to copy: ', err);
        alert('Failed to copy API key. Please copy it manually.');
    }
}

// Form validation
document.addEventListener('DOMContentLoaded', function() {
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            // Add basic validation here if needed
            const requiredFields = form.querySelectorAll('[required]');
            let isValid = true;
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    isValid = false;
                    field.classList.add('border-red-500');
                    
                    // Add error message
                    const errorSpan = document.createElement('span');
                    errorSpan.className = 'text-red-600 text-sm mt-1 block';
                    errorSpan.textContent = 'This field is required.';
                    
                    if (!field.nextElementSibling || !field.nextElementSibling.classList.contains('text-red-600')) {
                        field.parentNode.insertBefore(errorSpan, field.nextSibling);
                    }
                } else {
                    field.classList.remove('border-red-500');
                    // Remove error message if exists
                    const errorSpan = field.nextElementSibling;
                    if (errorSpan && errorSpan.classList.contains('text-red-600')) {
                        errorSpan.remove();
                    }
                }
            });
            
            if (!isValid) {
                e.preventDefault();
                return false;
            }
        });
    });
});
</script>
</body>
</html>