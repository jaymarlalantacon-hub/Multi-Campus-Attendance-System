<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_name = $_SESSION['full_name'];
$user_type = $_SESSION['user_type'];
$user_campus_id = $_SESSION['campus_id'];

// Get selected campus from query parameter
$selected_campus = isset($_GET['campus']) ? intval($_GET['campus']) : null;
$selected_campus_name = 'All Campuses';

// Get all campuses for filter dropdown
$campuses = [];
$campus_query = $conn->query("SELECT campus_id, campus_name FROM campuses WHERE status = 'active' ORDER BY campus_name");
while ($campus = $campus_query->fetch_assoc()) {
    $campuses[] = $campus;
}

// Build query based on user type and selected campus
if ($user_type === 'admin') {
    if ($selected_campus && $selected_campus > 0) {
        // Get campus name for display
        $campus_stmt = $conn->prepare("SELECT campus_name FROM campuses WHERE campus_id = ?");
        $campus_stmt->bind_param("i", $selected_campus);
        $campus_stmt->execute();
        $campus_result = $campus_stmt->get_result();
        if ($campus_row = $campus_result->fetch_assoc()) {
            $selected_campus_name = $campus_row['campus_name'];
        }
        
        $query = "SELECT s.*, c.campus_name 
                  FROM students s 
                  LEFT JOIN campuses c ON s.campus_id = c.campus_id 
                  WHERE s.status = 'active' AND s.campus_id = ?
                  ORDER BY s.student_number";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $selected_campus);
    } else {
        $query = "SELECT s.*, c.campus_name 
                  FROM students s 
                  LEFT JOIN campuses c ON s.campus_id = c.campus_id 
                  WHERE s.status = 'active' 
                  ORDER BY s.campus_id, s.student_number";
        $stmt = $conn->prepare($query);
    }
} else {
    // Coordinator can only see their campus
    $selected_campus = $user_campus_id;
    $campus_stmt = $conn->prepare("SELECT campus_name FROM campuses WHERE campus_id = ?");
    $campus_stmt->bind_param("i", $selected_campus);
    $campus_stmt->execute();
    $campus_result = $campus_stmt->get_result();
    if ($campus_row = $campus_result->fetch_assoc()) {
        $selected_campus_name = $campus_row['campus_name'];
    }
    
    $query = "SELECT s.*, c.campus_name 
              FROM students s 
              LEFT JOIN campuses c ON s.campus_id = c.campus_id 
              WHERE s.campus_id = ? AND s.status = 'active' 
              ORDER BY s.student_number";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_campus_id);
}

$stmt->execute();
$result = $stmt->get_result();
$total_students = $result->num_rows;

// Get student count per campus for admin
if ($user_type === 'admin') {
    $campus_counts_query = "SELECT c.campus_id, c.campus_name, COUNT(s.student_id) as student_count 
                            FROM campuses c 
                            LEFT JOIN students s ON c.campus_id = s.campus_id AND s.status = 'active'
                            WHERE c.status = 'active'
                            GROUP BY c.campus_id
                            ORDER BY c.campus_name";
    $campus_counts_result = $conn->query($campus_counts_query);
    $campus_counts = [];
    while ($row = $campus_counts_result->fetch_assoc()) {
        $campus_counts[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Students | Multi-Campus Attendance</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <style>
        
        .campus-select {
            transition: all 0.3s ease;
        }
        .campus-select:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        .campus-card.active {
            border-color: #4f46e5;
            background: linear-gradient(135deg, rgba(79, 70, 229, 0.05) 0%, rgba(99, 102, 241, 0.05) 100%);
        }
        .filter-dropdown {
            animation: fadeIn 0.3s ease;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
    <!-- Navigation -->
    <nav class="bg-gradient-to-r from-purple-800 to-indigo-900 text-white shadow-lg">
        <div class="container mx-auto px-4 py-3">
            <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div class="flex items-center space-x-4">
                    <a href="<?php echo $user_type === 'admin' ? 'admin_dashboard.php' : 'coordinator_dashboard.php'; ?>" 
                       class="flex items-center hover:text-purple-200 transition-colors">
                        <i class="fas fa-arrow-left mr-2"></i> Back to Dashboard
                    </a>
                    <h1 class="text-xl font-bold">
                        <i class="fas fa-users mr-2"></i> Student Directory
                    </h1>
                </div>
                <div class="flex items-center space-x-4">
                    <span class="text-sm">
                        <i class="fas fa-user mr-1"></i> <?php echo htmlspecialchars($user_name); ?>
                    </span>
                    <a href="add_student.php" class="text-sm bg-green-600 hover:bg-green-700 px-3 py-1 rounded-lg transition-colors">
                        <i class="fas fa-user-plus mr-1"></i> Add Student
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-8">
        <!-- Header -->
        <div class="mb-8">
            <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
                <div>
                    <h1 class="text-3xl font-bold text-gray-800">Student Directory</h1>
                    <p class="text-gray-600">
                        <?php 
                        if ($user_type === 'coordinator') {
                            echo "Viewing students for " . $selected_campus_name;
                        } else {
                            if ($selected_campus) {
                                echo "Viewing students for " . $selected_campus_name;
                            } else {
                                echo "All active students across all campuses";
                            }
                        }
                        ?>
                    </p>
                </div>
                <div class="flex items-center space-x-3">
                    <?php if ($user_type === 'admin'): ?>
                    <div class="relative" id="filterContainer">
                        <button onclick="toggleFilter()" 
                                class="flex items-center space-x-2 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                            <i class="fas fa-filter text-gray-600"></i>
                            <span class="text-gray-700">Filter by Campus</span>
                            <?php if ($selected_campus): ?>
                            <span class="px-2 py-1 bg-indigo-100 text-indigo-800 text-xs rounded-full">
                                <?php echo $selected_campus_name; ?>
                            </span>
                            <?php endif; ?>
                            <i class="fas fa-chevron-down text-gray-500"></i>
                        </button>
                        
                        <div id="filterDropdown" class="hidden absolute right-0 mt-2 w-64 bg-white rounded-lg shadow-xl border border-gray-200 filter-dropdown z-10">
                            <div class="p-4">
                                <h3 class="font-semibold text-gray-800 mb-3">Select Campus</h3>
                                <div class="space-y-2 max-h-60 overflow-y-auto">
                                    <a href="students.php" 
                                       class="flex items-center justify-between p-2 hover:bg-gray-100 rounded <?php echo !$selected_campus ? 'bg-indigo-50 text-indigo-700' : 'text-gray-700'; ?>">
                                        <span>All Campuses</span>
                                        <span class="text-sm px-2 py-1 bg-gray-100 rounded"><?php echo $total_students; ?></span>
                                    </a>
                                    <?php foreach ($campus_counts as $campus): ?>
                                    <a href="students.php?campus=<?php echo $campus['campus_id']; ?>" 
                                       class="flex items-center justify-between p-2 hover:bg-gray-100 rounded <?php echo $selected_campus == $campus['campus_id'] ? 'bg-indigo-50 text-indigo-700' : 'text-gray-700'; ?>">
                                        <span><?php echo htmlspecialchars($campus['campus_name']); ?></span>
                                        <span class="text-sm px-2 py-1 bg-gray-100 rounded"><?php echo $campus['student_count']; ?></span>
                                    </a>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <a href="add_student.php.php" 
                       class="px-4 py-2 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-lg hover:from-green-700 hover:to-emerald-700 transition-all shadow flex items-center space-x-2">
                        <i class="fas fa-user-plus"></i>
                        <span>Add Student</span>
                    </a>
                </div>
            </div>

            <!-- Stats Cards -->
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
                <div class="bg-white p-6 rounded-xl shadow border-l-4 border-blue-500">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-gray-600">Total Students</p>
                            <p class="text-3xl font-bold text-gray-800"><?php echo number_format($total_students); ?></p>
                        </div>
                        <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-users text-blue-600 text-xl"></i>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white p-6 rounded-xl shadow border-l-4 border-green-500">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-gray-600">Current Campus</p>
                            <p class="text-xl font-bold text-gray-800 truncate"><?php echo htmlspecialchars($selected_campus_name); ?></p>
                        </div>
                        <div class="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-school text-green-600 text-xl"></i>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white p-6 rounded-xl shadow border-l-4 border-purple-500">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-gray-600">With QR Codes</p>
                            <p class="text-3xl font-bold text-gray-800"><?php echo number_format($total_students); ?></p>
                        </div>
                        <div class="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-qrcode text-purple-600 text-xl"></i>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white p-6 rounded-xl shadow border-l-4 border-red-500">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-gray-600">Active Status</p>
                            <p class="text-3xl font-bold text-gray-800">100%</p>
                        </div>
                        <div class="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-check-circle text-red-600 text-xl"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Campus Cards (for admin) -->
        <?php if ($user_type === 'admin'): ?>
        <div class="mb-8">
            <h2 class="text-xl font-bold text-gray-800 mb-4">Browse by Campus</h2>
            <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-7 gap-3">
                <a href="students.php" 
                   class="campus-card p-4 bg-white rounded-lg shadow border border-gray-200 text-center hover:shadow-md transition-all <?php echo !$selected_campus ? 'active' : ''; ?>">
                    <div class="w-10 h-10 bg-gradient-to-r from-purple-500 to-indigo-500 rounded-full flex items-center justify-center mx-auto mb-2">
                        <i class="fas fa-globe text-white"></i>
                    </div>
                    <div class="font-semibold text-gray-800">All Campuses</div>
                    <div class="text-sm text-gray-600 mt-1"><?php echo $total_students; ?> students</div>
                </a>
                
                <?php foreach ($campus_counts as $campus): ?>
                <a href="students.php?campus=<?php echo $campus['campus_id']; ?>" 
                   class="campus-card p-4 bg-white rounded-lg shadow border border-gray-200 text-center hover:shadow-md transition-all <?php echo $selected_campus == $campus['campus_id'] ? 'active' : ''; ?>">
                    <?php 
                    $campus_icons = [
                        'ACCESS' => 'fas fa-university',
                        'Isulan' => 'fas fa-school',
                        'Tacurong' => 'fas fa-building',
                        'Lutayan' => 'fas fa-landmark',
                        'Bagumbayan' => 'fas fa-archway',
                        'Palimbang' => 'fas fa-city',
                        'Kalamansig' => 'fas fa-place-of-worship'
                    ];
                    $icon = $campus_icons[$campus['campus_name']] ?? 'fas fa-school';
                    ?>
                    <div class="w-10 h-10 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center mx-auto mb-2">
                        <i class="<?php echo $icon; ?> text-white"></i>
                    </div>
                    <div class="font-semibold text-gray-800 truncate"><?php echo htmlspecialchars($campus['campus_name']); ?></div>
                    <div class="text-sm text-gray-600 mt-1"><?php echo $campus['student_count']; ?> students</div>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Students Table -->
        <div class="bg-white rounded-xl shadow-lg overflow-hidden">
            <div class="p-6 border-b">
                <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                        <h2 class="text-xl font-bold text-gray-800">Student List</h2>
                        <p class="text-gray-600">Showing <?php echo $total_students; ?> students</p>
                    </div>
                    <div class="flex flex-wrap gap-3">
                        <div class="relative">
                            <input type="text" 
                                   id="searchInput" 
                                   placeholder="Search students..." 
                                   class="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                                   onkeyup="searchStudents()">
                            <i class="fas fa-search absolute left-3 top-3 text-gray-400"></i>
                        </div>
                        <button onclick="printStudentList()" 
                                class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2">
                            <i class="fas fa-print"></i>
                            <span>Print List</span>
                        </button>
                        <a href="export_students.php?campus=<?php echo $selected_campus; ?>" 
                           class="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors flex items-center space-x-2">
                            <i class="fas fa-file-export"></i>
                            <span>Export CSV</span>
                        </a>
                    </div>
                </div>
            </div>
            
            <?php if ($total_students > 0): ?>
            <div class="overflow-x-auto">
                <table id="studentsTable" class="w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-600">Student ID</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-600">Photo</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-600">Name</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-600">Campus</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-600">Course/Year</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-600">Contact</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-600">Status</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-600">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php while ($student = $result->fetch_assoc()): ?>
                        <tr class="hover:bg-gray-50 transition-colors">
                            <td class="py-4 px-4">
                                <div class="font-mono font-bold">
                                    <span class="text-blue-600"><?php echo htmlspecialchars($student['student_number']); ?></span>
                                </div>
                                <div class="text-xs text-gray-500">ID: <?php echo $student['student_id']; ?></div>
                            </td>
                            <td class="py-4 px-4">
                                <div class="w-12 h-12 rounded-full overflow-hidden bg-gray-100 border-2 border-white shadow">
                                    <?php if ($student['photo'] && file_exists($student['photo'])): ?>
                                    <img src="<?php echo $student['photo']; ?>" 
                                         alt="<?php echo htmlspecialchars($student['full_name']); ?>" 
                                         class="w-full h-full object-cover">
                                    <?php else: ?>
                                    <div class="w-full h-full flex items-center justify-center text-gray-400">
                                        <i class="fas fa-user text-xl"></i>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td class="py-4 px-4">
                                <div class="font-semibold text-gray-800"><?php echo htmlspecialchars($student['full_name']); ?></div>
                                <div class="text-sm text-gray-600"><?php echo htmlspecialchars($student['email']); ?></div>
                            </td>
                            <td class="py-4 px-4">
                                <span class="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-semibold">
                                    <?php echo htmlspecialchars($student['campus_name']); ?>
                                </span>
                            </td>
                            <td class="py-4 px-4">
                                <div class="text-gray-800 font-medium"><?php echo htmlspecialchars($student['course_year']); ?></div>
                                <div class="text-sm text-gray-600">Section <?php echo htmlspecialchars($student['section']); ?></div>
                            </td>
                            <td class="py-4 px-4">
                                <div class="text-gray-800">
                                    <i class="fas fa-phone-alt mr-2 text-gray-400"></i>
                                    <?php echo htmlspecialchars($student['phone']); ?>
                                </div>
                                <div class="text-sm text-gray-600">
                                    <i class="fas fa-envelope mr-2 text-gray-400"></i>
                                    <?php echo htmlspecialchars($student['email']); ?>
                                </div>
                            </td>
                            <td class="py-4 px-4">
                                <span class="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-semibold inline-flex items-center">
                                    <i class="fas fa-check-circle mr-1"></i> Active
                                </span>
                            </td>
                            <td class="py-4 px-4">
                                <div class="flex space-x-2">
                                    <a href="student_profile.php?id=<?php echo $student['student_id']; ?>" 
                                       class="w-8 h-8 bg-blue-100 text-blue-800 hover:bg-blue-200 rounded-full flex items-center justify-center transition-colors"
                                       title="View Profile">
                                        <i class="fas fa-eye text-sm"></i>
                                    </a>
                                    <a href="student_profile.php?id=<?php echo $student['student_id']; ?>&print=1" 
                                       class="w-8 h-8 bg-purple-100 text-purple-800 hover:bg-purple-200 rounded-full flex items-center justify-center transition-colors"
                                       title="Print QR Code">
                                        <i class="fas fa-qrcode text-sm"></i>
                                    </a>
                                    <?php if ($user_type === 'admin'): ?>
                                    <a href="edit_student.php?id=<?php echo $student['student_id']; ?>" 
                                       class="w-8 h-8 bg-yellow-100 text-yellow-800 hover:bg-yellow-200 rounded-full flex items-center justify-center transition-colors"
                                       title="Edit Student">
                                        <i class="fas fa-edit text-sm"></i>
                                    </a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="p-12 text-center">
                <i class="fas fa-users text-4xl text-gray-300 mb-4"></i>
                <h3 class="text-xl font-semibold text-gray-700 mb-2">No Students Found</h3>
                <p class="text-gray-600 mb-6">
                    <?php 
                    if ($selected_campus) {
                        echo "No students found for " . $selected_campus_name;
                    } else {
                        echo "No students found in the system.";
                    }
                    ?>
                </p>
                <a href="add_student.php.php" class="px-4 py-2 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-lg hover:from-green-700 hover:to-emerald-700 transition-all shadow inline-flex items-center space-x-2">
                    <i class="fas fa-user-plus"></i>
                    <span>Add First Student</span>
                </a>
            </div>
            <?php endif; ?>
        </div>

        <!-- Footer Stats -->
        <div class="mt-8 bg-white rounded-xl shadow-lg p-6">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div class="text-center">
                    <div class="text-sm text-gray-600 mb-2">Current View</div>
                    <div class="text-2xl font-bold text-gray-800"><?php echo $selected_campus_name; ?></div>
                </div>
                <div class="text-center">
                    <div class="text-sm text-gray-600 mb-2">Students Displayed</div>
                    <div class="text-2xl font-bold text-gray-800"><?php echo number_format($total_students); ?></div>
                </div>
                <div class="text-center">
                    <div class="text-sm text-gray-600 mb-2">Last Updated</div>
                    <div class="text-xl font-semibold text-gray-800"><?php echo date('M j, Y h:i A'); ?></div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Initialize DataTable
        $(document).ready(function() {
            $('#studentsTable').DataTable({
                "pageLength": 25,
                "order": [[2, 'asc']], // Sort by name
                "language": {
                    "search": "Search within list:",
                    "lengthMenu": "Show _MENU_ students",
                    "info": "Showing _START_ to _END_ of _TOTAL_ students",
                    "paginate": {
                        "first": "First",
                        "last": "Last",
                        "next": "Next",
                        "previous": "Previous"
                    }
                },
                "dom": '<"flex justify-between items-center mb-4"lf>rt<"flex justify-between items-center mt-4"ip>'
            });
        });
        
        // Toggle filter dropdown
        function toggleFilter() {
            const dropdown = document.getElementById('filterDropdown');
            dropdown.classList.toggle('hidden');
        }
        
        // Close filter dropdown when clicking outside
        document.addEventListener('click', function(event) {
            const filterContainer = document.getElementById('filterContainer');
            const dropdown = document.getElementById('filterDropdown');
            
            if (filterContainer && !filterContainer.contains(event.target)) {
                dropdown.classList.add('hidden');
            }
        });
        
        function printStudentList() {
            const campusParam = <?php echo $selected_campus ? "'&campus=" . $selected_campus . "'" : "''"; ?>;
            window.open('print_students.php?filter=' + campusParam, '_blank');
        }
        
        // Simple search functionality
        function searchStudents() {
            const search = document.getElementById('searchInput').value.toLowerCase();
            const table = $('#studentsTable').DataTable();
            table.search(search).draw();
        }
        
        // Add active class to clicked campus card
        document.querySelectorAll('.campus-card').forEach(card => {
            card.addEventListener('click', function() {
                document.querySelectorAll('.campus-card').forEach(c => {
                    c.classList.remove('active');
                });
                this.classList.add('active');
            });
        });
        
        // Export function
        function exportToExcel() {
            alert('Export feature would generate Excel file here');
            // In real implementation, this would trigger server-side export
        }
    </script>
</body>
</html>