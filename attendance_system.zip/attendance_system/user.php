<?php
session_start();
require_once 'db.php';

// Check authentication
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: login.php');
    exit();
}

$user_name = $_SESSION['full_name'];

// Handle actions (delete, activate, deactivate)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['delete_user'])) {
        $user_id = intval($_POST['user_id']);
        
        // Don't allow deleting yourself
        if ($user_id != $_SESSION['user_id']) {
            $stmt = $conn->prepare("DELETE FROM users WHERE user_id = ?");
            $stmt->bind_param("i", $user_id);
            if ($stmt->execute()) {
                $success = "User deleted successfully!";
            } else {
                $error = "Failed to delete user.";
            }
        } else {
            $error = "You cannot delete your own account!";
        }
    } elseif (isset($_POST['toggle_status'])) {
        $user_id = intval($_POST['user_id']);
        $current_status = $_POST['current_status'];
        $new_status = $current_status === 'active' ? 'inactive' : 'active';
        
        // Don't allow deactivating yourself
        if ($user_id != $_SESSION['user_id'] || $new_status === 'active') {
            $stmt = $conn->prepare("UPDATE users SET status = ? WHERE user_id = ?");
            $stmt->bind_param("si", $new_status, $user_id);
            if ($stmt->execute()) {
                $success = "User status updated to " . $new_status . "!";
            } else {
                $error = "Failed to update user status.";
            }
        } else {
            $error = "You cannot deactivate your own account!";
        }
    }
}

// Search and filter parameters
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$user_type = isset($_GET['user_type']) ? $_GET['user_type'] : '';
$status = isset($_GET['status']) ? $_GET['status'] : '';

// Build query
$query = "SELECT u.*, c.campus_name 
          FROM users u 
          LEFT JOIN campuses c ON u.campus_id = c.campus_id 
          WHERE 1=1";

$params = [];
$types = '';

if (!empty($search)) {
    $query .= " AND (u.full_name LIKE ? OR u.username LIKE ? OR u.email LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $types .= "sss";
}

if (!empty($user_type) && in_array($user_type, ['admin', 'coordinator'])) {
    $query .= " AND u.user_type = ?";
    $params[] = $user_type;
    $types .= "s";
}

if (!empty($status) && in_array($status, ['active', 'inactive'])) {
    $query .= " AND u.status = ?";
    $params[] = $status;
    $types .= "s";
}

$query .= " ORDER BY u.user_type, u.full_name";

// Prepare and execute query
$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

// Get user counts for stats
$stats = $conn->query("
    SELECT 
        COUNT(*) as total_users,
        SUM(CASE WHEN user_type = 'admin' THEN 1 ELSE 0 END) as admin_count,
        SUM(CASE WHEN user_type = 'coordinator' THEN 1 ELSE 0 END) as coordinator_count,
        SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_count,
        SUM(CASE WHEN status = 'inactive' THEN 1 ELSE 0 END) as inactive_count
    FROM users
")->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users | Multi-Campus Attendance</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .user-card {
            transition: all 0.3s ease;
        }
        .user-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }
        .status-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        .role-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
    <!-- Navigation -->
    <nav class="bg-gradient-to-r from-purple-800 to-indigo-900 text-white shadow-lg">
        <div class="container mx-auto px-4 py-3">
            <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div class="flex items-center space-x-4">
                    <a href="admin_dashboard.php" 
                       class="flex items-center hover:text-purple-200 transition-colors">
                        <i class="fas fa-arrow-left mr-2"></i> Back to Dashboard
                    </a>
                    <div class="flex items-center space-x-4">
                        <h1 class="text-xl font-bold">
                            <i class="fas fa-users mr-2"></i> Manage Users
                        </h1>
                        <span class="text-xs bg-white/20 px-2 py-1 rounded-full">Admin Panel</span>
                    </div>
                </div>
                <div class="flex items-center space-x-4">
                    <span class="text-sm">
                        <i class="fas fa-user-shield mr-1"></i> <?php echo htmlspecialchars($user_name); ?>
                    </span>
                    <span class="text-sm text-purple-300">|</span>
                    <a href="logout.php" class="text-sm hover:text-purple-200 transition-colors">
                        <i class="fas fa-sign-out-alt mr-1"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-8">
        <div class="max-w-7xl mx-auto">
            <!-- Header -->
            <div class="mb-8">
                <h1 class="text-4xl font-bold text-gray-800 mb-3">User Management</h1>
                <p class="text-gray-600">Manage administrators and campus coordinators in the system</p>
            </div>

            <?php if (isset($success)): ?>
                <div class="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-center text-green-700">
                    <i class="fas fa-check-circle mr-3"></i>
                    <span><?php echo htmlspecialchars($success); ?></span>
                </div>
            <?php endif; ?>

            <?php if (isset($error)): ?>
                <div class="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center text-red-700">
                    <i class="fas fa-exclamation-circle mr-3"></i>
                    <span><?php echo htmlspecialchars($error); ?></span>
                </div>
            <?php endif; ?>

            <!-- Statistics Cards -->
            <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                <div class="bg-white rounded-xl shadow-lg p-6">
                    <div class="flex items-center">
                        <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mr-4">
                            <i class="fas fa-users text-blue-600 text-xl"></i>
                        </div>
                        <div>
                            <p class="text-sm text-gray-600">Total Users</p>
                            <p class="text-2xl font-bold text-gray-800"><?php echo $stats['total_users']; ?></p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-xl shadow-lg p-6">
                    <div class="flex items-center">
                        <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mr-4">
                            <i class="fas fa-user-shield text-purple-600 text-xl"></i>
                        </div>
                        <div>
                            <p class="text-sm text-gray-600">Administrators</p>
                            <p class="text-2xl font-bold text-gray-800"><?php echo $stats['admin_count']; ?></p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-xl shadow-lg p-6">
                    <div class="flex items-center">
                        <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mr-4">
                            <i class="fas fa-user-tie text-green-600 text-xl"></i>
                        </div>
                        <div>
                            <p class="text-sm text-gray-600">Coordinators</p>
                            <p class="text-2xl font-bold text-gray-800"><?php echo $stats['coordinator_count']; ?></p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-xl shadow-lg p-6">
                    <div class="flex items-center">
                        <div class="w-12 h-12 bg-<?php echo $stats['inactive_count'] > 0 ? 'yellow' : 'green'; ?>-100 rounded-lg flex items-center justify-center mr-4">
                            <i class="fas fa-user-check text-<?php echo $stats['inactive_count'] > 0 ? 'yellow' : 'green'; ?>-600 text-xl"></i>
                        </div>
                        <div>
                            <p class="text-sm text-gray-600">Active Users</p>
                            <p class="text-2xl font-bold text-gray-800"><?php echo $stats['active_count']; ?> / <?php echo $stats['total_users']; ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Action Bar -->
            <div class="bg-white rounded-xl shadow-lg p-6 mb-8">
                <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                        <h2 class="text-xl font-bold text-gray-800">All Users</h2>
                        <p class="text-gray-600 text-sm">Showing <?php echo $result->num_rows; ?> user(s)</p>
                    </div>
                    
                    <div class="flex flex-col md:flex-row gap-4">
                        <a href="add_user.php" class="bg-gradient-to-r from-green-500 to-emerald-600 text-white px-5 py-2.5 rounded-lg font-semibold hover:from-green-600 hover:to-emerald-700 transition-colors flex items-center justify-center">
                            <i class="fas fa-user-plus mr-2"></i> Add New User
                        </a>
                    </div>
                </div>
                
                <!-- Search and Filter -->
                <form method="GET" action="" class="mt-6">
                    <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <!-- Search -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Search</label>
                            <div class="relative">
                                <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>"
                                       class="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                                       placeholder="Name, username, email...">
                                <i class="fas fa-search absolute left-3 top-3 text-gray-400"></i>
                            </div>
                        </div>
                        
                        <!-- User Type Filter -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">User Type</label>
                            <select name="user_type" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500">
                                <option value="">All Types</option>
                                <option value="admin" <?php echo $user_type === 'admin' ? 'selected' : ''; ?>>Administrator</option>
                                <option value="coordinator" <?php echo $user_type === 'coordinator' ? 'selected' : ''; ?>>Coordinator</option>
                            </select>
                        </div>
                        
                        <!-- Status Filter -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Status</label>
                            <select name="status" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500">
                                <option value="">All Status</option>
                                <option value="active" <?php echo $status === 'active' ? 'selected' : ''; ?>>Active</option>
                                <option value="inactive" <?php echo $status === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                            </select>
                        </div>
                        
                        <!-- Actions -->
                        <div class="flex items-end">
                            <button type="submit" class="w-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-5 py-2.5 rounded-lg font-semibold hover:from-purple-700 hover:to-indigo-700 transition-colors">
                                <i class="fas fa-filter mr-2"></i> Apply Filters
                            </button>
                            <?php if ($search || $user_type || $status): ?>
                            <a href="users.php" class="ml-2 px-4 py-2.5 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
                                <i class="fas fa-times"></i>
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Users Table -->
            <div class="bg-white rounded-xl shadow-lg overflow-hidden">
                <?php if ($result->num_rows > 0): ?>
                    <div class="overflow-x-auto">
                        <table class="w-full">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Role</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Campus</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Contact</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Last Login</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php while ($user = $result->fetch_assoc()): ?>
                                <tr class="hover:bg-gray-50 transition-colors">
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="flex items-center">
                                            <div class="flex-shrink-0 h-10 w-10 bg-<?php echo $user['user_type'] === 'admin' ? 'purple' : 'blue'; ?>-100 rounded-lg flex items-center justify-center">
                                                <i class="fas fa-<?php echo $user['user_type'] === 'admin' ? 'user-shield' : 'user-tie'; ?> text-<?php echo $user['user_type'] === 'admin' ? 'purple' : 'blue'; ?>-600"></i>
                                            </div>
                                            <div class="ml-4">
                                                <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($user['full_name']); ?></div>
                                                <div class="text-sm text-gray-500">@<?php echo htmlspecialchars($user['username']); ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <span class="role-badge <?php echo $user['user_type'] === 'admin' ? 'bg-purple-100 text-purple-800' : 'bg-blue-100 text-blue-800'; ?>">
                                            <?php echo ucfirst($user['user_type']); ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-900"><?php echo $user['campus_name'] ? htmlspecialchars($user['campus_name']) : '<span class="text-gray-400">-</span>'; ?></div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-900"><?php echo htmlspecialchars($user['email']); ?></div>
                                        <div class="text-sm text-gray-500"><?php echo $user['phone'] ? htmlspecialchars($user['phone']) : '<span class="text-gray-400">No phone</span>'; ?></div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <span class="status-badge <?php echo $user['status'] === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                                            <?php echo ucfirst($user['status']); ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        <?php 
                                        if ($user['last_login']) {
                                            $date = new DateTime($user['last_login']);
                                            echo $date->format('M d, Y H:i');
                                        } else {
                                            echo '<span class="text-gray-400">Never</span>';
                                        }
                                        ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                        <div class="flex space-x-2">
                                            <a href="edit_user.php?id=<?php echo $user['user_id']; ?>" 
                                               class="text-blue-600 hover:text-blue-900 transition-colors"
                                               title="Edit User">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            
                                            <form method="POST" action="" class="inline" onsubmit="return confirm('Are you sure you want to <?php echo $user['status'] === 'active' ? 'deactivate' : 'activate'; ?> this user?');">
                                                <input type="hidden" name="user_id" value="<?php echo $user['user_id']; ?>">
                                                <input type="hidden" name="current_status" value="<?php echo $user['status']; ?>">
                                                <button type="submit" name="toggle_status" 
                                                        class="<?php echo $user['status'] === 'active' ? 'text-yellow-600 hover:text-yellow-900' : 'text-green-600 hover:text-green-900'; ?> transition-colors"
                                                        title="<?php echo $user['status'] === 'active' ? 'Deactivate User' : 'Activate User'; ?>"
                                                        <?php echo ($user['user_id'] == $_SESSION['user_id'] && $user['status'] === 'active') ? 'disabled' : ''; ?>>
                                                    <i class="fas fa-<?php echo $user['status'] === 'active' ? 'user-slash' : 'user-check'; ?>"></i>
                                                </button>
                                            </form>
                                            
                                            <form method="POST" action="" class="inline" onsubmit="return confirm('Are you sure you want to delete this user? This action cannot be undone!');">
                                                <input type="hidden" name="user_id" value="<?php echo $user['user_id']; ?>">
                                                <button type="submit" name="delete_user" 
                                                        class="text-red-600 hover:text-red-900 transition-colors <?php echo $user['user_id'] == $_SESSION['user_id'] ? 'opacity-50 cursor-not-allowed' : ''; ?>"
                                                        title="Delete User"
                                                        <?php echo $user['user_id'] == $_SESSION['user_id'] ? 'disabled' : ''; ?>>
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Table Footer -->
                    <div class="px-6 py-4 border-t border-gray-200">
                        <div class="flex flex-col md:flex-row md:items-center justify-between">
                            <div class="text-sm text-gray-500">
                                Showing <span class="font-medium"><?php echo $result->num_rows; ?></span> user(s)
                            </div>
                            <div class="mt-4 md:mt-0">
                                <a href="users.php?export=csv" 
                                   class="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-lg text-gray-700 bg-white hover:bg-gray-50 transition-colors">
                                    <i class="fas fa-download mr-2"></i> Export as CSV
                                </a>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <!-- No Users Found -->
                    <div class="text-center py-12">
                        <div class="mx-auto w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mb-6">
                            <i class="fas fa-users text-gray-400 text-3xl"></i>
                        </div>
                        <h3 class="text-xl font-semibold text-gray-700 mb-2">No Users Found</h3>
                        <p class="text-gray-500 mb-6 max-w-md mx-auto">
                            <?php echo ($search || $user_type || $status) ? 'Try adjusting your filters or search term.' : 'No users have been registered yet.'; ?>
                        </p>
                        <?php if ($search || $user_type || $status): ?>
                            <a href="users.php" class="inline-flex items-center px-5 py-2.5 bg-purple-600 text-white rounded-lg font-semibold hover:bg-purple-700 transition-colors">
                                <i class="fas fa-times mr-2"></i> Clear Filters
                            </a>
                        <?php else: ?>
                            <a href="add_user.php" class="inline-flex items-center px-5 py-2.5 bg-gradient-to-r from-green-500 to-emerald-600 text-white rounded-lg font-semibold hover:from-green-600 hover:to-emerald-700 transition-colors">
                                <i class="fas fa-user-plus mr-2"></i> Add First User
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Quick Actions -->
            <div class="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="bg-gradient-to-r from-blue-50 to-cyan-50 p-6 rounded-2xl border border-blue-200">
                    <h3 class="text-lg font-semibold text-blue-800 mb-3 flex items-center">
                        <i class="fas fa-user-shield mr-2"></i> Administrator Guidelines
                    </h3>
                    <ul class="text-sm text-blue-700 space-y-2">
                        <li class="flex items-start">
                            <i class="fas fa-check-circle text-green-500 mt-0.5 mr-2"></i>
                            <span>Admins have full system access</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check-circle text-green-500 mt-0.5 mr-2"></i>
                            <span>Can manage all campuses and users</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check-circle text-green-500 mt-0.5 mr-2"></i>
                            <span>No campus assignment needed</span>
                        </li>
                    </ul>
                </div>
                
                <div class="bg-gradient-to-r from-green-50 to-emerald-50 p-6 rounded-2xl border border-green-200">
                    <h3 class="text-lg font-semibold text-green-800 mb-3 flex items-center">
                        <i class="fas fa-user-tie mr-2"></i> Coordinator Guidelines
                    </h3>
                    <ul class="text-sm text-green-700 space-y-2">
                        <li class="flex items-start">
                            <i class="fas fa-check-circle text-green-500 mt-0.5 mr-2"></i>
                            <span>Manages only assigned campus</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check-circle text-green-500 mt-0.5 mr-2"></i>
                            <span>Can add and manage students</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check-circle text-green-500 mt-0.5 mr-2"></i>
                            <span>Must be assigned to a campus</span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Confirm delete
        document.querySelectorAll('form[onsubmit*="delete"]').forEach(form => {
            form.onsubmit = function(e) {
                if (!confirm('Are you sure you want to delete this user? This action cannot be undone!')) {
                    e.preventDefault();
                    return false;
                }
            };
        });

        // Confirm status toggle
        document.querySelectorAll('form[onsubmit*="activate"]').forEach(form => {
            form.onsubmit = function(e) {
                const button = this.querySelector('button[name="toggle_status"]');
                const action = button.title.toLowerCase();
                if (!confirm('Are you sure you want to ' + action + ' this user?')) {
                    e.preventDefault();
                    return false;
                }
            };
        });

        // Auto-submit form on filter change (optional)
        document.querySelectorAll('select[name="user_type"], select[name="status"]').forEach(select => {
            select.addEventListener('change', function() {
                if (this.value) {
                    this.form.submit();
                }
            });
        });
    </script>
</body>
</html>