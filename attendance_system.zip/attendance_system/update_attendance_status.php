<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_type']) || !in_array($_SESSION['user_type'], ['admin','coordinator'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['attendance_id']) || !isset($input['status'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid input']);
    exit();
}

$attendance_id = intval($input['attendance_id']);
$status = $input['status'];
$updated_by = $_SESSION['user_id'];
$updated_at = date('Y-m-d H:i:s');

// Validate status
$valid_statuses = ['Present', 'Late', 'Absent', 'Excused'];
if (!in_array($status, $valid_statuses)) {
    echo json_encode(['success' => false, 'message' => 'Invalid status']);
    exit();
}

$query = "UPDATE attendance SET status = ?, updated_at = ? WHERE attendance_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("ssi", $status, $updated_at, $attendance_id);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Status updated successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
}

$conn->close();
?>