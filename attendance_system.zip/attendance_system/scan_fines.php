<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['full_name'] ?? 'Unknown User';
$user_type = $_SESSION['user_type'] ?? 'admin';

// Get user's campus info
$user_query = "SELECT u.*, c.campus_name 
               FROM users u 
               LEFT JOIN campuses c ON u.campus_id = c.campus_id 
               WHERE u.user_id = ?";
$user_stmt = $conn->prepare($user_query);
$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();
$user_result = $user_stmt->get_result();
$user_data = $user_result->fetch_assoc();

$user_campus_id = $user_data['campus_id'] ?? null;
$user_campus_name = $user_data['campus_name'] ?? 'System Admin';

// Get all campuses for selection (if admin) or just user's campus
$campuses = [];
if ($user_campus_id === null) {
    // Admin can see all campuses
    $campus_query = "SELECT * FROM campuses WHERE status = 'active' ORDER BY campus_name";
    $campus_result = $conn->query($campus_query);
    while ($campus = $campus_result->fetch_assoc()) {
        $campuses[] = $campus;
    }
} else {
    // Regular user can only see their campus
    $campuses[] = [
        'campus_id' => $user_campus_id,
        'campus_name' => $user_campus_name
    ];
}

// Handle campus selection
$selected_campus = isset($_GET['campus']) ? intval($_GET['campus']) : ($user_campus_id ?? 1);
$view_mode = $_GET['view'] ?? 'scan'; // 'scan', 'pending', 'paid', 'all'

// Validate campus access
$has_access = false;
foreach ($campuses as $campus) {
    if ($campus['campus_id'] == $selected_campus) {
        $has_access = true;
        $selected_campus_name = $campus['campus_name'];
        break;
    }
}

if (!$has_access) {
    die("Access denied: You don't have permission to access this campus.");
}

// Handle fine payment submission
$success_message = '';
$error_message = '';
$scanned_student = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        
        if ($action === 'pay_fine') {
            $fine_id = intval($_POST['fine_id']);
            $amount_paid = floatval($_POST['amount_paid']);
            $payment_method = $_POST['payment_method'] ?? 'cash';
            $reference_no = $_POST['reference_no'] ?? '';
            
            // Get fine details
            $fine_query = "SELECT f.*, s.student_number, s.full_name 
                          FROM fines f 
                          JOIN students s ON f.student_id = s.student_id 
                          WHERE f.fine_id = ?";
            $fine_stmt = $conn->prepare($fine_query);
            $fine_stmt->bind_param("i", $fine_id);
            $fine_stmt->execute();
            $fine_result = $fine_stmt->get_result();
            $fine = $fine_result->fetch_assoc();
            
            if ($fine) {
                if ($amount_paid <= 0) {
                    $error_message = "Payment amount must be greater than 0!";
                } elseif ($amount_paid > $fine['amount']) {
                    $error_message = "Payment amount cannot exceed fine amount!";
                } else {
                    // Start transaction
                    $conn->begin_transaction();
                    
                    try {
                        // Insert payment record
                        $payment_query = "INSERT INTO fine_payments 
                                         (fine_id, amount_paid, payment_date, payment_method, reference_no, received_by) 
                                         VALUES (?, ?, CURDATE(), ?, ?, ?)";
                        $payment_stmt = $conn->prepare($payment_query);
                        $payment_stmt->bind_param("idssi", $fine_id, $amount_paid, $payment_method, $reference_no, $user_id);
                        $payment_stmt->execute();
                        
                        // Calculate total paid amount
                        $total_paid_query = "SELECT SUM(amount_paid) as total_paid FROM fine_payments WHERE fine_id = ?";
                        $total_paid_stmt = $conn->prepare($total_paid_query);
                        $total_paid_stmt->bind_param("i", $fine_id);
                        $total_paid_stmt->execute();
                        $total_paid_result = $total_paid_stmt->get_result();
                        $total_paid_row = $total_paid_result->fetch_assoc();
                        $total_paid = $total_paid_row['total_paid'] ?? 0;
                        
                        // Update fine status
                        if ($total_paid >= $fine['amount']) {
                            $status = 'paid';
                        } elseif ($total_paid > 0) {
                            $status = 'partial';
                        } else {
                            $status = 'pending';
                        }
                        
                        $update_query = "UPDATE fines SET status = ? WHERE fine_id = ?";
                        $update_stmt = $conn->prepare($update_query);
                        $update_stmt->bind_param("si", $status, $fine_id);
                        $update_stmt->execute();
                        
                        // Log the payment
                        $log_query = "INSERT INTO scan_logs 
                                     (student_code, student_id, scan_type, action, user_id, user_type) 
                                     VALUES (?, ?, 'fines', ?, ?, ?)";
                        $log_stmt = $conn->prepare($log_query);
                        $log_action = 'payment_received';
                        $log_stmt->bind_param("sissi", 
                            $fine['student_number'],
                            $fine['student_id'],
                            $log_action,
                            $user_id,
                            $user_type
                        );
                        $log_stmt->execute();
                        
                        $conn->commit();
                        
                        $success_message = "Payment of ₱" . number_format($amount_paid, 2) . " recorded successfully!";
                        $scanned_student = [
                            'student_number' => $fine['student_number'],
                            'full_name' => $fine['full_name']
                        ];
                        
                    } catch (Exception $e) {
                        $conn->rollback();
                        $error_message = "Failed to record payment: " . $e->getMessage();
                    }
                }
            } else {
                $error_message = "Fine not found!";
            }
            
        } elseif ($action === 'scan_student') {
            $student_number = $_POST['student_number'] ?? '';
            
            if (!empty($student_number)) {
                // Get student details with pending fines
                $student_query = "SELECT s.*, 
                                 (SELECT SUM(f.amount) FROM fines f WHERE f.student_id = s.student_id AND f.status IN ('pending', 'partial')) as total_pending_fines,
                                 (SELECT COUNT(f.fine_id) FROM fines f WHERE f.student_id = s.student_id AND f.status IN ('pending', 'partial')) as pending_fines_count
                                 FROM students s 
                                 WHERE s.student_number = ? AND s.campus_id = ? AND s.status = 'active'";
                $student_stmt = $conn->prepare($student_query);
                $student_stmt->bind_param("si", $student_number, $selected_campus);
                $student_stmt->execute();
                $student_result = $student_stmt->get_result();
                
                if ($student_result->num_rows === 1) {
                    $scanned_student = $student_result->fetch_assoc();
                    
                    // Log the scan
                    $log_query = "INSERT INTO scan_logs 
                                 (student_code, student_id, scan_type, action, user_id, user_type) 
                                 VALUES (?, ?, 'fines', 'student_scanned', ?, ?)";
                    $log_stmt = $conn->prepare($log_query);
                    $log_stmt->bind_param("sisi", 
                        $scanned_student['student_number'],
                        $scanned_student['student_id'],
                        $user_id,
                        $user_type
                    );
                    $log_stmt->execute();
                    
                } else {
                    $error_message = "Student not found or not from this campus!";
                }
            } else {
                $error_message = "Please enter a student number!";
            }
        } elseif ($action === 'add_fine') {
            $student_id = intval($_POST['student_id']);
            $activity_id = intval($_POST['activity_id']) ?: null;
            $amount = floatval($_POST['amount']);
            $reason = $_POST['reason'] ?? 'absence';
            $description = $_POST['description'] ?? '';
            
            // Validate student belongs to campus
            $check_query = "SELECT campus_id FROM students WHERE student_id = ?";
            $check_stmt = $conn->prepare($check_query);
            $check_stmt->bind_param("i", $student_id);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            $student = $check_result->fetch_assoc();
            
            if ($student && $student['campus_id'] == $selected_campus) {
                $insert_query = "INSERT INTO fines 
                                (student_id, activity_id, amount, reason, description, status, created_by) 
                                VALUES (?, ?, ?, ?, ?, 'pending', ?)";
                $insert_stmt = $conn->prepare($insert_query);
                $insert_stmt->bind_param("iidssi", $student_id, $activity_id, $amount, $reason, $description, $user_id);
                
                if ($insert_stmt->execute()) {
                    $success_message = "Fine added successfully!";
                    
                    // Get student info for display
                    $student_info_query = "SELECT student_number, full_name FROM students WHERE student_id = ?";
                    $student_info_stmt = $conn->prepare($student_info_query);
                    $student_info_stmt->bind_param("i", $student_id);
                    $student_info_stmt->execute();
                    $student_info_result = $student_info_stmt->get_result();
                    $scanned_student = $student_info_result->fetch_assoc();
                } else {
                    $error_message = "Failed to add fine. Please try again.";
                }
            } else {
                $error_message = "Student not found or not from this campus!";
            }
        }
    }
}

// Get fines statistics
$stats = [
    'total_fines' => 0,
    'total_amount' => 0,
    'pending_fines' => 0,
    'pending_amount' => 0,
    'paid_fines' => 0,
    'paid_amount' => 0
];

if ($selected_campus) {
    // Total fines - FIXED: Specify table for status column
    $stats_query = "SELECT 
                    COUNT(*) as total_fines,
                    COALESCE(SUM(f.amount), 0) as total_amount,
                    COALESCE(SUM(CASE WHEN f.status IN ('pending', 'partial') THEN 1 ELSE 0 END), 0) as pending_fines,
                    COALESCE(SUM(CASE WHEN f.status IN ('pending', 'partial') THEN f.amount ELSE 0 END), 0) as pending_amount,
                    COALESCE(SUM(CASE WHEN f.status = 'paid' THEN 1 ELSE 0 END), 0) as paid_fines,
                    COALESCE(SUM(CASE WHEN f.status = 'paid' THEN f.amount ELSE 0 END), 0) as paid_amount
                    FROM fines f
                    JOIN students s ON f.student_id = s.student_id
                    WHERE s.campus_id = ?";
    
    $stats_stmt = $conn->prepare($stats_query);
    $stats_stmt->bind_param("i", $selected_campus);
    $stats_stmt->execute();
    $stats_result = $stats_stmt->get_result();
    $stats_row = $stats_result->fetch_assoc();
    
    if ($stats_row) {
        // Ensure all values are properly set
        $stats['total_fines'] = (int)($stats_row['total_fines'] ?? 0);
        $stats['total_amount'] = (float)($stats_row['total_amount'] ?? 0);
        $stats['pending_fines'] = (int)($stats_row['pending_fines'] ?? 0);
        $stats['pending_amount'] = (float)($stats_row['pending_amount'] ?? 0);
        $stats['paid_fines'] = (int)($stats_row['paid_fines'] ?? 0);
        $stats['paid_amount'] = (float)($stats_row['paid_amount'] ?? 0);
    }
}

// Get recent fines for the selected campus
$recent_fines = [];
$fines_query = "SELECT f.*, s.student_number, s.full_name, s.course_year, s.section,
                a.activity_name, c.campus_name,
                COALESCE((SELECT SUM(fp.amount_paid) FROM fine_payments fp WHERE fp.fine_id = f.fine_id), 0) as paid_amount
                FROM fines f
                JOIN students s ON f.student_id = s.student_id
                LEFT JOIN activities a ON f.activity_id = a.activity_id
                LEFT JOIN campuses c ON s.campus_id = c.campus_id
                WHERE s.campus_id = ? ";
                
// Add filter based on view mode - FIXED: Specify table for status column
switch ($view_mode) {
    case 'pending':
        $fines_query .= "AND f.status IN ('pending', 'partial') ";
        break;
    case 'paid':
        $fines_query .= "AND f.status = 'paid' ";
        break;
    case 'all':
        // Show all
        break;
    default:
        $fines_query .= "AND f.status IN ('pending', 'partial') ";
}

$fines_query .= "ORDER BY f.created_at DESC LIMIT 20";

$fines_stmt = $conn->prepare($fines_query);
$fines_stmt->bind_param("i", $selected_campus);
$fines_stmt->execute();
$fines_result = $fines_stmt->get_result();

while ($fine = $fines_result->fetch_assoc()) {
    $recent_fines[] = $fine;
}

// Get activities for manual fine creation
$activities = [];
$activity_query = "SELECT activity_id, activity_name, activity_date 
                   FROM activities 
                   WHERE (campus_id = ? OR campus_id IS NULL) 
                   AND status = 'active'
                   ORDER BY activity_date DESC";
$activity_stmt = $conn->prepare($activity_query);
$activity_stmt->bind_param("i", $selected_campus);
$activity_stmt->execute();
$activity_result = $activity_stmt->get_result();

while ($activity = $activity_result->fetch_assoc()) {
    $activities[] = $activity;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fines Management | <?php echo $selected_campus_name; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://unpkg.com/html5-qrcode"></script>
    <style>
        :root {
            --primary-color: #3b82f6;
            --secondary-color: #8b5cf6;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .card {
            background: white;
            border-radius: 1rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        
        .card:hover {
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
        }
        
        .campus-badge {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 0.25rem;
        }
        
        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        
        .status-pending { background-color: #fee2e2; color: #991b1b; }
        .status-partial { background-color: #fef3c7; color: #92400e; }
        .status-paid { background-color: #d1fae5; color: #065f46; }
        .status-cancelled { background-color: #e5e7eb; color: #374151; }
        
        .stat-card {
            background: linear-gradient(135deg, #f6f9fc 0%, #edf2f7 100%);
            border-radius: 0.75rem;
            padding: 1.5rem;
            text-align: center;
        }
        
        .stat-value {
            font-size: 2.5rem;
            font-weight: 700;
            line-height: 1;
        }
        
        .stat-label {
            color: #6b7280;
            font-size: 0.875rem;
            margin-top: 0.5rem;
        }
        
        .btn {
            padding: 0.75rem 1.5rem;
            border-radius: 0.75rem;
            font-weight: 600;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(59, 130, 246, 0.3);
        }
        
        .btn-success {
            background: var(--success-color);
            color: white;
        }
        
        .btn-danger {
            background: var(--danger-color);
            color: white;
        }
        
        .btn-warning {
            background: var(--warning-color);
            color: white;
        }
        
        .message {
            padding: 1rem;
            border-radius: 0.75rem;
            margin-bottom: 1rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        
        .message-success {
            background: #d1fae5;
            color: #065f46;
            border: 1px solid #a7f3d0;
        }
        
        .message-error {
            background: #fee2e2;
            color: #991b1b;
            border: 1px solid #fecaca;
        }
        
        .tab {
            padding: 0.75rem 1.5rem;
            border-radius: 0.75rem;
            font-weight: 600;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        
        .tab.active {
            background: var(--primary-color);
            color: white;
        }
        
        .tab:hover:not(.active) {
            background: #f3f4f6;
        }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }
        
        .modal.active {
            display: flex;
        }
        
        .modal-content {
            background: white;
            border-radius: 1rem;
            width: 90%;
            max-width: 500px;
            max-height: 90vh;
            overflow-y: auto;
        }
        
        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid #f3f3f3;
            border-top: 3px solid #3b82f6;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .fine-item {
            border-left: 4px solid transparent;
            transition: all 0.3s ease;
        }
        
        .fine-item.pending { border-left-color: #ef4444; }
        .fine-item.partial { border-left-color: #f59e0b; }
        .fine-item.paid { border-left-color: #10b981; }
        
        .fine-item:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body class="min-h-screen p-4 md:p-8">
    <!-- Header -->
    <div class="max-w-7xl mx-auto">
        <div class="card p-6 mb-8">
            <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h1 class="text-3xl font-bold text-gray-900 mb-2">
                        <i class="fas fa-money-bill-wave text-green-600 mr-2"></i>Fines Management
                    </h1>
                    <div class="flex flex-wrap items-center gap-2">
                        <span class="campus-badge">
                            <i class="fas fa-school"></i> <?php echo htmlspecialchars($selected_campus_name); ?>
                        </span>
                        <span class="px-3 py-1 bg-gray-100 text-gray-800 rounded-full text-sm font-medium">
                            <i class="fas fa-user mr-1"></i> <?php echo htmlspecialchars($user_name); ?>
                        </span>
                        <span class="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                            <i class="fas fa-shield-alt mr-1"></i> <?php echo ucfirst($user_type); ?>
                        </span>
                    </div>
                </div>
                <div class="flex flex-wrap gap-2">
                    <a href="admin_dashboard.php" class="btn">
                        <i class="fas fa-arrow-left"></i> Dashboard
                    </a>
                    <a href="scan_attendance.php?campus=<?php echo $selected_campus; ?>" class="btn">
                        <i class="fas fa-qrcode"></i> Scan Attendance
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Campus Selection -->
        <?php if (count($campuses) > 1): ?>
        <div class="card p-6 mb-8">
            <h2 class="text-xl font-bold text-gray-800 mb-4 flex items-center">
                <i class="fas fa-school text-blue-600 mr-2"></i> Select Campus
            </h2>
            <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-7 gap-3">
                <?php foreach ($campuses as $campus): ?>
                <a href="scan_fines.php?campus=<?php echo $campus['campus_id']; ?>&view=<?php echo $view_mode; ?>" 
                   class="p-4 bg-white rounded-lg shadow border border-gray-200 text-center hover:shadow-md transition-all <?php echo $selected_campus == $campus['campus_id'] ? 'border-blue-500 bg-blue-50' : ''; ?>">
                    <?php 
                    $campus_icons = [
                        'ACCESS' => 'fas fa-university',
                        'Isulan' => 'fas fa-school',
                        'Tacurong' => 'fas fa-building',
                        'Lutayan' => 'fas fa-landmark',
                        'Bagumbayan' => 'fas fa-archway',
                        'Palimbang' => 'fas fa-city',
                        'Kalamansig' => 'fas fa-place-of-worship'
                    ];
                    $icon = $campus_icons[$campus['campus_name']] ?? 'fas fa-school';
                    ?>
                    <div class="w-10 h-10 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center mx-auto mb-2">
                        <i class="<?php echo $icon; ?> text-white"></i>
                    </div>
                    <div class="font-semibold text-gray-800 truncate text-sm"><?php echo htmlspecialchars($campus['campus_name']); ?></div>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- View Mode Tabs -->
        <div class="card p-6 mb-8">
            <div class="flex flex-wrap gap-2">
                <a href="scan_fines.php?campus=<?php echo $selected_campus; ?>&view=scan" 
                   class="tab <?php echo $view_mode === 'scan' ? 'active' : ''; ?>">
                    <i class="fas fa-qrcode mr-2"></i> Scan Student
                </a>
                <a href="scan_fines.php?campus=<?php echo $selected_campus; ?>&view=pending" 
                   class="tab <?php echo $view_mode === 'pending' ? 'active' : ''; ?>">
                    <i class="fas fa-clock mr-2"></i> Pending Fines
                </a>
                <a href="scan_fines.php?campus=<?php echo $selected_campus; ?>&view=paid" 
                   class="tab <?php echo $view_mode === 'paid' ? 'active' : ''; ?>">
                    <i class="fas fa-check-circle mr-2"></i> Paid Fines
                </a>
                <a href="scan_fines.php?campus=<?php echo $selected_campus; ?>&view=all" 
                   class="tab <?php echo $view_mode === 'all' ? 'active' : ''; ?>">
                    <i class="fas fa-list mr-2"></i> All Fines
                </a>
                <button onclick="showAddFineModal()" class="tab bg-green-100 text-green-800 hover:bg-green-200">
                    <i class="fas fa-plus-circle mr-2"></i> Add Fine
                </button>
            </div>
        </div>
        
        <!-- Stats Cards -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div class="stat-card">
                <div class="stat-value text-blue-600"><?php echo $stats['total_fines']; ?></div>
                <div class="stat-label">Total Fines</div>
            </div>
            <div class="stat-card">
                <div class="stat-value text-red-600">₱<?php echo number_format($stats['pending_amount'] ?? 0, 2); ?></div>
                <div class="stat-label">Pending Amount</div>
            </div>
            <div class="stat-card">
                <div class="stat-value text-green-600">₱<?php echo number_format($stats['paid_amount'] ?? 0, 2); ?></div>
                <div class="stat-label">Paid Amount</div>
            </div>
            <div class="stat-card">
                <div class="stat-value text-yellow-600"><?php echo $stats['pending_fines']; ?></div>
                <div class="stat-label">Pending Fines</div>
            </div>
        </div>
        
        <!-- Main Content Area -->
        <?php if ($view_mode === 'scan'): ?>
        <!-- Scan Student Section -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <!-- Left: Scanner & Manual Entry -->
            <div class="space-y-8">
                <!-- QR Scanner -->
                <div class="card p-6">
                    <h2 class="text-xl font-bold text-gray-800 mb-4 flex items-center">
                        <i class="fas fa-camera text-blue-600 mr-2"></i> QR Code Scanner
                    </h2>
                    <div id="qr-reader" class="mb-6"></div>
                    <div class="flex space-x-2">
                        <button id="startScanner" class="btn btn-success flex-1">
                            <i class="fas fa-play"></i> Start Scanner
                        </button>
                        <button id="stopScanner" class="btn btn-danger flex-1">
                            <i class="fas fa-stop"></i> Stop Scanner
                        </button>
                    </div>
                </div>
                
                <!-- Manual Entry -->
                <div class="card p-6">
                    <h2 class="text-xl font-bold text-gray-800 mb-4 flex items-center">
                        <i class="fas fa-keyboard text-gray-600 mr-2"></i> Manual Entry
                    </h2>
                    <form id="manualEntryForm" method="POST" class="space-y-4">
                        <input type="hidden" name="action" value="scan_student">
                        <div>
                            <label class="block mb-2 text-sm font-medium text-gray-700">Student ID Number</label>
                            <input type="text" 
                                   name="student_number" 
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                   placeholder="Enter student ID number (e.g., STU202591956)"
                                   required>
                        </div>
                        <button type="submit" class="btn btn-primary w-full">
                            <i class="fas fa-search"></i> Search Student
                        </button>
                    </form>
                </div>
            </div>
            
            <!-- Right: Student Details & Fines -->
            <div class="space-y-8">
                <?php if ($success_message || $error_message): ?>
                <div class="message <?php echo $success_message ? 'message-success' : 'message-error'; ?>">
                    <i class="fas <?php echo $success_message ? 'fa-check-circle' : 'fa-exclamation-circle'; ?>"></i>
                    <div><?php echo $success_message ?: $error_message; ?></div>
                </div>
                <?php endif; ?>
                
                <?php if ($scanned_student): ?>
                <!-- Student Details -->
                <div class="card p-6">
                    <h2 class="text-xl font-bold text-gray-800 mb-4 flex items-center">
                        <i class="fas fa-user-graduate text-blue-600 mr-2"></i> Student Details
                    </h2>
                    <div class="space-y-3">
                        <div class="flex justify-between">
                            <span class="text-gray-600">Name:</span>
                            <span class="font-semibold"><?php echo htmlspecialchars($scanned_student['full_name']); ?></span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Student No:</span>
                            <span class="font-mono font-bold text-blue-600"><?php echo htmlspecialchars($scanned_student['student_number']); ?></span>
                        </div>
                        <?php if (isset($scanned_student['course_year'])): ?>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Course/Year:</span>
                            <span class="font-semibold"><?php echo htmlspecialchars($scanned_student['course_year']); ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if (isset($scanned_student['pending_fines_count']) && $scanned_student['pending_fines_count'] > 0): ?>
                        <div class="mt-4 p-3 bg-red-50 rounded-lg border border-red-200">
                            <div class="flex items-center justify-between">
                                <div>
                                    <div class="font-bold text-red-700">Pending Fines</div>
                                    <div class="text-sm text-red-600"><?php echo $scanned_student['pending_fines_count']; ?> fines</div>
                                </div>
                                <div class="text-right">
                                    <div class="text-2xl font-bold text-red-700">₱<?php echo number_format($scanned_student['total_pending_fines'] ?? 0, 2); ?></div>
                                </div>
                            </div>
                        </div>
                        <?php else: ?>
                        <div class="mt-4 p-3 bg-green-50 rounded-lg border border-green-200">
                            <div class="flex items-center">
                                <i class="fas fa-check-circle text-green-600 text-xl mr-3"></i>
                                <div>
                                    <div class="font-bold text-green-700">No Pending Fines</div>
                                    <div class="text-sm text-green-600">Student has no outstanding fines</div>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Student's Fines -->
                <?php 
                // Get student's fines
                if (isset($scanned_student['student_id'])) {
                    $student_fines_query = "SELECT f.*, a.activity_name, 
                                           COALESCE((SELECT SUM(fp.amount_paid) FROM fine_payments fp WHERE fp.fine_id = f.fine_id), 0) as paid_amount
                                           FROM fines f
                                           LEFT JOIN activities a ON f.activity_id = a.activity_id
                                           WHERE f.student_id = ?
                                           ORDER BY f.created_at DESC";
                    $student_fines_stmt = $conn->prepare($student_fines_query);
                    $student_fines_stmt->bind_param("i", $scanned_student['student_id']);
                    $student_fines_stmt->execute();
                    $student_fines_result = $student_fines_stmt->get_result();
                    $student_fines = [];
                    while ($fine = $student_fines_result->fetch_assoc()) {
                        $student_fines[] = $fine;
                    }
                } else {
                    $student_fines = [];
                }
                ?>
                
                <?php if (!empty($student_fines)): ?>
                <div class="card p-6">
                    <h2 class="text-xl font-bold text-gray-800 mb-4 flex items-center">
                        <i class="fas fa-file-invoice-dollar text-red-600 mr-2"></i> Student's Fines
                    </h2>
                    <div class="space-y-4">
                        <?php foreach ($student_fines as $fine): ?>
                        <?php 
                        $remaining = $fine['amount'] - ($fine['paid_amount'] ?? 0);
                        $status_class = $fine['status'] === 'paid' ? 'paid' : ($fine['status'] === 'partial' ? 'partial' : 'pending');
                        ?>
                        <div class="fine-item <?php echo $status_class; ?> p-4 bg-gray-50 rounded-lg">
                            <div class="flex justify-between items-start">
                                <div>
                                    <div class="font-bold text-gray-800">
                                        <?php echo htmlspecialchars($fine['activity_name'] ?? 'General Fine'); ?>
                                    </div>
                                    <div class="text-sm text-gray-600">
                                        Reason: <?php echo ucfirst($fine['reason']); ?>
                                    </div>
                                    <?php if ($fine['description']): ?>
                                    <div class="text-sm text-gray-600 mt-1">
                                        <?php echo htmlspecialchars($fine['description']); ?>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <div class="text-right">
                                    <div class="font-bold text-gray-800">₱<?php echo number_format($fine['amount'], 2); ?></div>
                                    <span class="status-badge status-<?php echo $fine['status']; ?>">
                                        <?php echo ucfirst($fine['status']); ?>
                                    </span>
                                </div>
                            </div>
                            
                            <?php if ($fine['status'] !== 'paid' && $remaining > 0): ?>
                            <div class="mt-3 pt-3 border-t border-gray-200">
                                <div class="flex justify-between items-center">
                                    <div>
                                        <div class="text-sm text-gray-600">Remaining: ₱<?php echo number_format($remaining, 2); ?></div>
                                        <?php if ($fine['paid_amount'] > 0): ?>
                                        <div class="text-xs text-gray-500">Paid: ₱<?php echo number_format($fine['paid_amount'], 2); ?></div>
                                        <?php endif; ?>
                                    </div>
                                    <button onclick="showPaymentModal(<?php echo $fine['fine_id']; ?>, '<?php echo htmlspecialchars($scanned_student['full_name']); ?>', <?php echo $remaining; ?>)" 
                                            class="btn btn-success text-sm">
                                        <i class="fas fa-money-bill-wave mr-1"></i> Pay Now
                                    </button>
                                </div>
                            </div>
                            <?php elseif ($fine['status'] === 'paid'): ?>
                            <div class="mt-3 pt-3 border-t border-gray-200">
                                <div class="text-sm text-green-600">
                                    <i class="fas fa-check-circle mr-1"></i> Fully paid on <?php echo date('M d, Y', strtotime($fine['updated_at'] ?? $fine['created_at'])); ?>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php else: ?>
                <div class="card p-6">
                    <div class="text-center py-8">
                        <i class="fas fa-check-circle text-green-500 text-5xl mb-4"></i>
                        <h3 class="text-lg font-bold text-gray-800 mb-2">No Fines Recorded</h3>
                        <p class="text-gray-600 mb-4">This student has no fine records.</p>
                        <button onclick="showAddFineModal(<?php echo $scanned_student['student_id'] ?? 'null'; ?>, '<?php echo isset($scanned_student['full_name']) ? htmlspecialchars($scanned_student['full_name']) : ''; ?>')" 
                                class="btn btn-primary">
                            <i class="fas fa-plus-circle mr-2"></i> Add New Fine
                        </button>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php else: ?>
                <!-- Welcome/Instructions -->
                <div class="card p-8 text-center">
                    <div class="w-24 h-24 bg-gradient-to-r from-blue-100 to-cyan-100 rounded-full flex items-center justify-center mx-auto mb-6">
                        <i class="fas fa-money-bill-wave text-blue-600 text-4xl"></i>
                    </div>
                    <h3 class="text-2xl font-bold text-gray-900 mb-3">Scan Student to Manage Fines</h3>
                    <p class="text-gray-600 mb-6 max-w-md mx-auto">
                        Use the QR scanner or manually enter a student ID number to view and manage their fines.
                    </p>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-xl mx-auto">
                        <div class="p-4 bg-blue-50 rounded-lg">
                            <div class="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                                <i class="fas fa-qrcode text-blue-600"></i>
                            </div>
                            <div class="font-semibold text-blue-800">Scan QR Code</div>
                            <div class="text-sm text-blue-600 mt-1">Point camera at student ID</div>
                        </div>
                        <div class="p-4 bg-green-50 rounded-lg">
                            <div class="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
                                <i class="fas fa-keyboard text-green-600"></i>
                            </div>
                            <div class="font-semibold text-green-800">Manual Entry</div>
                            <div class="text-sm text-green-600 mt-1">Type student ID number</div>
                        </div>
                        <div class="p-4 bg-purple-50 rounded-lg">
                            <div class="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-2">
                                <i class="fas fa-plus-circle text-purple-600"></i>
                            </div>
                            <div class="font-semibold text-purple-800">Add Fine</div>
                            <div class="text-sm text-purple-600 mt-1">Manually create fine record</div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <?php else: ?>
        <!-- Fines List View -->
        <div class="card p-6">
            <div class="flex justify-between items-center mb-6">
                <h2 class="text-xl font-bold text-gray-800 flex items-center">
                    <?php 
                    $icons = [
                        'pending' => 'fas fa-clock text-yellow-600',
                        'paid' => 'fas fa-check-circle text-green-600',
                        'all' => 'fas fa-list text-blue-600'
                    ];
                    ?>
                    <i class="<?php echo $icons[$view_mode] ?? 'fas fa-list text-blue-600'; ?> mr-2"></i>
                    <?php 
                    $titles = [
                        'pending' => 'Pending Fines',
                        'paid' => 'Paid Fines',
                        'all' => 'All Fines'
                    ];
                    echo $titles[$view_mode] ?? 'Fines List';
                    ?>
                    <span class="ml-2 text-sm font-normal text-gray-500">(<?php echo count($recent_fines); ?> records)</span>
                </h2>
                <div class="flex space-x-2">
                    <a href="scan_fines.php?campus=<?php echo $selected_campus; ?>&view=scan" class="btn btn-primary">
                        <i class="fas fa-qrcode mr-2"></i> Scan Student
                    </a>
                </div>
            </div>
            
            <?php if (!empty($recent_fines)): ?>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead>
                        <tr class="bg-gray-50 border-b border-gray-200">
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Student</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Activity</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Amount</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Status</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Date</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_fines as $fine): ?>
                        <?php 
                        $remaining = $fine['amount'] - ($fine['paid_amount'] ?? 0);
                        ?>
                        <tr class="border-b border-gray-100 hover:bg-gray-50">
                            <td class="py-3 px-4">
                                <div class="font-medium text-gray-900"><?php echo htmlspecialchars($fine['full_name']); ?></div>
                                <div class="text-sm text-gray-500"><?php echo htmlspecialchars($fine['student_number']); ?></div>
                                <div class="text-xs text-gray-400"><?php echo htmlspecialchars($fine['course_year'] ?? 'N/A'); ?> • <?php echo htmlspecialchars($fine['section'] ?? 'N/A'); ?></div>
                            </td>
                            <td class="py-3 px-4">
                                <div class="font-medium text-gray-900"><?php echo htmlspecialchars($fine['activity_name'] ?? 'General Fine'); ?></div>
                                <div class="text-sm text-gray-500"><?php echo ucfirst($fine['reason']); ?></div>
                            </td>
                            <td class="py-3 px-4">
                                <div class="font-bold text-gray-900">₱<?php echo number_format($fine['amount'], 2); ?></div>
                                <?php if ($fine['paid_amount'] > 0): ?>
                                <div class="text-sm text-green-600">Paid: ₱<?php echo number_format($fine['paid_amount'], 2); ?></div>
                                <?php endif; ?>
                                <?php if ($fine['status'] !== 'paid' && $remaining > 0): ?>
                                <div class="text-sm text-red-600">Remaining: ₱<?php echo number_format($remaining, 2); ?></div>
                                <?php endif; ?>
                            </td>
                            <td class="py-3 px-4">
                                <span class="status-badge status-<?php echo $fine['status']; ?>">
                                    <?php echo ucfirst($fine['status']); ?>
                                </span>
                            </td>
                            <td class="py-3 px-4 text-sm text-gray-600">
                                <?php echo date('M d, Y', strtotime($fine['created_at'])); ?>
                            </td>
                            <td class="py-3 px-4">
                                <div class="flex space-x-2">
                                    <?php if ($fine['status'] !== 'paid' && $remaining > 0): ?>
                                    <button onclick="showPaymentModal(<?php echo $fine['fine_id']; ?>, '<?php echo htmlspecialchars($fine['full_name']); ?>', <?php echo $remaining; ?>)" 
                                            class="px-3 py-1 bg-green-100 text-green-800 rounded text-sm font-medium hover:bg-green-200">
                                        <i class="fas fa-money-bill-wave mr-1"></i> Pay
                                    </button>
                                    <?php endif; ?>
                                    <a href="student_fines.php?student_id=<?php echo $fine['student_id']; ?>" 
                                       class="px-3 py-1 bg-blue-100 text-blue-800 rounded text-sm font-medium hover:bg-blue-200">
                                        <i class="fas fa-eye mr-1"></i> View
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <div class="mt-6 flex justify-between items-center">
                <div class="text-sm text-gray-600">
                    Showing <?php echo min(20, count($recent_fines)); ?> of <?php echo $stats['total_fines']; ?> fines
                </div>
                <a href="fines_report.php?campus=<?php echo $selected_campus; ?>" 
                   class="btn btn-primary">
                    <i class="fas fa-chart-bar mr-2"></i> View Full Report
                </a>
            </div>
            
            <?php else: ?>
            <div class="text-center py-12">
                <i class="fas fa-check-circle text-green-500 text-5xl mb-4"></i>
                <h3 class="text-xl font-bold text-gray-800 mb-2">No Fines Found</h3>
                <p class="text-gray-600 mb-6 max-w-md mx-auto">
                    <?php 
                    $messages = [
                        'pending' => 'No pending fines found for this campus.',
                        'paid' => 'No paid fines found for this campus.',
                        'all' => 'No fines records found for this campus.'
                    ];
                    echo $messages[$view_mode] ?? 'No fines found.';
                    ?>
                </p>
                <a href="scan_fines.php?campus=<?php echo $selected_campus; ?>&view=scan" class="btn btn-primary">
                    <i class="fas fa-qrcode mr-2"></i> Scan Student to Add Fines
                </a>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
    
    <!-- Payment Modal -->
    <div id="paymentModal" class="modal">
        <div class="modal-content">
            <div class="p-6 border-b border-gray-200">
                <h3 class="text-xl font-bold text-gray-900 flex items-center">
                    <i class="fas fa-money-bill-wave text-green-600 mr-2"></i> Process Payment
                </h3>
            </div>
            <form id="paymentForm" method="POST" class="p-6 space-y-4">
                <input type="hidden" name="action" value="pay_fine">
                <input type="hidden" id="fine_id" name="fine_id">
                
                <div>
                    <label class="block mb-1 text-sm font-medium text-gray-700">Student</label>
                    <div class="p-3 bg-gray-50 rounded-lg">
                        <div id="studentName" class="font-semibold text-gray-900"></div>
                    </div>
                </div>
                
                <div>
                    <label class="block mb-1 text-sm font-medium text-gray-700">Maximum Payable Amount</label>
                    <div class="p-3 bg-yellow-50 rounded-lg">
                        <div id="maxAmount" class="font-bold text-lg text-yellow-800"></div>
                    </div>
                </div>
                
                <div>
                    <label for="amount_paid" class="block mb-1 text-sm font-medium text-gray-700">Payment Amount (₱)</label>
                    <input type="number" 
                           id="amount_paid" 
                           name="amount_paid" 
                           step="0.01" 
                           min="0.01" 
                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                           placeholder="0.00"
                           required>
                    <p class="mt-1 text-sm text-gray-500">Enter the amount being paid</p>
                </div>
                
                <div>
                    <label for="payment_method" class="block mb-1 text-sm font-medium text-gray-700">Payment Method</label>
                    <select id="payment_method" 
                            name="payment_method" 
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500">
                        <option value="cash">Cash</option>
                        <option value="gcash">GCash</option>
                        <option value="paymaya">PayMaya</option>
                        <option value="bank_transfer">Bank Transfer</option>
                        <option value="check">Check</option>
                    </select>
                </div>
                
                <div id="referenceField" class="hidden">
                    <label for="reference_no" class="block mb-1 text-sm font-medium text-gray-700">Reference Number</label>
                    <input type="text" 
                           id="reference_no" 
                           name="reference_no" 
                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                           placeholder="Enter reference number">
                </div>
                
                <div class="pt-4 border-t border-gray-200 flex justify-end space-x-3">
                    <button type="button" onclick="hidePaymentModal()" class="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                        Cancel
                    </button>
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-check-circle mr-2"></i> Confirm Payment
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Add Fine Modal -->
    <div id="addFineModal" class="modal">
        <div class="modal-content">
            <div class="p-6 border-b border-gray-200">
                <h3 class="text-xl font-bold text-gray-900 flex items-center">
                    <i class="fas fa-plus-circle text-purple-600 mr-2"></i> Add New Fine
                </h3>
            </div>
            <form id="addFineForm" method="POST" class="p-6 space-y-4">
                <input type="hidden" name="action" value="add_fine">
                <input type="hidden" id="add_student_id" name="student_id">
                
                <div id="studentInfo" class="hidden">
                    <div class="p-3 bg-gray-50 rounded-lg mb-4">
                        <div class="font-semibold text-gray-900" id="selectedStudentName"></div>
                    </div>
                </div>
                
                <div id="studentSearch" class="space-y-3">
                    <div>
                        <label for="search_student" class="block mb-1 text-sm font-medium text-gray-700">Search Student</label>
                        <div class="flex space-x-2">
                            <input type="text" 
                                   id="search_student" 
                                   class="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                                   placeholder="Enter student name or number">
                            <button type="button" onclick="searchStudents()" class="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </div>
                    
                    <div id="studentResults" class="max-h-48 overflow-y-auto hidden">
                        <div class="text-sm font-medium text-gray-700 mb-2">Select Student:</div>
                        <div id="studentsList" class="space-y-1"></div>
                    </div>
                </div>
                
                <div>
                    <label for="activity_id" class="block mb-1 text-sm font-medium text-gray-700">Activity (Optional)</label>
                    <select id="activity_id" 
                            name="activity_id" 
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500">
                        <option value="">-- Select Activity --</option>
                        <?php foreach ($activities as $activity): ?>
                        <option value="<?php echo $activity['activity_id']; ?>">
                            <?php echo htmlspecialchars($activity['activity_name'] . ' (' . date('M d, Y', strtotime($activity['activity_date'])) . ')'); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div>
                    <label for="amount" class="block mb-1 text-sm font-medium text-gray-700">Fine Amount (₱)</label>
                    <input type="number" 
                           id="amount" 
                           name="amount" 
                           step="0.01" 
                           min="1" 
                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                           placeholder="0.00"
                           required>
                </div>
                
                <div>
                    <label for="reason" class="block mb-1 text-sm font-medium text-gray-700">Reason</label>
                    <select id="reason" 
                            name="reason" 
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500">
                        <option value="absence">Absence</option>
                        <option value="tardiness">Tardiness</option>
                        <option value="uniform">Uniform Violation</option>
                        <option value="conduct">Misconduct</option>
                        <option value="damage">Property Damage</option>
                        <option value="other">Other</option>
                    </select>
                </div>
                
                <div>
                    <label for="description" class="block mb-1 text-sm font-medium text-gray-700">Description</label>
                    <textarea id="description" 
                              name="description" 
                              rows="3"
                              class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                              placeholder="Additional details about the fine..."></textarea>
                </div>
                
                <div class="pt-4 border-t border-gray-200 flex justify-end space-x-3">
                    <button type="button" onclick="hideAddFineModal()" class="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                        Cancel
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save mr-2"></i> Save Fine
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        // QR Scanner
        let html5QrCode;
        let scannerActive = false;
        
        document.getElementById('startScanner').addEventListener('click', function() {
            if (scannerActive) return;
            
            const qrReader = document.getElementById('qr-reader');
            qrReader.innerHTML = '';
            
            html5QrCode = new Html5Qrcode("qr-reader");
            const qrCodeSuccessCallback = (decodedText, decodedResult) => {
                if (scannerActive) {
                    html5QrCode.stop().then(() => {
                        scannerActive = false;
                        document.getElementById('manualEntryForm').querySelector('input[name="student_number"]').value = decodedText;
                        document.getElementById('manualEntryForm').submit();
                    });
                }
            };
            
            const config = { fps: 10, qrbox: { width: 250, height: 250 } };
            
            html5QrCode.start({ facingMode: "environment" }, config, qrCodeSuccessCallback)
                .then(() => {
                    scannerActive = true;
                    this.innerHTML = '<i class="fas fa-play"></i> Scanner Running';
                    this.classList.remove('btn-success');
                    this.classList.add('btn-warning');
                })
                .catch(err => {
                    console.error(err);
                    alert("Failed to start camera. Please check permissions.");
                });
        });
        
        document.getElementById('stopScanner').addEventListener('click', function() {
            if (html5QrCode && scannerActive) {
                html5QrCode.stop().then(() => {
                    scannerActive = false;
                    document.getElementById('startScanner').innerHTML = '<i class="fas fa-play"></i> Start Scanner';
                    document.getElementById('startScanner').classList.remove('btn-warning');
                    document.getElementById('startScanner').classList.add('btn-success');
                });
            }
        });
        
        // Payment Modal
        function showPaymentModal(fineId, studentName, maxAmount) {
            document.getElementById('fine_id').value = fineId;
            document.getElementById('studentName').textContent = studentName;
            document.getElementById('maxAmount').textContent = '₱' + maxAmount.toFixed(2);
            document.getElementById('amount_paid').max = maxAmount;
            document.getElementById('amount_paid').value = maxAmount.toFixed(2);
            document.getElementById('paymentModal').classList.add('active');
        }
        
        function hidePaymentModal() {
            document.getElementById('paymentModal').classList.remove('active');
        }
        
        // Show reference field for non-cash payments
        document.getElementById('payment_method').addEventListener('change', function() {
            const referenceField = document.getElementById('referenceField');
            if (this.value !== 'cash') {
                referenceField.classList.remove('hidden');
                document.getElementById('reference_no').required = true;
            } else {
                referenceField.classList.add('hidden');
                document.getElementById('reference_no').required = false;
            }
        });
        
        // Add Fine Modal
        let selectedStudentId = null;
        let selectedStudentName = null;
        
        function showAddFineModal(studentId = null, studentName = null) {
            if (studentId && studentName) {
                selectedStudentId = studentId;
                selectedStudentName = studentName;
                document.getElementById('add_student_id').value = studentId;
                document.getElementById('selectedStudentName').textContent = studentName;
                document.getElementById('studentInfo').classList.remove('hidden');
                document.getElementById('studentSearch').classList.add('hidden');
            } else {
                selectedStudentId = null;
                selectedStudentName = null;
                document.getElementById('add_student_id').value = '';
                document.getElementById('studentInfo').classList.add('hidden');
                document.getElementById('studentSearch').classList.remove('hidden');
                document.getElementById('studentResults').classList.add('hidden');
            }
            document.getElementById('addFineModal').classList.add('active');
        }
        
        function hideAddFineModal() {
            document.getElementById('addFineModal').classList.remove('active');
        }
        
        async function searchStudents() {
            const searchTerm = document.getElementById('search_student').value.trim();
            if (searchTerm.length < 2) {
                alert('Please enter at least 2 characters');
                return;
            }
            
            const response = await fetch(`search_students.php?campus=<?php echo $selected_campus; ?>&q=${encodeURIComponent(searchTerm)}`);
            const students = await response.json();
            
            const studentsList = document.getElementById('studentsList');
            studentsList.innerHTML = '';
            
            if (students.length === 0) {
                studentsList.innerHTML = '<div class="p-3 text-gray-500 text-center">No students found</div>';
            } else {
                students.forEach(student => {
                    const div = document.createElement('div');
                    div.className = 'p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer';
                    div.innerHTML = `
                        <div class="font-medium text-gray-900">${student.full_name}</div>
                        <div class="text-sm text-gray-500">${student.student_number} • ${student.course_year || 'N/A'}</div>
                    `;
                    div.addEventListener('click', () => {
                        selectedStudentId = student.student_id;
                        selectedStudentName = student.full_name;
                        document.getElementById('add_student_id').value = student.student_id;
                        document.getElementById('selectedStudentName').textContent = student.full_name + ' (' + student.student_number + ')';
                        document.getElementById('studentInfo').classList.remove('hidden');
                        document.getElementById('studentSearch').classList.add('hidden');
                    });
                    studentsList.appendChild(div);
                });
            }
            
            document.getElementById('studentResults').classList.remove('hidden');
        }
        
        // Form validation
        document.getElementById('paymentForm').addEventListener('submit', function(e) {
            const amount = parseFloat(document.getElementById('amount_paid').value);
            const maxAmount = parseFloat(document.getElementById('maxAmount').textContent.replace('₱', ''));
            
            if (amount <= 0) {
                e.preventDefault();
                alert('Payment amount must be greater than 0');
                return;
            }
            
            if (amount > maxAmount) {
                e.preventDefault();
                alert('Payment amount cannot exceed the maximum payable amount');
                return;
            }
        });
        
        // Auto-focus on modal inputs
        document.getElementById('paymentModal').addEventListener('shown', function() {
            document.getElementById('amount_paid').focus();
        });
        
        document.getElementById('addFineModal').addEventListener('shown', function() {
            if (!selectedStudentId) {
                document.getElementById('search_student').focus();
            }
        });
        
        // Close modals on escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                hidePaymentModal();
                hideAddFineModal();
            }
        });
        
        // Close modals when clicking outside
        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('click', function(e) {
                if (e.target === this) {
                    this.classList.remove('active');
                }
            });
        });
    </script>
</body>
</html>
<?php
$conn->close();
?>