<?php
session_start();

// If user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: /attendance_system/login.php");
    exit;
}

// Optional: role-based protection
function requireRole($roles = [])
{
    if (!in_array($_SESSION['role'], $roles)) {
        echo "<h3>Access Denied</h3>";
        exit;
    }
}
