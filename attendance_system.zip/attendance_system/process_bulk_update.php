<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_type']) || !in_array($_SESSION['user_type'], ['admin','coordinator'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_FILES['update_file'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
    exit();
}

$activity_id = isset($_POST['activity_id']) ? intval($_POST['activity_id']) : 0;

if ($activity_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid activity ID']);
    exit();
}

// Process CSV file
$csv_file = $_FILES['update_file']['tmp_name'];
$handle = fopen($csv_file, 'r');

if ($handle === false) {
    echo json_encode(['success' => false, 'message' => 'Failed to open CSV file']);
    exit();
}

// Skip comment lines
while (($line = fgets($handle)) !== false) {
    if (substr(trim($line), 0, 1) !== '#') {
        fseek($handle, 0); // Reset to start
        break;
    }
}

// Read header
$header = fgetcsv($handle);
if ($header === false) {
    fclose($handle);
    echo json_encode(['success' => false, 'message' => 'Invalid CSV format']);
    exit();
}

// Process records
$success_count = 0;
$error_count = 0;
$errors = [];

while (($row = fgetcsv($handle)) !== false) {
    if (count($row) >= 5) {
        $student_number = trim($row[0]);
        $status = trim($row[2]);
        $time_in = !empty($row[3]) ? trim($row[3]) : null;
        $late_minutes = !empty($row[4]) ? intval($row[4]) : 0;
        
        // Get student ID
        $stmt = $conn->prepare("SELECT student_id FROM students WHERE student_number = ?");
        $stmt->bind_param("s", $student_number);
        $stmt->execute();
        $student_result = $stmt->get_result();
        
        if ($student_result->num_rows > 0) {
            $student = $student_result->fetch_assoc();
            
            // Update attendance record
            $update_stmt = $conn->prepare("
                UPDATE attendance 
                SET status = ?, time_in = ?, late_minutes = ?, updated_at = NOW() 
                WHERE student_id = ? AND activity_id = ?
            ");
            
            $update_stmt->bind_param("ssiii", $status, $time_in, $late_minutes, $student['student_id'], $activity_id);
            
            if ($update_stmt->execute()) {
                $success_count++;
            } else {
                $error_count++;
                $errors[] = "Failed to update student $student_number: " . $conn->error;
            }
        } else {
            $error_count++;
            $errors[] = "Student not found: $student_number";
        }
    }
}

fclose($handle);

echo json_encode([
    'success' => true,
    'message' => "Update completed. Successfully updated: $success_count records. Failed: $error_count records.",
    'errors' => $errors
]);

$conn->close();
?>