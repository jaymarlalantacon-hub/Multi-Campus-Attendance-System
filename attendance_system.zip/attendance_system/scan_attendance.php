<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_type']) || !in_array($_SESSION['user_type'], ['admin','coordinator'])) {
    header('Location: index.php');
    exit();
}

// Get user info
$user_name = $_SESSION['full_name'] ?? $_SESSION['username'] ?? 'User';
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Scan Attendance | Multi-Campus Attendance</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<script src="https://unpkg.com/html5-qrcode" type="text/javascript"></script>
<script src="https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.js"></script>
<style>
    @keyframes scanLine {
        0% { top: 0; }
        100% { top: 100%; }
    }
    .scan-line {
        position: absolute;
        width: 100%;
        height: 4px;
        background: linear-gradient(90deg, transparent, #8b5cf6, transparent);
        animation: scanLine 2s linear infinite;
    }
    .success-pulse {
        animation: successPulse 0.5s ease-in-out;
    }
    @keyframes successPulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.05); }
        100% { transform: scale(1); }
    }
    #imagePreview {
        max-width: 100%;
        max-height: 300px;
        border: 2px dashed #ddd;
        border-radius: 10px;
    }
    .drag-over {
        border-color: #8b5cf6 !important;
        background-color: #f5f3ff !important;
    }
    .scan-type-badge {
        transition: all 0.3s ease;
    }
    .scan-progress {
        background: linear-gradient(90deg, #8b5cf6 0%, #ec4899 100%);
        transition: width 0.5s ease-in-out;
    }
</style>
</head>
<body class="bg-gray-50 min-h-screen">

<!-- Navigation -->
<nav class="bg-gradient-to-r from-purple-800 to-indigo-900 text-white shadow-lg">
    <div class="container mx-auto px-4 py-3">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div class="flex items-center space-x-4">
                <a href="<?php echo $_SESSION['user_type'] === 'admin' ? 'admin_dashboard.php' : 'coordinator_dashboard.php'; ?>" class="flex items-center hover:text-purple-200 transition-colors">
                    <i class="fas fa-arrow-left mr-2"></i> Back to Dashboard
                </a>
                <h1 class="text-xl font-bold">
                    <i class="fas fa-qrcode mr-2"></i> Multi-Campus Attendance System
                </h1>
            </div>
            <div class="flex items-center space-x-4">
                <span class="text-sm">
                    <i class="fas fa-user mr-1"></i> <?php echo htmlspecialchars($user_name); ?>
                </span>
                <span class="text-sm text-purple-300">|</span>
                <a href="logout.php" class="text-sm hover:text-purple-200 transition-colors">
                    <i class="fas fa-sign-out-alt mr-1"></i> Logout
                </a>
            </div>
        </div>
    </div>
</nav>

<div class="container mx-auto px-4 py-8">
    <!-- Header -->
    <div class="mb-8 text-center">
        <h1 class="text-4xl font-bold text-gray-800 mb-3">Scan Attendance</h1>
        <p class="text-gray-600 max-w-2xl mx-auto">Scan student QR codes to mark attendance</p>
        <div class="inline-flex items-center mt-2 px-4 py-1 bg-gradient-to-r from-green-50 to-emerald-50 rounded-full border border-green-200">
            <i class="fas fa-user-check text-green-600 mr-2"></i>
            <span class="text-sm text-green-700">Advanced Attendance System</span>
        </div>
    </div>

    <!-- Quick Navigation -->
    <div class="flex flex-wrap gap-3 justify-center mb-8">
        <a href="<?php echo $_SESSION['user_type'] === 'admin' ? 'admin_dashboard.php' : 'coordinator_dashboard.php'; ?>" class="inline-flex items-center px-4 py-2.5 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
            <i class="fas fa-tachometer-alt mr-2"></i> Dashboard
        </a>
        <a href="activities.php" class="inline-flex items-center px-4 py-2.5 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
            <i class="fas fa-calendar-alt mr-2"></i> Activities
        </a>
        <a href="attendance_records.php" class="inline-flex items-center px-4 py-2.5 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors">
            <i class="fas fa-clipboard-list mr-2"></i> Attendance Records
        </a>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Scanner Section -->
        <div class="lg:col-span-2">
            <div class="bg-white rounded-2xl shadow-xl p-8">
                <!-- Campus Selection -->
                <div class="mb-8">
                    <label class="block mb-3 font-semibold text-gray-800 text-lg">
                        <i class="fas fa-school text-purple-600 mr-2"></i>Select Campus *
                    </label>
                    <select id="campusSelect" 
                            class="w-full px-5 py-3.5 border border-gray-300 rounded-xl focus:ring-3 focus:ring-purple-500 focus:border-purple-500 transition-colors text-lg bg-white">
                        <option value="">-- Loading campuses --</option>
                    </select>
                </div>

                <!-- Activity Selection -->
                <div class="mb-8">
                    <label class="block mb-3 font-semibold text-gray-800 text-lg">
                        <i class="fas fa-calendar-alt text-purple-600 mr-2"></i>Select Activity *
                    </label>
                    <select id="activitySelect" 
                            class="w-full px-5 py-3.5 border border-gray-300 rounded-xl focus:ring-3 focus:ring-purple-500 focus:border-purple-500 transition-colors text-lg bg-white"
                            disabled>
                        <option value="">-- Select campus first --</option>
                    </select>
                    <div id="activityInfo" class="mt-4 hidden p-4 bg-blue-50 rounded-xl border border-blue-200">
                        <div id="activityDescription" class="text-blue-800"></div>
                        <div id="activityDateTime" class="text-blue-700 text-sm mt-2"></div>
                    </div>
                    <div id="noActivitiesMessage" class="mt-3 hidden p-3 bg-yellow-50 text-yellow-700 rounded-lg">
                        <i class="fas fa-exclamation-triangle mr-2"></i>
                        <span>No upcoming activities found for this campus.</span>
                    </div>
                </div>

                <!-- Current Scan Type Info -->
                <div id="scanTypeInfo" class="mb-8 hidden p-6 bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl border border-purple-200">
                    <div class="flex items-center justify-between">
                        <div>
                            <h3 class="text-xl font-bold text-gray-800 mb-2">Scan Type: <span id="currentScanType" class="text-purple-600">Check-in</span></h3>
                            <p class="text-gray-600" id="scanTypeDescription">Scanning for check-in attendance</p>
                        </div>
                        <div class="flex items-center space-x-3">
                            <div class="px-4 py-2 bg-gradient-to-r from-blue-100 to-indigo-100 rounded-lg">
                                <div class="text-sm font-semibold text-blue-800" id="activityDuration">Whole Day</div>
                                <div class="text-xs text-blue-600" id="activityFrequency">2X Scan</div>
                            </div>
                            <div id="scanProgress" class="text-center">
                                <div class="text-2xl font-bold text-purple-600" id="scansCompleted">0</div>
                                <div class="text-xs text-gray-500">/ <span id="totalScansRequired">2</span> scans</div>
                            </div>
                        </div>
                    </div>
                    <!-- Progress Bar -->
                    <div class="mt-4">
                        <div class="flex justify-between text-sm text-gray-600 mb-1">
                            <span>Scan Progress</span>
                            <span id="progressPercentage">0%</span>
                        </div>
                        <div class="w-full bg-gray-200 rounded-full h-2.5">
                            <div id="progressBar" class="scan-progress h-2.5 rounded-full transition-all duration-500" style="width: 0%"></div>
                        </div>
                    </div>
                </div>

                <!-- Scanner Controls -->
                <div class="mb-8 p-6 bg-gradient-to-r from-purple-50 to-indigo-50 rounded-xl border border-purple-200">
                    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div>
                            <h2 class="text-2xl font-bold text-gray-800 mb-2">QR Code Scanner</h2>
                            <p class="text-gray-600">Scan student QR codes to mark attendance</p>
                        </div>
                        <div class="flex flex-wrap gap-3">
                            <button id="startScanner" 
                                    class="px-6 py-3 bg-green-600 text-white rounded-xl hover:bg-green-700 transition-colors flex items-center text-lg font-semibold shadow-lg hover:shadow-xl"
                                    disabled>
                                <i class="fas fa-camera mr-3"></i> Start Camera
                            </button>
                            <button id="stopScanner" 
                                    class="px-6 py-3 bg-red-600 text-white rounded-xl hover:bg-red-700 transition-colors flex items-center text-lg font-semibold shadow-lg hover:shadow-xl" 
                                    disabled>
                                <i class="fas fa-stop mr-3"></i> Stop Camera
                            </button>
                            <button id="resetScannerBtn" 
                                    class="px-6 py-3 bg-purple-600 text-white rounded-xl hover:bg-purple-700 transition-colors flex items-center text-lg font-semibold shadow-lg hover:shadow-xl">
                                <i class="fas fa-redo mr-3"></i> Reset
                            </button>
                        </div>
                    </div>
                </div>

                <!-- QR Scanner Container -->
                <div class="relative">
                    <div id="qr-reader" class="rounded-2xl overflow-hidden border-4 border-gray-200 relative">
                        <div class="scan-line"></div>
                    </div>
                    <div id="scannerOverlay" class="absolute inset-0 flex items-center justify-center bg-black/50 hidden rounded-2xl">
                        <div class="text-center p-8 bg-white rounded-xl shadow-2xl">

                        </div>
                    </div>
                </div>
                <div id="qr-reader-results" class="mt-4"></div>

                <!-- Upload QR from Photo Section -->
                <div class="mt-8 p-6 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl border border-blue-200">
                    <h3 class="text-2xl font-bold text-gray-800 mb-4 flex items-center">
                        <i class="fas fa-image text-blue-600 mr-3"></i>Upload QR Code Photo
                    </h3>
                    <p class="text-gray-600 mb-6">Take a photo of a student's QR code and upload it here</p>
                    
                    <!-- Upload Area -->
                    <div id="uploadArea" 
                         class="border-4 border-dashed border-gray-300 rounded-2xl p-8 text-center cursor-pointer transition-all duration-300 hover:border-purple-400 hover:bg-purple-50">
                        <div class="w-24 h-24 mx-auto mb-6 bg-gradient-to-r from-blue-100 to-indigo-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-cloud-upload-alt text-blue-600 text-3xl"></i>
                        </div>
                        <p class="text-xl font-semibold text-gray-700 mb-2">Drop QR Code Photo Here</p>
                        <p class="text-gray-500 mb-4">or click to browse files</p>
                        <p class="text-sm text-gray-400 mb-6">
                            Supported formats: JPG, PNG, GIF, WEBP (Max 5MB)
                        </p>
                        <input type="file" id="qrFileInput" accept="image/*" class="hidden">
                        <button id="browseFilesBtn" 
                                class="px-8 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl hover:from-blue-700 hover:to-indigo-700 transition-all font-semibold shadow-lg hover:shadow-xl">
                            <i class="fas fa-folder-open mr-2"></i> Browse Files
                        </button>
                    </div>
                    
                    <!-- Image Preview -->
                    <div id="previewContainer" class="mt-6 hidden">
                        <h4 class="text-lg font-semibold text-gray-800 mb-3 flex items-center">
                            <i class="fas fa-eye text-purple-600 mr-2"></i> Preview
                        </h4>
                        <div class="flex flex-col md:flex-row gap-6">
                            <div class="flex-1">
                                <img id="imagePreview" class="w-full h-auto rounded-xl shadow-lg" alt="QR Code Preview">
                            </div>
                            <div class="flex-1 flex flex-col justify-center">
                                <div id="imageInfo" class="space-y-3">
                                    <div class="flex justify-between">
                                        <span class="font-medium text-gray-700">Status:</span>
                                        <span id="imageStatus" class="px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full font-semibold">Ready to scan</span>
                                    </div>
                                    <div class="flex justify-between">
                                        <span class="font-medium text-gray-700">File name:</span>
                                        <span id="fileName" class="text-gray-900 font-medium truncate"></span>
                                    </div>
                                    <div class="flex justify-between">
                                        <span class="font-medium text-gray-700">File size:</span>
                                        <span id="fileSize" class="text-gray-900"></span>
                                    </div>
                                </div>
                                <div class="flex gap-3 mt-6">
                                    <button id="scanFromImageBtn" 
                                            class="flex-1 px-6 py-3 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-xl hover:from-green-700 hover:to-emerald-700 transition-all font-semibold shadow-lg hover:shadow-xl flex items-center justify-center">
                                        <i class="fas fa-search mr-2"></i> Scan QR Code
                                    </button>
                                    <button id="clearUploadBtn" 
                                            class="flex-1 px-6 py-3 bg-gradient-to-r from-gray-600 to-gray-700 text-white rounded-xl hover:from-gray-700 hover:to-gray-800 transition-all font-semibold shadow-lg hover:shadow-xl flex items-center justify-center">
                                        <i class="fas fa-times mr-2"></i> Clear
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Upload Processing -->
                    <div id="uploadProcessing" class="mt-6 hidden p-4 bg-gradient-to-r from-blue-50 to-cyan-50 text-blue-800 rounded-xl border border-blue-200">
                        <div class="flex items-center justify-center">
                            <div class="w-12 h-12 mr-4 bg-gradient-to-r from-blue-100 to-cyan-100 rounded-full flex items-center justify-center">
                                <i class="fas fa-spinner fa-spin text-blue-600 text-xl"></i>
                            </div>
                            <div>
                                <p class="font-semibold">Processing image...</p>
                                <p class="text-sm">Detecting and scanning QR code</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Manual Entry -->
                <div class="mt-8 p-6 bg-gradient-to-r from-gray-50 to-gray-100 rounded-xl border border-gray-200">
                    <h3 class="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                        <i class="fas fa-keyboard text-purple-600 mr-2"></i> Manual Student Entry
                    </h3>
                    <div class="flex flex-col md:flex-row gap-3">
                        <input type="text" id="manualStudentCode" 
                               placeholder="Enter student ID number" 
                               class="flex-grow px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors"
                               disabled>
                        <button id="manualEntryBtn" 
                                class="px-6 py-3 bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-lg hover:from-purple-700 hover:to-indigo-700 transition-all font-semibold shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
                                disabled>
                            <i class="fas fa-user-check mr-2"></i> Mark Attendance
                        </button>
                    </div>
                    <div class="mt-3 flex items-center text-sm text-gray-500">
                        <i class="fas fa-info-circle mr-1"></i>
                        <span>Enter student number manually if QR code is unavailable</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Right Sidebar -->
        <div class="space-y-6">
            <!-- Scan Result -->
            <div id="scanResult" class="hidden bg-gradient-to-r from-green-50 to-emerald-50 p-6 rounded-2xl shadow-2xl border border-green-200 success-pulse">
                <div class="text-center">
                    <div class="w-24 h-24 bg-gradient-to-r from-green-100 to-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                        <i class="fas fa-check-circle text-green-600 text-4xl"></i>
                    </div>
                    <h3 class="text-2xl font-bold text-green-800 mb-2" id="resultTitle">Attendance Marked!</h3>
                    <div id="resultDetails" class="text-left bg-white p-4 rounded-xl mb-6 shadow-inner"></div>
                    <button id="continueScanningBtn" 
                            class="w-full px-6 py-3 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-xl hover:from-green-700 hover:to-emerald-700 transition-all font-semibold shadow-lg hover:shadow-xl flex items-center justify-center transform hover:-translate-y-0.5">
                        <i class="fas fa-redo mr-2"></i> Scan Next
                    </button>
                </div>
            </div>

            <!-- Current Session Info -->
            <div class="bg-gradient-to-r from-blue-50 to-cyan-50 p-6 rounded-2xl border border-blue-200 shadow-sm">
                <h3 class="text-xl font-semibold text-blue-800 mb-4 flex items-center">
                    <i class="fas fa-info-circle text-blue-600 mr-3"></i>Current Session
                </h3>
                <div class="space-y-3">
                    <div class="flex justify-between items-center p-3 bg-white/50 rounded-xl">
                        <span class="font-medium text-gray-700">Date:</span>
                        <span class="font-semibold text-gray-900"><?php echo date('F j, Y'); ?></span>
                    </div>
                    <div class="flex justify-between items-center p-3 bg-white/50 rounded-xl">
                        <span class="font-medium text-gray-700">Time:</span>
                        <span class="font-semibold text-gray-900" id="currentTime"><?php echo date('h:i A'); ?></span>
                    </div>
                    <div class="flex justify-between items-center p-3 bg-white/50 rounded-xl">
                        <span class="font-medium text-gray-700">Scanner:</span>
                        <span id="scannerStatus" class="px-3 py-1 bg-red-100 text-red-800 rounded-full text-sm font-semibold">Stopped</span>
                    </div>
                    <div class="flex justify-between items-center p-3 bg-white/50 rounded-xl">
                        <span class="font-medium text-gray-700">Scans:</span>
                        <span id="scanCount" class="px-3 py-1 bg-gradient-to-r from-purple-100 to-indigo-100 text-purple-800 rounded-full text-sm font-semibold">0</span>
                    </div>
                    <div class="flex justify-between items-center p-3 bg-white/50 rounded-xl">
                        <span class="font-medium text-gray-700">Method:</span>
                        <span id="scanMethod" class="px-3 py-1 bg-gradient-to-r from-gray-100 to-gray-200 text-gray-800 rounded-full text-sm font-semibold">None</span>
                    </div>
                </div>
            </div>

            <!-- Activity Type Info -->
            <div id="activityTypeCard" class="bg-white p-6 rounded-2xl shadow-lg border border-purple-200 hidden">
                <h3 class="text-xl font-semibold text-purple-800 mb-4 flex items-center">
                    <i class="fas fa-calendar-day text-purple-600 mr-3"></i>Activity Details
                </h3>
                <div class="space-y-4">
                    <div class="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl border border-blue-200">
                        <div class="flex items-center mb-2">
                            <div class="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center mr-4">
                                <i class="fas fa-sun text-blue-600"></i>
                            </div>
                            <div>
                                <h4 class="font-semibold text-gray-800" id="activityTypeTitle">Whole Day</h4>
                                <p class="text-sm text-gray-600">8:00 AM - 5:00 PM</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl border border-green-200">
                        <div class="flex items-center mb-2">
                            <div class="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center mr-4">
                                <i class="fas fa-qrcode text-green-600"></i>
                            </div>
                            <div>
                                <h4 class="font-semibold text-gray-800" id="scanFrequencyTitle">2X Scan</h4>
                                <p class="text-sm text-gray-600" id="scanFrequencyDesc">Check-in & Check-out</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl border border-purple-200">
                        <div class="flex items-center mb-2">
                            <div class="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center mr-4">
                                <i class="fas fa-exclamation-circle text-purple-600"></i>
                            </div>
                            <div>
                                <h4 class="font-semibold text-gray-800">Mandatory</h4>
                                <p class="text-sm text-gray-600">Attendance required</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Scanning Instructions -->
            <div class="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
                <h3 class="text-lg font-semibold text-gray-800 mb-3 flex items-center">
                    <i class="fas fa-lightbulb text-yellow-500 mr-2"></i> Scanning Rules
                </h3>
                <div class="space-y-3">
                    <div class="flex items-start">
                        <div class="flex-shrink-0 mt-1">
                            <div class="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center">
                                <i class="fas fa-sun text-blue-600 text-xs"></i>
                            </div>
                        </div>
                        <div class="ml-3">
                            <p class="text-sm font-medium text-gray-700">Whole Day Activity</p>
                            <p class="text-xs text-gray-600">• 4 scans required: AM IN/OUT & PM IN/OUT</p>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="flex-shrink-0 mt-1">
                            <div class="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center">
                                <i class="fas fa-clock text-green-600 text-xs"></i>
                            </div>
                        </div>
                        <div class="ml-3">
                            <p class="text-sm font-medium text-gray-700">Half Day Activity</p>
                            <p class="text-xs text-gray-600">• 2 scans required: Check-in & Check-out only</p>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="flex-shrink-0 mt-1">
                            <div class="w-6 h-6 bg-purple-100 rounded-full flex items-center justify-center">
                                <i class="fas fa-qrcode text-purple-600 text-xs"></i>
                            </div>
                        </div>
                        <div class="ml-3">
                            <p class="text-sm font-medium text-gray-700">Scan Sequence</p>
                            <p class="text-xs text-gray-600">• System determines next required scan automatically</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
let html5QrcodeScanner = null;
let currentActivityId = null;
let scanCount = 0;
let currentUploadedImage = null;
let currentActivityData = null;
let studentScanProgress = {};

// Update current time
function updateTime() {
    const now = new Date();
    document.getElementById('currentTime').textContent = 
        now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
}
setInterval(updateTime, 1000);

// Update scan count display
function updateScanCount() {
    document.getElementById('scanCount').textContent = scanCount;
}

// Update scan method display
function updateScanMethod(method) {
    const methodElement = document.getElementById('scanMethod');
    methodElement.textContent = method;
    
    switch(method.toLowerCase()) {
        case 'camera':
            methodElement.className = 'px-3 py-1 bg-gradient-to-r from-green-100 to-emerald-100 text-green-800 rounded-full text-sm font-semibold';
            break;
        case 'photo':
            methodElement.className = 'px-3 py-1 bg-gradient-to-r from-blue-100 to-indigo-100 text-blue-800 rounded-full text-sm font-semibold';
            break;
        case 'manual':
            methodElement.className = 'px-3 py-1 bg-gradient-to-r from-purple-100 to-pink-100 text-purple-800 rounded-full text-sm font-semibold';
            break;
        default:
            methodElement.className = 'px-3 py-1 bg-gradient-to-r from-gray-100 to-gray-200 text-gray-800 rounded-full text-sm font-semibold';
    }
}

// Load campuses
async function loadCampuses() {
    try {
        const response = await fetch('get_campuses.php');
        const data = await response.json();
        const select = document.getElementById('campusSelect');
        select.innerHTML = '<option value="">-- Select Campus --</option>';
        
        if(data.success && data.campuses && data.campuses.length > 0) {
            data.campuses.forEach(campus => {
                const option = document.createElement('option');
                option.value = campus.campus_id;
                option.textContent = campus.campus_name;
                select.appendChild(option);
            });
        } else {
            select.innerHTML = '<option value="">No campuses found</option>';
        }
    } catch (error) {
        console.error('Error loading campuses:', error);
        document.getElementById('campusSelect').innerHTML = '<option value="">Error loading campuses</option>';
    }
}

// Load activities for selected campus
async function loadActivitiesForCampus(campusId) {
    if (!campusId) return;
    
    const activitySelect = document.getElementById('activitySelect');
    activitySelect.innerHTML = '<option value="">Loading activities...</option>';
    activitySelect.disabled = true;
    
    try {
        const response = await fetch(`get_activities.php?campus_id=${campusId}`);
        const data = await response.json();
        activitySelect.innerHTML = '<option value="">-- Select Activity --</option>';
        
        if(data.success && data.activities && data.activities.length > 0) {
            data.activities.forEach(activity => {
                const option = document.createElement('option');
                option.value = activity.activity_id;
                option.textContent = activity.activity_name;
                // Store additional data in dataset
                option.dataset.description = activity.description || 'No description';
                option.dataset.date = activity.activity_date;
                option.dataset.time = activity.activity_time;
                option.dataset.venue = activity.venue || 'No venue specified';
                option.dataset.type = activity.activity_type;
                option.dataset.frequency = activity.scan_frequency;
                option.dataset.mandatory = activity.mandatory;
                activitySelect.appendChild(option);
            });
            activitySelect.disabled = false;
            document.getElementById('noActivitiesMessage').classList.add('hidden');
        } else {
            activitySelect.innerHTML = '<option value="">No activities available</option>';
            document.getElementById('noActivitiesMessage').classList.remove('hidden');
        }
    } catch (error) {
        console.error('Error loading activities:', error);
        activitySelect.innerHTML = '<option value="">Error loading activities</option>';
    }
}

// Show activity info when selected
document.getElementById('activitySelect').addEventListener('change', function() {
    const selectedOption = this.options[this.selectedIndex];
    const activityInfo = document.getElementById('activityInfo');
    const startScannerBtn = document.getElementById('startScanner');
    const manualEntryInput = document.getElementById('manualStudentCode');
    const manualEntryBtn = document.getElementById('manualEntryBtn');
    const scanTypeInfo = document.getElementById('scanTypeInfo');
    const activityTypeCard = document.getElementById('activityTypeCard');
    
    if(this.value) {
        currentActivityId = this.value;
        currentActivityData = {
            activity_id: this.value,
            name: selectedOption.textContent,
            description: selectedOption.dataset.description,
            date: selectedOption.dataset.date,
            time: selectedOption.dataset.time,
            venue: selectedOption.dataset.venue,
            type: selectedOption.dataset.type || 'whole_day',
            frequency: selectedOption.dataset.frequency || '2x',
            mandatory: selectedOption.dataset.mandatory === '1'
        };
        
        // Enable buttons
        startScannerBtn.disabled = false;
        manualEntryInput.disabled = false;
        manualEntryBtn.disabled = false;
        
        // Show activity info
        if (selectedOption.dataset.description) {
            let typeInfo = '';
            let typeIcon = '';
            if (currentActivityData.type === 'whole_day') {
                typeInfo = 'Whole Day Activity (8AM-5PM)';
                typeIcon = 'fas fa-sun';
            } else {
                typeInfo = 'Half Day Activity (4 hours)';
                typeIcon = 'fas fa-clock';
            }
            
            let frequencyInfo = '';
            let frequencyDesc = '';
            if (currentActivityData.frequency === '2x') {
                frequencyInfo = '2X Scan';
                frequencyDesc = 'Check-in & Check-out';
            } else {
                frequencyInfo = '4X Scan';
                frequencyDesc = 'AM/PM Check-in & Check-out';
            }
            
            // For half day, force 2x scan only
            if (currentActivityData.type === 'half_day') {
                frequencyInfo = '2X Scan';
                frequencyDesc = 'Check-in & Check-out only (Half Day)';
            }
            
            document.getElementById('activityDescription').innerHTML = `
                <div class="mb-2">${selectedOption.dataset.description}</div>
                <div class="flex flex-wrap gap-2 mt-3">
                    <span class="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-semibold flex items-center">
                        <i class="${typeIcon} mr-1"></i> ${typeInfo}
                    </span>
                    <span class="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-semibold flex items-center">
                        <i class="fas fa-qrcode mr-1"></i> ${frequencyInfo}
                    </span>
                    ${currentActivityData.mandatory ? 
                        '<span class="px-3 py-1 bg-red-100 text-red-800 rounded-full text-sm font-semibold flex items-center"><i class="fas fa-exclamation-circle mr-1"></i> Mandatory</span>' : 
                        '<span class="px-3 py-1 bg-gray-100 text-gray-800 rounded-full text-sm font-semibold flex items-center"><i class="fas fa-check-circle mr-1"></i> Optional</span>'}
                </div>
            `;
            document.getElementById('activityDateTime').textContent = 
                `${selectedOption.dataset.date} at ${selectedOption.dataset.time} • ${selectedOption.dataset.venue}`;
            activityInfo.classList.remove('hidden');
            
            // Update activity type card
            document.getElementById('activityTypeTitle').textContent = typeInfo.split(' ')[0] + ' ' + typeInfo.split(' ')[1];
            document.getElementById('scanFrequencyTitle').textContent = frequencyInfo;
            document.getElementById('scanFrequencyDesc').textContent = frequencyDesc;
            activityTypeCard.classList.remove('hidden');
            
            // Update scan type info
            document.getElementById('activityDuration').textContent = currentActivityData.type === 'whole_day' ? 'Whole Day' : 'Half Day';
            document.getElementById('activityFrequency').textContent = frequencyInfo;
            
            // Set total scans required based on activity type
            let totalScans = 2; // Default for half day or 2x scan
            if (currentActivityData.type === 'whole_day' && currentActivityData.frequency === '4x') {
                totalScans = 4;
            }
            
            document.getElementById('totalScansRequired').textContent = totalScans;
            
            // Show scan type info
            scanTypeInfo.classList.remove('hidden');
            updateScanTypeInfo('checkin');
            
        } else {
            activityInfo.classList.add('hidden');
            activityTypeCard.classList.add('hidden');
            scanTypeInfo.classList.add('hidden');
        }
    } else {
        activityInfo.classList.add('hidden');
        activityTypeCard.classList.add('hidden');
        scanTypeInfo.classList.add('hidden');
        startScannerBtn.disabled = true;
        manualEntryInput.disabled = true;
        manualEntryBtn.disabled = true;
        currentActivityId = null;
        currentActivityData = null;
    }
});

// Update scan type information
function updateScanTypeInfo(scanType) {
    const scanTypeElement = document.getElementById('currentScanType');
    const scanTypeDescription = document.getElementById('scanTypeDescription');
    
    const scanTypes = {
        'checkin': { name: 'Check-in', desc: 'Scanning for check-in attendance' },
        'checkout': { name: 'Check-out', desc: 'Scanning for check-out attendance' },
        'checkin_am': { name: 'AM Check-in', desc: 'Scanning for morning check-in (8:00 AM)' },
        'checkout_am': { name: 'AM Check-out', desc: 'Scanning for morning check-out (before lunch)' },
        'checkin_pm': { name: 'PM Check-in', desc: 'Scanning for afternoon check-in (1:00 PM)' },
        'checkout_pm': { name: 'PM Check-out', desc: 'Scanning for afternoon check-out (end of day)' }
    };
    
    const typeInfo = scanTypes[scanType] || scanTypes.checkin;
    scanTypeElement.textContent = typeInfo.name;
    scanTypeDescription.textContent = typeInfo.desc;
}

// Update student scan progress
function updateStudentProgress(studentId, scanType) {
    if (!studentScanProgress[studentId]) {
        // Initialize based on activity type
        let totalScans = 2; // Default for half day or 2x scan
        if (currentActivityData.type === 'whole_day' && currentActivityData.frequency === '4x') {
            totalScans = 4;
        }
        
        studentScanProgress[studentId] = {
            scans: new Set(),
            totalScans: totalScans,
            lastScanTime: null,
            scanSequence: []
        };
    }
    
    // Add this scan to the set
    studentScanProgress[studentId].scans.add(scanType);
    studentScanProgress[studentId].lastScanTime = new Date();
    studentScanProgress[studentId].scanSequence.push({
        type: scanType,
        time: new Date().toISOString()
    });
    
    const completed = studentScanProgress[studentId].scans.size;
    const total = studentScanProgress[studentId].totalScans;
    const percentage = Math.round((completed / total) * 100);
    
    // Update progress display
    document.getElementById('scansCompleted').textContent = completed;
    document.getElementById('progressPercentage').textContent = `${percentage}%`;
    document.getElementById('progressBar').style.width = `${percentage}%`;
    
    // Determine next scan type
    const nextScanType = determineNextScanType(studentScanProgress[studentId].scans);
    updateScanTypeInfo(nextScanType);
    
    return { completed, total, percentage, nextScanType };
}

// Determine next scan type based on completed scans
function determineNextScanType(completedScans) {
    if (!currentActivityData) return 'checkin';
    
    const isHalfDay = currentActivityData.type === 'half_day';
    const is4xScan = currentActivityData.frequency === '4x' && currentActivityData.type === 'whole_day';
    
    if (isHalfDay) {
        // Half day: only check-in and check-out
        if (!completedScans.has('checkin')) return 'checkin';
        if (!completedScans.has('checkout')) return 'checkout';
        return 'complete';
    } else if (is4xScan) {
        // Whole day with 4x scan: AM check-in/out & PM check-in/out
        if (!completedScans.has('checkin_am')) return 'checkin_am';
        if (!completedScans.has('checkout_am')) return 'checkout_am';
        if (!completedScans.has('checkin_pm')) return 'checkin_pm';
        if (!completedScans.has('checkout_pm')) return 'checkout_pm';
        return 'complete';
    } else {
        // Whole day with 2x scan: check-in and check-out
        if (!completedScans.has('checkin')) return 'checkin';
        if (!completedScans.has('checkout')) return 'checkout';
        return 'complete';
    }
}

// Determine scan type based on current time and activity data
function determineScanTypeByTime() {
    if (!currentActivityData) return 'checkin';
    
    const now = new Date();
    const currentHour = now.getHours();
    const currentMinutes = now.getMinutes();
    const currentTime = currentHour * 60 + currentMinutes;
    
    // Parse activity time
    const activityTime = currentActivityData.time;
    const [timeHour, timeMinute] = activityTime.split(':').map(Number);
    const activityStartTime = timeHour * 60 + timeMinute;
    
    // Define time boundaries
    const morningEnd = 12 * 60; // 12:00 PM
    const afternoonStart = 13 * 60; // 1:00 PM
    const activityEnd = activityStartTime + (currentActivityData.type === 'half_day' ? 240 : 540); // 4 hours or 9 hours
    
    if (currentActivityData.type === 'half_day') {
        // Half day: only check-in and check-out
        if (currentTime < activityStartTime + 30) {
            return 'checkin';
        } else {
            return 'checkout';
        }
    } else {
        // Whole day
        if (currentActivityData.frequency === '4x') {
            // 4x scan
            if (currentTime < morningEnd) {
                if (currentTime < activityStartTime + 30) {
                    return 'checkin_am';
                } else {
                    return 'checkout_am';
                }
            } else {
                if (currentTime < afternoonStart + 30) {
                    return 'checkin_pm';
                } else {
                    return 'checkout_pm';
                }
            }
        } else {
            // 2x scan
            if (currentTime < activityEnd - 30) {
                return 'checkin';
            } else {
                return 'checkout';
            }
        }
    }
}

// Start scanner
document.getElementById('startScanner').addEventListener('click', async function(e) {
    e.preventDefault();
    
    if(!currentActivityId) {
        alert('Please select an activity first!');
        return;
    }

    try {
        // Check camera permissions
        const stream = await navigator.mediaDevices.getUserMedia({ 
            video: { facingMode: "environment" } 
        });
        stream.getTracks().forEach(track => track.stop());
        
        // Hide overlay and show scanner
        document.getElementById('scannerOverlay').classList.add('hidden');
        document.getElementById('scannerStatus').textContent = 'Scanning';
        document.getElementById('scannerStatus').className = 'px-3 py-1 bg-gradient-to-r from-green-100 to-emerald-100 text-green-800 rounded-full text-sm font-semibold';

        // Initialize and start scanner
        html5QrcodeScanner = new Html5QrcodeScanner(
            "qr-reader",
            { 
                fps: 10, 
                qrbox: { width: 250, height: 250 },
                showTorchButtonIfSupported: true,
                showZoomSliderIfSupported: true,
                aspectRatio: 1.0
            },
            false
        );

        html5QrcodeScanner.render(
            qrCodeMessage => {
                updateScanMethod('Camera');
                handleScan(qrCodeMessage, 'camera');
            },
            errorMessage => {
                // Handle scan errors silently
            }
        );

        this.disabled = true;
        document.getElementById('stopScanner').disabled = false;

    } catch (error) {
        console.error('Camera error:', error);
        alert('Camera access denied. Please allow camera permissions to use the scanner or use photo upload instead.');
    }
});

// Stop scanner
document.getElementById('stopScanner').addEventListener('click', function(e) {
    e.preventDefault();
    
    if(html5QrcodeScanner) {
        html5QrcodeScanner.clear();
        html5QrcodeScanner = null;
        
        // Show overlay
        document.getElementById('scannerOverlay').classList.remove('hidden');
        document.getElementById('scannerStatus').textContent = 'Stopped';
        document.getElementById('scannerStatus').className = 'px-3 py-1 bg-red-100 text-red-800 rounded-full text-sm font-semibold';
    }
    
    document.getElementById('startScanner').disabled = false;
    this.disabled = true;
});

// Handle scan (camera, photo, or manual)
async function handleScan(qrData, source = 'scan') {
    console.log(`Processing ${source}:`, qrData);
    
    // Validate required fields
    if (!currentActivityId) {
        showMessage('Please select an activity first!', 'warning');
        return;
    }
    
    if (!qrData || qrData.trim() === '') {
        showMessage('No data received', 'error');
        return;
    }
    
    try {
        // Parse QR data
        let studentData;
        let studentNumber;
        
        try {
            studentData = JSON.parse(qrData);
            console.log("Parsed JSON QR:", studentData);
            
            // Extract student number
            if (studentData.student_number) {
                studentNumber = studentData.student_number;
            } else if (studentData.student_code) {
                studentNumber = studentData.student_code;
            } else if (studentData.code) {
                studentNumber = studentData.code;
            } else {
                studentNumber = qrData.trim();
            }
        } catch (e) {
            // If not JSON, treat as plain student number
            studentNumber = qrData.trim();
        }
        
        // Validate student number
        if (!studentNumber || studentNumber.length < 2) {
            showMessage('Invalid student number format', 'error');
            return;
        }
        
        // Show scanning indicator
        showScanningIndicator(studentNumber, source);
        
        // Determine scan type based on time and student progress
        let scanType = determineScanTypeByTime();
        
        // Check if student has existing scans
        const existingStudentId = Object.keys(studentScanProgress).find(id => 
            id.includes(studentNumber) || id === studentNumber
        );
        
        if (existingStudentId) {
            // Student has existing scans, determine next required scan
            const nextScanType = determineNextScanType(studentScanProgress[existingStudentId].scans);
            if (nextScanType !== 'complete') {
                scanType = nextScanType;
            }
        }
        
        // Prepare request data
        const requestData = {
            student_code: studentNumber,
            activity_id: currentActivityId,
            scan_type: scanType,
            activity_type: currentActivityData.type,
            scan_frequency: currentActivityData.frequency
        };
        
        console.log("Sending to server:", requestData);
        
        // Send to server
        const response = await fetch('attendance_process.php', {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify(requestData)
        });
        
        const data = await response.json();
        console.log("Server response:", data);
        
        if (data.success) {
            // Success handling
            scanCount++;
            updateScanCount();
            playSuccessSound();
            
            // Update student progress
            const progress = updateStudentProgress(data.student_id || studentNumber, scanType);
            showSuccessResult(data, studentNumber, source, progress);
            
            // Clear upload if it was from photo
            if(source === 'upload') {
                clearUpload();
            }
            
        } else {
            // Error handling
            showScanError(data.message, data.details || '', source);
            playErrorSound();
        }
        
    } catch(error) {
        console.error(`Error processing ${source}:`, error);
        showNetworkError(source);
        playErrorSound();
    }
}

// Helper functions
function showMessage(message, type = 'info') {
    const resultDiv = document.getElementById('qr-reader-results');
    const colors = {
        'warning': 'from-yellow-50 to-amber-50 border-yellow-200 text-yellow-800',
        'error': 'from-red-50 to-rose-50 border-red-200 text-red-800',
        'info': 'from-blue-50 to-cyan-50 border-blue-200 text-blue-800'
    };
    
    resultDiv.innerHTML = `
        <div class="p-4 bg-gradient-to-r ${colors[type]} rounded-xl border">
            <div class="flex items-center">
                <div class="w-10 h-10 mr-3 rounded-full flex items-center justify-center">
                    <i class="fas ${type === 'warning' ? 'fa-exclamation-triangle text-yellow-600' : type === 'error' ? 'fa-times-circle text-red-600' : 'fa-info-circle text-blue-600'}"></i>
                </div>
                <div>
                    <p class="font-semibold">${type === 'warning' ? 'Warning' : type === 'error' ? 'Error' : 'Information'}</p>
                    <p class="text-sm">${message}</p>
                </div>
            </div>
    `;
    
    setTimeout(() => {
        resultDiv.innerHTML = '';
    }, 3000);
}

function showScanningIndicator(studentNumber, source) {
    const resultDiv = document.getElementById('qr-reader-results');
    resultDiv.innerHTML = `
        <div class="p-4 bg-gradient-to-r from-blue-50 to-cyan-50 text-blue-800 rounded-xl animate-pulse border border-blue-200">
            <div class="flex items-center justify-center">
                <div class="w-12 h-12 mr-4 bg-gradient-to-r from-blue-100 to-cyan-100 rounded-full flex items-center justify-center">
                    <i class="fas fa-spinner fa-spin text-blue-600 text-xl"></i>
                </div>
                <div>
                    <p class="font-semibold">Processing...</p>
                    <p class="text-sm">Student: <span class="font-medium">${studentNumber}</span></p>
                    <p class="text-xs">Activity: ${currentActivityData?.name || 'N/A'}</p>
                </div>
            </div>
        </div>
    `;
}

function showSuccessResult(data, studentNumber, source, progress = null) {
    const scanResult = document.getElementById('scanResult');
    const resultTitle = document.getElementById('resultTitle');
    const resultDetails = document.getElementById('resultDetails');
    
    scanResult.className = `bg-gradient-to-r from-green-50 to-emerald-50 p-6 rounded-2xl shadow-2xl border border-green-200 success-pulse`;
    scanResult.classList.remove('hidden');
    
    // Adjust title based on scan completion
    if (progress && progress.completed === progress.total) {
        resultTitle.textContent = '✓ Attendance Complete!';
    } else if (data.scan_type === 'checkout' || data.scan_type.includes('Check-out')) {
        resultTitle.textContent = '✓ Checked Out!';
    } else {
        resultTitle.textContent = '✓ Checked In!';
    }
    
    // Build result details
    let detailsHTML = `
        <div class="space-y-3">
            <div class="flex items-center justify-between">
                <span class="font-medium text-gray-700">Student Name:</span>
                <span class="font-semibold text-gray-900">${data.student_name || 'N/A'}</span>
            </div>
            
            <div class="flex items-center justify-between">
                <span class="font-medium text-gray-700">Student Number:</span>
                <span class="font-semibold text-blue-600">${studentNumber}</span>
            </div>
    `;
    
    if (data.campus) {
        detailsHTML += `
            <div class="flex items-center justify-between">
                <span class="font-medium text-gray-700">Campus:</span>
                <span class="text-gray-900">${data.campus}</span>
            </div>
        `;
    }
    
    if (data.activity) {
        detailsHTML += `
            <div class="flex items-center justify-between">
                <span class="font-medium text-gray-700">Activity:</span>
                <span class="text-gray-900">${data.activity.name}</span>
            </div>
        `;
    }
    
    // Show scan type
    const scanTypeDisplay = data.scan_type || 'checkin';
    const scanTypeClass = scanTypeDisplay.includes('Check-out') ? 'bg-purple-100 text-purple-800' : 'bg-blue-100 text-blue-800';
    detailsHTML += `
            <div class="flex items-center justify-between">
                <span class="font-medium text-gray-700">Scan Type:</span>
                <span class="px-2 py-1 ${scanTypeClass} rounded-full text-sm font-semibold">
                    ${scanTypeDisplay}
                </span>
            </div>
    `;
    
    if (progress) {
        detailsHTML += `
            <div class="flex items-center justify-between">
                <span class="font-medium text-gray-700">Progress:</span>
                <span class="px-2 py-1 bg-gradient-to-r from-purple-100 to-pink-100 text-purple-800 rounded-full text-sm font-semibold">
                    ${progress.completed}/${progress.total} scans
                </span>
            </div>
        `;
    }
    
    detailsHTML += `
            <div class="flex items-center justify-between">
                <span class="font-medium text-gray-700">Status:</span>
                <span class="px-2 py-1 ${getStatusClass(data.status)} rounded-full text-sm font-semibold">
                    ${data.status}
                </span>
            </div>
    `;
    
    if (data.late_minutes > 0) {
        detailsHTML += `
            <div class="flex items-center justify-between">
                <span class="font-medium text-gray-700">Late:</span>
                <span class="px-2 py-1 bg-yellow-100 text-yellow-800 rounded-full text-sm font-semibold">
                    ${data.late_minutes} minutes
                </span>
            </div>
        `;
    }
    
    if (data.time_in) {
        detailsHTML += `
            <div class="flex items-center justify-between">
                <span class="font-medium text-gray-700">Time:</span>
                <span class="text-gray-900">${formatDateTime(data.time_in)}</span>
            </div>
        `;
    }
    
    detailsHTML += `
            <div class="flex items-center justify-between">
                <span class="font-medium text-gray-700">Method:</span>
                <span class="px-2 py-1 ${source === 'upload' ? 'bg-blue-100 text-blue-800' : source === 'manual' ? 'bg-purple-100 text-purple-800' : 'bg-green-100 text-green-800'} rounded-full text-sm font-semibold">
                    ${source === 'upload' ? 'Photo Upload' : source === 'manual' ? 'Manual Entry' : 'Camera Scan'}
                </span>
            </div>
        </div>
    `;
    
    resultDetails.innerHTML = detailsHTML;
    
    // Auto-hide after 5 seconds
    setTimeout(() => {
        scanResult.classList.add('hidden');
        document.getElementById('qr-reader-results').innerHTML = '';
    }, 5000);
}

function getStatusClass(status) {
    switch(status?.toLowerCase()) {
        case 'present': return 'bg-green-100 text-green-800';
        case 'late': return 'bg-yellow-100 text-yellow-800';
        case 'absent': return 'bg-red-100 text-red-800';
        case 'complete': return 'bg-gradient-to-r from-purple-100 to-pink-100 text-purple-800';
        default: return 'bg-gray-100 text-gray-800';
    }
}

function formatDateTime(dateTimeStr) {
    const date = new Date(dateTimeStr);
    return date.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit',
        second: '2-digit'
    });
}

function showScanError(message, details, source) {
    const resultDiv = document.getElementById('qr-reader-results');
    resultDiv.innerHTML = `
        <div class="p-4 bg-gradient-to-r from-red-50 to-rose-50 text-red-800 rounded-xl border border-red-200">
            <div class="flex items-center">
                <div class="w-12 h-12 mr-4 bg-gradient-to-r from-red-100 to-rose-100 rounded-full flex items-center justify-center">
                    <i class="fas fa-exclamation-triangle text-red-600 text-xl"></i>
                </div>
                <div>
                    <p class="font-semibold">Failed</p>
                    <p class="text-sm">${message}</p>
                    ${details ? `<p class="text-xs mt-1 opacity-80">${details}</p>` : ''}
                </div>
            </div>
        </div>
    `;
}

function showNetworkError(source) {
    const resultDiv = document.getElementById('qr-reader-results');
    resultDiv.innerHTML = `
        <div class="p-4 bg-gradient-to-r from-red-50 to-rose-50 text-red-800 rounded-xl border border-red-200">
            <div class="flex items-center">
                <div class="w-12 h-12 mr-4 bg-gradient-to-r from-red-100 to-rose-100 rounded-full flex items-center justify-center">
                    <i class="fas fa-wifi text-red-600 text-xl"></i>
                </div>
                <div>
                    <p class="font-semibold">Network Error</p>
                    <p class="text-sm">Please check your connection</p>
                </div>
            </div>
        </div>
    `;
}

// Manual entry processing
async function processManualEntry() {
    const studentCode = document.getElementById('manualStudentCode').value.trim();
    
    if(!studentCode) {
        alert('Please enter a student number');
        return;
    }
    
    if(!currentActivityId) {
        alert('Please select an activity first');
        return;
    }

    updateScanMethod('Manual');
    await handleScan(studentCode, 'manual');
    
    // Clear input
    document.getElementById('manualStudentCode').value = '';
}

// Photo Upload Functions
document.getElementById('qrFileInput').addEventListener('change', handleFileSelect);
document.getElementById('browseFilesBtn').addEventListener('click', () => document.getElementById('qrFileInput').click());

// Handle file selection
function handleFileSelect(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    // Validate file size (5MB max)
    if (file.size > 5 * 1024 * 1024) {
        alert('File size must be less than 5MB');
        return;
    }
    
    // Validate file type
    const validTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (!validTypes.includes(file.type)) {
        alert('Please upload a valid image file (JPG, PNG, GIF, WEBP)');
        return;
    }
    
    const reader = new FileReader();
    reader.onload = function(e) {
        currentUploadedImage = e.target.result;
        
        // Show preview
        document.getElementById('imagePreview').src = currentUploadedImage;
        document.getElementById('fileName').textContent = file.name;
        document.getElementById('fileSize').textContent = formatFileSize(file.size);
        document.getElementById('previewContainer').classList.remove('hidden');
        document.getElementById('uploadProcessing').classList.add('hidden');
        document.getElementById('imageStatus').textContent = 'Ready to scan';
        document.getElementById('imageStatus').className = 'px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full font-semibold';
    };
    reader.readAsDataURL(file);
}

// Handle drag and drop
const uploadArea = document.getElementById('uploadArea');
['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
    uploadArea.addEventListener(eventName, preventDefaults, false);
});

function preventDefaults(e) {
    e.preventDefault();
    e.stopPropagation();
}

['dragenter', 'dragover'].forEach(eventName => {
    uploadArea.addEventListener(eventName, highlight, false);
});

['dragleave', 'drop'].forEach(eventName => {
    uploadArea.addEventListener(eventName, unhighlight, false);
});

function highlight() {
    uploadArea.classList.add('drag-over');
}

function unhighlight() {
    uploadArea.classList.remove('drag-over');
}

uploadArea.addEventListener('drop', handleDrop, false);

function handleDrop(e) {
    const dt = e.dataTransfer;
    const files = dt.files;
    
    if (files.length) {
        document.getElementById('qrFileInput').files = files;
        handleFileSelect({ target: { files: files } });
    }
}

// Scan QR code from uploaded image
async function scanFromImage() {
    if (!currentUploadedImage || !currentActivityId) {
        if (!currentActivityId) {
            alert('Please select an activity first!');
        } else {
            alert('Please upload an image first!');
        }
        return;
    }
    
    updateScanMethod('Photo');
    
    // Show processing indicator
    document.getElementById('uploadProcessing').classList.remove('hidden');
    document.getElementById('imageStatus').textContent = 'Scanning...';
    document.getElementById('imageStatus').className = 'px-3 py-1 bg-blue-100 text-blue-800 rounded-full font-semibold';
    
    try {
        // Create an image element
        const img = new Image();
        img.onload = function() {
            // Create canvas to process image
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            canvas.width = img.width;
            canvas.height = img.height;
            ctx.drawImage(img, 0, 0);
            
            // Get image data for jsQR
            const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
            
            // Use jsQR to decode QR code
            const code = jsQR(imageData.data, imageData.width, imageData.height, {
                inversionAttempts: "dontInvert",
            });
            
            if (code) {
                document.getElementById('uploadProcessing').classList.add('hidden');
                document.getElementById('imageStatus').textContent = 'QR Code Found!';
                document.getElementById('imageStatus').className = 'px-3 py-1 bg-green-100 text-green-800 rounded-full font-semibold';
                
                // Process the QR code data
                handleScan(code.data, 'upload');
            } else {
                document.getElementById('uploadProcessing').classList.add('hidden');
                document.getElementById('imageStatus').textContent = 'No QR Code Found';
                document.getElementById('imageStatus').className = 'px-3 py-1 bg-red-100 text-red-800 rounded-full font-semibold';
                
                alert('Could not detect a QR code in the uploaded image');
            }
        };
        
        img.onerror = function() {
            document.getElementById('uploadProcessing').classList.add('hidden');
            document.getElementById('imageStatus').textContent = 'Error Loading Image';
            document.getElementById('imageStatus').className = 'px-3 py-1 bg-red-100 text-red-800 rounded-full font-semibold';
            
            alert('Error loading image. Please try again with a different file.');
        };
        
        img.src = currentUploadedImage;
    } catch (error) {
        console.error('Error scanning image:', error);
        document.getElementById('uploadProcessing').classList.add('hidden');
        document.getElementById('imageStatus').textContent = 'Scan Error';
        document.getElementById('imageStatus').className = 'px-3 py-1 bg-red-100 text-red-800 rounded-full font-semibold';
        
        alert('Error scanning image. Please try again.');
    }
}

// Clear uploaded image
function clearUpload() {
    document.getElementById('qrFileInput').value = '';
    document.getElementById('previewContainer').classList.add('hidden');
    document.getElementById('uploadProcessing').classList.add('hidden');
    currentUploadedImage = null;
    document.getElementById('qr-reader-results').innerHTML = '';
}

// Format file size
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Reset scanner
function resetScanner() {
    document.getElementById('scanResult').classList.add('hidden');
    document.getElementById('qr-reader-results').innerHTML = '';
    clearUpload();
    studentScanProgress = {};
    
    // Reset progress bar
    document.getElementById('scansCompleted').textContent = '0';
    document.getElementById('progressPercentage').textContent = '0%';
    document.getElementById('progressBar').style.width = '0%';
    updateScanTypeInfo('checkin');
    
    if(html5QrcodeScanner) {
        // Scanner will continue automatically
        document.getElementById('scannerStatus').textContent = 'Ready to scan';
    }
}

// Continue scanning
document.getElementById('continueScanningBtn').addEventListener('click', function() {
    document.getElementById('scanResult').classList.add('hidden');
    document.getElementById('qr-reader-results').innerHTML = '';
});

// Play success sound
function playSuccessSound() {
    try {
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        oscillator.frequency.value = 800;
        oscillator.type = 'sine';
        
        gainNode.gain.setValueAtTime(0.2, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
        
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.5);
    } catch (e) {
        // Sound not supported - ignore
    }
}

// Play error sound
function playErrorSound() {
    try {
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        oscillator.frequency.value = 400;
        oscillator.type = 'sine';
        
        gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
        
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.3);
    } catch (e) {
        // Sound not supported - ignore
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    loadCampuses();
    updateTime();
    updateScanCount();
    updateScanMethod('None');
    
    // Initialize scanner overlay as visible
    document.getElementById('scannerOverlay').classList.remove('hidden');
    
    // Add event listeners for photo upload buttons
    document.getElementById('scanFromImageBtn').addEventListener('click', (e) => {
        e.preventDefault();
        scanFromImage();
    });
    
    document.getElementById('clearUploadBtn').addEventListener('click', (e) => {
        e.preventDefault();
        clearUpload();
    });
    
    document.getElementById('resetScannerBtn').addEventListener('click', (e) => {
        e.preventDefault();
        resetScanner();
    });
    
    // Manual entry Enter key
    document.getElementById('manualStudentCode').addEventListener('keypress', function(e) {
        if(e.key === 'Enter') {
            e.preventDefault();
            processManualEntry();
        }
    });
    
    document.getElementById('manualEntryBtn').addEventListener('click', function(e) {
        e.preventDefault();
        processManualEntry();
    });
    
    // Campus change event
    document.getElementById('campusSelect').addEventListener('change', function() {
        const campusId = this.value;
        loadActivitiesForCampus(campusId);
    });
});
</script>
</body>
</html>