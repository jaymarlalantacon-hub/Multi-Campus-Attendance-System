<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}

$user_type = $_SESSION['user_type'];
$user_campus_id = $_SESSION['campus_id'];

// Check if activity ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error_message'] = "No activity ID specified.";
    header('Location: activities.php');
    exit();
}

$activity_id = intval($_GET['id']);

// Start transaction
$conn->begin_transaction();

try {
    // First, check if the user has permission to delete this activity
    $check_sql = "SELECT a.*, c.campus_name 
                  FROM activities a 
                  LEFT JOIN campuses c ON a.campus_id = c.campus_id 
                  WHERE a.activity_id = ?";
    
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("i", $activity_id);
    $check_stmt->execute();
    $activity = $check_stmt->get_result()->fetch_assoc();
    
    if (!$activity) {
        throw new Exception("Activity not found.");
    }
    
    // Check permissions
    if ($user_type === 'coordinator') {
        // Coordinators can only delete activities from their campus or activities they created
        if ($activity['campus_id'] != $user_campus_id && $activity['created_by'] != $_SESSION['user_id']) {
            throw new Exception("You don't have permission to delete this activity.");
        }
    }
    
    // Get counts for confirmation message
    $count_sql = "SELECT 
                  (SELECT COUNT(*) FROM attendance WHERE activity_id = ?) as attendance_count,
                  (SELECT COUNT(*) FROM fines WHERE activity_id = ?) as fines_count";
    
    $count_stmt = $conn->prepare($count_sql);
    $count_stmt->bind_param("ii", $activity_id, $activity_id);
    $count_stmt->execute();
    $counts = $count_stmt->get_result()->fetch_assoc();
    
    // Check if there are associated records (for confirmation)
    if ($counts['attendance_count'] > 0 || $counts['fines_count'] > 0) {
        // Ask for confirmation (we'll handle this in JavaScript, but set a flag)
        if (!isset($_GET['confirm']) || $_GET['confirm'] !== 'yes') {
            $_SESSION['delete_confirmation'] = [
                'activity_id' => $activity_id,
                'activity_name' => $activity['activity_name'],
                'attendance_count' => $counts['attendance_count'],
                'fines_count' => $counts['fines_count']
            ];
            header('Location: activities.php');
            exit();
        }
    }
    
    // Delete associated records first (to maintain referential integrity)
    
    // 1. Delete attendance records
    $delete_attendance_sql = "DELETE FROM attendance WHERE activity_id = ?";
    $delete_attendance_stmt = $conn->prepare($delete_attendance_sql);
    $delete_attendance_stmt->bind_param("i", $activity_id);
    $delete_attendance_stmt->execute();
    
    // 2. Delete fines (and their payments)
    $get_fines_sql = "SELECT fine_id FROM fines WHERE activity_id = ?";
    $get_fines_stmt = $conn->prepare($get_fines_sql);
    $get_fines_stmt->bind_param("i", $activity_id);
    $get_fines_stmt->execute();
    $fines_result = $get_fines_stmt->get_result();
    
    while ($fine = $fines_result->fetch_assoc()) {
        // Delete payments for each fine
        $delete_payments_sql = "DELETE FROM fine_payments WHERE fine_id = ?";
        $delete_payments_stmt = $conn->prepare($delete_payments_sql);
        $delete_payments_stmt->bind_param("i", $fine['fine_id']);
        $delete_payments_stmt->execute();
        
        // Delete the fine
        $delete_fine_sql = "DELETE FROM fines WHERE fine_id = ?";
        $delete_fine_stmt = $conn->prepare($delete_fine_sql);
        $delete_fine_stmt->bind_param("i", $fine['fine_id']);
        $delete_fine_stmt->execute();
    }
    
    // 3. Delete the activity
    $delete_activity_sql = "DELETE FROM activities WHERE activity_id = ?";
    $delete_activity_stmt = $conn->prepare($delete_activity_sql);
    $delete_activity_stmt->bind_param("i", $activity_id);
    $delete_activity_stmt->execute();
    
    // 4. Log the deletion
    $log_sql = "INSERT INTO audit_logs (user_id, action, table_name, record_id, details) 
                VALUES (?, 'DELETE', 'activities', ?, ?)";
    $log_stmt = $conn->prepare($log_sql);
    $details = "Deleted activity: " . $activity['activity_name'] . 
               " | Date: " . $activity['activity_date'] . 
               " | Associated records deleted: Attendance(" . $counts['attendance_count'] . 
               "), Fines(" . $counts['fines_count'] . ")";
    $log_stmt->bind_param("iis", $_SESSION['user_id'], $activity_id, $details);
    $log_stmt->execute();
    
    // Commit transaction
    $conn->commit();
    
    $_SESSION['success_message'] = "Activity '{$activity['activity_name']}' has been deleted successfully.";
    
} catch (Exception $e) {
    // Rollback transaction on error
    $conn->rollback();
    $_SESSION['error_message'] = "Error deleting activity: " . $e->getMessage();
}

// Redirect back to activities page
header('Location: activities.php');
exit();
?>