<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}

$user_name = $_SESSION['full_name'];
$user_type = $_SESSION['user_type'];
$user_campus_id = $_SESSION['campus_id'];

// Build query based on user type
if ($user_type === 'admin') {
    $query = "SELECT a.*, c.campus_name, u.full_name as created_by_name 
              FROM activities a 
              LEFT JOIN campuses c ON a.campus_id = c.campus_id 
              LEFT JOIN users u ON a.created_by = u.user_id 
              ORDER BY a.activity_date DESC, a.activity_time DESC";
    $stmt = $conn->prepare($query);
} else {
    $query = "SELECT a.*, c.campus_name, u.full_name as created_by_name 
              FROM activities a 
              LEFT JOIN campuses c ON a.campus_id = c.campus_id 
              LEFT JOIN users u ON a.created_by = u.user_id 
              WHERE (a.campus_id = ? OR a.campus_id IS NULL)
              ORDER BY a.activity_date DESC, a.activity_time DESC";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_campus_id);
}

$stmt->execute();
$result = $stmt->get_result();

// Get statistics
$stats = [
    'total' => 0,
    'upcoming' => 0,
    'completed' => 0,
    'mandatory' => 0,
    'optional' => 0
];

$activities = [];
while ($row = $result->fetch_assoc()) {
    $activities[] = $row;
    
    $stats['total']++;
    if ($row['status'] === 'upcoming') $stats['upcoming']++;
    if ($row['status'] === 'completed') $stats['completed']++;
    if ($row['mandatory'] == 1) $stats['mandatory']++;
    else $stats['optional']++;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Activities | Multi-Campus Attendance</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
</head>
<body class="bg-gray-50 min-h-screen">
    <!-- Navigation -->
    <nav class="bg-gradient-to-r from-purple-800 to-indigo-900 text-white shadow-lg">
        <div class="container mx-auto px-4 py-3">
            <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div class="flex items-center space-x-4">
                    <a href="<?php echo $user_type === 'admin' ? 'admin_dashboard.php' : 'coordinator_dashboard.php'; ?>" 
                       class="flex items-center hover:text-purple-200 transition-colors">
                        <i class="fas fa-arrow-left mr-2"></i> Back to Dashboard
                    </a>
                    <h1 class="text-xl font-bold">
                        <i class="fas fa-calendar-alt mr-2"></i> Activities
                    </h1>
                </div>
                <div class="flex items-center space-x-4">
                    <span class="text-sm">
                        <i class="fas fa-user mr-1"></i> <?php echo htmlspecialchars($user_name); ?>
                    </span>
                    <a href="create_activity.php" class="text-sm bg-green-600 hover:bg-green-700 px-3 py-1 rounded-lg transition-colors">
                        <i class="fas fa-calendar-plus mr-1"></i> New Activity
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-8">
        <!-- Header -->
        <div class="mb-8">
            <h1 class="text-3xl font-bold text-gray-800">Activity Management</h1>
            <p class="text-gray-600">
                <?php 
                if ($user_type === 'coordinator') {
                    echo "Viewing activities for your campus";
                } else {
                    echo "All activities across all campuses";
                }
                ?>
            </p>
        </div>

        <!-- Stats -->
        <div class="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
            <div class="bg-white p-4 rounded-lg shadow border-l-4 border-blue-500">
                <p class="text-sm text-gray-600">Total Activities</p>
                <p class="text-2xl font-bold text-gray-800"><?php echo $stats['total']; ?></p>
            </div>
            <div class="bg-white p-4 rounded-lg shadow border-l-4 border-green-500">
                <p class="text-sm text-gray-600">Upcoming</p>
                <p class="text-2xl font-bold text-gray-800"><?php echo $stats['upcoming']; ?></p>
            </div>
            <div class="bg-white p-4 rounded-lg shadow border-l-4 border-purple-500">
                <p class="text-sm text-gray-600">Completed</p>
                <p class="text-2xl font-bold text-gray-800"><?php echo $stats['completed']; ?></p>
            </div>
            <div class="bg-white p-4 rounded-lg shadow border-l-4 border-red-500">
                <p class="text-sm text-gray-600">Mandatory</p>
                <p class="text-2xl font-bold text-gray-800"><?php echo $stats['mandatory']; ?></p>
            </div>
            <div class="bg-white p-4 rounded-lg shadow border-l-4 border-yellow-500">
                <p class="text-sm text-gray-600">Optional</p>
                <p class="text-2xl font-bold text-gray-800"><?php echo $stats['optional']; ?></p>
            </div>
        </div>

        <!-- Activities Table -->
        <div class="bg-white rounded-xl shadow-lg overflow-hidden">
            <div class="p-6 border-b">
                <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                        <h2 class="text-xl font-bold text-gray-800">All Activities</h2>
                        <p class="text-gray-600">Click on activity to view details</p>
                    </div>
                    <div class="flex gap-3">
                        <a href="create_activity.php" class="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                            <i class="fas fa-calendar-plus mr-2"></i> New Activity
                        </a>
                        <button onclick="exportActivities()" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                            <i class="fas fa-download mr-2"></i> Export
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="overflow-x-auto">
                <table id="activitiesTable" class="w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-600">Activity</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-600">Date & Time</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-600">Campus</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-600">Type</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-600">Fine Details</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-600">Status</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-600">Created By</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-600">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php foreach ($activities as $activity): ?>
                        <tr class="hover:bg-gray-50">
                            <td class="py-4 px-4">
                                <div class="flex items-start">
                                    <?php if ($activity['photo'] && file_exists($activity['photo'])): ?>
                                    <div class="w-12 h-12 rounded-lg overflow-hidden mr-3 flex-shrink-0">
                                        <img src="<?php echo $activity['photo']; ?>" 
                                             alt="<?php echo htmlspecialchars($activity['activity_name']); ?>" 
                                             class="w-full h-full object-cover">
                                    </div>
                                    <?php endif; ?>
                                    <div>
                                        <div class="font-semibold text-gray-800"><?php echo htmlspecialchars($activity['activity_name']); ?></div>
                                        <?php if ($activity['venue']): ?>
                                        <div class="text-sm text-gray-600">
                                            <i class="fas fa-map-marker-alt mr-1"></i>
                                            <?php echo htmlspecialchars($activity['venue']); ?>
                                        </div>
                                        <?php endif; ?>
                                        <?php if ($activity['description']): ?>
                                        <div class="text-sm text-gray-500 mt-1 truncate max-w-xs">
                                            <?php echo htmlspecialchars(substr($activity['description'], 0, 100)); ?>...
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                            <td class="py-4 px-4">
                                <div class="font-medium text-gray-800"><?php echo formatDate($activity['activity_date']); ?></div>
                                <div class="text-sm text-gray-600"><?php echo formatTime($activity['activity_time']); ?></div>
                            </td>
                            <td class="py-4 px-4">
                                <?php if ($activity['campus_name']): ?>
                                <span class="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-semibold">
                                    <?php echo htmlspecialchars($activity['campus_name']); ?>
                                </span>
                                <?php else: ?>
                                <span class="px-3 py-1 bg-gray-100 text-gray-800 rounded-full text-sm font-semibold">
                                    All Campuses
                                </span>
                                <?php endif; ?>
                            </td>
                            <td class="py-4 px-4">
                                <?php if ($activity['mandatory'] == 1): ?>
                                <span class="px-3 py-1 bg-red-100 text-red-800 rounded-full text-sm font-semibold">
                                    <i class="fas fa-exclamation-circle mr-1"></i> Mandatory
                                </span>
                                <div class="mt-1 text-xs text-gray-500">
                                    <?php echo ucfirst($activity['activity_type']); ?> | 
                                    <?php echo $activity['scan_frequency']; ?> Scan
                                </div>
                                <?php else: ?>
                                <span class="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-semibold">
                                    <i class="fas fa-check-circle mr-1"></i> Optional
                                </span>
                                <?php endif; ?>
                            </td>
                            <td class="py-4 px-4">
                                <?php if ($activity['mandatory'] == 1): ?>
                                <div class="space-y-1">
                                    <div class="flex items-center justify-between text-xs">
                                        <span class="text-gray-600">Absent:</span>
                                        <span class="font-semibold text-red-600">₱<?php echo number_format($activity['absent_fine'], 2); ?></span>
                                    </div>
                                    <div class="flex items-center justify-between text-xs">
                                        <span class="text-gray-600">No Check-in:</span>
                                        <span class="font-semibold text-red-500">₱<?php echo number_format($activity['checkin_fine'], 2); ?></span>
                                    </div>
                                    <div class="flex items-center justify-between text-xs">
                                        <span class="text-gray-600">No Check-out:</span>
                                        <span class="font-semibold text-red-500">₱<?php echo number_format($activity['checkout_fine'], 2); ?></span>
                                    </div>
                                    <div class="flex items-center justify-between text-xs">
                                        <span class="text-gray-600">Late Arrival:</span>
                                        <span class="font-semibold text-yellow-600">₱<?php echo number_format($activity['late_checkin_fine'], 2); ?></span>
                                    </div>
                                    <div class="flex items-center justify-between text-xs">
                                        <span class="text-gray-600">Early Leave:</span>
                                        <span class="font-semibold text-orange-600">₱<?php echo number_format($activity['late_checkout_fine'], 2); ?></span>
                                    </div>
                                </div>
                                <?php else: ?>
                                <span class="text-sm text-gray-500 italic">No fines</span>
                                <?php endif; ?>
                            </td>
                            <td class="py-4 px-4">
                                <?php 
                                $status_color = [
                                    'upcoming' => 'bg-blue-100 text-blue-800',
                                    'ongoing' => 'bg-yellow-100 text-yellow-800',
                                    'completed' => 'bg-green-100 text-green-800',
                                    'cancelled' => 'bg-red-100 text-red-800'
                                ];
                                ?>
                                <span class="px-3 py-1 <?php echo $status_color[$activity['status']]; ?> rounded-full text-sm font-semibold">
                                    <?php echo ucfirst($activity['status']); ?>
                                </span>
                                <?php if ($activity['status'] === 'upcoming'): ?>
                                <div class="mt-1 text-xs text-gray-500">
                                    <?php 
                                    $days_left = floor((strtotime($activity['activity_date']) - time()) / (60 * 60 * 24));
                                    if ($days_left > 0) {
                                        echo $days_left . ' day' . ($days_left != 1 ? 's' : '') . ' left';
                                    } elseif ($days_left == 0) {
                                        echo 'Today';
                                    } else {
                                        echo 'Past due';
                                    }
                                    ?>
                                </div>
                                <?php endif; ?>
                            </td>
                            <td class="py-4 px-4">
                                <div class="text-sm text-gray-800"><?php echo htmlspecialchars($activity['created_by_name']); ?></div>
                                <div class="text-xs text-gray-500"><?php echo formatDate($activity['created_at'], 'M j, Y'); ?></div>
                            </td>
                            <td class="py-4 px-4">
                                <div class="flex space-x-2">
                                    <a href="activity_details.php?id=<?php echo $activity['activity_id']; ?>" 
                                       class="px-3 py-1 bg-blue-100 text-blue-800 hover:bg-blue-200 rounded text-sm transition-colors"
                                       title="View Details">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="attendance_records.php?activity=<?php echo $activity['activity_id']; ?>" 
                                       class="px-3 py-1 bg-green-100 text-green-800 hover:bg-green-200 rounded text-sm transition-colors"
                                       title="Attendance">
                                        <i class="fas fa-clipboard-list"></i>
                                    </a>
                                    <a href="fines.php?activity=<?php echo $activity['activity_id']; ?>" 
                                       class="px-3 py-1 bg-red-100 text-red-800 hover:bg-red-200 rounded text-sm transition-colors"
                                       title="Fines">
                                        <i class="fas fa-money-bill-wave"></i>
                                    </a>
                                    <?php if ($user_type === 'admin' || $activity['created_by'] == $_SESSION['user_id']): ?>
                                    <a href="edit_activity.php?id=<?php echo $activity['activity_id']; ?>" 
                                       class="px-3 py-1 bg-yellow-100 text-yellow-800 hover:bg-yellow-200 rounded text-sm transition-colors"
                                       title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <?php endif; ?>
                                    <?php if ($user_type === 'admin'): ?>
                                    <button onclick="deleteActivity(<?php echo $activity['activity_id']; ?>)" 
                                            class="px-3 py-1 bg-red-100 text-red-800 hover:bg-red-200 rounded text-sm transition-colors"
                                            title="Delete">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
            <a href="scan_attendance.php" class="p-6 bg-gradient-to-r from-purple-50 to-indigo-50 border border-purple-200 rounded-xl hover:from-purple-100 hover:to-indigo-100 transition-all">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mr-4">
                        <i class="fas fa-qrcode text-purple-600 text-xl"></i>
                    </div>
                    <div>
                        <h3 class="font-semibold text-gray-800">Scan Attendance</h3>
                        <p class="text-sm text-gray-600">Start scanning for current activity</p>
                    </div>
                </div>
            </a>
            
            <a href="fines.php" class="p-6 bg-gradient-to-r from-red-50 to-rose-50 border border-red-200 rounded-xl hover:from-red-100 hover:to-rose-100 transition-all">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mr-4">
                        <i class="fas fa-money-bill-wave text-red-600 text-xl"></i>
                    </div>
                    <div>
                        <h3 class="font-semibold text-gray-800">Manage Fines</h3>
                        <p class="text-sm text-gray-600">View and process fines</p>
                    </div>
                </div>
            </a>
            
            <a href="reports.php" class="p-6 bg-gradient-to-r from-blue-50 to-cyan-50 border border-blue-200 rounded-xl hover:from-blue-100 hover:to-cyan-100 transition-all">
                <div class="flex items-center">
                    <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mr-4">
                        <i class="fas fa-chart-bar text-blue-600 text-xl"></i>
                    </div>
                    <div>
                        <h3 class="font-semibold text-gray-800">Generate Reports</h3>
                        <p class="text-sm text-gray-600">Attendance and financial reports</p>
                    </div>
                </div>
            </a>
        </div>
    </div>

    <script>
        // Initialize DataTable
        $(document).ready(function() {
            $('#activitiesTable').DataTable({
                "pageLength": 25,
                "order": [[1, 'desc']], // Sort by date
                "language": {
                    "search": "Search activities:",
                    "lengthMenu": "Show _MENU_ activities per page",
                    "info": "Showing _START_ to _END_ of _TOTAL_ activities",
                    "paginate": {
                        "first": "First",
                        "last": "Last",
                        "next": "Next",
                        "previous": "Previous"
                    }
                }
            });
        });
        
        function exportActivities() {
            window.open('export_activities.php', '_blank');
        }
        
        function deleteActivity(activityId) {
            if (confirm('Are you sure you want to delete this activity? This will also delete all attendance records and fines associated with it.')) {
                window.location.href = 'delete_activity.php?id=' + activityId;
            }
        }
        
        // Add tooltips
        $(document).ready(function() {
            $('[title]').tooltip({
                trigger: 'hover'
            });
        });
    </script>
</body>
</html>