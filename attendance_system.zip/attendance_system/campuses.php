<?php
session_start();
require_once 'db.php';

// Check authentication
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: login.php');
    exit();
}

$user_name = $_SESSION['full_name'];

// Handle actions (add, edit, delete, toggle status)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_campus'])) {
        $campus_name = trim($_POST['campus_name']);
        $campus_code = trim($_POST['campus_code']);
        $address = trim($_POST['address']);
        $contact_person = trim($_POST['contact_person']);
        $contact_number = trim($_POST['contact_number']);
        $fines_per_absence = floatval($_POST['fines_per_absence']);
        
        // Validate
        if (empty($campus_name) || empty($campus_code)) {
            $error = "Campus name and code are required!";
        } else {
            // Check if campus code already exists
            $check = $conn->prepare("SELECT campus_id FROM campuses WHERE campus_code = ?");
            $check->bind_param("s", $campus_code);
            $check->execute();
            $check->store_result();
            
            if ($check->num_rows > 0) {
                $error = "Campus code already exists!";
            } else {
                $stmt = $conn->prepare("INSERT INTO campuses (campus_name, campus_code, address, contact_person, contact_number, fines_per_absence, status, created_at) VALUES (?, ?, ?, ?, ?, ?, 'active', NOW())");
                $stmt->bind_param("sssssd", $campus_name, $campus_code, $address, $contact_person, $contact_number, $fines_per_absence);
                
                if ($stmt->execute()) {
                    $success = "Campus added successfully!";
                } else {
                    $error = "Failed to add campus. Please try again.";
                }
            }
        }
    } elseif (isset($_POST['update_campus'])) {
        $campus_id = intval($_POST['campus_id']);
        $campus_name = trim($_POST['campus_name']);
        $address = trim($_POST['address']);
        $contact_person = trim($_POST['contact_person']);
        $contact_number = trim($_POST['contact_number']);
        $fines_per_absence = floatval($_POST['fines_per_absence']);
        $status = $_POST['status'];
        
        $stmt = $conn->prepare("UPDATE campuses SET campus_name = ?, address = ?, contact_person = ?, contact_number = ?, fines_per_absence = ?, status = ? WHERE campus_id = ?");
        $stmt->bind_param("ssssdsi", $campus_name, $address, $contact_person, $contact_number, $fines_per_absence, $status, $campus_id);
        
        if ($stmt->execute()) {
            $success = "Campus updated successfully!";
        } else {
            $error = "Failed to update campus.";
        }
    } elseif (isset($_POST['delete_campus'])) {
        $campus_id = intval($_POST['campus_id']);
        
        // Check if campus has users or students
        $check_users = $conn->prepare("SELECT COUNT(*) as user_count FROM users WHERE campus_id = ?");
        $check_users->bind_param("i", $campus_id);
        $check_users->execute();
        $user_count = $check_users->get_result()->fetch_assoc()['user_count'];
        
        $check_students = $conn->prepare("SELECT COUNT(*) as student_count FROM students WHERE campus_id = ?");
        $check_students->bind_param("i", $campus_id);
        $check_students->execute();
        $student_count = $check_students->get_result()->fetch_assoc()['student_count'];
        
        if ($user_count > 0 || $student_count > 0) {
            $error = "Cannot delete campus. There are users or students assigned to this campus.";
        } else {
            $stmt = $conn->prepare("DELETE FROM campuses WHERE campus_id = ?");
            $stmt->bind_param("i", $campus_id);
            
            if ($stmt->execute()) {
                $success = "Campus deleted successfully!";
            } else {
                $error = "Failed to delete campus.";
            }
        }
    }
}

// Get campuses with statistics
$campuses = [];
$result = $conn->query("
    SELECT c.*, 
           COALESCE(u.user_count, 0) as user_count,
           COALESCE(s.student_count, 0) as student_count,
           COALESCE(a.activity_count, 0) as activity_count
    FROM campuses c
    LEFT JOIN (
        SELECT campus_id, COUNT(*) as user_count 
        FROM users 
        WHERE user_type = 'coordinator' 
        GROUP BY campus_id
    ) u ON c.campus_id = u.campus_id
    LEFT JOIN (
        SELECT campus_id, COUNT(*) as student_count 
        FROM students 
        GROUP BY campus_id
    ) s ON c.campus_id = s.campus_id
    LEFT JOIN (
        SELECT campus_id, COUNT(*) as activity_count 
        FROM activities 
        GROUP BY campus_id
    ) a ON c.campus_id = a.campus_id
    ORDER BY c.campus_name
");

while ($row = $result->fetch_assoc()) {
    $campuses[] = $row;
}

// Get overall statistics
$stats = $conn->query("
    SELECT 
        COUNT(*) as total_campuses,
        SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active_campuses,
        SUM(CASE WHEN status = 'inactive' THEN 1 ELSE 0 END) as inactive_campuses,
        (SELECT COUNT(*) FROM users WHERE user_type = 'coordinator') as total_coordinators,
        (SELECT COUNT(*) FROM students) as total_students
    FROM campuses
")->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Campuses | Multi-Campus Attendance</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .campus-card {
            transition: all 0.3s ease;
        }
        .campus-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
        }
        .status-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }
        .modal-content {
            background-color: white;
            margin: 5% auto;
            padding: 0;
            border-radius: 12px;
            max-width: 500px;
            animation: modalSlideIn 0.3s ease-out;
        }
        @keyframes modalSlideIn {
            from { transform: translateY(-50px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
    <!-- Navigation -->
    <nav class="bg-gradient-to-r from-purple-800 to-indigo-900 text-white shadow-lg">
        <div class="container mx-auto px-4 py-3">
            <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div class="flex items-center space-x-4">
                    <a href="admin_dashboard.php" 
                       class="flex items-center hover:text-purple-200 transition-colors">
                        <i class="fas fa-arrow-left mr-2"></i> Back to Dashboard
                    </a>
                    <div class="flex items-center space-x-4">
                        <h1 class="text-xl font-bold">
                            <i class="fas fa-university mr-2"></i> Manage Campuses
                        </h1>
                        <span class="text-xs bg-white/20 px-2 py-1 rounded-full">Admin Panel</span>
                    </div>
                </div>
                <div class="flex items-center space-x-4">
                    <span class="text-sm">
                        <i class="fas fa-user-shield mr-1"></i> <?php echo htmlspecialchars($user_name); ?>
                    </span>
                    <span class="text-sm text-purple-300">|</span>
                    <a href="logout.php" class="text-sm hover:text-purple-200 transition-colors">
                        <i class="fas fa-sign-out-alt mr-1"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-8">
        <div class="max-w-7xl mx-auto">
            <!-- Header -->
            <div class="mb-8">
                <h1 class="text-4xl font-bold text-gray-800 mb-3">Campus Management</h1>
                <p class="text-gray-600">Manage all 7 campuses of the Multi-Campus Attendance System</p>
            </div>

            <?php if (isset($success)): ?>
                <div class="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-center text-green-700">
                    <i class="fas fa-check-circle mr-3"></i>
                    <span><?php echo htmlspecialchars($success); ?></span>
                </div>
            <?php endif; ?>

            <?php if (isset($error)): ?>
                <div class="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center text-red-700">
                    <i class="fas fa-exclamation-circle mr-3"></i>
                    <span><?php echo htmlspecialchars($error); ?></span>
                </div>
            <?php endif; ?>

            <!-- Statistics Cards -->
            <div class="grid grid-cols-1 md:grid-cols-5 gap-6 mb-8">
                <div class="bg-white rounded-xl shadow-lg p-6">
                    <div class="flex items-center">
                        <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mr-4">
                            <i class="fas fa-university text-purple-600 text-xl"></i>
                        </div>
                        <div>
                            <p class="text-sm text-gray-600">Total Campuses</p>
                            <p class="text-2xl font-bold text-gray-800"><?php echo $stats['total_campuses']; ?></p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-xl shadow-lg p-6">
                    <div class="flex items-center">
                        <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mr-4">
                            <i class="fas fa-check-circle text-green-600 text-xl"></i>
                        </div>
                        <div>
                            <p class="text-sm text-gray-600">Active</p>
                            <p class="text-2xl font-bold text-gray-800"><?php echo $stats['active_campuses']; ?></p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-xl shadow-lg p-6">
                    <div class="flex items-center">
                        <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mr-4">
                            <i class="fas fa-user-tie text-blue-600 text-xl"></i>
                        </div>
                        <div>
                            <p class="text-sm text-gray-600">Coordinators</p>
                            <p class="text-2xl font-bold text-gray-800"><?php echo $stats['total_coordinators']; ?></p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-xl shadow-lg p-6">
                    <div class="flex items-center">
                        <div class="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mr-4">
                            <i class="fas fa-user-graduate text-orange-600 text-xl"></i>
                        </div>
                        <div>
                            <p class="text-sm text-gray-600">Students</p>
                            <p class="text-2xl font-bold text-gray-800"><?php echo $stats['total_students']; ?></p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-xl shadow-lg p-6">
                    <div class="flex items-center">
                        <button onclick="openAddCampusModal()" 
                                class="w-full h-full flex items-center justify-center bg-gradient-to-r from-green-500 to-emerald-600 text-white rounded-lg hover:from-green-600 hover:to-emerald-700 transition-colors">
                            <div class="text-center">
                                <i class="fas fa-plus-circle text-2xl mb-2"></i>
                                <p class="text-sm font-semibold">Add Campus</p>
                            </div>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Campuses Grid -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                <?php foreach ($campuses as $campus): ?>
                <div class="campus-card bg-white rounded-xl shadow-lg overflow-hidden">
                    <!-- Campus Header -->
                    <div class="p-6 border-b">
                        <div class="flex items-center justify-between mb-4">
                            <div class="flex items-center">
                                <div class="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center mr-4">
                                    <i class="fas fa-school text-white text-xl"></i>
                                </div>
                                <div>
                                    <h3 class="text-xl font-bold text-gray-800"><?php echo htmlspecialchars($campus['campus_name']); ?></h3>
                                    <p class="text-sm text-gray-600">Code: <?php echo htmlspecialchars($campus['campus_code']); ?></p>
                                </div>
                            </div>
                            <span class="status-badge <?php echo $campus['status'] === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                                <?php echo ucfirst($campus['status']); ?>
                            </span>
                        </div>
                        
                        <p class="text-gray-600 text-sm mb-4">
                            <?php echo htmlspecialchars($campus['address'] ?: 'No address provided'); ?>
                        </p>
                        
                        <div class="flex items-center text-sm text-gray-500 mb-2">
                            <i class="fas fa-user mr-2"></i>
                            <span><?php echo htmlspecialchars($campus['contact_person'] ?: 'Not specified'); ?></span>
                        </div>
                        <div class="flex items-center text-sm text-gray-500">
                            <i class="fas fa-phone mr-2"></i>
                            <span><?php echo htmlspecialchars($campus['contact_number'] ?: 'Not specified'); ?></span>
                        </div>
                    </div>
                    
                    <!-- Campus Stats -->
                    <div class="p-6 bg-gray-50">
                        <div class="grid grid-cols-3 gap-4 text-center">
                            <div>
                                <p class="text-2xl font-bold text-blue-600"><?php echo $campus['user_count']; ?></p>
                                <p class="text-xs text-gray-600">Coordinators</p>
                            </div>
                            <div>
                                <p class="text-2xl font-bold text-green-600"><?php echo $campus['student_count']; ?></p>
                                <p class="text-xs text-gray-600">Students</p>
                            </div>
                            <div>
                                <p class="text-2xl font-bold text-purple-600"><?php echo $campus['activity_count']; ?></p>
                                <p class="text-xs text-gray-600">Activities</p>
                            </div>
                        </div>
                        
                        <div class="mt-4 pt-4 border-t border-gray-200">
                            <p class="text-sm text-gray-600 mb-2">Fine per Absence:</p>
                            <p class="text-lg font-bold text-red-600">₱<?php echo number_format($campus['fines_per_absence'], 2); ?></p>
                        </div>
                    </div>
                    
                    <!-- Campus Actions -->
                    <div class="p-4 bg-white border-t">
                        <div class="flex justify-between">
                            <button onclick="openEditCampusModal(<?php echo $campus['campus_id']; ?>)" 
                                    class="px-4 py-2 bg-blue-600 text-white text-sm font-semibold rounded-lg hover:bg-blue-700 transition-colors">
                                <i class="fas fa-edit mr-1"></i> Edit
                            </button>
                            
                            <form method="POST" action="" class="inline" onsubmit="return confirm('Are you sure you want to delete this campus? This action cannot be undone!');">
                                <input type="hidden" name="campus_id" value="<?php echo $campus['campus_id']; ?>">
                                <button type="submit" name="delete_campus" 
                                        class="px-4 py-2 bg-red-600 text-white text-sm font-semibold rounded-lg hover:bg-red-700 transition-colors">
                                    <i class="fas fa-trash mr-1"></i> Delete
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- Campuses Table (Alternative View) -->
            <div class="bg-white rounded-xl shadow-lg overflow-hidden mb-8">
                <div class="p-6 border-b">
                    <h2 class="text-xl font-bold text-gray-800">Campuses List View</h2>
                    <p class="text-gray-600 text-sm">Detailed view of all campuses</p>
                </div>
                
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Campus</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Contact Info</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Statistics</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fine Rate</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($campuses as $campus): ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-6 py-4">
                                    <div class="flex items-center">
                                        <div class="flex-shrink-0 h-10 w-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                                            <i class="fas fa-school text-white"></i>
                                        </div>
                                        <div class="ml-4">
                                            <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($campus['campus_name']); ?></div>
                                            <div class="text-sm text-gray-500"><?php echo htmlspecialchars($campus['campus_code']); ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-4">
                                    <div class="text-sm text-gray-900"><?php echo htmlspecialchars($campus['contact_person']); ?></div>
                                    <div class="text-sm text-gray-500"><?php echo htmlspecialchars($campus['contact_number']); ?></div>
                                </td>
                                <td class="px-6 py-4">
                                    <div class="flex space-x-4">
                                        <div class="text-center">
                                            <div class="text-lg font-bold text-blue-600"><?php echo $campus['user_count']; ?></div>
                                            <div class="text-xs text-gray-500">Coords</div>
                                        </div>
                                        <div class="text-center">
                                            <div class="text-lg font-bold text-green-600"><?php echo $campus['student_count']; ?></div>
                                            <div class="text-xs text-gray-500">Students</div>
                                        </div>
                                        <div class="text-center">
                                            <div class="text-lg font-bold text-purple-600"><?php echo $campus['activity_count']; ?></div>
                                            <div class="text-xs text-gray-500">Activities</div>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-4">
                                    <div class="text-lg font-bold text-red-600">₱<?php echo number_format($campus['fines_per_absence'], 2); ?></div>
                                    <div class="text-xs text-gray-500">per absence</div>
                                </td>
                                <td class="px-6 py-4">
                                    <span class="status-badge <?php echo $campus['status'] === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                                        <?php echo ucfirst($campus['status']); ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4">
                                    <div class="flex space-x-2">
                                        <button onclick="openEditCampusModal(<?php echo $campus['campus_id']; ?>)" 
                                                class="px-3 py-1 bg-blue-600 text-white text-sm font-semibold rounded-lg hover:bg-blue-700 transition-colors">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <form method="POST" action="" class="inline" onsubmit="return confirm('Are you sure you want to delete this campus? This action cannot be undone!');">
                                            <input type="hidden" name="campus_id" value="<?php echo $campus['campus_id']; ?>">
                                            <button type="submit" name="delete_campus" 
                                                    class="px-3 py-1 bg-red-600 text-white text-sm font-semibold rounded-lg hover:bg-red-700 transition-colors">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- System Information -->
            <div class="bg-gradient-to-r from-blue-50 to-cyan-50 p-6 rounded-2xl border border-blue-200">
                <h3 class="text-xl font-bold text-blue-800 mb-4 flex items-center">
                    <i class="fas fa-info-circle text-blue-600 mr-3"></i> Campus Management Guidelines
                </h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="p-4 bg-white rounded-lg border border-blue-100">
                        <h4 class="font-semibold text-blue-700 mb-2 flex items-center">
                            <i class="fas fa-exclamation-triangle mr-2"></i> Important Notes
                        </h4>
                        <ul class="text-sm text-gray-600 space-y-2">
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-green-500 mt-0.5 mr-2"></i>
                                <span>Each campus must have a unique campus code</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-green-500 mt-0.5 mr-2"></i>
                                <span>Cannot delete campuses with assigned users or students</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-green-500 mt-0.5 mr-2"></i>
                                <span>Deactivated campuses won't appear in dropdowns</span>
                            </li>
                        </ul>
                    </div>
                    
                    <div class="p-4 bg-white rounded-lg border border-blue-100">
                        <h4 class="font-semibold text-blue-700 mb-2 flex items-center">
                            <i class="fas fa-money-bill-wave mr-2"></i> Fine Settings
                        </h4>
                        <ul class="text-sm text-gray-600 space-y-2">
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-green-500 mt-0.5 mr-2"></i>
                                <span>Default fine per absence is ₱100.00</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-green-500 mt-0.5 mr-2"></i>
                                <span>Fine rate can be customized per campus</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-green-500 mt-0.5 mr-2"></i>
                                <span>Changes affect all students in the campus</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Campus Modal -->
    <div id="addCampusModal" class="modal">
        <div class="modal-content">
            <div class="p-6 border-b">
                <h2 class="text-xl font-bold text-gray-800">Add New Campus</h2>
                <button onclick="closeModal('addCampusModal')" class="absolute top-4 right-4 text-gray-400 hover:text-gray-600">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST" action="" id="addCampusForm">
                <div class="p-6 space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Campus Name *</label>
                        <input type="text" name="campus_name" required
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Campus Code *</label>
                        <input type="text" name="campus_code" required maxlength="10"
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                               placeholder="e.g., ACC, ISU">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Address</label>
                        <textarea name="address" rows="2"
                                  class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"></textarea>
                    </div>
                    
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Contact Person</label>
                            <input type="text" name="contact_person"
                                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Contact Number</label>
                            <input type="tel" name="contact_number"
                                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                   placeholder="0912 345 6789">
                        </div>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Fine per Absence (₱)</label>
                        <input type="number" name="fines_per_absence" step="0.01" min="0" value="100.00"
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    </div>
                </div>
                
                <div class="p-6 border-t bg-gray-50 flex justify-end space-x-3">
                    <button type="button" onclick="closeModal('addCampusModal')"
                            class="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
                        Cancel
                    </button>
                    <button type="submit" name="add_campus"
                            class="px-4 py-2 bg-gradient-to-r from-green-500 to-emerald-600 text-white rounded-lg font-semibold hover:from-green-600 hover:to-emerald-700 transition-colors">
                        Add Campus
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit Campus Modal -->
    <div id="editCampusModal" class="modal">
        <div class="modal-content">
            <div class="p-6 border-b">
                <h2 class="text-xl font-bold text-gray-800">Edit Campus</h2>
                <button onclick="closeModal('editCampusModal')" class="absolute top-4 right-4 text-gray-400 hover:text-gray-600">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST" action="" id="editCampusForm">
                <input type="hidden" name="campus_id" id="edit_campus_id">
                
                <div class="p-6 space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Campus Name *</label>
                        <input type="text" name="campus_name" id="edit_campus_name" required
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Campus Code</label>
                        <input type="text" id="edit_campus_code" disabled
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-50">
                        <p class="text-xs text-gray-500 mt-1">Campus code cannot be changed</p>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Address</label>
                        <textarea name="address" id="edit_address" rows="2"
                                  class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"></textarea>
                    </div>
                    
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Contact Person</label>
                            <input type="text" name="contact_person" id="edit_contact_person"
                                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Contact Number</label>
                            <input type="tel" name="contact_number" id="edit_contact_number"
                                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                        </div>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Fine per Absence (₱)</label>
                        <input type="number" name="fines_per_absence" id="edit_fines" step="0.01" min="0"
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Status</label>
                        <select name="status" id="edit_status"
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                </div>
                
                <div class="p-6 border-t bg-gray-50 flex justify-end space-x-3">
                    <button type="button" onclick="closeModal('editCampusModal')"
                            class="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
                        Cancel
                    </button>
                    <button type="submit" name="update_campus"
                            class="px-4 py-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg font-semibold hover:from-blue-600 hover:to-purple-700 transition-colors">
                        Update Campus
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Modal functions
        function openAddCampusModal() {
            document.getElementById('addCampusModal').style.display = 'block';
        }

        function openEditCampusModal(campusId) {
            // In a real application, you would fetch campus data via AJAX
            // For now, we'll redirect to a separate edit page or use the current data
            window.location.href = 'edit_campus.php?id=' + campusId;
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            if (event.target.className === 'modal') {
                event.target.style.display = 'none';
            }
        }

        // Form validation
        document.getElementById('addCampusForm').addEventListener('submit', function(e) {
            const campusCode = this.querySelector('[name="campus_code"]');
            if (campusCode.value.trim().length > 10) {
                e.preventDefault();
                alert('Campus code must be 10 characters or less.');
                campusCode.focus();
            }
        });

        // Auto-generate campus code from name
        document.querySelector('[name="campus_name"]').addEventListener('blur', function() {
            const campusCodeField = document.querySelector('[name="campus_code"]');
            if (campusCodeField.value === '') {
                const name = this.value.trim();
                if (name.length > 3) {
                    // Get first 3 letters in uppercase
                    campusCodeField.value = name.substring(0, 3).toUpperCase();
                }
            }
        });
    </script>
</body>
</html>