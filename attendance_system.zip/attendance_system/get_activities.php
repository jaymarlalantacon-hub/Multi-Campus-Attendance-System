<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_type']) || !in_array($_SESSION['user_type'], ['admin','coordinator'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$campus_id = isset($_GET['campus_id']) ? intval($_GET['campus_id']) : 0;

if (!$campus_id) {
    echo json_encode(['success' => false, 'message' => 'Campus ID required']);
    exit();
}

// Get current date
$current_date = date('Y-m-d');

// Get upcoming and ongoing activities for the selected campus
$stmt = $conn->prepare("SELECT activity_id, activity_name, description, activity_date, activity_time, venue 
                       FROM activities 
                       WHERE campus_id = ? 
                       AND status IN ('upcoming', 'ongoing') 
                       AND activity_date >= ?
                       ORDER BY activity_date, activity_time");
$stmt->bind_param("is", $campus_id, $current_date);
$stmt->execute();
$result = $stmt->get_result();
$activities = [];

while ($row = $result->fetch_assoc()) {
    $activities[] = [
        'activity_id' => $row['activity_id'],
        'activity_name' => $row['activity_name'],
        'description' => $row['description'],
        'activity_date' => $row['activity_date'],
        'activity_time' => $row['activity_time'],
        'venue' => $row['venue']
    ];
}

echo json_encode(['success' => true, 'activities' => $activities]);
$conn->close();
?>