<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['full_name'] ?? 'Unknown User';
$user_type = $_SESSION['user_type'] ?? 'admin';

// Get user's campus info
$user_query = "SELECT u.*, c.campus_name 
               FROM users u 
               LEFT JOIN campuses c ON u.campus_id = c.campus_id 
               WHERE u.user_id = ?";
$user_stmt = $conn->prepare($user_query);
$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();
$user_result = $user_stmt->get_result();
$user_data = $user_result->fetch_assoc();

$user_campus_id = $user_data['campus_id'] ?? null;
$user_campus_name = $user_data['campus_name'] ?? 'System Admin';

// Get all campuses for selection (if admin) or just user's campus
$campuses = [];
if ($user_campus_id === null) {
    // Admin can see all campuses
    $campus_query = "SELECT * FROM campuses WHERE status = 'active' ORDER BY campus_name";
    $campus_result = $conn->query($campus_query);
    while ($campus = $campus_result->fetch_assoc()) {
        $campuses[] = $campus;
    }
} else {
    // Regular user can only see their campus
    $campuses[] = [
        'campus_id' => $user_campus_id,
        'campus_name' => $user_campus_name
    ];
}

// Handle campus selection
$selected_campus = isset($_GET['campus']) ? intval($_GET['campus']) : ($user_campus_id ?? 1);
$selected_year = isset($_GET['year']) ? intval($_GET['year']) : date('Y');
$selected_month = isset($_GET['month']) ? intval($_GET['month']) : date('m');
$report_type = isset($_GET['type']) ? $_GET['type'] : 'fines'; // 'fines' or 'payments'

// Validate campus access
$has_access = false;
foreach ($campuses as $campus) {
    if ($campus['campus_id'] == $selected_campus) {
        $has_access = true;
        $selected_campus_name = $campus['campus_name'];
        break;
    }
}

if (!$has_access) {
    die("Access denied: You don't have permission to access this campus.");
}

// Get years with data - FIXED: Added table alias for created_at
$years_query = "SELECT DISTINCT YEAR(f.created_at) as year 
                FROM fines f
                JOIN students s ON f.student_id = s.student_id
                WHERE s.campus_id = ?
                UNION
                SELECT DISTINCT YEAR(fp.payment_date) as year 
                FROM fine_payments fp
                JOIN fines f ON fp.fine_id = f.fine_id
                JOIN students s ON f.student_id = s.student_id
                WHERE s.campus_id = ?
                ORDER BY year DESC";
$years_stmt = $conn->prepare($years_query);
$years_stmt->bind_param("ii", $selected_campus, $selected_campus);
$years_stmt->execute();
$years_result = $years_stmt->get_result();
$years = [];
while ($year = $years_result->fetch_assoc()) {
    $years[] = $year['year'];
}
if (empty($years)) {
    $years[] = date('Y');
}

// Months array
$months = [
    1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April',
    5 => 'May', 6 => 'June', 7 => 'July', 8 => 'August',
    9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'
];

// Get monthly statistics
$monthly_stats = [
    'total_fines' => 0,
    'total_fines_amount' => 0,
    'pending_fines' => 0,
    'pending_amount' => 0,
    'paid_fines' => 0,
    'paid_amount' => 0,
    'total_payments' => 0,
    'total_payments_amount' => 0,
    'cash_payments' => 0,
    'digital_payments' => 0
];

if ($selected_campus && $selected_year && $selected_month) {
    // Fines statistics for the month
    $stats_query = "SELECT 
                    COUNT(*) as total_fines,
                    COALESCE(SUM(f.amount), 0) as total_fines_amount,
                    COALESCE(SUM(CASE WHEN f.status IN ('pending', 'partial') THEN 1 ELSE 0 END), 0) as pending_fines,
                    COALESCE(SUM(CASE WHEN f.status IN ('pending', 'partial') THEN f.amount ELSE 0 END), 0) as pending_amount,
                    COALESCE(SUM(CASE WHEN f.status = 'paid' THEN 1 ELSE 0 END), 0) as paid_fines,
                    COALESCE(SUM(CASE WHEN f.status = 'paid' THEN f.amount ELSE 0 END), 0) as paid_amount
                    FROM fines f
                    JOIN students s ON f.student_id = s.student_id
                    WHERE s.campus_id = ?
                    AND YEAR(f.created_at) = ?
                    AND MONTH(f.created_at) = ?";
    
    $stats_stmt = $conn->prepare($stats_query);
    $stats_stmt->bind_param("iii", $selected_campus, $selected_year, $selected_month);
    $stats_stmt->execute();
    $stats_result = $stats_stmt->get_result();
    $stats_row = $stats_result->fetch_assoc();
    
    if ($stats_row) {
        $monthly_stats = array_merge($monthly_stats, $stats_row);
    }
    
    // Payments statistics for the month
    $payments_query = "SELECT 
                      COUNT(*) as total_payments,
                      COALESCE(SUM(fp.amount_paid), 0) as total_payments_amount,
                      COALESCE(SUM(CASE WHEN fp.payment_method = 'cash' THEN 1 ELSE 0 END), 0) as cash_payments,
                      COALESCE(SUM(CASE WHEN fp.payment_method != 'cash' THEN 1 ELSE 0 END), 0) as digital_payments
                      FROM fine_payments fp
                      JOIN fines f ON fp.fine_id = f.fine_id
                      JOIN students s ON f.student_id = s.student_id
                      WHERE s.campus_id = ?
                      AND YEAR(fp.payment_date) = ?
                      AND MONTH(fp.payment_date) = ?";
    
    $payments_stmt = $conn->prepare($payments_query);
    $payments_stmt->bind_param("iii", $selected_campus, $selected_year, $selected_month);
    $payments_stmt->execute();
    $payments_result = $payments_stmt->get_result();
    $payments_row = $payments_result->fetch_assoc();
    
    if ($payments_row) {
        $monthly_stats = array_merge($monthly_stats, $payments_row);
    }
}

// Get fines data for the month
$fines_data = [];
$fines_query = "SELECT f.*, s.student_number, s.full_name, s.course_year, s.section,
                a.activity_name, c.campus_name,
                COALESCE((SELECT SUM(fp.amount_paid) FROM fine_payments fp WHERE fp.fine_id = f.fine_id), 0) as paid_amount
                FROM fines f
                JOIN students s ON f.student_id = s.student_id
                LEFT JOIN activities a ON f.activity_id = a.activity_id
                LEFT JOIN campuses c ON s.campus_id = c.campus_id
                WHERE s.campus_id = ?
                AND YEAR(f.created_at) = ?
                AND MONTH(f.created_at) = ?
                ORDER BY f.created_at DESC";

$fines_stmt = $conn->prepare($fines_query);
$fines_stmt->bind_param("iii", $selected_campus, $selected_year, $selected_month);
$fines_stmt->execute();
$fines_result = $fines_stmt->get_result();

while ($fine = $fines_result->fetch_assoc()) {
    $fines_data[] = $fine;
}

// Get payments data for the month
$payments_data = [];
$payments_query = "SELECT fp.*, f.amount as fine_amount, f.reason,
                  s.student_number, s.full_name,
                  u.full_name as received_by_name,
                  a.activity_name
                  FROM fine_payments fp
                  JOIN fines f ON fp.fine_id = f.fine_id
                  JOIN students s ON f.student_id = s.student_id
                  LEFT JOIN users u ON fp.received_by = u.user_id
                  LEFT JOIN activities a ON f.activity_id = a.activity_id
                  WHERE s.campus_id = ?
                  AND YEAR(fp.payment_date) = ?
                  AND MONTH(fp.payment_date) = ?
                  ORDER BY fp.payment_date DESC, fp.payment_id DESC";

$payments_stmt = $conn->prepare($payments_query);
$payments_stmt->bind_param("iii", $selected_campus, $selected_year, $selected_month);
$payments_stmt->execute();
$payments_result = $payments_stmt->get_result();

while ($payment = $payments_result->fetch_assoc()) {
    $payments_data[] = $payment;
}

// Get daily breakdown
$daily_breakdown = [];
$daily_query = "SELECT 
                DATE(fp.payment_date) as payment_day,
                COUNT(fp.payment_id) as payment_count,
                COALESCE(SUM(fp.amount_paid), 0) as total_amount
                FROM fine_payments fp
                JOIN fines f ON fp.fine_id = f.fine_id
                JOIN students s ON f.student_id = s.student_id
                WHERE s.campus_id = ?
                AND YEAR(fp.payment_date) = ?
                AND MONTH(fp.payment_date) = ?
                GROUP BY DATE(fp.payment_date)
                ORDER BY payment_day DESC";

$daily_stmt = $conn->prepare($daily_query);
$daily_stmt->bind_param("iii", $selected_campus, $selected_year, $selected_month);
$daily_stmt->execute();
$daily_result = $daily_stmt->get_result();

while ($day = $daily_result->fetch_assoc()) {
    $daily_breakdown[] = $day;
}

// Handle report download
if (isset($_GET['download']) && $_GET['download'] == 'pdf') {
    require_once __DIR__ . '/vendor/autoload.php'; // For TCPDF or similar
    
    // Generate PDF report
    generatePDFReport($selected_campus_name, $selected_year, $selected_month, 
                     $monthly_stats, $fines_data, $payments_data, $daily_breakdown);
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monthly Report | <?php echo $selected_campus_name; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --primary-color: #3b82f6;
            --secondary-color: #8b5cf6;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .card {
            background: white;
            border-radius: 1rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        
        .card:hover {
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
        }
        
        .campus-badge {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 0.25rem;
        }
        
        .stat-card {
            background: linear-gradient(135deg, #f6f9fc 0%, #edf2f7 100%);
            border-radius: 0.75rem;
            padding: 1.5rem;
            text-align: center;
        }
        
        .stat-value {
            font-size: 2.5rem;
            font-weight: 700;
            line-height: 1;
        }
        
        .stat-label {
            color: #6b7280;
            font-size: 0.875rem;
            margin-top: 0.5rem;
        }
        
        .btn {
            padding: 0.75rem 1.5rem;
            border-radius: 0.75rem;
            font-weight: 600;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(59, 130, 246, 0.3);
        }
        
        .btn-success {
            background: var(--success-color);
            color: white;
        }
        
        .btn-danger {
            background: var(--danger-color);
            color: white;
        }
        
        .tab {
            padding: 0.75rem 1.5rem;
            border-radius: 0.75rem;
            font-weight: 600;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        
        .tab.active {
            background: var(--primary-color);
            color: white;
        }
        
        .tab:hover:not(.active) {
            background: #f3f4f6;
        }
        
        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        
        .status-pending { background-color: #fee2e2; color: #991b1b; }
        .status-partial { background-color: #fef3c7; color: #92400e; }
        .status-paid { background-color: #d1fae5; color: #065f46; }
        
        .chart-container {
            position: relative;
            height: 300px;
            width: 100%;
        }
        
        .report-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            padding: 2rem;
            border-radius: 1rem 1rem 0 0;
        }
        
        .filter-card {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
    </style>
</head>
<body class="min-h-screen p-4 md:p-8">
    <div class="max-w-7xl mx-auto">
        <!-- Header -->
        <div class="card p-6 mb-8">
            <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h1 class="text-3xl font-bold text-gray-900 mb-2">
                        <i class="fas fa-chart-bar text-blue-600 mr-2"></i>Monthly Report
                    </h1>
                    <div class="flex flex-wrap items-center gap-2">
                        <span class="campus-badge">
                            <i class="fas fa-school"></i> <?php echo htmlspecialchars($selected_campus_name); ?>
                        </span>
                        <span class="px-3 py-1 bg-gray-100 text-gray-800 rounded-full text-sm font-medium">
                            <i class="fas fa-user mr-1"></i> <?php echo htmlspecialchars($user_name); ?>
                        </span>
                        <span class="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                            <i class="fas fa-shield-alt mr-1"></i> <?php echo ucfirst($user_type); ?>
                        </span>
                    </div>
                </div>
                <div class="flex flex-wrap gap-2">
                    <a href="admin_dashboard.php" class="btn">
                        <i class="fas fa-arrow-left"></i> Dashboard
                    </a>
                    <a href="scan_fines.php?campus=<?php echo $selected_campus; ?>" class="btn btn-primary">
                        <i class="fas fa-money-bill-wave"></i> Fines Management
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Campus Selection -->
        <?php if (count($campuses) > 1): ?>
        <div class="card p-6 mb-8">
            <h2 class="text-xl font-bold text-gray-800 mb-4 flex items-center">
                <i class="fas fa-school text-blue-600 mr-2"></i> Select Campus
            </h2>
            <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-7 gap-3">
                <?php foreach ($campuses as $campus): ?>
                <a href="monthly_report.php?campus=<?php echo $campus['campus_id']; ?>&year=<?php echo $selected_year; ?>&month=<?php echo $selected_month; ?>&type=<?php echo $report_type; ?>" 
                   class="p-4 bg-white rounded-lg shadow border border-gray-200 text-center hover:shadow-md transition-all <?php echo $selected_campus == $campus['campus_id'] ? 'border-blue-500 bg-blue-50' : ''; ?>">
                    <?php 
                    $campus_icons = [
                        'ACCESS' => 'fas fa-university',
                        'Isulan' => 'fas fa-school',
                        'Tacurong' => 'fas fa-building',
                        'Lutayan' => 'fas fa-landmark',
                        'Bagumbayan' => 'fas fa-archway',
                        'Palimbang' => 'fas fa-city',
                        'Kalamansig' => 'fas fa-place-of-worship'
                    ];
                    $icon = $campus_icons[$campus['campus_name']] ?? 'fas fa-school';
                    ?>
                    <div class="w-10 h-10 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center mx-auto mb-2">
                        <i class="<?php echo $icon; ?> text-white"></i>
                    </div>
                    <div class="font-semibold text-gray-800 truncate text-sm"><?php echo htmlspecialchars($campus['campus_name']); ?></div>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Report Type Tabs -->
        <div class="card p-6 mb-8">
            <div class="flex flex-wrap gap-2">
                <a href="monthly_report.php?campus=<?php echo $selected_campus; ?>&year=<?php echo $selected_year; ?>&month=<?php echo $selected_month; ?>&type=fines" 
                   class="tab <?php echo $report_type === 'fines' ? 'active' : ''; ?>">
                    <i class="fas fa-file-invoice-dollar mr-2"></i> Fines Report
                </a>
                <a href="monthly_report.php?campus=<?php echo $selected_campus; ?>&year=<?php echo $selected_year; ?>&month=<?php echo $selected_month; ?>&type=payments" 
                   class="tab <?php echo $report_type === 'payments' ? 'active' : ''; ?>">
                    <i class="fas fa-money-bill-wave mr-2"></i> Payments Report
                </a>
            </div>
        </div>
        
        <!-- Month/Year Selection -->
        <div class="card p-6 mb-8">
            <h2 class="text-xl font-bold text-gray-800 mb-4 flex items-center">
                <i class="fas fa-calendar-alt text-blue-600 mr-2"></i> Select Month & Year
            </h2>
            <form method="GET" class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <input type="hidden" name="campus" value="<?php echo $selected_campus; ?>">
                <input type="hidden" name="type" value="<?php echo $report_type; ?>">
                
                <div>
                    <label class="block mb-2 text-sm font-medium text-gray-700">Year</label>
                    <select name="year" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                        <?php for ($y = date('Y'); $y >= 2020; $y--): ?>
                        <option value="<?php echo $y; ?>" <?php echo $selected_year == $y ? 'selected' : ''; ?>>
                            <?php echo $y; ?>
                        </option>
                        <?php endfor; ?>
                    </select>
                </div>
                
                <div>
                    <label class="block mb-2 text-sm font-medium text-gray-700">Month</label>
                    <select name="month" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                        <?php foreach ($months as $key => $month): ?>
                        <option value="<?php echo $key; ?>" <?php echo $selected_month == $key ? 'selected' : ''; ?>>
                            <?php echo $month; ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="flex items-end">
                    <button type="submit" class="btn btn-primary w-full">
                        <i class="fas fa-search mr-2"></i> Generate Report
                    </button>
                </div>
            </form>
        </div>
        
        <!-- Report Header -->
        <div class="report-header card mb-8">
            <div class="flex flex-col md:flex-row justify-between items-center">
                <div>
                    <h2 class="text-2xl font-bold text-white mb-2">
                        Monthly Report - <?php echo $months[$selected_month]; ?> <?php echo $selected_year; ?>
                    </h2>
                    <p class="text-blue-100">
                        Campus: <?php echo htmlspecialchars($selected_campus_name); ?>
                    </p>
                </div>
                <div class="mt-4 md:mt-0">
                    <a href="monthly_report.php?campus=<?php echo $selected_campus; ?>&year=<?php echo $selected_year; ?>&month=<?php echo $selected_month; ?>&type=<?php echo $report_type; ?>&download=pdf" 
                       class="btn bg-white text-blue-600 hover:bg-blue-50">
                        <i class="fas fa-file-pdf mr-2"></i> Download PDF
                    </a>
                    <button onclick="printReport()" class="btn bg-white text-blue-600 hover:bg-blue-50 ml-2">
                        <i class="fas fa-print mr-2"></i> Print Report
                    </button>
                </div>
            </div>
        </div>
        
        <!-- Statistics Cards -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <?php if ($report_type === 'fines'): ?>
            <div class="stat-card">
                <div class="stat-value text-blue-600"><?php echo $monthly_stats['total_fines']; ?></div>
                <div class="stat-label">Total Fines Issued</div>
            </div>
            <div class="stat-card">
                <div class="stat-value text-green-600">₱<?php echo number_format($monthly_stats['total_fines_amount'], 2); ?></div>
                <div class="stat-label">Total Fines Amount</div>
            </div>
            <div class="stat-card">
                <div class="stat-value text-yellow-600"><?php echo $monthly_stats['pending_fines']; ?></div>
                <div class="stat-label">Pending Fines</div>
            </div>
            <div class="stat-card">
                <div class="stat-value text-red-600">₱<?php echo number_format($monthly_stats['pending_amount'], 2); ?></div>
                <div class="stat-label">Pending Amount</div>
            </div>
            <?php else: ?>
            <div class="stat-card">
                <div class="stat-value text-blue-600"><?php echo $monthly_stats['total_payments']; ?></div>
                <div class="stat-label">Total Payments</div>
            </div>
            <div class="stat-card">
                <div class="stat-value text-green-600">₱<?php echo number_format($monthly_stats['total_payments_amount'], 2); ?></div>
                <div class="stat-label">Total Collected</div>
            </div>
            <div class="stat-card">
                <div class="stat-value text-purple-600"><?php echo $monthly_stats['cash_payments']; ?></div>
                <div class="stat-label">Cash Payments</div>
            </div>
            <div class="stat-card">
                <div class="stat-value text-indigo-600"><?php echo $monthly_stats['digital_payments']; ?></div>
                <div class="stat-label">Digital Payments</div>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- Charts Section -->
        <?php if ($report_type === 'payments' && !empty($daily_breakdown)): ?>
        <div class="card p-6 mb-8">
            <h2 class="text-xl font-bold text-gray-800 mb-6 flex items-center">
                <i class="fas fa-chart-line text-green-600 mr-2"></i> Daily Collections
            </h2>
            <div class="chart-container">
                <canvas id="dailyChart"></canvas>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Data Tables -->
        <div class="card p-6">
            <?php if ($report_type === 'fines'): ?>
            <!-- Fines Report -->
            <div class="flex justify-between items-center mb-6">
                <h2 class="text-xl font-bold text-gray-800 flex items-center">
                    <i class="fas fa-file-invoice-dollar text-blue-600 mr-2"></i> Fines Details
                    <span class="ml-2 text-sm font-normal text-gray-500">(<?php echo count($fines_data); ?> records)</span>
                </h2>
                <div class="text-sm text-gray-600">
                    Generated on: <?php echo date('F j, Y, g:i a'); ?>
                </div>
            </div>
            
            <?php if (!empty($fines_data)): ?>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead>
                        <tr class="bg-gray-50 border-b border-gray-200">
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Date</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Student</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Activity</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Amount</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Status</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Reason</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($fines_data as $fine): ?>
                        <?php 
                        $remaining = $fine['amount'] - ($fine['paid_amount'] ?? 0);
                        ?>
                        <tr class="border-b border-gray-100 hover:bg-gray-50">
                            <td class="py-3 px-4 text-sm text-gray-600">
                                <?php echo date('M d, Y', strtotime($fine['created_at'])); ?>
                            </td>
                            <td class="py-3 px-4">
                                <div class="font-medium text-gray-900"><?php echo htmlspecialchars($fine['full_name']); ?></div>
                                <div class="text-sm text-gray-500"><?php echo htmlspecialchars($fine['student_number']); ?></div>
                            </td>
                            <td class="py-3 px-4">
                                <div class="font-medium text-gray-900"><?php echo htmlspecialchars($fine['activity_name'] ?? 'General Fine'); ?></div>
                            </td>
                            <td class="py-3 px-4">
                                <div class="font-bold text-gray-900">₱<?php echo number_format($fine['amount'], 2); ?></div>
                                <?php if ($fine['paid_amount'] > 0): ?>
                                <div class="text-sm text-green-600">Paid: ₱<?php echo number_format($fine['paid_amount'], 2); ?></div>
                                <?php endif; ?>
                                <?php if ($fine['status'] !== 'paid' && $remaining > 0): ?>
                                <div class="text-sm text-red-600">Remaining: ₱<?php echo number_format($remaining, 2); ?></div>
                                <?php endif; ?>
                            </td>
                            <td class="py-3 px-4">
                                <span class="status-badge status-<?php echo $fine['status']; ?>">
                                    <?php echo ucfirst($fine['status']); ?>
                                </span>
                            </td>
                            <td class="py-3 px-4">
                                <div class="text-sm text-gray-600"><?php echo ucfirst($fine['reason']); ?></div>
                                <?php if ($fine['description']): ?>
                                <div class="text-xs text-gray-500"><?php echo htmlspecialchars($fine['description']); ?></div>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <div class="mt-6 pt-6 border-t border-gray-200">
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div class="p-4 bg-blue-50 rounded-lg">
                        <div class="text-sm font-medium text-blue-800">Summary</div>
                        <div class="mt-2 space-y-1">
                            <div class="flex justify-between">
                                <span class="text-sm text-gray-600">Total Fines:</span>
                                <span class="font-semibold"><?php echo $monthly_stats['total_fines']; ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-sm text-gray-600">Total Amount:</span>
                                <span class="font-semibold">₱<?php echo number_format($monthly_stats['total_fines_amount'], 2); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-sm text-gray-600">Pending Fines:</span>
                                <span class="font-semibold text-red-600"><?php echo $monthly_stats['pending_fines']; ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-sm text-gray-600">Paid Fines:</span>
                                <span class="font-semibold text-green-600"><?php echo $monthly_stats['paid_fines']; ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <?php else: ?>
            <div class="text-center py-12">
                <i class="fas fa-chart-bar text-gray-400 text-5xl mb-4"></i>
                <h3 class="text-xl font-bold text-gray-800 mb-2">No Fines Data</h3>
                <p class="text-gray-600 mb-6">No fines were issued in <?php echo $months[$selected_month]; ?> <?php echo $selected_year; ?>.</p>
            </div>
            <?php endif; ?>
            
            <?php else: ?>
            <!-- Payments Report -->
            <div class="flex justify-between items-center mb-6">
                <h2 class="text-xl font-bold text-gray-800 flex items-center">
                    <i class="fas fa-money-bill-wave text-green-600 mr-2"></i> Payment Transactions
                    <span class="ml-2 text-sm font-normal text-gray-500">(<?php echo count($payments_data); ?> records)</span>
                </h2>
                <div class="text-sm text-gray-600">
                    Generated on: <?php echo date('F j, Y, g:i a'); ?>
                </div>
            </div>
            
            <?php if (!empty($payments_data)): ?>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead>
                        <tr class="bg-gray-50 border-b border-gray-200">
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Date</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Student</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Activity</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Amount Paid</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Method</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Received By</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Reference</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($payments_data as $payment): ?>
                        <tr class="border-b border-gray-100 hover:bg-gray-50">
                            <td class="py-3 px-4 text-sm text-gray-600">
                                <?php echo date('M d, Y', strtotime($payment['payment_date'])); ?>
                            </td>
                            <td class="py-3 px-4">
                                <div class="font-medium text-gray-900"><?php echo htmlspecialchars($payment['full_name']); ?></div>
                                <div class="text-sm text-gray-500"><?php echo htmlspecialchars($payment['student_number']); ?></div>
                            </td>
                            <td class="py-3 px-4">
                                <div class="font-medium text-gray-900"><?php echo htmlspecialchars($payment['activity_name'] ?? 'General Fine'); ?></div>
                                <div class="text-sm text-gray-500"><?php echo ucfirst($payment['reason']); ?></div>
                            </td>
                            <td class="py-3 px-4">
                                <div class="font-bold text-green-600">₱<?php echo number_format($payment['amount_paid'], 2); ?></div>
                                <div class="text-xs text-gray-500">Fine: ₱<?php echo number_format($payment['fine_amount'], 2); ?></div>
                            </td>
                            <td class="py-3 px-4">
                                <?php 
                                $method_colors = [
                                    'cash' => 'bg-green-100 text-green-800',
                                    'gcash' => 'bg-blue-100 text-blue-800',
                                    'paymaya' => 'bg-purple-100 text-purple-800',
                                    'bank_transfer' => 'bg-yellow-100 text-yellow-800',
                                    'check' => 'bg-red-100 text-red-800'
                                ];
                                $method_class = $method_colors[$payment['payment_method']] ?? 'bg-gray-100 text-gray-800';
                                ?>
                                <span class="px-2 py-1 rounded text-xs font-medium <?php echo $method_class; ?>">
                                    <?php echo ucfirst(str_replace('_', ' ', $payment['payment_method'])); ?>
                                </span>
                            </td>
                            <td class="py-3 px-4 text-sm text-gray-600">
                                <?php echo htmlspecialchars($payment['received_by_name'] ?? 'System'); ?>
                            </td>
                            <td class="py-3 px-4 text-sm text-gray-600 font-mono">
                                <?php echo $payment['reference_no'] ?: 'N/A'; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <div class="mt-6 pt-6 border-t border-gray-200">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="p-4 bg-green-50 rounded-lg">
                        <div class="text-sm font-medium text-green-800">Payment Summary</div>
                        <div class="mt-2 space-y-1">
                            <div class="flex justify-between">
                                <span class="text-sm text-gray-600">Total Payments:</span>
                                <span class="font-semibold"><?php echo $monthly_stats['total_payments']; ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-sm text-gray-600">Total Collected:</span>
                                <span class="font-semibold text-green-600">₱<?php echo number_format($monthly_stats['total_payments_amount'], 2); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-sm text-gray-600">Cash Payments:</span>
                                <span class="font-semibold"><?php echo $monthly_stats['cash_payments']; ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-sm text-gray-600">Digital Payments:</span>
                                <span class="font-semibold"><?php echo $monthly_stats['digital_payments']; ?></span>
                            </div>
                        </div>
                    </div>
                    
                    <?php if (!empty($daily_breakdown)): ?>
                    <div class="p-4 bg-blue-50 rounded-lg">
                        <div class="text-sm font-medium text-blue-800">Daily Breakdown</div>
                        <div class="mt-2 space-y-2 max-h-40 overflow-y-auto">
                            <?php foreach ($daily_breakdown as $day): ?>
                            <div class="flex justify-between items-center">
                                <span class="text-sm text-gray-600"><?php echo date('M d', strtotime($day['payment_day'])); ?></span>
                                <div class="text-right">
                                    <div class="font-semibold text-gray-900">₱<?php echo number_format($day['total_amount'], 2); ?></div>
                                    <div class="text-xs text-gray-500"><?php echo $day['payment_count']; ?> payments</div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <?php else: ?>
            <div class="text-center py-12">
                <i class="fas fa-money-bill-wave text-gray-400 text-5xl mb-4"></i>
                <h3 class="text-xl font-bold text-gray-800 mb-2">No Payment Data</h3>
                <p class="text-gray-600 mb-6">No payments were recorded in <?php echo $months[$selected_month]; ?> <?php echo $selected_year; ?>.</p>
            </div>
            <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
        // Chart for daily payments
        <?php if ($report_type === 'payments' && !empty($daily_breakdown)): ?>
        document.addEventListener('DOMContentLoaded', function() {
            const ctx = document.getElementById('dailyChart').getContext('2d');
            
            // Sort days in ascending order for chart
            const sortedDays = [...<?php echo json_encode($daily_breakdown); ?>].sort((a, b) => 
                new Date(a.payment_day) - new Date(b.payment_day)
            );
            
            const labels = sortedDays.map(day => {
                const date = new Date(day.payment_day);
                return date.getDate();
            });
            
            const data = sortedDays.map(day => day.total_amount);
            
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Daily Collections (₱)',
                        data: data,
                        backgroundColor: 'rgba(59, 130, 246, 0.5)',
                        borderColor: 'rgb(59, 130, 246)',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    return '₱' + value.toLocaleString();
                                }
                            }
                        }
                    },
                    plugins: {
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return '₱' + context.parsed.y.toLocaleString();
                                }
                            }
                        }
                    }
                }
            });
        });
        <?php endif; ?>
        
        // Print report function
        function printReport() {
            const printContent = document.querySelector('.max-w-7xl').innerHTML;
            const originalContent = document.body.innerHTML;
            
            // Create a print-friendly version
            const printWindow = window.open('', '_blank');
            printWindow.document.write(`
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Monthly Report - <?php echo $selected_campus_name; ?></title>
                    <style>
                        body { font-family: Arial, sans-serif; margin: 20px; }
                        .report-header { background: #3b82f6; color: white; padding: 20px; border-radius: 10px; margin-bottom: 20px; }
                        .stat-card { background: #f8fafc; padding: 15px; border-radius: 8px; margin: 10px 0; }
                        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
                        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                        th { background-color: #f3f4f6; }
                        .status-badge { padding: 2px 8px; border-radius: 12px; font-size: 12px; }
                        .status-pending { background: #fee2e2; color: #991b1b; }
                        .status-paid { background: #d1fae5; color: #065f46; }
                        .no-print { display: none; }
                        @media print {
                            .no-print { display: none; }
                            @page { margin: 0.5in; }
                        }
                    </style>
                </head>
                <body>
                    ${printContent}
                    <div class="no-print">
                        <br><br>
                        <p>Generated on: <?php echo date('F j, Y, g:i a'); ?></p>
                        <p>Campus: <?php echo htmlspecialchars($selected_campus_name); ?></p>
                        <p>Report Period: <?php echo $months[$selected_month]; ?> <?php echo $selected_year; ?></p>
                    </div>
                    <script>
                        window.onload = function() {
                            window.print();
                            window.onafterprint = function() {
                                window.close();
                            };
                        };
                    <\/script>
                </body>
                </html>
            `);
            printWindow.document.close();
        }
        
        // Export to Excel (basic CSV)
        function exportToExcel() {
            let csv = [];
            let rows = document.querySelectorAll("table tr");
            
            for (let i = 0; i < rows.length; i++) {
                let row = [], cols = rows[i].querySelectorAll("td, th");
                
                for (let j = 0; j < cols.length; j++) {
                    // Clean up the text content
                    let text = cols[j].innerText.replace(/\n/g, ' ').trim();
                    row.push('"' + text + '"');
                }
                
                csv.push(row.join(","));
            }
            
            // Download CSV file
            let csvString = csv.join("\n");
            let blob = new Blob([csvString], { type: 'text/csv' });
            let url = window.URL.createObjectURL(blob);
            let a = document.createElement('a');
            a.setAttribute('hidden', '');
            a.setAttribute('href', url);
            a.setAttribute('download', 'monthly_report_<?php echo $selected_campus_name; ?>_<?php echo $selected_month; ?>_<?php echo $selected_year; ?>.csv');
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
        }
    </script>
</body>
</html>
<?php
$conn->close();
?>

<?php
// Function to generate PDF report (requires TCPDF library)
function generatePDFReport($campus_name, $year, $month, $stats, $fines_data, $payments_data, $daily_breakdown) {
    // This is a placeholder function. You'll need to install TCPDF or similar library.
    // Example: composer require tecnickcom/tcpdf
    
    /*
    require_once('tcpdf/tcpdf.php');
    
    $pdf = new TCPDF('P', 'mm', 'A4', true, 'UTF-8', false);
    $pdf->SetCreator('Attendance System');
    $pdf->SetAuthor('Attendance System');
    $pdf->SetTitle('Monthly Report - ' . $campus_name);
    $pdf->SetSubject('Monthly Fines and Payments Report');
    
    $pdf->AddPage();
    
    // Add content to PDF
    $html = '<h1>Monthly Report - ' . $campus_name . '</h1>';
    $html .= '<p>Report Period: ' . date('F Y', mktime(0, 0, 0, $month, 1, $year)) . '</p>';
    
    // Add statistics
    $html .= '<h2>Statistics</h2>';
    $html .= '<table border="1">';
    $html .= '<tr><th>Metric</th><th>Value</th></tr>';
    foreach ($stats as $key => $value) {
        $html .= '<tr><td>' . ucfirst(str_replace('_', ' ', $key)) . '</td><td>' . $value . '</td></tr>';
    }
    $html .= '</table>';
    
    $pdf->writeHTML($html, true, false, true, false, '');
    
    $pdf->Output('monthly_report_' . $campus_name . '_' . $month . '_' . $year . '.pdf', 'D');
    */
    
    // For now, redirect back with message
    header('Location: monthly_report.php?campus=' . $_GET['campus'] . '&year=' . $year . '&month=' . $month . '&type=' . $_GET['type'] . '&message=PDF+generation+requires+TCPDF+library');
    exit();
}
?>