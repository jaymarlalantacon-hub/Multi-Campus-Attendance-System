<?php
// functions.php

function sanitizeInput($data) {
    if (!isset($data)) return '';
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function formatDate($date, $format = 'M j, Y') {
    if (!$date) return 'N/A';
    $dateObj = new DateTime($date);
    return $dateObj->format($format);
}

function formatTime($time) {
    if (!$time) return 'N/A';
    return date('h:i A', strtotime($time));
}

function getPageTitle($filename) {
    $titles = [
        'admin_dashboard.php' => 'Dashboard',
        'students.php' => 'Students Management',
        'users.php' => 'Coordinators Management',
        'activities.php' => 'Activities Management',
        'fines.php' => 'Fines Management',
        'campuses.php' => 'Campuses Management',
        'register.php' => 'Register Student',
        'create_activity.php' => 'Create Activity',
        'scan_attendance.php' => 'Scan Attendance',
        'scan_fines.php' => 'Scan Fines',
        'reports.php' => 'Reports',
        'monthly_report.php' => 'Monthly Report',
        'audit_logs.php' => 'Audit Logs',
        'settings.php' => 'Settings'
    ];
    return $titles[$filename] ?? ucfirst(str_replace(['.php', '_'], ['', ' '], $filename));
}
?>