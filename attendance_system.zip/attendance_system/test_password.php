<?php
require_once 'db.php';

echo "<h2>Password Hash Test</h2>";

// Test password
$test_password = "test123";
echo "Test password: $test_password<br>";

// Generate hash using same method as registration
$hash = password_hash($test_password, PASSWORD_DEFAULT);
echo "New hash: $hash<br>";

// Verify it works
echo "Verification: " . (password_verify($test_password, $hash) ? "SUCCESS" : "FAILED") . "<br><br>";

// Check existing users
echo "<h3>Existing Users in Database:</h3>";
$result = $conn->query("SELECT username, password, status, user_type FROM users LIMIT 10");
echo "<table border='1' cellpadding='5'>";
echo "<tr><th>Username</th><th>Password Hash</th><th>Status</th><th>Type</th><th>Length</th></tr>";
while ($row = $result->fetch_assoc()) {
    echo "<tr>";
    echo "<td>" . $row['username'] . "</td>";
    echo "<td>" . substr($row['password'], 0, 30) . "...</td>";
    echo "<td>" . $row['status'] . "</td>";
    echo "<td>" . $row['user_type'] . "</td>";
    echo "<td>" . strlen($row['password']) . "</td>";
    echo "</tr>";
}
echo "</table>";

// Test with a specific user
if (isset($_GET['user'])) {
    $user = $_GET['user'];
    $stmt = $conn->prepare("SELECT password FROM users WHERE username = ?");
    $stmt->bind_param("s", $user);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        echo "<h3>Testing user: $user</h3>";
        echo "Hash: " . $row['password'] . "<br>";
        echo "Hash info: <pre>";
        print_r(password_get_info($row['password']));
        echo "</pre>";
    }
}
?>