<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_name = $_SESSION['full_name'];
$user_type = $_SESSION['user_type'];
$user_campus_id = $_SESSION['campus_id'];

// Display messages from previous actions
$success_message = $_SESSION['success_message'] ?? '';
$error_message = $_SESSION['error_message'] ?? '';
unset($_SESSION['success_message'], $_SESSION['error_message']);

// Get filter parameters
$status = $_GET['status'] ?? 'pending';
$campus_id = $_GET['campus'] ?? ($user_type === 'coordinator' ? $user_campus_id : null);
$month = $_GET['month'] ?? date('Y-m');

// Build query
$where = [];
$params = [];
$types = "";

if ($user_type === 'coordinator') {
    $where[] = "s.campus_id = ?";
    $params[] = $user_campus_id;
    $types .= "i";
}

if ($status !== 'all') {
    $where[] = "f.status = ?";
    $params[] = $status;
    $types .= "s";
}

if ($campus_id && $user_type === 'admin') {
    $where[] = "s.campus_id = ?";
    $params[] = $campus_id;
    $types .= "i";
}

if ($month) {
    $where[] = "DATE_FORMAT(f.created_at, '%Y-%m') = ?";
    $params[] = $month;
    $types .= "s";
}

$where_clause = $where ? "WHERE " . implode(" AND ", $where) : "";

$query = "SELECT f.*, 
                 s.student_number, s.full_name as student_name, s.campus_id as student_campus,
                 a.activity_name, a.activity_date, a.mandatory,
                 c.campus_name,
                 u.full_name as created_by_name
          FROM fines f
          JOIN students s ON f.student_id = s.student_id
          JOIN activities a ON f.activity_id = a.activity_id
          LEFT JOIN campuses c ON s.campus_id = c.campus_id
          LEFT JOIN users u ON f.created_by = u.user_id
          $where_clause
          ORDER BY f.created_at DESC";

$stmt = $conn->prepare($query);
if ($params) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

// Get totals - FIXED with COALESCE to handle NULL values
$totalQuery = "SELECT 
               COUNT(*) as total_count,
               COALESCE(SUM(CASE WHEN f.status = 'pending' THEN 1 ELSE 0 END), 0) as pending_count,
               COALESCE(SUM(CASE WHEN f.status = 'paid' THEN 1 ELSE 0 END), 0) as paid_count,
               COALESCE(SUM(CASE WHEN f.status = 'partial' THEN 1 ELSE 0 END), 0) as partial_count,
               COALESCE(SUM(CASE WHEN f.status = 'cancelled' THEN 1 ELSE 0 END), 0) as cancelled_count,
               COALESCE(SUM(f.amount), 0) as total_amount,
               COALESCE(SUM(CASE WHEN f.status = 'pending' THEN f.amount ELSE 0 END), 0) as pending_amount,
               COALESCE(SUM(CASE WHEN f.status = 'paid' THEN f.amount ELSE 0 END), 0) as paid_amount,
               COALESCE(SUM(CASE WHEN f.status = 'partial' THEN f.amount ELSE 0 END), 0) as partial_amount,
               COALESCE(SUM(CASE WHEN f.status = 'cancelled' THEN f.amount ELSE 0 END), 0) as cancelled_amount
               FROM fines f
               JOIN students s ON f.student_id = s.student_id
               WHERE 1=1 " . ($user_type === 'coordinator' ? " AND s.campus_id = $user_campus_id" : "");

$totalResult = $conn->query($totalQuery);
$totals = $totalResult->fetch_assoc();

// Initialize totals if query returns no rows
if (!$totals) {
    $totals = [
        'total_count' => 0,
        'pending_count' => 0,
        'paid_count' => 0,
        'partial_count' => 0,
        'cancelled_count' => 0,
        'total_amount' => 0,
        'pending_amount' => 0,
        'paid_amount' => 0,
        'partial_amount' => 0,
        'cancelled_amount' => 0
    ];
}

// Ensure all totals are not null
foreach ($totals as $key => $value) {
    if (is_null($value)) {
        $totals[$key] = 0;
    }
}

// Get campuses for filter
$campuses = [];
if ($user_type === 'admin') {
    $campusResult = $conn->query("SELECT * FROM campuses WHERE status = 'active' ORDER BY campus_name");
    while ($row = $campusResult->fetch_assoc()) {
        $campuses[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fines Management | Multi-Campus Attendance</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <style>
        .animate-in {
            animation: fadeIn 0.3s ease-out;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        input[type="checkbox"] {
            width: 18px;
            height: 18px;
            cursor: pointer;
        }
        .dataTables_wrapper .dataTables_filter input {
            border: 1px solid #d1d5db;
            border-radius: 0.375rem;
            padding: 0.5rem 0.75rem;
        }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
    <!-- Navigation -->
    <nav class="bg-gradient-to-r from-red-800 to-rose-900 text-white shadow-lg">
        <div class="container mx-auto px-4 py-3">
            <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div class="flex items-center space-x-4">
                    <a href="<?php echo $user_type === 'admin' ? 'admin_dashboard.php' : 'coordinator_dashboard.php'; ?>" 
                       class="flex items-center hover:text-red-200 transition-colors">
                        <i class="fas fa-arrow-left mr-2"></i> Back to Dashboard
                    </a>
                    <h1 class="text-xl font-bold">
                        <i class="fas fa-money-bill-wave mr-2"></i> Fines Management
                    </h1>
                </div>
                <div class="flex items-center space-x-4">
                    <span class="text-sm">
                        <i class="fas fa-user mr-1"></i> <?php echo htmlspecialchars($user_name); ?>
                    </span>
                    <a href="scan_fines.php" class="text-sm bg-green-600 hover:bg-green-700 px-3 py-1 rounded-lg transition-colors">
                        <i class="fas fa-qrcode mr-1"></i> Scan Payment
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-8">
        <!-- Header -->
        <div class="mb-8">
            <h1 class="text-3xl font-bold text-gray-800">Fines Management</h1>
            <p class="text-gray-600">Track and manage fines for student absences</p>
        </div>

        <!-- Messages -->
        <?php if ($success_message): ?>
        <div class="mb-6 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg animate-in">
            <div class="flex items-center">
                <i class="fas fa-check-circle mr-3 text-green-600"></i>
                <span><?php echo htmlspecialchars($success_message); ?></span>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if ($error_message): ?>
        <div class="mb-6 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg animate-in">
            <div class="flex items-center">
                <i class="fas fa-exclamation-circle mr-3 text-red-600"></i>
                <span><?php echo htmlspecialchars($error_message); ?></span>
            </div>
        </div>
        <?php endif; ?>

        <!-- Stats Cards -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-red-500">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm text-gray-600">Total Fines</p>
                        <h3 class="text-2xl font-bold text-gray-800"><?php echo number_format($totals['total_count']); ?></h3>
                    </div>
                    <div class="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                        <i class="fas fa-file-invoice-dollar text-red-600 text-xl"></i>
                    </div>
                </div>
                <div class="mt-2">
                    <p class="text-sm text-gray-600">Amount: <span class="font-bold text-red-600">₱<?php echo number_format($totals['total_amount'] ?? 0, 2); ?></span></p>
                </div>
            </div>

            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-yellow-500">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm text-gray-600">Pending</p>
                        <h3 class="text-2xl font-bold text-gray-800"><?php echo number_format($totals['pending_count']); ?></h3>
                    </div>
                    <div class="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center">
                        <i class="fas fa-clock text-yellow-600 text-xl"></i>
                    </div>
                </div>
                <div class="mt-2">
                    <p class="text-sm text-gray-600">Amount: <span class="font-bold text-yellow-600">₱<?php echo number_format($totals['pending_amount'] ?? 0, 2); ?></span></p>
                </div>
            </div>

            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-green-500">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm text-gray-600">Paid</p>
                        <h3 class="text-2xl font-bold text-gray-800"><?php echo number_format($totals['paid_count']); ?></h3>
                    </div>
                    <div class="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                        <i class="fas fa-check-circle text-green-600 text-xl"></i>
                    </div>
                </div>
                <div class="mt-2">
                    <p class="text-sm text-gray-600">Amount: <span class="font-bold text-green-600">₱<?php echo number_format($totals['paid_amount'] ?? 0, 2); ?></span></p>
                </div>
            </div>

            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-blue-500">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm text-gray-600">Partial</p>
                        <h3 class="text-2xl font-bold text-gray-800"><?php echo number_format($totals['partial_count']); ?></h3>
                    </div>
                    <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                        <i class="fas fa-percentage text-blue-600 text-xl"></i>
                    </div>
                </div>
                <div class="mt-2">
                    <p class="text-sm text-gray-600">Amount: <span class="font-bold text-blue-600">₱<?php echo number_format($totals['partial_amount'] ?? 0, 2); ?></span></p>
                </div>
            </div>
        </div>

        <!-- Alternative: Simple stats if no fines -->
        <?php if ($totals['total_count'] == 0): ?>
        <div class="mb-8 bg-blue-50 border border-blue-200 rounded-xl p-6">
            <div class="flex items-center">
                <div class="flex-shrink-0">
                    <i class="fas fa-info-circle text-blue-600 text-2xl"></i>
                </div>
                <div class="ml-4">
                    <h3 class="text-lg font-semibold text-blue-800">No Fines Recorded Yet</h3>
                    <p class="text-blue-700">Start by creating activities and scanning student attendance. Fines are automatically generated for unexcused absences in mandatory activities.</p>
                    <div class="mt-3">
                        <a href="activities.php" class="text-sm font-medium text-blue-600 hover:text-blue-500">
                            Create Activities <i class="fas fa-arrow-right ml-1"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Bulk Actions -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-8">
            <h2 class="text-xl font-bold text-gray-800 mb-4">Bulk Actions</h2>
            <div class="flex flex-col md:flex-row gap-4">
                <div class="flex-1">
                    <label class="block mb-2 text-sm font-medium text-gray-700">Select Fines for Bulk Action</label>
                    <div class="flex items-center space-x-4">
                        <button onclick="selectAllFines()" class="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors text-sm">
                            <i class="fas fa-check-square mr-2"></i> Select All
                        </button>
                        <button onclick="deselectAllFines()" class="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors text-sm">
                            <i class="fas fa-square mr-2"></i> Deselect All
                        </button>
                    </div>
                </div>
                <div class="flex-1">
                    <label class="block mb-2 text-sm font-medium text-gray-700">Bulk Action</label>
                    <div class="flex space-x-3">
                        <select id="bulkAction" class="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500">
                            <option value="">Choose action...</option>
                            <option value="delete">Delete Selected Fines</option>
                            <option value="cancel">Cancel Selected Fines</option>
                            <option value="export">Export Selected</option>
                        </select>
                        <button onclick="executeBulkAction()" class="px-6 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
                            <i class="fas fa-play mr-2"></i> Execute
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filters -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-8">
            <h2 class="text-xl font-bold text-gray-800 mb-4">Filters</h2>
            <form method="GET" action="" class="grid grid-cols-1 md:grid-cols-4 gap-4">
                <!-- Status Filter -->
                <div>
                    <label class="block mb-2 text-sm font-medium text-gray-700">Status</label>
                    <select name="status" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500">
                        <option value="all" <?php echo $status === 'all' ? 'selected' : ''; ?>>All Status</option>
                        <option value="pending" <?php echo $status === 'pending' ? 'selected' : ''; ?>>Pending</option>
                        <option value="paid" <?php echo $status === 'paid' ? 'selected' : ''; ?>>Paid</option>
                        <option value="partial" <?php echo $status === 'partial' ? 'selected' : ''; ?>>Partial</option>
                        <option value="cancelled" <?php echo $status === 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                    </select>
                </div>

                <!-- Campus Filter (Admin only) -->
                <?php if ($user_type === 'admin'): ?>
                <div>
                    <label class="block mb-2 text-sm font-medium text-gray-700">Campus</label>
                    <select name="campus" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500">
                        <option value="">All Campuses</option>
                        <?php foreach ($campuses as $campus): ?>
                        <option value="<?php echo $campus['campus_id']; ?>" <?php echo $campus_id == $campus['campus_id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($campus['campus_name']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php endif; ?>

                <!-- Month Filter -->
                <div>
                    <label class="block mb-2 text-sm font-medium text-gray-700">Month</label>
                    <input type="month" name="month" value="<?php echo $month; ?>" 
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500">
                </div>

                <!-- Action Buttons -->
                <div class="flex items-end space-x-3">
                    <button type="submit" class="px-6 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
                        <i class="fas fa-filter mr-2"></i> Apply Filters
                    </button>
                    <a href="fines.php" class="px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors">
                        <i class="fas fa-redo mr-2"></i> Reset
                    </a>
                </div>
            </form>
        </div>

        <!-- Fines Table -->
        <div class="bg-white rounded-xl shadow-lg overflow-hidden">
            <div class="p-6 border-b">
                <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                        <h2 class="text-xl font-bold text-gray-800">Fines Records</h2>
                        <p class="text-gray-600"><?php echo $result->num_rows; ?> records found</p>
                    </div>
                    <div class="flex gap-3">
                        <a href="scan_fines.php" class="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                            <i class="fas fa-qrcode mr-2"></i> Scan Payment
                        </a>
                        <?php if ($result->num_rows > 0): ?>
                        <button onclick="exportFines()" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                            <i class="fas fa-download mr-2"></i> Export
                        </button>
                        <button onclick="printReport()" class="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
                            <i class="fas fa-print mr-2"></i> Print
                        </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <?php if ($result->num_rows > 0): ?>
            <div class="overflow-x-auto">
                <table id="finesTable" class="w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-600 w-12">
                                <input type="checkbox" id="selectAll" onclick="toggleSelectAll()">
                            </th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-600">Student</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-600">Activity</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-600">Campus</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-600">Amount</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-600">Reason</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-600">Status</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-600">Created</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-600">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php 
                        while ($fine = $result->fetch_assoc()):
                            // Ensure amount is not null
                            $fine_amount = $fine['amount'] ?? 0;
                            $fine_status = $fine['status'] ?? 'pending';
                        ?>
                        <tr class="hover:bg-gray-50" id="fine-<?php echo $fine['fine_id']; ?>">
                            <td class="py-4 px-4">
                                <input type="checkbox" name="fine_ids[]" value="<?php echo $fine['fine_id']; ?>" class="fine-checkbox">
                            </td>
                            <td class="py-4 px-4">
                                <div class="font-semibold text-gray-800"><?php echo htmlspecialchars($fine['student_name']); ?></div>
                                <div class="text-sm text-gray-600"><?php echo htmlspecialchars($fine['student_number']); ?></div>
                            </td>
                            <td class="py-4 px-4">
                                <div class="font-medium text-gray-800"><?php echo htmlspecialchars($fine['activity_name']); ?></div>
                                <div class="text-sm text-gray-600"><?php echo !empty($fine['activity_date']) ? formatDate($fine['activity_date']) : 'N/A'; ?></div>
                            </td>
                            <td class="py-4 px-4">
                                <span class="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-semibold">
                                    <?php echo htmlspecialchars($fine['campus_name'] ?? 'Unknown'); ?>
                                </span>
                            </td>
                            <td class="py-4 px-4">
                                <div class="font-bold text-lg <?php echo $fine_status === 'paid' ? 'text-green-600' : 'text-red-600'; ?>">
                                    ₱<?php echo number_format($fine_amount, 2); ?>
                                </div>
                            </td>
                            <td class="py-4 px-4">
                                <span class="px-3 py-1 <?php echo ($fine['reason'] ?? '') === 'absence' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'; ?> rounded-full text-sm font-semibold">
                                    <?php echo ucfirst($fine['reason'] ?? 'unknown'); ?>
                                </span>
                                <?php if (!empty($fine['description'])): ?>
                                <div class="text-xs text-gray-500 mt-1"><?php echo htmlspecialchars($fine['description']); ?></div>
                                <?php endif; ?>
                            </td>
                            <td class="py-4 px-4">
                                <?php 
                                $status_colors = [
                                    'pending' => 'bg-yellow-100 text-yellow-800',
                                    'paid' => 'bg-green-100 text-green-800',
                                    'partial' => 'bg-blue-100 text-blue-800',
                                    'cancelled' => 'bg-gray-100 text-gray-800'
                                ];
                                ?>
                                <span class="px-3 py-1 <?php echo $status_colors[$fine_status] ?? 'bg-gray-100 text-gray-800'; ?> rounded-full text-sm font-semibold">
                                    <?php echo ucfirst($fine_status); ?>
                                </span>
                            </td>
                            <td class="py-4 px-4">
                                <div class="text-sm text-gray-800"><?php echo !empty($fine['created_at']) ? formatDate($fine['created_at'], 'M j, Y') : 'N/A'; ?></div>
                                <div class="text-xs text-gray-500">by <?php echo htmlspecialchars($fine['created_by_name'] ?? 'System'); ?></div>
                            </td>
                            <td class="py-4 px-4">
                                <div class="flex space-x-2">
                                    <?php if ($fine_status !== 'paid'): ?>
                                    <button onclick="recordPayment(<?php echo $fine['fine_id']; ?>)" 
                                            class="px-3 py-1 bg-green-100 text-green-800 hover:bg-green-200 rounded text-sm transition-colors"
                                            title="Record Payment">
                                        <i class="fas fa-money-bill-wave"></i>
                                    </button>
                                    <?php endif; ?>
                                    <a href="fine_payments.php?fine_id=<?php echo $fine['fine_id']; ?>" 
                                       class="px-3 py-1 bg-blue-100 text-blue-800 hover:bg-blue-200 rounded text-sm transition-colors"
                                       title="View Payments">
                                        <i class="fas fa-history"></i>
                                    </a>
                                    <?php if ($user_type === 'admin'): ?>
                                    <button onclick="editFine(<?php echo $fine['fine_id']; ?>)" 
                                            class="px-3 py-1 bg-yellow-100 text-yellow-800 hover:bg-yellow-200 rounded text-sm transition-colors"
                                            title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <?php endif; ?>
                                    <!-- DELETE BUTTON -->
                                    <button onclick="deleteFine(<?php echo $fine['fine_id']; ?>, '<?php echo htmlspecialchars(addslashes($fine['student_name'])); ?>', '<?php echo number_format($fine['amount'] ?? 0, 2); ?>')" 
                                            class="px-3 py-1 bg-red-100 text-red-800 hover:bg-red-200 rounded text-sm transition-colors"
                                            title="Delete Fine">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="p-12 text-center">
                <i class="fas fa-file-invoice-dollar text-4xl text-gray-300 mb-4"></i>
                <h3 class="text-xl font-semibold text-gray-700 mb-2">No Fines Found</h3>
                <p class="text-gray-600 mb-6">
                    <?php 
                    if ($status !== 'all') {
                        echo "No {$status} fines found with the current filters.";
                    } elseif ($campus_id) {
                        echo "No fines found for the selected campus.";
                    } else {
                        echo "No fines have been recorded yet.";
                    }
                    ?>
                </p>
                <div class="flex justify-center space-x-3">
                    <a href="fines.php?status=all" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                        <i class="fas fa-eye mr-2"></i> View All Fines
                    </a>
                    <a href="activities.php" class="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                        <i class="fas fa-calendar-plus mr-2"></i> Create Activity
                    </a>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Payment Modal -->
        <div id="paymentModal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center p-4 z-50">
            <div class="bg-white rounded-xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto">
                <div class="p-6 border-b">
                    <h3 class="text-xl font-bold text-gray-800">Record Fine Payment</h3>
                </div>
                <form id="paymentForm" method="POST" action="process_payment.php" class="p-6 space-y-4">
                    <input type="hidden" name="fine_id" id="modalFineId">
                    
                    <div>
                        <label class="block mb-2 text-sm font-medium text-gray-700">Payment Amount *</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <span class="text-gray-500">₱</span>
                            </div>
                            <input type="number" name="amount_paid" step="0.01" min="0" required
                                   class="w-full pl-8 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                                   placeholder="0.00">
                        </div>
                    </div>
                    
                    <div>
                        <label class="block mb-2 text-sm font-medium text-gray-700">Payment Date *</label>
                        <input type="date" name="payment_date" required
                               class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                               value="<?php echo date('Y-m-d'); ?>">
                    </div>
                    
                    <div>
                        <label class="block mb-2 text-sm font-medium text-gray-700">Payment Method</label>
                        <select name="payment_method" 
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500">
                            <option value="cash">Cash</option>
                            <option value="gcash">GCash</option>
                            <option value="bank_transfer">Bank Transfer</option>
                            <option value="check">Check</option>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block mb-2 text-sm font-medium text-gray-700">Reference Number</label>
                        <input type="text" name="reference_no"
                               class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                               placeholder="e.g., GCash Ref #, Check #">
                    </div>
                    
                    <div>
                        <label class="block mb-2 text-sm font-medium text-gray-700">Notes</label>
                        <textarea name="notes" rows="3"
                                  class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                                  placeholder="Additional notes..."></textarea>
                    </div>
                    
                    <div class="flex gap-3 pt-4">
                        <button type="submit" 
                                class="flex-1 bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors">
                            <i class="fas fa-check-circle mr-2"></i> Record Payment
                        </button>
                        <button type="button" onclick="closeModal()" 
                                class="flex-1 bg-gray-600 text-white py-3 rounded-lg font-semibold hover:bg-gray-700 transition-colors">
                            Cancel
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        // Initialize DataTable only if there's data
        $(document).ready(function() {
            <?php if ($result->num_rows > 0): ?>
            $('#finesTable').DataTable({
                "pageLength": 25,
                "order": [[7, 'desc']], // Sort by created date (8th column)
                "columnDefs": [
                    { "orderable": false, "targets": [0, 8] } // Make checkbox and actions columns not sortable
                ],
                "language": {
                    "search": "Search fines:",
                    "lengthMenu": "Show _MENU_ fines per page",
                    "info": "Showing _START_ to _END_ of _TOTAL_ fines",
                    "paginate": {
                        "first": "First",
                        "last": "Last",
                        "next": "Next",
                        "previous": "Previous"
                    }
                }
            });
            <?php endif; ?>
        });
        
        // Payment modal functions
        function recordPayment(fineId) {
            document.getElementById('modalFineId').value = fineId;
            document.getElementById('paymentModal').classList.remove('hidden');
            document.getElementById('paymentModal').classList.add('flex');
        }
        
        function closeModal() {
            document.getElementById('paymentModal').classList.add('hidden');
            document.getElementById('paymentModal').classList.remove('flex');
        }
        
        // Close modal when clicking outside
        document.getElementById('paymentModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeModal();
            }
        });
        
        function exportFines() {
            const params = new URLSearchParams(window.location.search);
            window.open('export_fines.php?' + params.toString(), '_blank');
        }
        
        function printReport() {
            const params = new URLSearchParams(window.location.search);
            window.open('print_fines.php?' + params.toString(), '_blank');
        }
        
        function editFine(fineId) {
            window.location.href = 'edit_fine.php?id=' + fineId;
        }
        
        // Delete fine function
        function deleteFine(fineId, studentName, amount) {
            if (confirm(`Are you sure you want to delete this fine?\n\nStudent: ${studentName}\nAmount: ₱${amount}\n\nThis action cannot be undone!`)) {
                // Create form and submit via POST
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = 'delete_fine.php';
                
                const fineIdInput = document.createElement('input');
                fineIdInput.type = 'hidden';
                fineIdInput.name = 'fine_id';
                fineIdInput.value = fineId;
                form.appendChild(fineIdInput);
                
                document.body.appendChild(form);
                form.submit();
            }
        }
        
        // Bulk actions functions
        function selectAllFines() {
            document.querySelectorAll('.fine-checkbox').forEach(checkbox => {
                checkbox.checked = true;
            });
            document.getElementById('selectAll').checked = true;
        }
        
        function deselectAllFines() {
            document.querySelectorAll('.fine-checkbox').forEach(checkbox => {
                checkbox.checked = false;
            });
            document.getElementById('selectAll').checked = false;
        }
        
        function toggleSelectAll() {
            const selectAll = document.getElementById('selectAll');
            document.querySelectorAll('.fine-checkbox').forEach(checkbox => {
                checkbox.checked = selectAll.checked;
            });
        }
        
        function executeBulkAction() {
            const action = document.getElementById('bulkAction').value;
            const selectedFines = Array.from(document.querySelectorAll('.fine-checkbox:checked')).map(cb => cb.value);
            
            if (selectedFines.length === 0) {
                alert('Please select at least one fine.');
                return;
            }
            
            if (!action) {
                alert('Please select an action.');
                return;
            }
            
            if (action === 'delete') {
                if (confirm(`Are you sure you want to delete ${selectedFines.length} fine(s)? This action cannot be undone!`)) {
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.action = 'bulk_delete_fines.php';
                    
                    selectedFines.forEach(fineId => {
                        const input = document.createElement('input');
                        input.type = 'hidden';
                        input.name = 'fine_ids[]';
                        input.value = fineId;
                        form.appendChild(input);
                    });
                    
                    document.body.appendChild(form);
                    form.submit();
                }
            } else if (action === 'cancel') {
                if (confirm(`Are you sure you want to cancel ${selectedFines.length} fine(s)?`)) {
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.action = 'bulk_cancel_fines.php';
                    
                    selectedFines.forEach(fineId => {
                        const input = document.createElement('input');
                        input.type = 'hidden';
                        input.name = 'fine_ids[]';
                        input.value = fineId;
                        form.appendChild(input);
                    });
                    
                    document.body.appendChild(form);
                    form.submit();
                }
            } else if (action === 'export') {
                // Export selected fines
                const params = new URLSearchParams(window.location.search);
                params.set('selected_fines', selectedFines.join(','));
                window.open('export_fines.php?' + params.toString(), '_blank');
            }
        }
        
        // Update select all checkbox when individual checkboxes change
        document.addEventListener('DOMContentLoaded', function() {
            const checkboxes = document.querySelectorAll('.fine-checkbox');
            const selectAll = document.getElementById('selectAll');
            
            checkboxes.forEach(checkbox => {
                checkbox.addEventListener('change', function() {
                    const allChecked = Array.from(checkboxes).every(cb => cb.checked);
                    const someChecked = Array.from(checkboxes).some(cb => cb.checked);
                    
                    selectAll.checked = allChecked;
                    selectAll.indeterminate = someChecked && !allChecked;
                });
            });
        });
    </script>
</body>
</html>