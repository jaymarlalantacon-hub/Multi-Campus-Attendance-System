<?php
session_start();
require_once 'db.php';

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    header('Location: ' . ($_SESSION['user_type'] === 'admin' ? 'admin_dashboard.php' : 'coordinator_dashboard.php'));
    exit();
}

$error = '';
$success = '';

// Get campuses
$campuses = $conn->query("SELECT * FROM campuses WHERE status = 'active' ORDER BY campus_name")->fetch_all(MYSQLI_ASSOC);

// Handle Registration
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name']);
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $campus_id = isset($_POST['campus_id']) ? intval($_POST['campus_id']) : NULL;
    $user_type = $_POST['user_type'] ?? 'coordinator';
    
    // Debug: Log the input
    error_log("Registration attempt - Username: $username, Email: $email, User Type: $user_type, Campus ID: $campus_id");
    
    // Validation
    if (empty($full_name) || empty($username) || empty($email) || empty($password)) {
        $error = 'All fields are required!';
    } elseif ($password !== $confirm_password) {
        $error = 'Passwords do not match!';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters!';
    } elseif ($user_type === 'coordinator' && empty($campus_id)) {
        $error = 'Coordinator must select a campus!';
    } elseif ($user_type === 'admin' && !empty($campus_id)) {
        $error = 'Admin should not be assigned to a specific campus!';
    } else {
        // Check if username or email exists
        $check = $conn->prepare("SELECT user_id FROM users WHERE username = ? OR email = ?");
        $check->bind_param("ss", $username, $email);
        $check->execute();
        $check->store_result();
        
        if ($check->num_rows > 0) {
            $error = 'Username or email already exists!';
        } else {
            // Hash password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Debug: Log the hashed password
            error_log("Hashed password for $username: " . substr($hashed_password, 0, 50) . "...");
            error_log("Password length: " . strlen($hashed_password));
            
            // Insert user
            if ($user_type === 'admin') {
                $stmt = $conn->prepare("INSERT INTO users (full_name, username, email, password, user_type, status, created_at) VALUES (?, ?, ?, ?, 'admin', 'active', NOW())");
                $stmt->bind_param("ssss", $full_name, $username, $email, $hashed_password);
                error_log("Registering as ADMIN - bind_param types: ssss");
            } else {
                $stmt = $conn->prepare("INSERT INTO users (full_name, username, email, password, campus_id, user_type, status, created_at) VALUES (?, ?, ?, ?, ?, 'coordinator', 'active', NOW())");
                $stmt->bind_param("ssssi", $full_name, $username, $email, $hashed_password, $campus_id); // FIXED: Changed "sssis" to "ssssi"
                error_log("Registering as COORDINATOR - bind_param types: ssssi");
            }
            
            if ($stmt->execute()) {
                $user_id = $stmt->insert_id;
                error_log("Registration SUCCESS for user ID: $user_id, Username: $username");
                
                $success = 'Registration successful! You can now <a href="login.php" class="font-semibold underline">login here</a>.';
                
                // Optional: Auto-login after registration
                // $_SESSION['user_id'] = $user_id;
                // $_SESSION['username'] = $username;
                // $_SESSION['user_type'] = $user_type;
                // $_SESSION['campus_id'] = $campus_id;
                // header('Location: ' . ($user_type === 'admin' ? 'admin_dashboard.php' : 'coordinator_dashboard.php'));
                // exit();
            } else {
                $error = 'Registration failed. Please try again!';
                error_log("Registration FAILED: " . $stmt->error);
                error_log("SQL State: " . $stmt->sqlstate);
                error_log("Error no: " . $stmt->errno);
            }
            
            $stmt->close();
        }
        $check->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | Multi-Campus Attendance System</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        .register-box {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
        }
        .password-strength {
            height: 4px;
            transition: all 0.3s;
        }
    </style>
</head>
<body class="flex items-center justify-center p-4">
    <div class="w-full max-w-lg">
        <div class="register-box rounded-2xl shadow-2xl overflow-hidden">
            <!-- Header -->
            <div class="bg-gradient-to-r from-purple-800 to-indigo-900 text-white p-8 text-center">
                <div class="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-user-plus text-3xl"></i>
                </div>
                <h1 class="text-3xl font-bold mb-2">Create Account</h1>
                <p class="text-purple-200 text-sm">Register as admin or campus coordinator</p>
            </div>
            
            <!-- Register Form -->
            <div class="p-8">
                <?php if ($error): ?>
                <div class="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center text-red-700">
                    <i class="fas fa-exclamation-circle mr-3"></i>
                    <span><?php echo htmlspecialchars($error); ?></span>
                </div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                <div class="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-center text-green-700">
                    <i class="fas fa-check-circle mr-3"></i>
                    <span><?php echo $success; ?></span>
                </div>
                <?php endif; ?>
                
                <form method="POST" action="" id="registerForm">
                    <div class="space-y-6">
                        <!-- User Type -->
                        <div>
                            <label class="block text-gray-700 mb-3 font-semibold">
                                <i class="fas fa-user-tag text-purple-600 mr-2"></i>Register As *
                            </label>
                            <div class="grid grid-cols-2 gap-4">
                                <div>
                                    <input type="radio" id="coordinator" name="user_type" value="coordinator" checked 
                                           class="hidden peer" onchange="toggleCampusField()">
                                    <label for="coordinator" class="block p-4 border-2 border-gray-300 rounded-lg cursor-pointer peer-checked:border-purple-600 peer-checked:bg-purple-50 text-center hover:bg-purple-50 transition duration-200">
                                        <i class="fas fa-users text-blue-600 text-xl mb-2 block"></i>
                                        <span class="font-medium">Coordinator</span>
                                        <p class="text-xs text-gray-600 mt-1">Campus-specific access</p>
                                    </label>
                                </div>
                                <div>
                                    <input type="radio" id="admin" name="user_type" value="admin"
                                           class="hidden peer" onchange="toggleCampusField()">
                                    <label for="admin" class="block p-4 border-2 border-gray-300 rounded-lg cursor-pointer peer-checked:border-purple-600 peer-checked:bg-purple-50 text-center hover:bg-purple-50 transition duration-200">
                                        <i class="fas fa-user-shield text-purple-600 text-xl mb-2 block"></i>
                                        <span class="font-medium">Admin</span>
                                        <p class="text-xs text-gray-600 mt-1">System-wide access</p>
                                    </label>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Personal Info -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-gray-700 mb-2 font-medium">
                                    <i class="fas fa-user text-purple-600 mr-2"></i>Full Name *
                                </label>
                                <input type="text" name="full_name" required
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition duration-200"
                                       placeholder="Enter full name"
                                       value="<?php echo isset($_POST['full_name']) ? htmlspecialchars($_POST['full_name']) : ''; ?>">
                            </div>
                            
                            <div>
                                <label class="block text-gray-700 mb-2 font-medium">
                                    <i class="fas fa-at text-purple-600 mr-2"></i>Username *
                                </label>
                                <input type="text" name="username" required
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition duration-200"
                                       placeholder="Choose username"
                                       value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>"
                                       minlength="3">
                                <p class="text-xs text-gray-500 mt-1">3+ characters, no spaces</p>
                            </div>
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 mb-2 font-medium">
                                <i class="fas fa-envelope text-purple-600 mr-2"></i>Email *
                            </label>
                            <input type="email" name="email" required
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition duration-200"
                                   placeholder="Enter email address"
                                   value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                        </div>
                        
                        <!-- Campus Selection (for coordinators only) -->
                        <div id="campusField">
                            <label class="block text-gray-700 mb-2 font-medium">
                                <i class="fas fa-university text-purple-600 mr-2"></i>Campus *
                            </label>
                            <select name="campus_id" required
                                    class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition duration-200">
                                <option value="">Select Campus</option>
                                <?php foreach ($campuses as $campus): ?>
                                    <option value="<?php echo $campus['campus_id']; ?>" 
                                        <?php echo (isset($_POST['campus_id']) && $_POST['campus_id'] == $campus['campus_id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($campus['campus_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <!-- Password Fields -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-gray-700 mb-2 font-medium">
                                    <i class="fas fa-lock text-purple-600 mr-2"></i>Password *
                                </label>
                                <div class="relative">
                                    <input type="password" name="password" required minlength="6"
                                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition duration-200"
                                           placeholder="Min. 6 characters"
                                           id="passwordInput"
                                           onkeyup="checkPasswordStrength()">
                                    <button type="button" onclick="togglePassword('passwordInput', 'toggleIcon1')" 
                                            class="absolute right-3 top-3 text-gray-500 hover:text-gray-700">
                                        <i class="fas fa-eye" id="toggleIcon1"></i>
                                    </button>
                                </div>
                                <div class="mt-2">
                                    <div class="flex space-x-1 mb-1">
                                        <div id="strength1" class="password-strength flex-1 bg-gray-200 rounded"></div>
                                        <div id="strength2" class="password-strength flex-1 bg-gray-200 rounded"></div>
                                        <div id="strength3" class="password-strength flex-1 bg-gray-200 rounded"></div>
                                        <div id="strength4" class="password-strength flex-1 bg-gray-200 rounded"></div>
                                    </div>
                                    <p id="passwordFeedback" class="text-xs text-gray-500"></p>
                                </div>
                            </div>
                            
                            <div>
                                <label class="block text-gray-700 mb-2 font-medium">
                                    <i class="fas fa-lock text-purple-600 mr-2"></i>Confirm Password *
                                </label>
                                <div class="relative">
                                    <input type="password" name="confirm_password" required minlength="6"
                                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition duration-200"
                                           placeholder="Confirm password"
                                           id="confirmPasswordInput"
                                           onkeyup="checkPasswordMatch()">
                                    <button type="button" onclick="togglePassword('confirmPasswordInput', 'toggleIcon2')" 
                                            class="absolute right-3 top-3 text-gray-500 hover:text-gray-700">
                                        <i class="fas fa-eye" id="toggleIcon2"></i>
                                    </button>
                                </div>
                                <p id="passwordMatch" class="text-xs mt-2"></p>
                            </div>
                        </div>
                        
                        <!-- Terms and Submit -->
                        <div class="pt-4 border-t border-gray-200">
                            <div class="flex items-center mb-6">
                                <input type="checkbox" id="terms" name="terms" required
                                       class="h-4 w-4 text-purple-600 rounded focus:ring-purple-500">
                                <label for="terms" class="ml-2 text-gray-700 text-sm">
                                    I agree to the <a href="#" class="text-purple-600 hover:text-purple-800">Terms of Service</a> and <a href="#" class="text-purple-600 hover:text-purple-800">Privacy Policy</a>
                                </label>
                            </div>
                            
                            <button type="submit"
                                    class="w-full bg-gradient-to-r from-green-500 to-emerald-600 text-white py-3 rounded-lg font-semibold hover:from-green-600 hover:to-emerald-700 transition duration-200 transform hover:-translate-y-0.5 shadow-lg hover:shadow-xl">
                                <i class="fas fa-user-plus mr-2"></i>Create Account
                            </button>
                            
                            <div class="text-center mt-6">
                                <p class="text-gray-600">
                                    Already have an account?
                                    <a href="login.php" class="text-purple-600 font-semibold hover:text-purple-800 ml-1">
                                        Login here
                                    </a>
                                </p>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Debug Info (Remove in production) -->
        <div class="mt-4 p-4 bg-black/80 text-white rounded-lg text-sm text-center">
            <p><strong>Note:</strong> Check error logs for registration debugging</p>
            <p class="mt-1">
                <a href="test_registration.php" class="text-blue-300 underline">Test Registration</a> |
                <a href="check_users.php" class="text-blue-300 underline">Check Users</a>
            </p>
        </div>
    </div>
    
    <script>
        function toggleCampusField() {
            const userType = document.querySelector('input[name="user_type"]:checked').value;
            const campusField = document.getElementById('campusField');
            const campusSelect = campusField.querySelector('select[name="campus_id"]');
            
            if (userType === 'admin') {
                campusField.style.display = 'none';
                campusSelect.removeAttribute('required');
                campusSelect.value = '';
            } else {
                campusField.style.display = 'block';
                campusSelect.setAttribute('required', 'required');
            }
        }
        
        function togglePassword(fieldId, iconId) {
            const field = document.getElementById(fieldId);
            const icon = document.getElementById(iconId);
            
            if (field.type === 'password') {
                field.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                field.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }
        
        function checkPasswordStrength() {
            const password = document.getElementById('passwordInput').value;
            const strengthBars = ['strength1', 'strength2', 'strength3', 'strength4'];
            const feedback = document.getElementById('passwordFeedback');
            let strength = 0;
            let feedbackText = '';
            
            // Reset bars
            strengthBars.forEach(barId => {
                document.getElementById(barId).style.backgroundColor = '#e5e7eb';
            });
            
            if (password.length >= 6) strength++;
            if (password.length >= 8) strength++;
            if (/[A-Z]/.test(password) && /[a-z]/.test(password)) strength++;
            if (/[0-9]/.test(password)) strength++;
            if (/[^A-Za-z0-9]/.test(password)) strength++;
            
            // Cap strength at 4
            strength = Math.min(strength, 4);
            
            // Update bars
            for (let i = 0; i < strength; i++) {
                let color;
                if (strength === 1) color = '#ef4444'; // Red
                else if (strength === 2) color = '#f59e0b'; // Orange
                else if (strength === 3) color = '#10b981'; // Green
                else color = '#059669'; // Dark Green
                
                document.getElementById(strengthBars[i]).style.backgroundColor = color;
            }
            
            // Set feedback text
            if (password.length === 0) {
                feedbackText = '';
            } else if (password.length < 6) {
                feedbackText = 'Password too short (min 6 characters)';
                feedback.style.color = '#ef4444';
            } else if (strength <= 2) {
                feedbackText = 'Weak password';
                feedback.style.color = '#f59e0b';
            } else if (strength === 3) {
                feedbackText = 'Good password';
                feedback.style.color = '#10b981';
            } else {
                feedbackText = 'Strong password';
                feedback.style.color = '#059669';
            }
            
            feedback.textContent = feedbackText;
        }
        
        function checkPasswordMatch() {
            const password = document.getElementById('passwordInput').value;
            const confirm = document.getElementById('confirmPasswordInput').value;
            const matchText = document.getElementById('passwordMatch');
            
            if (confirm.length === 0) {
                matchText.textContent = '';
                matchText.style.color = '';
            } else if (password === confirm) {
                matchText.textContent = '✓ Passwords match';
                matchText.style.color = '#10b981';
            } else {
                matchText.textContent = '✗ Passwords do not match';
                matchText.style.color = '#ef4444';
            }
        }
        
        // Form validation
        document.getElementById('registerForm').addEventListener('submit', function(e) {
            const password = document.getElementById('passwordInput').value;
            const confirm = document.getElementById('confirmPasswordInput').value;
            const terms = document.getElementById('terms').checked;
            
            if (!terms) {
                e.preventDefault();
                alert('You must agree to the Terms of Service and Privacy Policy.');
                return false;
            }
            
            if (password !== confirm) {
                e.preventDefault();
                alert('Passwords do not match!');
                return false;
            }
            
            if (password.length < 6) {
                e.preventDefault();
                alert('Password must be at least 6 characters long.');
                return false;
            }
        });
        
        // Initialize
        document.addEventListener('DOMContentLoaded', function() {
            toggleCampusField();
            checkPasswordStrength();
            checkPasswordMatch();
        });
    </script>
</body>
</html>