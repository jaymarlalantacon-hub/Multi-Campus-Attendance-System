<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['full_name'] ?? 'Unknown User';
$user_type = $_SESSION['user_type'] ?? 'admin';

// Check if user has permission to view audit logs
if ($user_type !== 'admin') {
    die("Access denied: You don't have permission to view audit logs.");
}

// Get user's campus info
$user_query = "SELECT u.*, c.campus_name 
               FROM users u 
               LEFT JOIN campuses c ON u.campus_id = c.campus_id 
               WHERE u.user_id = ?";
$user_stmt = $conn->prepare($user_query);
$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();
$user_result = $user_stmt->get_result();
$user_data = $user_result->fetch_assoc();

$user_campus_id = $user_data['campus_id'] ?? null;
$user_campus_name = $user_data['campus_name'] ?? 'System Admin';

// Get all campuses for selection
$campuses = [];
$campus_query = "SELECT * FROM campuses WHERE status = 'active' ORDER BY campus_name";
$campus_result = $conn->query($campus_query);
while ($campus = $campus_result->fetch_assoc()) {
    $campuses[] = $campus;
}

// Handle filters
$selected_campus = isset($_GET['campus']) ? intval($_GET['campus']) : ($user_campus_id ?? 0);
$selected_action = isset($_GET['action']) ? $_GET['action'] : 'all';
$selected_user = isset($_GET['user']) ? intval($_GET['user']) : 0;
$selected_type = isset($_GET['type']) ? $_GET['type'] : 'all';
$selected_date = isset($_GET['date']) ? $_GET['date'] : '';
$search_term = isset($_GET['search']) ? trim($_GET['search']) : '';

// Build filter conditions
$where_conditions = [];
$params = [];
$param_types = '';

// Campus filter
if ($selected_campus > 0) {
    $where_conditions[] = "(s.campus_id = ? OR a.user_id IN (SELECT user_id FROM users WHERE campus_id = ?))";
    $params[] = $selected_campus;
    $params[] = $selected_campus;
    $param_types .= 'ii';
} elseif ($user_campus_id !== null) {
    // Non-admin users can only see their campus logs
    $where_conditions[] = "(s.campus_id = ? OR a.user_id IN (SELECT user_id FROM users WHERE campus_id = ?))";
    $params[] = $user_campus_id;
    $params[] = $user_campus_id;
    $param_types .= 'ii';
}

// Action filter
if ($selected_action !== 'all') {
    $where_conditions[] = "a.action = ?";
    $params[] = $selected_action;
    $param_types .= 's';
}

// User filter
if ($selected_user > 0) {
    $where_conditions[] = "a.user_id = ?";
    $params[] = $selected_user;
    $param_types .= 'i';
}

// Type filter
if ($selected_type !== 'all') {
    $where_conditions[] = "a.scan_type = ?";
    $params[] = $selected_type;
    $param_types .= 's';
}

// Date filter
if (!empty($selected_date)) {
    $where_conditions[] = "DATE(a.created_at) = ?";
    $params[] = $selected_date;
    $param_types .= 's';
}

// Search term filter
if (!empty($search_term)) {
    $where_conditions[] = "(s.student_number LIKE ? OR s.full_name LIKE ? OR u.full_name LIKE ? OR a.action LIKE ? OR a.scan_type LIKE ?)";
    $search_param = "%{$search_term}%";
    $params = array_merge($params, array_fill(0, 5, $search_param));
    $param_types .= str_repeat('s', 5);
}

// Build WHERE clause
$where_clause = '';
if (!empty($where_conditions)) {
    $where_clause = "WHERE " . implode(" AND ", $where_conditions);
}

// Get total count for pagination
$count_query = "SELECT COUNT(*) as total 
                FROM scan_logs a
                LEFT JOIN students s ON a.student_id = s.student_id
                LEFT JOIN users u ON a.user_id = u.user_id
                $where_clause";
                
$count_stmt = $conn->prepare($count_query);
if (!empty($params)) {
    $count_stmt->bind_param($param_types, ...$params);
}
$count_stmt->execute();
$count_result = $count_stmt->get_result();
$total_logs = $count_result->fetch_assoc()['total'] ?? 0;

// Pagination
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$per_page = 50;
$total_pages = ceil($total_logs / $per_page);
$offset = ($page - 1) * $per_page;

// Get audit logs with filters and pagination
$logs_query = "SELECT a.*, 
               s.student_number, s.full_name as student_name, s.course_year, s.section,
               u.full_name as user_name, u.user_type,
               c.campus_name,
               camp.campus_name as student_campus_name
               FROM scan_logs a
               LEFT JOIN students s ON a.student_id = s.student_id
               LEFT JOIN users u ON a.user_id = u.user_id
               LEFT JOIN campuses c ON u.campus_id = c.campus_id
               LEFT JOIN campuses camp ON s.campus_id = camp.campus_id
               $where_clause
               ORDER BY a.created_at DESC
               LIMIT ? OFFSET ?";

// Add pagination parameters
$params[] = $per_page;
$params[] = $offset;
$param_types .= 'ii';

$logs_stmt = $conn->prepare($logs_query);
if (!empty($params)) {
    $logs_stmt->bind_param($param_types, ...$params);
}
$logs_stmt->execute();
$logs_result = $logs_stmt->get_result();

$audit_logs = [];
while ($log = $logs_result->fetch_assoc()) {
    $audit_logs[] = $log;
}

// Get distinct actions for filter dropdown
$actions_query = "SELECT DISTINCT action FROM scan_logs WHERE action != '' ORDER BY action";
$actions_result = $conn->query($actions_query);
$actions = [];
while ($action = $actions_result->fetch_assoc()) {
    $actions[] = $action['action'];
}

// Get distinct scan types for filter dropdown
$types_query = "SELECT DISTINCT scan_type FROM scan_logs WHERE scan_type != '' ORDER BY scan_type";
$types_result = $conn->query($types_query);
$scan_types = [];
while ($type = $types_result->fetch_assoc()) {
    $scan_types[] = $type['scan_type'];
}

// Get users for filter dropdown
$users_query = "SELECT user_id, full_name, user_type FROM users WHERE status = 'active' ORDER BY full_name";
$users_result = $conn->query($users_query);
$users = [];
while ($user = $users_result->fetch_assoc()) {
    $users[] = $user;
}

// Get statistics
$stats_query = "SELECT 
                COUNT(*) as total_logs,
                COUNT(DISTINCT DATE(created_at)) as total_days,
                COUNT(DISTINCT user_id) as total_users,
                COUNT(DISTINCT student_id) as total_students
                FROM scan_logs";
$stats_result = $conn->query($stats_query);
$stats = $stats_result->fetch_assoc();

// Get recent activity by hour (for chart)
$hourly_query = "SELECT 
                 HOUR(created_at) as hour,
                 COUNT(*) as count
                 FROM scan_logs
                 WHERE DATE(created_at) = CURDATE()
                 GROUP BY HOUR(created_at)
                 ORDER BY hour";
$hourly_result = $conn->query($hourly_query);
$hourly_data = [];
while ($row = $hourly_result->fetch_assoc()) {
    $hourly_data[$row['hour']] = $row['count'];
}

// Get top actions
$top_actions_query = "SELECT 
                      action,
                      COUNT(*) as count
                      FROM scan_logs
                      GROUP BY action
                      ORDER BY count DESC
                      LIMIT 10";
$top_actions_result = $conn->query($top_actions_query);
$top_actions = [];
while ($action = $top_actions_result->fetch_assoc()) {
    $top_actions[] = $action;
}

// Get top users
$top_users_query = "SELECT 
                    u.full_name,
                    COUNT(*) as count
                    FROM scan_logs a
                    JOIN users u ON a.user_id = u.user_id
                    GROUP BY a.user_id
                    ORDER BY count DESC
                    LIMIT 10";
$top_users_result = $conn->query($top_users_query);
$top_users = [];
while ($user = $top_users_result->fetch_assoc()) {
    $top_users[] = $user;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Audit Logs | System Administration</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --primary-color: #3b82f6;
            --secondary-color: #8b5cf6;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .card {
            background: white;
            border-radius: 1rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        
        .card:hover {
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
        }
        
        .campus-badge {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 0.25rem;
        }
        
        .stat-card {
            background: linear-gradient(135deg, #f6f9fc 0%, #edf2f7 100%);
            border-radius: 0.75rem;
            padding: 1.5rem;
            text-align: center;
        }
        
        .stat-value {
            font-size: 2.5rem;
            font-weight: 700;
            line-height: 1;
        }
        
        .stat-label {
            color: #6b7280;
            font-size: 0.875rem;
            margin-top: 0.5rem;
        }
        
        .btn {
            padding: 0.75rem 1.5rem;
            border-radius: 0.75rem;
            font-weight: 600;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(59, 130, 246, 0.3);
        }
        
        .badge {
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 0.25rem;
        }
        
        .badge-info { background-color: #dbeafe; color: #1e40af; }
        .badge-success { background-color: #d1fae5; color: #065f46; }
        .badge-warning { background-color: #fef3c7; color: #92400e; }
        .badge-danger { background-color: #fee2e2; color: #991b1b; }
        .badge-purple { background-color: #ede9fe; color: #5b21b6; }
        
        .log-row {
            border-left: 4px solid transparent;
            transition: all 0.3s ease;
        }
        
        .log-row:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            background-color: #f9fafb;
        }
        
        .action-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.25rem;
        }
        
        .action-login { background-color: #dbeafe; color: #1e40af; }
        .action-scan { background-color: #d1fae5; color: #065f46; }
        .action-payment { background-color: #fef3c7; color: #92400e; }
        .action-create { background-color: #ede9fe; color: #5b21b6; }
        .action-update { background-color: #fce7f3; color: #9d174d; }
        .action-delete { background-color: #fee2e2; color: #991b1b; }
        
        .chart-container {
            position: relative;
            height: 200px;
            width: 100%;
        }
        
        .filter-card {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .pagination-btn {
            padding: 0.5rem 1rem;
            border-radius: 0.5rem;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .pagination-btn.active {
            background: var(--primary-color);
            color: white;
        }
        
        .pagination-btn:hover:not(.active) {
            background: #f3f4f6;
        }
        
        .log-details {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease-out;
        }
        
        .log-details.expanded {
            max-height: 500px;
        }
    </style>
</head>
<body class="min-h-screen p-4 md:p-8">
    <div class="max-w-7xl mx-auto">
        <!-- Header -->
        <div class="card p-6 mb-8">
            <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h1 class="text-3xl font-bold text-gray-900 mb-2">
                        <i class="fas fa-shield-alt text-blue-600 mr-2"></i>Audit Logs
                    </h1>
                    <div class="flex flex-wrap items-center gap-2">
                        <span class="campus-badge">
                            <i class="fas fa-school"></i> <?php echo htmlspecialchars($user_campus_name); ?>
                        </span>
                        <span class="px-3 py-1 bg-gray-100 text-gray-800 rounded-full text-sm font-medium">
                            <i class="fas fa-user mr-1"></i> <?php echo htmlspecialchars($user_name); ?>
                        </span>
                        <span class="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                            <i class="fas fa-shield-alt mr-1"></i> <?php echo ucfirst($user_type); ?>
                        </span>
                    </div>
                </div>
                <div class="flex flex-wrap gap-2">
                    <a href="admin_dashboard.php" class="btn">
                        <i class="fas fa-arrow-left"></i> Dashboard
                    </a>
                    <button onclick="exportLogs()" class="btn btn-primary">
                        <i class="fas fa-file-export mr-2"></i> Export Logs
                    </button>
                    <button onclick="clearOldLogs()" class="btn bg-red-100 text-red-800 hover:bg-red-200">
                        <i class="fas fa-trash-alt mr-2"></i> Clear Old Logs
                    </button>
                </div>
            </div>
        </div>
        
        <!-- Statistics Cards -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div class="stat-card">
                <div class="stat-value text-blue-600"><?php echo number_format($stats['total_logs']); ?></div>
                <div class="stat-label">Total Log Entries</div>
            </div>
            <div class="stat-card">
                <div class="stat_value text-green-600"><?php echo number_format($stats['total_days']); ?></div>
                <div class="stat-label">Days of Activity</div>
            </div>
            <div class="stat-card">
                <div class="stat-value text-purple-600"><?php echo number_format($stats['total_users']); ?></div>
                <div class="stat-label">Active Users</div>
            </div>
            <div class="stat-card">
                <div class="stat-value text-yellow-600"><?php echo number_format($stats['total_students']); ?></div>
                <div class="stat-label">Students Scanned</div>
            </div>
        </div>
        
        <!-- Charts Row -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <!-- Today's Activity Chart -->
            <div class="card p-6">
                <h2 class="text-xl font-bold text-gray-800 mb-4 flex items-center">
                    <i class="fas fa-chart-line text-blue-600 mr-2"></i> Today's Activity
                </h2>
                <div class="chart-container">
                    <canvas id="hourlyChart"></canvas>
                </div>
            </div>
            
            <!-- Top Actions -->
            <div class="card p-6">
                <h2 class="text-xl font-bold text-gray-800 mb-4 flex items-center">
                    <i class="fas fa-star text-yellow-600 mr-2"></i> Top Actions
                </h2>
                <div class="space-y-3">
                    <?php foreach ($top_actions as $action): ?>
                    <div class="flex items-center justify-between">
                        <div class="flex items-center">
                            <?php 
                            $action_icons = [
                                'login' => 'fas fa-sign-in-alt text-blue-600',
                                'logout' => 'fas fa-sign-out-alt text-gray-600',
                                'student_scanned' => 'fas fa-qrcode text-green-600',
                                'attendance_marked' => 'fas fa-check-circle text-green-600',
                                'payment_received' => 'fas fa-money-bill-wave text-yellow-600',
                                'fine_added' => 'fas fa-file-invoice-dollar text-purple-600',
                                'user_created' => 'fas fa-user-plus text-blue-600',
                                'user_updated' => 'fas fa-user-edit text-indigo-600',
                                'student_created' => 'fas fa-user-graduate text-green-600',
                                'student_updated' => 'fas fa-edit text-yellow-600'
                            ];
                            $icon = $action_icons[$action['action']] ?? 'fas fa-history text-gray-600';
                            ?>
                            <i class="<?php echo $icon; ?> mr-3"></i>
                            <div>
                                <div class="font-medium text-gray-900"><?php echo ucfirst(str_replace('_', ' ', $action['action'])); ?></div>
                            </div>
                        </div>
                        <span class="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                            <?php echo number_format($action['count']); ?>
                        </span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        
        <!-- Filters Card -->
        <div class="card p-6 mb-8">
            <h2 class="text-xl font-bold text-gray-800 mb-4 flex items-center">
                <i class="fas fa-filter text-purple-600 mr-2"></i> Filter Logs
            </h2>
            <form method="GET" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <input type="hidden" name="page" value="1">
                
                <div>
                    <label class="block mb-2 text-sm font-medium text-gray-700">Campus</label>
                    <select name="campus" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                        <option value="0" <?php echo $selected_campus == 0 ? 'selected' : ''; ?>>All Campuses</option>
                        <?php foreach ($campuses as $campus): ?>
                        <option value="<?php echo $campus['campus_id']; ?>" <?php echo $selected_campus == $campus['campus_id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($campus['campus_name']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div>
                    <label class="block mb-2 text-sm font-medium text-gray-700">Action Type</label>
                    <select name="action" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                        <option value="all" <?php echo $selected_action == 'all' ? 'selected' : ''; ?>>All Actions</option>
                        <?php foreach ($actions as $action): ?>
                        <option value="<?php echo $action; ?>" <?php echo $selected_action == $action ? 'selected' : ''; ?>>
                            <?php echo ucfirst(str_replace('_', ' ', $action)); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div>
                    <label class="block mb-2 text-sm font-medium text-gray-700">User</label>
                    <select name="user" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                        <option value="0" <?php echo $selected_user == 0 ? 'selected' : ''; ?>>All Users</option>
                        <?php foreach ($users as $user): ?>
                        <option value="<?php echo $user['user_id']; ?>" <?php echo $selected_user == $user['user_id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($user['full_name']); ?> (<?php echo $user['user_type']; ?>)
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div>
                    <label class="block mb-2 text-sm font-medium text-gray-700">Scan Type</label>
                    <select name="type" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                        <option value="all" <?php echo $selected_type == 'all' ? 'selected' : ''; ?>>All Types</option>
                        <?php foreach ($scan_types as $type): ?>
                        <option value="<?php echo $type; ?>" <?php echo $selected_type == $type ? 'selected' : ''; ?>>
                            <?php echo ucfirst($type); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div>
                    <label class="block mb-2 text-sm font-medium text-gray-700">Date</label>
                    <input type="date" 
                           name="date" 
                           value="<?php echo htmlspecialchars($selected_date); ?>"
                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                </div>
                
                <div>
                    <label class="block mb-2 text-sm font-medium text-gray-700">Search</label>
                    <input type="text" 
                           name="search" 
                           value="<?php echo htmlspecialchars($search_term); ?>"
                           placeholder="Search student, user, or action..."
                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                </div>
                
                <div class="flex items-end space-x-2">
                    <button type="submit" class="btn btn-primary flex-1">
                        <i class="fas fa-search mr-2"></i> Apply Filters
                    </button>
                    <a href="audit_logs.php" class="btn bg-gray-100 text-gray-800 hover:bg-gray-200">
                        <i class="fas fa-redo mr-2"></i> Reset
                    </a>
                </div>
            </form>
        </div>
        
        <!-- Logs Table -->
        <div class="card p-6">
            <div class="flex flex-col md:flex-row justify-between items-center mb-6">
                <h2 class="text-xl font-bold text-gray-800 flex items-center">
                    <i class="fas fa-history text-gray-600 mr-2"></i> Audit Trail
                    <span class="ml-2 text-sm font-normal text-gray-500">
                        (Showing <?php echo count($audit_logs); ?> of <?php echo number_format($total_logs); ?> entries)
                    </span>
                </h2>
                <div class="flex items-center space-x-2 mt-4 md:mt-0">
                    <span class="text-sm text-gray-600">
                        Page <?php echo $page; ?> of <?php echo $total_pages; ?>
                    </span>
                </div>
            </div>
            
            <?php if (!empty($audit_logs)): ?>
            <div class="space-y-4">
                <?php foreach ($audit_logs as $log): ?>
                <div class="log-row p-4 bg-gray-50 rounded-lg">
                    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div class="flex items-start space-x-4">
                            <div class="action-icon <?php echo getActionClass($log['action']); ?>">
                                <?php echo getActionIcon($log['action']); ?>
                            </div>
                            <div>
                                <div class="flex flex-wrap items-center gap-2 mb-1">
                                    <span class="font-semibold text-gray-900">
                                        <?php echo ucfirst(str_replace('_', ' ', $log['action'])); ?>
                                    </span>
                                    <?php if ($log['scan_type']): ?>
                                    <span class="badge badge-info">
                                        <i class="fas fa-tag mr-1"></i> <?php echo ucfirst($log['scan_type']); ?>
                                    </span>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="text-sm text-gray-600 mb-2">
                                    <?php if ($log['student_name']): ?>
                                    <span class="font-medium">Student:</span> 
                                    <?php echo htmlspecialchars($log['student_name']); ?>
                                    (<?php echo htmlspecialchars($log['student_number']); ?>)
                                    <?php if ($log['student_campus_name']): ?>
                                    • <span class="text-gray-500"><?php echo htmlspecialchars($log['student_campus_name']); ?></span>
                                    <?php endif; ?>
                                    <br>
                                    <?php endif; ?>
                                    
                                    <?php if ($log['user_name']): ?>
                                    <span class="font-medium">By:</span> 
                                    <?php echo htmlspecialchars($log['user_name']); ?>
                                    (<?php echo $log['user_type']; ?>)
                                    <?php if ($log['campus_name']): ?>
                                    • <span class="text-gray-500"><?php echo htmlspecialchars($log['campus_name']); ?></span>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="text-xs text-gray-500">
                                    <i class="far fa-clock mr-1"></i>
                                    <?php echo date('M d, Y g:i:s A', strtotime($log['created_at'])); ?>
                                    • IP: <?php echo $log['ip_address'] ?? 'N/A'; ?>
                                    <?php if ($log['user_agent']): ?>
                                    • Device: <?php echo htmlspecialchars($log['user_agent']); ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mt-4 md:mt-0">
                            <button onclick="toggleLogDetails(<?php echo $log['log_id']; ?>)" 
                                    class="btn bg-blue-50 text-blue-700 hover:bg-blue-100 text-sm">
                                <i class="fas fa-info-circle mr-1"></i> Details
                            </button>
                        </div>
                    </div>
                    
                    <!-- Hidden details section -->
                    <div id="log-details-<?php echo $log['log_id']; ?>" class="log-details mt-4 pt-4 border-t border-gray-200">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <h4 class="font-medium text-gray-700 mb-2">Log Information</h4>
                                <div class="space-y-1 text-sm">
                                    <div class="flex">
                                        <span class="w-32 text-gray-600">Log ID:</span>
                                        <span class="font-mono"><?php echo $log['log_id']; ?></span>
                                    </div>
                                    <div class="flex">
                                        <span class="w-32 text-gray-600">Timestamp:</span>
                                        <span><?php echo date('Y-m-d H:i:s', strtotime($log['created_at'])); ?></span>
                                    </div>
                                    <div class="flex">
                                        <span class="w-32 text-gray-600">IP Address:</span>
                                        <span><?php echo $log['ip_address'] ?? 'N/A'; ?></span>
                                    </div>
                                    <div class="flex">
                                        <span class="w-32 text-gray-600">Device Info:</span>
                                        <span><?php echo htmlspecialchars($log['user_agent'] ?? 'N/A'); ?></span>
                                    </div>
                                </div>
                            </div>
                            
                            <div>
                                <h4 class="font-medium text-gray-700 mb-2">Related Information</h4>
                                <div class="space-y-1 text-sm">
                                    <?php if ($log['student_id']): ?>
                                    <div class="flex">
                                        <span class="w-32 text-gray-600">Student ID:</span>
                                        <span><?php echo $log['student_id']; ?></span>
                                    </div>
                                    <div class="flex">
                                        <span class="w-32 text-gray-600">Student No:</span>
                                        <span><?php echo htmlspecialchars($log['student_number']); ?></span>
                                    </div>
                                    <div class="flex">
                                        <span class="w-32 text-gray-600">Course/Year:</span>
                                        <span><?php echo htmlspecialchars($log['course_year'] ?? 'N/A'); ?></span>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <?php if ($log['user_id']): ?>
                                    <div class="flex">
                                        <span class="w-32 text-gray-600">User ID:</span>
                                        <span><?php echo $log['user_id']; ?></span>
                                    </div>
                                    <div class="flex">
                                        <span class="w-32 text-gray-600">User Type:</span>
                                        <span><?php echo $log['user_type']; ?></span>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <div class="flex">
                                        <span class="w-32 text-gray-600">Student Code:</span>
                                        <span><?php echo htmlspecialchars($log['student_code'] ?? 'N/A'); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <?php if ($log['user_agent']): ?>
                        <div class="mt-4 pt-4 border-t border-gray-200">
                            <h4 class="font-medium text-gray-700 mb-2">Device Information</h4>
                            <div class="bg-gray-100 p-3 rounded text-sm">
                                <?php echo htmlspecialchars($log['user_agent']); ?>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
            <div class="mt-8 pt-6 border-t border-gray-200">
                <div class="flex flex-wrap justify-center items-center gap-2">
                    <!-- First Page -->
                    <?php if ($page > 1): ?>
                    <a href="<?php echo buildPaginationLink(1); ?>" 
                       class="pagination-btn">
                        <i class="fas fa-angle-double-left"></i>
                    </a>
                    <?php endif; ?>
                    
                    <!-- Previous Page -->
                    <?php if ($page > 1): ?>
                    <a href="<?php echo buildPaginationLink($page - 1); ?>" 
                       class="pagination-btn">
                        <i class="fas fa-angle-left"></i>
                    </a>
                    <?php endif; ?>
                    
                    <!-- Page Numbers -->
                    <?php 
                    $start_page = max(1, $page - 2);
                    $end_page = min($total_pages, $page + 2);
                    
                    for ($i = $start_page; $i <= $end_page; $i++): 
                    ?>
                    <a href="<?php echo buildPaginationLink($i); ?>" 
                       class="pagination-btn <?php echo $i == $page ? 'active' : ''; ?>">
                        <?php echo $i; ?>
                    </a>
                    <?php endfor; ?>
                    
                    <!-- Next Page -->
                    <?php if ($page < $total_pages): ?>
                    <a href="<?php echo buildPaginationLink($page + 1); ?>" 
                       class="pagination-btn">
                        <i class="fas fa-angle-right"></i>
                    </a>
                    <?php endif; ?>
                    
                    <!-- Last Page -->
                    <?php if ($page < $total_pages): ?>
                    <a href="<?php echo buildPaginationLink($total_pages); ?>" 
                       class="pagination-btn">
                        <i class="fas fa-angle-double-right"></i>
                    </a>
                    <?php endif; ?>
                </div>
                
                <div class="text-center mt-4 text-sm text-gray-600">
                    Showing <?php echo number_format(($page - 1) * $per_page + 1); ?> 
                    to <?php echo number_format(min($page * $per_page, $total_logs)); ?> 
                    of <?php echo number_format($total_logs); ?> entries
                </div>
            </div>
            <?php endif; ?>
            
            <?php else: ?>
            <div class="text-center py-12">
                <i class="fas fa-search text-gray-400 text-5xl mb-4"></i>
                <h3 class="text-xl font-bold text-gray-800 mb-2">No Audit Logs Found</h3>
                <p class="text-gray-600 mb-6">No log entries match your filter criteria.</p>
                <a href="audit_logs.php" class="btn btn-primary">
                    <i class="fas fa-redo mr-2"></i> Clear Filters
                </a>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Clear Logs Modal -->
    <div id="clearLogsModal" class="modal hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
        <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div class="mt-3">
                <div class="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-red-100">
                    <i class="fas fa-exclamation-triangle text-red-600 text-xl"></i>
                </div>
                <div class="mt-3 text-center">
                    <h3 class="text-lg leading-6 font-medium text-gray-900">Clear Old Logs</h3>
                    <div class="mt-2 px-7 py-3">
                        <p class="text-sm text-gray-500">
                            This will permanently delete audit logs older than 90 days. 
                            This action cannot be undone.
                        </p>
                        <div class="mt-4">
                            <label class="flex items-center">
                                <input type="checkbox" id="confirmDelete" class="rounded border-gray-300 text-red-600 focus:ring-red-500">
                                <span class="ml-2 text-sm text-gray-600">I understand this action cannot be undone</span>
                            </label>
                        </div>
                    </div>
                </div>
                <div class="items-center px-4 py-3">
                    <div class="flex justify-end space-x-3">
                        <button onclick="hideClearModal()" class="px-4 py-2 bg-gray-100 text-gray-800 rounded-lg hover:bg-gray-200">
                            Cancel
                        </button>
                        <button onclick="confirmClearLogs()" id="clearBtn" disabled class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 opacity-50 cursor-not-allowed">
                            Clear Logs
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Today's activity chart
        document.addEventListener('DOMContentLoaded', function() {
            const ctx = document.getElementById('hourlyChart').getContext('2d');
            
            // Prepare hourly data
            const hours = Array.from({length: 24}, (_, i) => i);
            const data = hours.map(hour => <?php echo json_encode($hourly_data); ?>[hour] || 0);
            
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: hours.map(hour => hour.toString().padStart(2, '0') + ':00'),
                    datasets: [{
                        label: 'Activity Count',
                        data: data,
                        backgroundColor: 'rgba(59, 130, 246, 0.1)',
                        borderColor: 'rgb(59, 130, 246)',
                        borderWidth: 2,
                        fill: true,
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                precision: 0
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                }
            });
        });
        
        // Toggle log details
        function toggleLogDetails(logId) {
            const details = document.getElementById('log-details-' + logId);
            details.classList.toggle('expanded');
            
            const button = event.currentTarget;
            if (details.classList.contains('expanded')) {
                button.innerHTML = '<i class="fas fa-chevron-up mr-1"></i> Hide Details';
                button.classList.remove('bg-blue-50', 'text-blue-700');
                button.classList.add('bg-blue-100', 'text-blue-800');
            } else {
                button.innerHTML = '<i class="fas fa-info-circle mr-1"></i> Details';
                button.classList.remove('bg-blue-100', 'text-blue-800');
                button.classList.add('bg-blue-50', 'text-blue-700');
            }
        }
        
        // Export logs to CSV
        function exportLogs() {
            // Show loading
            const button = event.currentTarget;
            const originalText = button.innerHTML;
            button.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Exporting...';
            button.disabled = true;
            
            // Build export URL with current filters
            const params = new URLSearchParams(window.location.search);
            params.set('export', 'csv');
            
            // Create download link
            const link = document.createElement('a');
            link.href = 'audit_logs.php?' + params.toString();
            link.download = 'audit_logs_' + new Date().toISOString().split('T')[0] + '.csv';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            // Reset button
            setTimeout(() => {
                button.innerHTML = originalText;
                button.disabled = false;
            }, 1000);
        }
        
        // Show clear logs modal
        function clearOldLogs() {
            document.getElementById('clearLogsModal').classList.remove('hidden');
            document.getElementById('clearLogsModal').classList.add('flex');
        }
        
        // Hide clear logs modal
        function hideClearModal() {
            document.getElementById('clearLogsModal').classList.remove('flex');
            document.getElementById('clearLogsModal').classList.add('hidden');
            document.getElementById('confirmDelete').checked = false;
            document.getElementById('clearBtn').disabled = true;
            document.getElementById('clearBtn').classList.add('opacity-50', 'cursor-not-allowed');
        }
        
        // Enable/disable clear button based on checkbox
        document.getElementById('confirmDelete').addEventListener('change', function() {
            const clearBtn = document.getElementById('clearBtn');
            if (this.checked) {
                clearBtn.disabled = false;
                clearBtn.classList.remove('opacity-50', 'cursor-not-allowed');
            } else {
                clearBtn.disabled = true;
                clearBtn.classList.add('opacity-50', 'cursor-not-allowed');
            }
        });
        
        // Confirm clear logs
        function confirmClearLogs() {
            if (!document.getElementById('confirmDelete').checked) return;
            
            const button = document.getElementById('clearBtn');
            button.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Clearing...';
            button.disabled = true;
            
            // Make AJAX request to clear logs
            fetch('clear_logs.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    days: 90,
                    confirm: true
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Successfully cleared ' + data.deleted + ' old log entries.');
                    location.reload();
                } else {
                    alert('Error: ' + data.message);
                    hideClearModal();
                }
            })
            .catch(error => {
                alert('Error clearing logs: ' + error.message);
                hideClearModal();
            });
        }
        
        // Modal backdrop click handler
        document.getElementById('clearLogsModal').addEventListener('click', function(e) {
            if (e.target === this) {
                hideClearModal();
            }
        });
        
        // Escape key handler
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                hideClearModal();
            }
        });
        
        // Auto-refresh page every 5 minutes to show latest logs
        setInterval(() => {
            if (!document.hidden) {
                // Only refresh if filters haven't been modified
                const currentParams = new URLSearchParams(window.location.search);
                if (!currentParams.has('search') && !currentParams.has('date') && !currentParams.has('action') && currentParams.get('page') === '1') {
                    location.reload();
                }
            }
        }, 300000); // 5 minutes
    </script>
</body>
</html>

<?php
// Helper functions
function getActionIcon($action) {
    $icons = [
        'login' => 'fas fa-sign-in-alt',
        'logout' => 'fas fa-sign-out-alt',
        'student_scanned' => 'fas fa-qrcode',
        'attendance_marked' => 'fas fa-check-circle',
        'payment_received' => 'fas fa-money-bill-wave',
        'fine_added' => 'fas fa-file-invoice-dollar',
        'user_created' => 'fas fa-user-plus',
        'user_updated' => 'fas fa-user-edit',
        'student_created' => 'fas fa-user-graduate',
        'student_updated' => 'fas fa-edit',
        'fine_paid' => 'fas fa-money-check',
        'fine_updated' => 'fas fa-edit',
        'system_event' => 'fas fa-cog'
    ];
    
    return $icons[$action] ?? 'fas fa-history';
}

function getActionClass($action) {
    $classes = [
        'login' => 'action-login',
        'logout' => 'action-login',
        'student_scanned' => 'action-scan',
        'attendance_marked' => 'action-scan',
        'payment_received' => 'action-payment',
        'fine_added' => 'action-create',
        'fine_paid' => 'action-payment',
        'user_created' => 'action-create',
        'user_updated' => 'action-update',
        'student_created' => 'action-create',
        'student_updated' => 'action-update',
        'fine_updated' => 'action-update',
        'system_event' => 'action-login'
    ];
    
    return $classes[$action] ?? 'action-login';
}

function buildPaginationLink($page) {
    $params = $_GET;
    $params['page'] = $page;
    return 'audit_logs.php?' . http_build_query($params);
}

$conn->close();
?>

<?php
// Handle CSV export
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=audit_logs_' . date('Y-m-d') . '.csv');
    
    $output = fopen('php://output', 'w');
    
    // Add CSV headers
    fputcsv($output, [
        'Log ID', 'Created At', 'Action', 'Scan Type', 
        'Student Number', 'Student Name', 'Course/Year', 'Section',
        'User Name', 'User Type', 'Campus',
        'IP Address', 'Device Info', 'Student Code', 'Attendance Type'
    ]);
    
    // Output all logs (not just current page)
    $export_query = "SELECT a.*, 
                     s.student_number, s.full_name as student_name, s.course_year, s.section,
                     u.full_name as user_name, u.user_type,
                     c.campus_name
                     FROM scan_logs a
                     LEFT JOIN students s ON a.student_id = s.student_id
                     LEFT JOIN users u ON a.user_id = u.user_id
                     LEFT JOIN campuses c ON u.campus_id = c.campus_id
                     ORDER BY a.created_at DESC";
    
    $export_result = $conn->query($export_query);
    
    while ($log = $export_result->fetch_assoc()) {
        fputcsv($output, [
            $log['log_id'],
            $log['created_at'],
            $log['action'],
            $log['scan_type'],
            $log['student_number'] ?? '',
            $log['student_name'] ?? '',
            $log['course_year'] ?? '',
            $log['section'] ?? '',
            $log['user_name'] ?? '',
            $log['user_type'] ?? '',
            $log['campus_name'] ?? '',
            $log['ip_address'] ?? '',
            $log['user_agent'] ?? '',
            $log['student_code'] ?? '',
            $log['attendance_type'] ?? ''
        ]);
    }
    
    fclose($output);
    exit();
}
?>