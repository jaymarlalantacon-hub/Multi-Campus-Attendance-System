<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_type']) || !in_array($_SESSION['user_type'], ['admin','coordinator'])) {
    header('Location: index.php');
    exit();
}

$user_campus_id = $_SESSION['campus_id'] ?? null;

// Build query based on user role
$query = "
    SELECT 
        s.student_number,
        s.full_name,
        s.email,
        s.phone,
        s.course_year,
        s.section,
        c.campus_name,
        c.campus_code
    FROM students s
    LEFT JOIN campuses c ON s.campus_id = c.campus_id
    WHERE s.status = 'active'
";

if ($user_campus_id && $_SESSION['user_type'] === 'coordinator') {
    $query .= " AND s.campus_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_campus_id);
} else {
    $stmt = $conn->prepare($query);
}

$stmt->execute();
$result = $stmt->get_result();

// Set headers for CSV download
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=student_list_' . date('Y-m-d') . '.csv');

// Output CSV headers
echo "student_number,full_name,email,phone,course_year,section,campus_name,campus_code\n";

// Output data
while ($row = $result->fetch_assoc()) {
    echo '"' . str_replace('"', '""', $row['student_number']) . '",';
    echo '"' . str_replace('"', '""', $row['full_name']) . '",';
    echo '"' . str_replace('"', '""', $row['email']) . '",';
    echo '"' . str_replace('"', '""', $row['phone']) . '",';
    echo '"' . str_replace('"', '""', $row['course_year']) . '",';
    echo '"' . str_replace('"', '""', $row['section']) . '",';
    echo '"' . str_replace('"', '""', $row['campus_name']) . '",';
    echo '"' . str_replace('"', '""', $row['campus_code']) . '"';
    echo "\n";
}

$conn->close();
?>