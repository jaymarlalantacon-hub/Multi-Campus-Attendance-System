<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_type']) || !in_array($_SESSION['user_type'], ['admin','coordinator'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// For coordinators, only show their campus
if ($_SESSION['user_type'] === 'coordinator' && isset($_SESSION['campus_id'])) {
    $campus_id = intval($_SESSION['campus_id']);
    $stmt = $conn->prepare("SELECT campus_id, campus_name FROM campuses WHERE campus_id = ? AND status = 'active'");
    $stmt->bind_param("i", $campus_id);
} else {
    // For admins, show all campuses
    $stmt = $conn->prepare("SELECT campus_id, campus_name FROM campuses WHERE status = 'active' ORDER BY campus_name");
}

$stmt->execute();
$result = $stmt->get_result();
$campuses = [];

while ($row = $result->fetch_assoc()) {
    $campuses[] = $row;
}

echo json_encode(['success' => true, 'campuses' => $campuses]);
$conn->close();
?>