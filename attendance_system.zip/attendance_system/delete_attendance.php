<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_type']) || !in_array($_SESSION['user_type'], ['admin','coordinator'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$attendance_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($attendance_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid attendance ID']);
    exit();
}

$query = "DELETE FROM attendance WHERE attendance_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $attendance_id);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Attendance record deleted successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
}

$conn->close();
?>