<?php
session_start();
require_once 'db.php';

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    header('Location: ' . ($_SESSION['user_type'] === 'admin' ? 'admin_dashboard.php' : 'coordinator_dashboard.php'));
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = sanitizeInput($_POST['full_name']);
    $username = sanitizeInput($_POST['username']);
    $email = sanitizeInput($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $admin_code = sanitizeInput($_POST['admin_code']);
    $security_question = sanitizeInput($_POST['security_question']);
    $security_answer = sanitizeInput($_POST['security_answer']);
    
    // Validation
    if (empty($full_name) || empty($username) || empty($email) || empty($password) || empty($admin_code)) {
        $error = 'All fields are required!';
    } elseif ($admin_code !== 'ADMIN2025SECURE') {
        $error = 'Invalid admin registration code!';
    } elseif ($password !== $confirm_password) {
        $error = 'Passwords do not match!';
    } elseif (strlen($password) < 8) {
        $error = 'Password must be at least 8 characters!';
    } else {
        // Check if username or email exists
        $check = $conn->prepare("SELECT user_id FROM users WHERE username = ? OR email = ?");
        $check->bind_param("ss", $username, $email);
        $check->execute();
        $check->store_result();
        
        if ($check->num_rows > 0) {
            $error = 'Username or email already exists!';
        } else {
            // Hash password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Insert admin user
            $stmt = $conn->prepare("INSERT INTO users (full_name, username, email, password, user_type, status, security_question, security_answer, created_at) VALUES (?, ?, ?, ?, 'admin', 'pending', ?, ?, NOW())");
            $stmt->bind_param("ssssss", $full_name, $username, $email, $hashed_password, $security_question, $security_answer);
            
            if ($stmt->execute()) {
                $success = 'Admin registration submitted successfully! Your account requires super admin approval.';
            } else {
                $error = 'Registration failed. Please try again!';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Registration | Multi-Campus Attendance System</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            min-height: 100vh;
        }
        .admin-register-box {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.25);
        }
        .security-badge {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
    </style>
</head>
<body class="flex items-center justify-center p-4 min-h-screen">
    <div class="w-full max-w-2xl">
        <!-- Main Container -->
        <div class="admin-register-box rounded-3xl overflow-hidden">
            <!-- Header -->
            <div class="security-badge text-white p-8 text-center">
                <div class="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-shield-alt text-3xl"></i>
                </div>
                <h1 class="text-3xl font-bold mb-2">Admin Registration Portal</h1>
                <p class="text-white/80 text-sm">Super Admin access requires special authorization</p>
            </div>
            
            <!-- Form -->
            <div class="bg-white p-8 md:p-12">
                <?php if ($error): ?>
                <div class="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl flex items-center text-red-700">
                    <i class="fas fa-exclamation-circle mr-3"></i>
                    <span><?php echo htmlspecialchars($error); ?></span>
                </div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                <div class="mb-6 p-4 bg-green-50 border border-green-200 rounded-xl flex items-center text-green-700">
                    <i class="fas fa-check-circle mr-3"></i>
                    <span><?php echo htmlspecialchars($success); ?></span>
                    <a href="index.php" class="ml-auto text-blue-600 hover:text-blue-800">Back to Login</a>
                </div>
                <?php endif; ?>
                
                <form method="POST" action="">
                    <div class="space-y-6">
                        <!-- Personal Info -->
                        <div class="grid md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-gray-700 mb-2 font-semibold">
                                    <i class="fas fa-user text-blue-600 mr-2"></i>Full Name *
                                </label>
                                <input type="text" name="full_name" required
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                                       placeholder="Enter full name">
                            </div>
                            
                            <div>
                                <label class="block text-gray-700 mb-2 font-semibold">
                                    <i class="fas fa-at text-blue-600 mr-2"></i>Username *
                                </label>
                                <input type="text" name="username" required
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                                       placeholder="Choose username">
                            </div>
                        </div>
                        
                        <!-- Email & Security -->
                        <div class="grid md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-gray-700 mb-2 font-semibold">
                                    <i class="fas fa-envelope text-blue-600 mr-2"></i>Email Address *
                                </label>
                                <input type="email" name="email" required
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                                       placeholder="Enter email">
                            </div>
                            
                            <div>
                                <label class="block text-gray-700 mb-2 font-semibold">
                                    <i class="fas fa-shield text-purple-600 mr-2"></i>Admin Code *
                                </label>
                                <input type="password" name="admin_code" required
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all"
                                       placeholder="Enter admin code">
                            </div>
                        </div>
                        
                        <!-- Passwords -->
                        <div class="grid md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-gray-700 mb-2 font-semibold">
                                    <i class="fas fa-lock text-green-600 mr-2"></i>Password *
                                </label>
                                <input type="password" name="password" required minlength="8"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all"
                                       placeholder="Min. 8 characters">
                            </div>
                            
                            <div>
                                <label class="block text-gray-700 mb-2 font-semibold">
                                    <i class="fas fa-lock text-green-600 mr-2"></i>Confirm Password *
                                </label>
                                <input type="password" name="confirm_password" required minlength="8"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-all"
                                       placeholder="Confirm password">
                            </div>
                        </div>
                        
                        <!-- Security Question -->
                        <div class="grid md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-gray-700 mb-2 font-semibold">
                                    <i class="fas fa-question-circle text-orange-600 mr-2"></i>Security Question *
                                </label>
                                <select name="security_question" required
                                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition-all">
                                    <option value="">Select a question</option>
                                    <option value="What is your mother's maiden name?">What is your mother's maiden name?</option>
                                    <option value="What was your first pet's name?">What was your first pet's name?</option>
                                    <option value="What elementary school did you attend?">What elementary school did you attend?</option>
                                    <option value="What city were you born in?">What city were you born in?</option>
                                    <option value="What is your favorite book?">What is your favorite book?</option>
                                </select>
                            </div>
                            
                            <div>
                                <label class="block text-gray-700 mb-2 font-semibold">
                                    <i class="fas fa-key text-orange-600 mr-2"></i>Security Answer *
                                </label>
                                <input type="text" name="security_answer" required
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 transition-all"
                                       placeholder="Your answer">
                            </div>
                        </div>
                        
                        <!-- Security Notice -->
                        <div class="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                            <div class="flex items-start">
                                <i class="fas fa-exclamation-triangle text-yellow-600 mt-1 mr-3"></i>
                                <div>
                                    <h4 class="font-semibold text-yellow-800 mb-1">Security Notice</h4>
                                    <ul class="text-sm text-yellow-700 space-y-1">
                                        <li>• Admin accounts require manual approval from existing super admin</li>
                                        <li>• Keep your admin code confidential</li>
                                        <li>• Use strong passwords with mixed characters</li>
                                        <li>• Remember your security question for account recovery</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Submit Button -->
                        <button type="submit"
                                class="w-full bg-gradient-to-r from-purple-700 to-indigo-800 text-white py-3.5 rounded-lg font-semibold hover:from-purple-800 hover:to-indigo-900 transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-0.5">
                            <i class="fas fa-user-shield mr-2"></i>Register as Admin
                        </button>
                        
                        <!-- Back to Login -->
                        <div class="text-center pt-4">
                            <a href="index.php" class="text-gray-600 hover:text-purple-600 transition-colors">
                                <i class="fas fa-arrow-left mr-2"></i>Back to Regular Login
                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Footer -->
        <div class="text-center text-white/60 mt-6 text-sm">
            <p>Admin Registration Portal | Multi-Campus System © 2025</p>
            <p class="mt-1">For authorized personnel only</p>
        </div>
    </div>
</body>
</html>