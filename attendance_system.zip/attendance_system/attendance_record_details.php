<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_type']) || !in_array($_SESSION['user_type'], ['admin','coordinator'])) {
    header('Location: index.php');
    exit();
}

$record_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($record_id <= 0) {
    header('Location: manage_attendance.php');
    exit();
}

// Get record details
$query = "
    SELECT 
        a.*,
        s.student_number,
        s.full_name,
        s.email,
        s.phone,
        s.course_year,
        s.section,
        s.photo,
        ac.activity_name,
        ac.activity_date,
        ac.activity_time,
        ac.venue,
        ac.description as activity_description,
        c.campus_name,
        c.campus_code,
        u.full_name as checked_by_name,
        u.email as checked_by_email
    FROM attendance a
    LEFT JOIN students s ON a.student_id = s.student_id
    LEFT JOIN activities ac ON a.activity_id = ac.activity_id
    LEFT JOIN campuses c ON s.campus_id = c.campus_id
    LEFT JOIN users u ON a.checked_by = u.user_id
    WHERE a.attendance_id = ?
";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $record_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header('Location: manage_attendance.php');
    exit();
}

$record = $result->fetch_assoc();
$user_name = $_SESSION['full_name'] ?? $_SESSION['username'] ?? 'User';

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Attendance Record Details | Multi-Campus Attendance</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50 min-h-screen">

<!-- Navigation -->
<nav class="bg-gradient-to-r from-purple-800 to-indigo-900 text-white shadow-lg">
    <div class="container mx-auto px-4 py-3">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div class="flex items-center space-x-4">
                <a href="manage_attendance.php" class="flex items-center hover:text-purple-200 transition-colors">
                    <i class="fas fa-arrow-left mr-2"></i> Back to Manage
                </a>
                <h1 class="text-xl font-bold">
                    <i class="fas fa-file-alt mr-2"></i> Record Details
                </h1>
            </div>
            <div class="flex items-center space-x-4">
                <span class="text-sm">
                    <i class="fas fa-user mr-1"></i> <?php echo htmlspecialchars($user_name); ?>
                </span>
                <a href="logout.php" class="text-sm hover:text-purple-200 transition-colors">
                    <i class="fas fa-sign-out-alt mr-1"></i> Logout
                </a>
            </div>
        </div>
    </div>
</nav>

<div class="container mx-auto px-4 py-8">
    <div class="max-w-4xl mx-auto">
        <!-- Header -->
        <div class="mb-8">
            <h1 class="text-3xl font-bold text-gray-800 mb-2">Attendance Record Details</h1>
            <p class="text-gray-600">Complete information for attendance record #<?php echo $record['attendance_id']; ?></p>
        </div>

        <!-- Record Card -->
        <div class="bg-white rounded-2xl shadow-xl overflow-hidden">
            <!-- Status Header -->
            <div class="px-8 py-6 <?php echo getStatusColor($record['status']); ?> text-white">
                <div class="flex justify-between items-center">
                    <div>
                        <h2 class="text-2xl font-bold"><?php echo $record['status']; ?> Attendance</h2>
                        <p class="opacity-90">Record ID: <?php echo $record['attendance_id']; ?></p>
                    </div>
                    <span class="text-3xl">
                        <?php echo getStatusIcon($record['status']); ?>
                    </span>
                </div>
            </div>

            <!-- Record Details -->
            <div class="p-8">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <!-- Student Information -->
                    <div>
                        <h3 class="text-xl font-semibold text-gray-800 mb-4 pb-2 border-b border-gray-200">
                            <i class="fas fa-user-graduate text-purple-600 mr-2"></i> Student Information
                        </h3>
                        <div class="space-y-3">
                            <div class="flex justify-between">
                                <span class="font-medium text-gray-700">Full Name:</span>
                                <span class="text-gray-900"><?php echo htmlspecialchars($record['full_name']); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="font-medium text-gray-700">Student Number:</span>
                                <span class="text-gray-900 font-semibold"><?php echo htmlspecialchars($record['student_number']); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="font-medium text-gray-700">Email:</span>
                                <span class="text-gray-900"><?php echo htmlspecialchars($record['email'] ?? 'N/A'); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="font-medium text-gray-700">Phone:</span>
                                <span class="text-gray-900"><?php echo htmlspecialchars($record['phone'] ?? 'N/A'); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="font-medium text-gray-700">Course/Year:</span>
                                <span class="text-gray-900"><?php echo htmlspecialchars($record['course_year'] ?? 'N/A'); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="font-medium text-gray-700">Section:</span>
                                <span class="text-gray-900"><?php echo htmlspecialchars($record['section'] ?? 'N/A'); ?></span>
                            </div>
                        </div>
                    </div>

                    <!-- Activity Information -->
                    <div>
                        <h3 class="text-xl font-semibold text-gray-800 mb-4 pb-2 border-b border-gray-200">
                            <i class="fas fa-calendar-alt text-purple-600 mr-2"></i> Activity Information
                        </h3>
                        <div class="space-y-3">
                            <div class="flex justify-between">
                                <span class="font-medium text-gray-700">Activity Name:</span>
                                <span class="text-gray-900"><?php echo htmlspecialchars($record['activity_name']); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="font-medium text-gray-700">Date:</span>
                                <span class="text-gray-900"><?php echo date('F j, Y', strtotime($record['activity_date'])); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="font-medium text-gray-700">Time:</span>
                                <span class="text-gray-900"><?php echo date('h:i A', strtotime($record['activity_time'])); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="font-medium text-gray-700">Venue:</span>
                                <span class="text-gray-900"><?php echo htmlspecialchars($record['venue'] ?? 'N/A'); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="font-medium text-gray-700">Campus:</span>
                                <span class="text-gray-900"><?php echo htmlspecialchars($record['campus_name']); ?></span>
                            </div>
                        </div>
                    </div>

                    <!-- Attendance Details -->
                    <div>
                        <h3 class="text-xl font-semibold text-gray-800 mb-4 pb-2 border-b border-gray-200">
                            <i class="fas fa-clock text-purple-600 mr-2"></i> Attendance Details
                        </h3>
                        <div class="space-y-3">
                            <div class="flex justify-between">
                                <span class="font-medium text-gray-700">Time In:</span>
                                <span class="text-gray-900"><?php echo $record['time_in'] ? date('F j, Y h:i A', strtotime($record['time_in'])) : 'N/A'; ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="font-medium text-gray-700">Time Out:</span>
                                <span class="text-gray-900"><?php echo $record['time_out'] ? date('F j, Y h:i A', strtotime($record['time_out'])) : 'N/A'; ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="font-medium text-gray-700">Late Minutes:</span>
                                <span class="text-gray-900"><?php echo $record['late_minutes'] > 0 ? $record['late_minutes'] . ' minutes' : 'None'; ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="font-medium text-gray-700">Scanned At:</span>
                                <span class="text-gray-900"><?php echo date('F j, Y h:i A', strtotime($record['scanned_at'])); ?></span>
                            </div>
                        </div>
                    </div>

                    <!-- System Information -->
                    <div>
                        <h3 class="text-xl font-semibold text-gray-800 mb-4 pb-2 border-b border-gray-200">
                            <i class="fas fa-cogs text-purple-600 mr-2"></i> System Information
                        </h3>
                        <div class="space-y-3">
                            <div class="flex justify-between">
                                <span class="font-medium text-gray-700">Checked By:</span>
                                <span class="text-gray-900"><?php echo htmlspecialchars($record['checked_by_name'] ?? 'System'); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="font-medium text-gray-700">Created At:</span>
                                <span class="text-gray-900"><?php echo date('F j, Y h:i A', strtotime($record['scanned_at'])); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="font-medium text-gray-700">Last Updated:</span>
                                <span class="text-gray-900"><?php echo date('F j, Y h:i A', strtotime($record['updated_at'])); ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Activity Description -->
                <?php if (!empty($record['activity_description'])): ?>
                <div class="mt-8 pt-6 border-t border-gray-200">
                    <h3 class="text-xl font-semibold text-gray-800 mb-3">
                        <i class="fas fa-align-left text-purple-600 mr-2"></i> Activity Description
                    </h3>
                    <div class="bg-gray-50 p-4 rounded-lg">
                        <p class="text-gray-700"><?php echo nl2br(htmlspecialchars($record['activity_description'])); ?></p>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Action Buttons -->
                <div class="mt-8 pt-6 border-t border-gray-200 flex justify-end gap-3">
                    <a href="manage_attendance.php" class="px-6 py-2.5 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors">
                        Back to List
                    </a>
                    <button onclick="window.print()" class="px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                        <i class="fas fa-print mr-2"></i> Print
                    </button>
                    <a href="edit_attendance.php?id=<?php echo $record['attendance_id']; ?>" class="px-6 py-2.5 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                        <i class="fas fa-edit mr-2"></i> Edit Record
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>

<?php
function getStatusColor($status) {
    switch($status) {
        case 'Present': return 'bg-gradient-to-r from-green-500 to-emerald-600';
        case 'Late': return 'bg-gradient-to-r from-yellow-500 to-amber-600';
        case 'Absent': return 'bg-gradient-to-r from-red-500 to-rose-600';
        case 'Excused': return 'bg-gradient-to-r from-blue-500 to-indigo-600';
        default: return 'bg-gradient-to-r from-gray-500 to-gray-600';
    }
}

function getStatusIcon($status) {
    switch($status) {
        case 'Present': return 'fas fa-user-check';
        case 'Late': return 'fas fa-clock';
        case 'Absent': return 'fas fa-user-times';
        case 'Excused': return 'fas fa-user-check';
        default: return 'fas fa-user';
    }
}
?>