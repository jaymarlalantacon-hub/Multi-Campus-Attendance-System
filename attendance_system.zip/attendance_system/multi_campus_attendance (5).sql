-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 30, 2025 at 09:32 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `multi_campus_attendance`
--

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

CREATE TABLE `activities` (
  `activity_id` int(11) NOT NULL,
  `activity_name` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `campus_id` int(11) NOT NULL,
  `activity_date` date NOT NULL,
  `activity_time` time NOT NULL,
  `venue` varchar(200) DEFAULT NULL,
  `mandatory` tinyint(1) DEFAULT 1,
  `fines_amount` decimal(10,2) DEFAULT 100.00,
  `photo` varchar(255) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `status` enum('upcoming','ongoing','completed','cancelled') DEFAULT 'upcoming',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `cancellation_reason` text DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `activity_type` enum('whole_day','half_day') DEFAULT 'whole_day',
  `scan_frequency` enum('2x','4x') DEFAULT '2x',
  `checkin_fine` decimal(10,2) DEFAULT 50.00,
  `checkout_fine` decimal(10,2) DEFAULT 50.00,
  `late_checkin_fine` decimal(10,2) DEFAULT 25.00,
  `late_checkout_fine` decimal(10,2) DEFAULT 25.00,
  `absent_fine` decimal(10,2) DEFAULT 100.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `activities`
--

INSERT INTO `activities` (`activity_id`, `activity_name`, `description`, `campus_id`, `activity_date`, `activity_time`, `venue`, `mandatory`, `fines_amount`, `photo`, `created_by`, `status`, `created_at`, `updated_at`, `cancellation_reason`, `end_time`, `activity_type`, `scan_frequency`, `checkin_fine`, `checkout_fine`, `late_checkin_fine`, `late_checkout_fine`, `absent_fine`) VALUES
(1, 'meeting', 'nghge', 2, '2025-12-18', '08:00:00', '', 1, 25.00, NULL, 1, 'upcoming', '2025-12-17 09:55:35', '2025-12-17 09:55:35', NULL, NULL, 'whole_day', '2x', 50.00, 50.00, 25.00, 25.00, 100.00),
(2, 'Assembly', 'ggha', 2, '2025-12-17', '20:00:00', 'gym', 1, 25.00, NULL, 1, 'upcoming', '2025-12-17 11:41:19', '2025-12-17 11:41:19', NULL, NULL, 'whole_day', '2x', 50.00, 50.00, 25.00, 25.00, 100.00),
(3, 'Assembly', 'gfrr', 2, '2025-12-17', '23:00:00', 'h', 1, 100.00, NULL, 1, 'upcoming', '2025-12-17 14:44:43', '2025-12-17 14:44:43', NULL, NULL, 'whole_day', '2x', 50.00, 50.00, 25.00, 25.00, 100.00),
(4, 'sports', 'dghrrv', 2, '2025-12-18', '15:00:00', 'gym', 1, 25.00, NULL, 5, 'upcoming', '2025-12-18 05:47:56', '2025-12-18 05:47:56', NULL, NULL, 'whole_day', '2x', 50.00, 50.00, 25.00, 25.00, 100.00),
(5, 'Assembly', 'hfgeygf', 2, '2025-12-19', '08:00:00', 'gym', 1, 25.00, NULL, 1, 'upcoming', '2025-12-18 08:56:07', '2025-12-18 08:56:07', NULL, NULL, 'whole_day', '2x', 50.00, 50.00, 25.00, 25.00, 100.00),
(6, 'Intramurals', 'ef3', 2, '2025-12-31', '08:00:00', 'gym', 1, 100.00, NULL, 1, 'upcoming', '2025-12-30 01:23:33', '2025-12-30 07:35:09', NULL, NULL, 'whole_day', '4x', 50.00, 50.00, 25.00, 25.00, 100.00);

-- --------------------------------------------------------

--
-- Table structure for table `activity_logs`
--

CREATE TABLE `activity_logs` (
  `log_id` int(11) NOT NULL,
  `activity_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action` varchar(50) NOT NULL,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `admin_logs`
--

CREATE TABLE `admin_logs` (
  `log_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `action` varchar(50) NOT NULL,
  `details` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `attendance_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `activity_id` int(11) NOT NULL,
  `scan_type` varchar(20) NOT NULL DEFAULT 'checkin' COMMENT 'checkin, checkout, checkin_am, checkout_am, checkin_pm, checkout_pm',
  `time_in` datetime DEFAULT NULL,
  `time_out` datetime DEFAULT NULL,
  `is_late` tinyint(1) DEFAULT 0,
  `status` enum('Present','Absent','Late','Excused') DEFAULT 'Absent',
  `late_minutes` int(11) DEFAULT 0,
  `checked_by` int(11) DEFAULT NULL,
  `scanned_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`attendance_id`, `student_id`, `activity_id`, `scan_type`, `time_in`, `time_out`, `is_late`, `status`, `late_minutes`, `checked_by`, `scanned_at`, `updated_at`) VALUES
(1, 3, 2, 'checkin', '2025-12-17 23:48:02', NULL, 0, 'Late', 214, 1, '2025-12-17 15:48:02', '2025-12-17 15:48:02'),
(2, 3, 1, 'checkin', '2025-12-18 13:50:30', NULL, 0, 'Absent', 336, 5, '2025-12-18 05:50:30', '2025-12-30 01:09:33'),
(3, 4, 5, 'checkin', '2025-12-18 16:57:23', NULL, 0, 'Present', 0, 1, '2025-12-18 08:57:23', '2025-12-18 08:57:23'),
(4, 15, 6, 'checkin', '2025-12-30 16:10:43', NULL, 1, 'Late', 491, 1, '2025-12-30 08:10:43', '2025-12-30 08:10:43');

-- --------------------------------------------------------

--
-- Table structure for table `campuses`
--

CREATE TABLE `campuses` (
  `campus_id` int(11) NOT NULL,
  `campus_name` varchar(100) NOT NULL,
  `campus_code` varchar(10) NOT NULL,
  `address` text DEFAULT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `fines_per_absence` decimal(10,2) DEFAULT 100.00,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `campuses`
--

INSERT INTO `campuses` (`campus_id`, `campus_name`, `campus_code`, `address`, `contact_person`, `contact_number`, `fines_per_absence`, `status`, `created_at`) VALUES
(1, 'ACCESS Campus', 'ACC', 'ACCESS Campus, Isulan, Sultan Kudarat', 'Campus Head', '09123456789', 100.00, 'active', '2025-12-17 09:01:19'),
(2, 'Isulan', 'ISU', 'Isulan Campus, Sultan Kudarat', 'Campus Head', '09123456790', 100.00, 'active', '2025-12-17 09:01:19'),
(3, 'Tacurong', 'TAC', 'Tacurong City, Sultan Kudarat', 'Campus Head', '09123456791', 100.00, 'active', '2025-12-17 09:01:19'),
(4, 'Kalamansig', 'KAL', 'Kalamansig, Sultan Kudarat', 'Campus Head', '09123456792', 100.00, 'active', '2025-12-17 09:01:19'),
(5, 'Bagumbayan', 'BAG', 'Bagumbayan, Sultan Kudarat', 'Campus Head', '09123456793', 100.00, 'active', '2025-12-17 09:01:19'),
(6, 'Palimbang', 'PAL', 'Palimbang, Sultan Kudarat', 'Campus Head', '09123456794', 100.00, 'active', '2025-12-17 09:01:19'),
(7, 'Lutayan', 'LUT', 'Lutayan, Sultan Kudarat', 'Campus Head', '09123456795', 100.00, 'active', '2025-12-17 09:01:19');

-- --------------------------------------------------------

--
-- Table structure for table `email_logs`
--

CREATE TABLE `email_logs` (
  `log_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `email_type` varchar(50) NOT NULL,
  `sent_at` datetime NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fines`
--

CREATE TABLE `fines` (
  `fine_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `activity_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `reason` enum('absence','late','other') DEFAULT 'absence',
  `description` text DEFAULT NULL,
  `status` enum('pending','paid','partial','cancelled') DEFAULT 'pending',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `scan_type` enum('checkin','checkout','checkin_am','checkout_am','checkin_pm','checkout_pm','absent','late_checkin','late_checkout','partial_attendance') DEFAULT 'absent'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fines`
--

INSERT INTO `fines` (`fine_id`, `student_id`, `activity_id`, `amount`, `reason`, `description`, `status`, `created_by`, `created_at`, `updated_at`, `scan_type`) VALUES
(3, 3, 3, 100.00, 'absence', NULL, 'pending', 1, '2025-12-17 14:44:43', '2025-12-17 14:44:43', 'absent'),
(5, 3, 4, 25.00, 'absence', NULL, 'paid', 5, '2025-12-18 05:47:56', '2025-12-18 06:23:45', 'absent');

-- --------------------------------------------------------

--
-- Table structure for table `fine_payments`
--

CREATE TABLE `fine_payments` (
  `payment_id` int(11) NOT NULL,
  `fine_id` int(11) NOT NULL,
  `amount_paid` decimal(10,2) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_method` enum('cash','gcash','bank_transfer','check') DEFAULT 'cash',
  `reference_no` varchar(100) DEFAULT NULL,
  `received_by` int(11) NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fine_payments`
--

INSERT INTO `fine_payments` (`payment_id`, `fine_id`, `amount_paid`, `payment_date`, `payment_method`, `reference_no`, `received_by`, `notes`, `created_at`) VALUES
(1, 5, 25.00, '2025-12-18', 'cash', '', 5, NULL, '2025-12-18 06:23:45');

-- --------------------------------------------------------

--
-- Table structure for table `login_logs`
--

CREATE TABLE `login_logs` (
  `log_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `login_time` datetime NOT NULL DEFAULT current_timestamp(),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `monthly_reports`
--

CREATE TABLE `monthly_reports` (
  `report_id` int(11) NOT NULL,
  `campus_id` int(11) NOT NULL,
  `report_month` date NOT NULL,
  `total_students` int(11) DEFAULT 0,
  `activities_count` int(11) DEFAULT 0,
  `present_count` int(11) DEFAULT 0,
  `absent_count` int(11) DEFAULT 0,
  `total_fines` decimal(10,2) DEFAULT 0.00,
  `paid_fines` decimal(10,2) DEFAULT 0.00,
  `pending_fines` decimal(10,2) DEFAULT 0.00,
  `generated_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `scan_logs`
--

CREATE TABLE `scan_logs` (
  `log_id` int(11) NOT NULL,
  `student_code` varchar(50) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `activity_id` int(11) DEFAULT NULL,
  `scan_type` enum('attendance','fines') NOT NULL,
  `attendance_type` enum('in','out') DEFAULT NULL,
  `action` varchar(50) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_type` varchar(20) NOT NULL,
  `details` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `scan_logs`
--

INSERT INTO `scan_logs` (`log_id`, `student_code`, `student_id`, `activity_id`, `scan_type`, `attendance_type`, `action`, `user_id`, `user_type`, `details`, `ip_address`, `user_agent`, `created_at`) VALUES
(1, 'STU202591956', 1, NULL, 'attendance', NULL, 'student_added', 1, 'admin', NULL, NULL, NULL, '2025-12-17 09:40:26'),
(2, 'yry', 2, NULL, 'attendance', NULL, 'student_added', 1, 'admin', NULL, NULL, NULL, '2025-12-17 14:09:40'),
(3, 'STU202588201', 3, NULL, 'attendance', NULL, 'student_added', 1, 'admin', NULL, NULL, NULL, '2025-12-17 14:27:33'),
(4, 'STU202588201', 3, NULL, 'fines', NULL, 'student_scanned', 5, '0', NULL, NULL, NULL, '2025-12-18 06:21:27'),
(5, 'STU202588201', 3, NULL, 'fines', NULL, 'payment_received', 5, '0', NULL, NULL, NULL, '2025-12-18 06:23:45'),
(6, 'STU202586635', 4, NULL, 'attendance', NULL, 'student_added', 1, 'admin', NULL, NULL, NULL, '2025-12-18 08:54:41'),
(7, 'STU202588201', 3, NULL, 'fines', NULL, 'student_scanned', 1, '0', NULL, NULL, NULL, '2025-12-29 06:10:56'),
(8, 'STU202591956', 1, NULL, 'fines', NULL, 'student_scanned', 1, '0', NULL, NULL, NULL, '2025-12-29 06:11:26'),
(9, 'STU202591956', 1, NULL, 'fines', NULL, 'student_scanned', 1, '0', NULL, NULL, NULL, '2025-12-29 06:12:06'),
(10, 'STU202591956', 1, NULL, 'fines', NULL, 'student_scanned', 1, '0', NULL, NULL, NULL, '2025-12-29 06:22:25'),
(11, 'STU202556840', 5, NULL, 'attendance', NULL, 'student_added', 1, 'admin', NULL, NULL, NULL, '2025-12-29 06:24:22'),
(12, 'STU202511628', 6, NULL, 'attendance', NULL, 'student_added', 1, 'admin', NULL, NULL, NULL, '2025-12-29 06:29:17'),
(13, 'STU202511398', 7, NULL, 'attendance', NULL, 'student_added', 1, 'admin', NULL, NULL, NULL, '2025-12-29 06:37:57'),
(14, 'STU202569635', 8, NULL, 'attendance', NULL, 'student_added', 1, 'admin', NULL, NULL, NULL, '2025-12-29 06:52:27'),
(15, 'STU202591410', 9, NULL, 'attendance', NULL, 'student_added', 1, 'admin', NULL, NULL, NULL, '2025-12-29 06:54:09'),
(16, 'STU202590019', 10, NULL, 'attendance', NULL, 'student_added', 1, 'admin', NULL, NULL, NULL, '2025-12-29 07:03:50'),
(17, 'STU202533762', 11, NULL, 'attendance', NULL, 'student_added', 1, 'admin', NULL, NULL, NULL, '2025-12-29 07:17:56'),
(18, 'STU202595166', 12, NULL, 'attendance', NULL, 'student_added', 1, 'admin', NULL, NULL, NULL, '2025-12-29 07:22:50'),
(19, 'STU202532147', 13, NULL, 'attendance', NULL, 'student_added', 1, 'admin', NULL, NULL, NULL, '2025-12-29 07:53:41'),
(20, 'STU202588201', 3, NULL, 'fines', NULL, 'student_scanned', 1, '0', NULL, NULL, NULL, '2025-12-29 08:25:56'),
(21, 'STU202588201', 3, NULL, 'fines', NULL, 'student_scanned', 1, '0', NULL, NULL, NULL, '2025-12-29 08:39:48'),
(22, 'STU202588201', 3, NULL, 'fines', NULL, 'student_scanned', 1, '0', NULL, NULL, NULL, '2025-12-29 08:40:07'),
(23, 'STU202588201', 3, NULL, 'fines', NULL, 'student_scanned', 1, '0', NULL, NULL, NULL, '2025-12-29 08:40:39'),
(24, 'STU202588201', 3, NULL, 'fines', NULL, 'student_scanned', 1, '0', NULL, NULL, NULL, '2025-12-29 08:40:51'),
(25, 'STU202579930', 14, NULL, 'attendance', NULL, 'student_added', 1, 'admin', NULL, NULL, NULL, '2025-12-29 08:53:20'),
(26, 'STU202566259', 15, NULL, 'attendance', NULL, 'student_added', 1, 'admin', NULL, NULL, NULL, '2025-12-29 08:54:57'),
(27, 'STU202588201', 3, NULL, 'fines', NULL, 'student_scanned', 1, '0', NULL, NULL, NULL, '2025-12-29 10:48:29'),
(28, 'STU202588201', 3, NULL, 'fines', NULL, 'student_scanned', 1, '0', NULL, NULL, NULL, '2025-12-29 10:49:44'),
(29, 'STU202588201', 3, NULL, 'fines', NULL, 'student_scanned', 1, '0', NULL, NULL, NULL, '2025-12-29 11:05:37'),
(30, 'STU202588201', 3, NULL, 'fines', NULL, 'student_scanned', 1, '0', NULL, NULL, NULL, '2025-12-29 11:08:10'),
(31, 'STU202588201', 3, NULL, 'fines', NULL, 'student_scanned', 1, '0', NULL, NULL, NULL, '2025-12-29 11:09:38'),
(32, 'STU202588201', 3, NULL, 'fines', NULL, 'student_scanned', 1, '0', NULL, NULL, NULL, '2025-12-29 11:10:37'),
(33, 'STU202588201', 3, NULL, 'fines', NULL, 'student_scanned', 1, '0', NULL, NULL, NULL, '2025-12-29 11:11:54'),
(34, 'STU202588201', 3, NULL, 'fines', NULL, 'student_scanned', 1, '0', NULL, NULL, NULL, '2025-12-29 13:41:39'),
(35, 'STU202588201', 3, NULL, 'fines', NULL, 'student_scanned', 1, '0', NULL, NULL, NULL, '2025-12-29 14:10:13'),
(36, 'STU202588201', 3, NULL, 'fines', NULL, 'student_scanned', 1, '0', NULL, NULL, NULL, '2025-12-29 14:10:24');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `student_id` int(11) NOT NULL,
  `student_number` varchar(50) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `campus_id` int(11) NOT NULL,
  `course_year` varchar(50) DEFAULT NULL,
  `section` varchar(20) DEFAULT NULL,
  `qr_code_path` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive','graduated') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`student_id`, `student_number`, `full_name`, `email`, `phone`, `photo`, `campus_id`, `course_year`, `section`, `qr_code_path`, `status`, `created_at`, `updated_at`) VALUES
(3, 'STU202588201', 'Karl Marlou Pagdato', 'karlpagdato@gmail.com', '09456465965', 'uploads/students/stu202588201.jpg', 2, 'BSIT-3', 'B', 'qr_codes/STU202588201.png', 'active', '2025-12-17 14:27:33', '2025-12-17 14:27:33'),
(4, 'STU202586635', 'rodrigo', 'admin@example.com', '09456465965', 'uploads/students/stu202586635.jpeg', 2, 'BSIT-3', 'B', 'qr_codes/STU202586635.png', 'active', '2025-12-18 08:54:41', '2025-12-18 08:54:41'),
(15, 'STU202566259', 'jaymar lalantacon', 'jaymarlalantacon@gmail.com', '09456465965', 'uploads/students/stu202566259.jpg', 2, 'BSIT-3', 'B', 'qr_codes/STU202566259.png', 'active', '2025-12-29 08:54:53', '2025-12-29 08:54:53');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_type` enum('admin','coordinator') NOT NULL DEFAULT 'coordinator',
  `campus_id` int(11) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_login` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `full_name`, `email`, `username`, `password`, `user_type`, `campus_id`, `phone`, `photo`, `status`, `created_at`, `last_login`) VALUES
(1, 'jaymar lalantacon', 'jaymarlalantacon@gmail.com', 'admin', '$2y$10$XmbFKHy7rqE7RBUBvSBn2uL1wcUXFY1zoEUF1Mb298krlV2NoEfV6', 'admin', NULL, NULL, NULL, 'active', '2025-12-17 09:13:20', '2025-12-30 15:32:55'),
(5, 'Karl Marlou Pagdato', 'karlpagdato@gmail.com', 'user', '$2y$10$6KwVNilNbP3uqlnL5ecCROOFZw7ZmvLMXmO18n53drC4c.XHYYSgK', 'coordinator', 2, NULL, NULL, 'active', '2025-12-17 17:03:10', '2025-12-18 17:07:28');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activities`
--
ALTER TABLE `activities`
  ADD PRIMARY KEY (`activity_id`),
  ADD KEY `fk_activities_campus` (`campus_id`),
  ADD KEY `fk_activities_created_by` (`created_by`);

--
-- Indexes for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `idx_activity` (`activity_id`),
  ADD KEY `idx_action` (`action`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `admin_logs`
--
ALTER TABLE `admin_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `fk_admin_logs_admin` (`admin_id`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`attendance_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `activity_id` (`activity_id`),
  ADD KEY `fk_attendance_checked_by` (`checked_by`),
  ADD KEY `idx_scan_type` (`scan_type`);

--
-- Indexes for table `campuses`
--
ALTER TABLE `campuses`
  ADD PRIMARY KEY (`campus_id`),
  ADD UNIQUE KEY `campus_code` (`campus_code`);

--
-- Indexes for table `email_logs`
--
ALTER TABLE `email_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `fines`
--
ALTER TABLE `fines`
  ADD PRIMARY KEY (`fine_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `activity_id` (`activity_id`),
  ADD KEY `fk_fines_created_by` (`created_by`);

--
-- Indexes for table `fine_payments`
--
ALTER TABLE `fine_payments`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `fine_id` (`fine_id`),
  ADD KEY `fk_payments_received_by` (`received_by`);

--
-- Indexes for table `login_logs`
--
ALTER TABLE `login_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `monthly_reports`
--
ALTER TABLE `monthly_reports`
  ADD PRIMARY KEY (`report_id`),
  ADD KEY `campus_id` (`campus_id`),
  ADD KEY `generated_by` (`generated_by`);

--
-- Indexes for table `scan_logs`
--
ALTER TABLE `scan_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `idx_student_code` (`student_code`),
  ADD KEY `idx_activity_id` (`activity_id`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`student_id`),
  ADD UNIQUE KEY `student_number` (`student_number`),
  ADD KEY `fk_students_campus` (`campus_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `fk_users_campus` (`campus_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activities`
--
ALTER TABLE `activities`
  MODIFY `activity_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `activity_logs`
--
ALTER TABLE `activity_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admin_logs`
--
ALTER TABLE `admin_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `attendance_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `campuses`
--
ALTER TABLE `campuses`
  MODIFY `campus_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `email_logs`
--
ALTER TABLE `email_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `fines`
--
ALTER TABLE `fines`
  MODIFY `fine_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `fine_payments`
--
ALTER TABLE `fine_payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `login_logs`
--
ALTER TABLE `login_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `monthly_reports`
--
ALTER TABLE `monthly_reports`
  MODIFY `report_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `scan_logs`
--
ALTER TABLE `scan_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activities`
--
ALTER TABLE `activities`
  ADD CONSTRAINT `fk_activities_campus` FOREIGN KEY (`campus_id`) REFERENCES `campuses` (`campus_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_activities_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD CONSTRAINT `activity_logs_ibfk_1` FOREIGN KEY (`activity_id`) REFERENCES `activities` (`activity_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `activity_logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `admin_logs`
--
ALTER TABLE `admin_logs`
  ADD CONSTRAINT `fk_admin_logs_admin` FOREIGN KEY (`admin_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `attendance_ibfk_2` FOREIGN KEY (`activity_id`) REFERENCES `activities` (`activity_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_attendance_checked_by` FOREIGN KEY (`checked_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `email_logs`
--
ALTER TABLE `email_logs`
  ADD CONSTRAINT `email_logs_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE;

--
-- Constraints for table `fines`
--
ALTER TABLE `fines`
  ADD CONSTRAINT `fines_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fines_ibfk_2` FOREIGN KEY (`activity_id`) REFERENCES `activities` (`activity_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_fines_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `fine_payments`
--
ALTER TABLE `fine_payments`
  ADD CONSTRAINT `fine_payments_ibfk_1` FOREIGN KEY (`fine_id`) REFERENCES `fines` (`fine_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_payments_received_by` FOREIGN KEY (`received_by`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `login_logs`
--
ALTER TABLE `login_logs`
  ADD CONSTRAINT `login_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `monthly_reports`
--
ALTER TABLE `monthly_reports`
  ADD CONSTRAINT `monthly_reports_ibfk_1` FOREIGN KEY (`campus_id`) REFERENCES `campuses` (`campus_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `monthly_reports_ibfk_2` FOREIGN KEY (`generated_by`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `fk_students_campus` FOREIGN KEY (`campus_id`) REFERENCES `campuses` (`campus_id`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk_users_campus` FOREIGN KEY (`campus_id`) REFERENCES `campuses` (`campus_id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
