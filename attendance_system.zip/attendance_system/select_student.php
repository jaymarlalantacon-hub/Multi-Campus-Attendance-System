<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['student_search_results'])) {
    header('Location: scan_fines.php');
    exit();
}

$students = $_SESSION['student_search_results'];
$selected_campus = $_GET['campus'] ?? '';
$view_mode = $_GET['view'] ?? 'scan';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Select Student</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="p-8">
    <div class="max-w-4xl mx-auto">
        <h1 class="text-2xl font-bold mb-6">Select Student</h1>
        <p class="mb-4">Multiple students found. Please select the correct one:</p>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <?php foreach ($students as $student): ?>
            <div class="border rounded-lg p-4 hover:bg-gray-50 cursor-pointer"
                 onclick="selectStudent(<?php echo $student['student_id']; ?>)">
                <div class="font-bold"><?php echo htmlspecialchars($student['full_name']); ?></div>
                <div class="text-sm text-gray-600">ID: <?php echo htmlspecialchars($student['student_number']); ?></div>
                <?php if ($student['course_year']): ?>
                <div class="text-sm text-gray-600"><?php echo htmlspecialchars($student['course_year']); ?></div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <script>
    function selectStudent(studentId) {
        // Create a form to submit
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = 'scan_fines.php';
        
        // Add hidden fields
        const studentIdInput = document.createElement('input');
        studentIdInput.type = 'hidden';
        studentIdInput.name = 'selected_student_id';
        studentIdInput.value = studentId;
        form.appendChild(studentIdInput);
        
        const campusInput = document.createElement('input');
        campusInput.type = 'hidden';
        campusInput.name = 'campus';
        campusInput.value = '<?php echo $selected_campus; ?>';
        form.appendChild(campusInput);
        
        const viewInput = document.createElement('input');
        viewInput.type = 'hidden';
        viewInput.name = 'view';
        viewInput.value = '<?php echo $view_mode; ?>';
        form.appendChild(viewInput);
        
        document.body.appendChild(form);
        form.submit();
    }
    </script>
</body>
</html>
<?php
unset($_SESSION['student_search_results']);
?>