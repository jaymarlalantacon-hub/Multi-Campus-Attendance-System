<?php
session_start();
require_once 'db.php';

// Check if user is logged in and is coordinator or admin
if (!isset($_SESSION['user_id']) || ($_SESSION['user_type'] !== 'coordinator' && $_SESSION['user_type'] !== 'admin')) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['full_name'];
$user_type = $_SESSION['user_type'];
$user_campus_id = $_SESSION['campus_id'] ?? null;

// Check if activity ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: activities.php');
    exit();
}

$activity_id = intval($_GET['id']);

// Initialize variables
$activity = null;
$campuses = [];
$stats = [
    'total_attendance' => 0,
    'present_count' => 0,
    'absent_count' => 0,
    'late_count' => 0,
    'excused_count' => 0
];
$fines_data = ['total_fines' => 0, 'total_amount' => 0];

// Get activity details - UPDATED TO INCLUDE ALL FINE COLUMNS
$activity_query = "SELECT a.*, c.campus_name 
                   FROM activities a 
                   LEFT JOIN campuses c ON a.campus_id = c.campus_id 
                   WHERE a.activity_id = ?";
$activity_stmt = $conn->prepare($activity_query);
$activity_stmt->bind_param("i", $activity_id);
$activity_stmt->execute();
$activity_result = $activity_stmt->get_result();
$activity = $activity_result->fetch_assoc();

// Check if activity exists
if (!$activity) {
    header('Location: activities.php');
    exit();
}

// Check if user has permission to edit this activity
if ($user_type === 'coordinator' && $activity['campus_id'] != $user_campus_id && $activity['campus_id'] !== null) {
    die("Access denied: You don't have permission to edit this activity.");
}

// Get campuses for dropdown
if ($user_type === 'admin') {
    $campus_query = "SELECT * FROM campuses WHERE status = 'active' ORDER BY campus_name";
    $campus_result = $conn->query($campus_query);
    while ($campus = $campus_result->fetch_assoc()) {
        $campuses[] = $campus;
    }
} else {
    // Coordinator only sees their campus
    if ($user_campus_id) {
        $campus_query = "SELECT * FROM campuses WHERE campus_id = ? AND status = 'active'";
        $campus_stmt = $conn->prepare($campus_query);
        $campus_stmt->bind_param("i", $user_campus_id);
        $campus_stmt->execute();
        $campus_result = $campus_stmt->get_result();
        if ($campus_row = $campus_result->fetch_assoc()) {
            $campuses[] = $campus_row;
        }
    }
}

// Handle form submission
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'update_activity') {
        $activity_name = trim($_POST['activity_name']);
        $description = trim($_POST['description']);
        $activity_date = $_POST['activity_date'];
        $activity_time = $_POST['activity_time'];
        $activity_type = $_POST['activity_type']; // whole_day or half_day
        $scan_frequency = $_POST['scan_frequency']; // 2x or 4x
        $venue = trim($_POST['venue']);
        $mandatory = isset($_POST['mandatory']) ? 1 : 0;
        $status = $_POST['status'];
        
        // Fine amounts - NEW FIELDS
        $checkin_fine = floatval($_POST['checkin_fine']);
        $checkout_fine = floatval($_POST['checkout_fine']);
        $late_checkin_fine = floatval($_POST['late_checkin_fine']);
        $late_checkout_fine = floatval($_POST['late_checkout_fine']);
        $absent_fine = floatval($_POST['absent_fine']);
        
        // Get campus ID
        if ($user_type === 'admin') {
            $new_campus_id = !empty($_POST['campus_id']) ? intval($_POST['campus_id']) : null;
        } else {
            $new_campus_id = $user_campus_id;
        }
        
        // Validation
        $errors = [];
        
        if (empty($activity_name)) {
            $errors[] = "Activity name is required.";
        }
        
        if (empty($activity_date)) {
            $errors[] = "Activity date is required.";
        }
        
        if (empty($activity_time)) {
            $errors[] = "Activity time is required.";
        }
        
        if ($activity_type === 'half_day' && $scan_frequency === '4x') {
            $errors[] = "Half day activities can only use 2X scan frequency.";
        }
        
        // Validate fine amounts
        if ($mandatory) {
            if ($checkin_fine < 0 || $checkout_fine < 0 || $late_checkin_fine < 0 || 
                $late_checkout_fine < 0 || $absent_fine < 0) {
                $errors[] = "Fine amounts cannot be negative.";
            }
            
            if ($absent_fine < ($checkin_fine + $checkout_fine)) {
                $errors[] = "Absent fine should be equal to or greater than the sum of check-in and check-out fines.";
            }
        }
        
        if (empty($errors)) {
            try {
                // Update activity with new fine fields
                $update_query = "UPDATE activities SET 
                                activity_name = ?,
                                description = ?,
                                campus_id = ?,
                                activity_date = ?,
                                activity_time = ?,
                                activity_type = ?,
                                scan_frequency = ?,
                                venue = ?,
                                mandatory = ?,
                                checkin_fine = ?,
                                checkout_fine = ?,
                                late_checkin_fine = ?,
                                late_checkout_fine = ?,
                                absent_fine = ?,
                                status = ?,
                                updated_at = NOW()
                                WHERE activity_id = ?";
                
                $update_stmt = $conn->prepare($update_query);
                $update_stmt->bind_param("ssisssssidddddsi", 
                    $activity_name,
                    $description,
                    $new_campus_id,
                    $activity_date,
                    $activity_time,
                    $activity_type,
                    $scan_frequency,
                    $venue,
                    $mandatory,
                    $checkin_fine,
                    $checkout_fine,
                    $late_checkin_fine,
                    $late_checkout_fine,
                    $absent_fine,
                    $status,
                    $activity_id
                );
                
                if ($update_stmt->execute()) {
                    $success_message = "Activity updated successfully!";
                    
                    // Update the activity data for display
                    $activity['activity_name'] = $activity_name;
                    $activity['description'] = $description;
                    $activity['campus_id'] = $new_campus_id;
                    $activity['activity_date'] = $activity_date;
                    $activity['activity_time'] = $activity_time;
                    $activity['activity_type'] = $activity_type;
                    $activity['scan_frequency'] = $scan_frequency;
                    $activity['venue'] = $venue;
                    $activity['mandatory'] = $mandatory;
                    $activity['checkin_fine'] = $checkin_fine;
                    $activity['checkout_fine'] = $checkout_fine;
                    $activity['late_checkin_fine'] = $late_checkin_fine;
                    $activity['late_checkout_fine'] = $late_checkout_fine;
                    $activity['absent_fine'] = $absent_fine;
                    $activity['status'] = $status;
                    
                } else {
                    $error_message = "Failed to update activity. Please try again.";
                }
            } catch (Exception $e) {
                $error_message = "Error: " . $e->getMessage();
            }
        } else {
            $error_message = implode("<br>", $errors);
        }
        
    } elseif ($action === 'duplicate_activity') {
        $new_date = $_POST['new_date'] ?? '';
        
        if (empty($new_date)) {
            $error_message = "Please select a date for the duplicated activity.";
        } else {
            try {
                $duplicate_query = "INSERT INTO activities 
                                   (activity_name, description, campus_id, activity_date, activity_time,
                                    activity_type, scan_frequency, venue, mandatory,
                                    checkin_fine, checkout_fine, late_checkin_fine, late_checkout_fine, absent_fine,
                                    status, created_by)
                                   SELECT 
                                   CONCAT(activity_name, ' (Copy)'), description, campus_id, ?, activity_time,
                                    activity_type, scan_frequency, venue, mandatory,
                                    checkin_fine, checkout_fine, late_checkin_fine, late_checkout_fine, absent_fine,
                                    'upcoming', ?
                                   FROM activities 
                                   WHERE activity_id = ?";
                
                $duplicate_stmt = $conn->prepare($duplicate_query);
                $duplicate_stmt->bind_param("sii", $new_date, $user_id, $activity_id);
                
                if ($duplicate_stmt->execute()) {
                    $new_activity_id = $conn->insert_id;
                    $success_message = "Activity duplicated successfully! New Activity ID: #" . $new_activity_id;
                    
                    // Redirect to edit the new activity
                    header("Location: edit_activity.php?id=" . $new_activity_id);
                    exit();
                } else {
                    $error_message = "Failed to duplicate activity.";
                }
            } catch (Exception $e) {
                $error_message = "Error: " . $e->getMessage();
            }
        }
        
    } elseif ($action === 'cancel_activity') {
        $cancellation_reason = trim($_POST['cancellation_reason']);
        
        if (empty($cancellation_reason)) {
            $error_message = "Please provide a reason for cancellation.";
        } else {
            try {
                $cancel_query = "UPDATE activities SET 
                                status = 'cancelled',
                                cancellation_reason = ?,
                                updated_at = NOW()
                                WHERE activity_id = ?";
                
                $cancel_stmt = $conn->prepare($cancel_query);
                $cancel_stmt->bind_param("si", $cancellation_reason, $activity_id);
                
                if ($cancel_stmt->execute()) {
                    $success_message = "Activity cancelled successfully!";
                    $activity['status'] = 'cancelled';
                    $activity['cancellation_reason'] = $cancellation_reason;
                    
                } else {
                    $error_message = "Failed to cancel activity.";
                }
            } catch (Exception $e) {
                $error_message = "Error: " . $e->getMessage();
            }
        }
        
    } elseif ($action === 'delete_activity') {
        try {
            // Check if activity has attendance records
            $check_attendance = $conn->prepare("SELECT COUNT(*) as count FROM attendance WHERE activity_id = ?");
            $check_attendance->bind_param("i", $activity_id);
            $check_attendance->execute();
            $attendance_count = $check_attendance->get_result()->fetch_assoc()['count'];
            
            if ($attendance_count > 0) {
                $error_message = "Cannot delete activity that has attendance records. Please cancel the activity instead.";
            } else {
                // Delete associated fines first
                $delete_fines = $conn->prepare("DELETE FROM fines WHERE activity_id = ?");
                $delete_fines->bind_param("i", $activity_id);
                $delete_fines->execute();
                
                // Delete the activity
                $delete_query = "DELETE FROM activities WHERE activity_id = ?";
                $delete_stmt = $conn->prepare($delete_query);
                $delete_stmt->bind_param("i", $activity_id);
                
                if ($delete_stmt->execute()) {
                    header("Location: activities.php?deleted=1");
                    exit();
                } else {
                    $error_message = "Failed to delete activity.";
                }
            }
        } catch (Exception $e) {
            $error_message = "Error: " . $e->getMessage();
        }
    }
}

// Get activity statistics
try {
    $stats_query = "SELECT 
                    COUNT(*) as total_attendance,
                    COUNT(CASE WHEN status = 'present' THEN 1 END) as present_count,
                    COUNT(CASE WHEN status = 'absent' THEN 1 END) as absent_count,
                    COUNT(CASE WHEN status = 'late' THEN 1 END) as late_count,
                    COUNT(CASE WHEN status = 'excused' THEN 1 END) as excused_count
                    FROM attendance 
                    WHERE activity_id = ?";
    $stats_stmt = $conn->prepare($stats_query);
    $stats_stmt->bind_param("i", $activity_id);
    $stats_stmt->execute();
    $stats_result = $stats_stmt->get_result();
    if ($stats_row = $stats_result->fetch_assoc()) {
        $stats = $stats_row;
    }
} catch (Exception $e) {
    // Use default values
}

// Get fines generated from this activity
try {
    $fines_query = "SELECT COUNT(*) as total_fines, SUM(amount) as total_amount 
                    FROM fines 
                    WHERE activity_id = ? AND status IN ('pending', 'partial')";
    $fines_stmt = $conn->prepare($fines_query);
    $fines_stmt->bind_param("i", $activity_id);
    $fines_stmt->execute();
    $fines_result = $fines_stmt->get_result();
    $fines_data = $fines_result->fetch_assoc() ?: ['total_fines' => 0, 'total_amount' => 0];
} catch (Exception $e) {
    $fines_data = ['total_fines' => 0, 'total_amount' => 0];
}

// Activity status options
$status_options = [
    'upcoming' => 'Upcoming',
    'ongoing' => 'Ongoing',
    'completed' => 'Completed',
    'cancelled' => 'Cancelled'
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Activity | Multi-Campus Attendance</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .activity-type-btn, .scan-frequency-btn {
            transition: all 0.3s ease;
        }
        .activity-type-btn.active, .scan-frequency-btn.active {
            transform: translateY(-2px);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .fine-type-card {
            transition: all 0.3s ease;
            border: 2px solid transparent;
        }
        .fine-type-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .tab-pane {
            display: none;
        }
        .tab-pane.active {
            display: block;
        }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
    <!-- Navigation -->
    <nav class="bg-gradient-to-r from-purple-800 to-indigo-900 text-white shadow-lg">
        <div class="container mx-auto px-4 py-3">
            <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div class="flex items-center space-x-4">
                    <a href="activities.php" class="flex items-center hover:text-purple-200 transition-colors">
                        <i class="fas fa-arrow-left mr-2"></i> Back to Activities
                    </a>
                    <h1 class="text-xl font-bold">
                        <i class="fas fa-edit mr-2"></i> Edit Activity
                    </h1>
                </div>
                <div class="flex items-center space-x-4">
                    <span class="text-sm">
                        <i class="fas fa-user mr-1"></i> <?php echo htmlspecialchars($user_name); ?>
                    </span>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-8">
        <div class="max-w-6xl mx-auto">
            <!-- Header -->
            <div class="mb-8">
                <h1 class="text-3xl font-bold text-gray-800 mb-2">Edit Activity: <?php echo htmlspecialchars($activity['activity_name']); ?></h1>
                <div class="flex flex-wrap items-center gap-3">
                    <?php if ($activity['campus_name']): ?>
                    <span class="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-semibold">
                        <i class="fas fa-school mr-1"></i> <?php echo htmlspecialchars($activity['campus_name']); ?>
                    </span>
                    <?php endif; ?>
                    <span class="px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm font-semibold">
                        <?php echo formatDate($activity['activity_date']); ?> at <?php echo formatTime($activity['activity_time']); ?>
                    </span>
                    <span class="px-3 py-1 <?php 
                        echo $activity['status'] === 'upcoming' ? 'bg-blue-100 text-blue-800' : 
                              ($activity['status'] === 'ongoing' ? 'bg-yellow-100 text-yellow-800' : 
                              ($activity['status'] === 'completed' ? 'bg-green-100 text-green-800' : 
                              'bg-red-100 text-red-800')); 
                    ?> rounded-full text-sm font-semibold">
                        <?php echo ucfirst($activity['status']); ?>
                    </span>
                    <?php if ($activity['mandatory']): ?>
                    <span class="px-3 py-1 bg-red-100 text-red-800 rounded-full text-sm font-semibold">
                        <i class="fas fa-exclamation-circle mr-1"></i> Mandatory
                    </span>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Messages -->
            <?php if ($success_message): ?>
            <div class="mb-8 p-4 bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-xl">
                <div class="flex items-center">
                    <i class="fas fa-check-circle text-green-600 text-xl mr-3"></i>
                    <span class="text-green-800 font-medium"><?php echo $success_message; ?></span>
                </div>
            </div>
            <?php endif; ?>

            <?php if ($error_message): ?>
            <div class="mb-8 p-4 bg-gradient-to-r from-red-50 to-rose-50 border border-red-200 rounded-xl">
                <div class="flex items-center">
                    <i class="fas fa-exclamation-triangle text-red-600 text-xl mr-3"></i>
                    <span class="text-red-800 font-medium"><?php echo $error_message; ?></span>
                </div>
            </div>
            <?php endif; ?>

            <!-- Stats -->
            <div class="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
                <div class="bg-white p-4 rounded-lg shadow border-l-4 border-blue-500">
                    <p class="text-sm text-gray-600">Total Attendance</p>
                    <p class="text-2xl font-bold text-gray-800"><?php echo $stats['total_attendance']; ?></p>
                </div>
                <div class="bg-white p-4 rounded-lg shadow border-l-4 border-green-500">
                    <p class="text-sm text-gray-600">Present</p>
                    <p class="text-2xl font-bold text-gray-800"><?php echo $stats['present_count']; ?></p>
                </div>
                <div class="bg-white p-4 rounded-lg shadow border-l-4 border-yellow-500">
                    <p class="text-sm text-gray-600">Late</p>
                    <p class="text-2xl font-bold text-gray-800"><?php echo $stats['late_count']; ?></p>
                </div>
                <div class="bg-white p-4 rounded-lg shadow border-l-4 border-red-500">
                    <p class="text-sm text-gray-600">Absent</p>
                    <p class="text-2xl font-bold text-gray-800"><?php echo $stats['absent_count']; ?></p>
                </div>
                <div class="bg-white p-4 rounded-lg shadow border-l-4 border-purple-500">
                    <p class="text-sm text-gray-600">Pending Fines</p>
                    <p class="text-2xl font-bold text-gray-800"><?php echo $fines_data['total_fines']; ?></p>
                </div>
            </div>

            <!-- Tabs -->
            <div class="flex flex-wrap gap-2 mb-8 bg-white rounded-xl p-2">
                <button id="tab-edit" class="px-4 py-2 rounded-lg font-semibold bg-blue-600 text-white" onclick="showTab('edit')">
                    <i class="fas fa-edit mr-2"></i> Edit Details
                </button>
                <button id="tab-actions" class="px-4 py-2 rounded-lg font-semibold text-gray-700 hover:bg-gray-100" onclick="showTab('actions')">
                    <i class="fas fa-cog mr-2"></i> Actions
                </button>
            </div>

            <!-- Edit Tab -->
            <div id="edit-tab" class="tab-pane active">
                <div class="bg-white rounded-2xl shadow-xl p-8">
                    <h2 class="text-2xl font-bold text-gray-800 mb-6 border-b pb-3">
                        <i class="fas fa-edit text-blue-600 mr-2"></i> Activity Details
                    </h2>
                    
                    <form method="POST" action="" id="activityForm">
                        <input type="hidden" name="action" value="update_activity">
                        
                        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                            <!-- Left Column -->
                            <div class="space-y-6">
                                <!-- Activity Name -->
                                <div>
                                    <label class="block mb-2 font-semibold text-gray-800">
                                        <i class="fas fa-calendar-check text-blue-600 mr-2"></i>Activity Name *
                                    </label>
                                    <input type="text" name="activity_name" required
                                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                                           value="<?php echo htmlspecialchars($activity['activity_name']); ?>"
                                           placeholder="e.g., Monthly General Assembly">
                                </div>
                                
                                <!-- Description -->
                                <div>
                                    <label class="block mb-2 font-semibold text-gray-800">
                                        <i class="fas fa-align-left text-blue-600 mr-2"></i>Description
                                    </label>
                                    <textarea name="description" rows="4"
                                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                                           placeholder="Describe the activity..."><?php echo htmlspecialchars($activity['description']); ?></textarea>
                                </div>
                                
                                <!-- Activity Type -->
                                <div>
                                    <label class="block mb-2 font-semibold text-gray-800">
                                        <i class="fas fa-calendar-day text-blue-600 mr-2"></i>Activity Duration *
                                    </label>
                                    <div class="grid grid-cols-2 gap-3">
                                        <input type="radio" name="activity_type" value="whole_day" id="whole_day" 
                                               class="hidden" <?php echo ($activity['activity_type'] === 'whole_day') ? 'checked' : ''; ?>>
                                        <label for="whole_day" class="activity-type-btn cursor-pointer p-4 border-2 border-blue-200 rounded-lg text-center hover:border-blue-400 hover:bg-blue-50 transition-colors <?php echo ($activity['activity_type'] === 'whole_day') ? 'border-blue-400 bg-blue-50' : ''; ?>">
                                            <i class="fas fa-sun text-yellow-500 text-2xl mb-2"></i>
                                            <div class="font-semibold text-blue-800">Whole Day</div>
                                            <div class="text-sm text-blue-600 mt-1">8:00 AM - 5:00 PM</div>
                                        </label>
                                        
                                        <input type="radio" name="activity_type" value="half_day" id="half_day" 
                                               class="hidden" <?php echo ($activity['activity_type'] === 'half_day') ? 'checked' : ''; ?>>
                                        <label for="half_day" class="activity-type-btn cursor-pointer p-4 border-2 border-green-200 rounded-lg text-center hover:border-green-400 hover:bg-green-50 transition-colors <?php echo ($activity['activity_type'] === 'half_day') ? 'border-green-400 bg-green-50' : ''; ?>">
                                            <i class="fas fa-clock text-green-500 text-2xl mb-2"></i>
                                            <div class="font-semibold text-green-800">Half Day</div>
                                            <div class="text-sm text-green-600 mt-1">4 hours only</div>
                                        </label>
                                    </div>
                                </div>
                                
                                <!-- Campus -->
                                <div>
                                    <label class="block mb-2 font-semibold text-gray-800">
                                        <i class="fas fa-school text-blue-600 mr-2"></i>Campus
                                    </label>
                                    <select name="campus_id" 
                                            <?php echo ($user_type === 'admin') ? '' : 'disabled'; ?>
                                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors bg-white">
                                        <option value="">-- All Campuses --</option>
                                        <?php foreach ($campuses as $campus): ?>
                                        <option value="<?php echo $campus['campus_id']; ?>" 
                                                <?php echo ($activity['campus_id'] == $campus['campus_id']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($campus['campus_name']); ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <?php if ($user_type === 'coordinator'): ?>
                                    <input type="hidden" name="campus_id" value="<?php echo $user_campus_id; ?>">
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <!-- Right Column -->
                            <div class="space-y-6">
                                <!-- Date & Time -->
                                <div class="grid grid-cols-2 gap-4">
                                    <div>
                                        <label class="block mb-2 font-semibold text-gray-800">
                                            <i class="fas fa-calendar-day text-green-600 mr-2"></i>Date *
                                        </label>
                                        <input type="date" name="activity_date" required
                                               class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-colors"
                                               value="<?php echo $activity['activity_date']; ?>"
                                               id="activityDate">
                                    </div>
                                    <div>
                                        <label class="block mb-2 font-semibold text-gray-800">
                                            <i class="fas fa-clock text-green-600 mr-2"></i>Start Time *
                                        </label>
                                        <input type="time" name="activity_time" required
                                               class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-colors"
                                               value="<?php echo $activity['activity_time']; ?>"
                                               id="activityTime">
                                    </div>
                                </div>
                                
                                <!-- Scan Frequency -->
                                <div>
                                    <label class="block mb-2 font-semibold text-gray-800">
                                        <i class="fas fa-qrcode text-green-600 mr-2"></i>Scan Frequency *
                                    </label>
                                    <div class="grid grid-cols-2 gap-3">
                                        <input type="radio" name="scan_frequency" value="2x" id="scan_2x" 
                                               class="hidden" <?php echo ($activity['scan_frequency'] === '2x') ? 'checked' : ''; ?>>
                                        <label for="scan_2x" class="scan-frequency-btn cursor-pointer p-4 border-2 border-purple-200 rounded-lg text-center hover:border-purple-400 hover:bg-purple-50 transition-colors <?php echo ($activity['scan_frequency'] === '2x') ? 'border-purple-400 bg-purple-50' : ''; ?>">
                                            <i class="fas fa-exchange-alt text-purple-500 text-2xl mb-2"></i>
                                            <div class="font-semibold text-purple-800">2X Scan</div>
                                            <div class="text-sm text-purple-600 mt-1">IN & OUT only</div>
                                        </label>
                                        
                                        <input type="radio" name="scan_frequency" value="4x" id="scan_4x" 
                                               class="hidden" <?php echo ($activity['scan_frequency'] === '4x') ? 'checked' : ''; ?>
                                               <?php echo ($activity['activity_type'] === 'half_day') ? 'disabled' : ''; ?>>
                                        <label for="scan_4x" class="scan-frequency-btn cursor-pointer p-4 border-2 border-indigo-200 rounded-lg text-center hover:border-indigo-400 hover:bg-indigo-50 transition-colors <?php echo ($activity['scan_frequency'] === '4x') ? 'border-indigo-400 bg-indigo-50' : ''; ?> <?php echo ($activity['activity_type'] === 'half_day') ? 'opacity-50 cursor-not-allowed' : ''; ?>">
                                            <i class="fas fa-retweet text-indigo-500 text-2xl mb-2"></i>
                                            <div class="font-semibold text-indigo-800">4X Scan</div>
                                            <div class="text-sm text-indigo-600 mt-1">AM IN/OUT & PM IN/OUT</div>
                                        </label>
                                    </div>
                                    <p class="text-sm text-gray-500 mt-2" id="scanInfo">
                                        <?php echo ($activity['scan_frequency'] === '2x') ? 'Students will scan QR code twice: Check-in and Check-out' : 'Students will scan QR code four times: AM Check-in/out & PM Check-in/out'; ?>
                                    </p>
                                </div>
                                
                                <!-- Venue -->
                                <div>
                                    <label class="block mb-2 font-semibold text-gray-800">
                                        <i class="fas fa-map-marker-alt text-green-600 mr-2"></i>Venue
                                    </label>
                                    <input type="text" name="venue"
                                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-colors"
                                           value="<?php echo htmlspecialchars($activity['venue']); ?>"
                                           placeholder="e.g., Main Auditorium">
                                </div>
                                
                                <!-- Mandatory & Status -->
                                <div class="grid grid-cols-2 gap-4">
                                    <div>
                                        <label class="block mb-2 font-semibold text-gray-800">
                                            <i class="fas fa-exclamation-circle text-red-600 mr-2"></i>Mandatory
                                        </label>
                                        <div class="flex items-center">
                                            <input type="checkbox" name="mandatory" id="mandatory" value="1" 
                                                   class="w-5 h-5 text-red-600 rounded focus:ring-red-500" 
                                                   <?php echo ($activity['mandatory'] == 1) ? 'checked' : ''; ?>
                                                   onchange="toggleFinesSection()">
                                            <label for="mandatory" class="ml-3 font-semibold text-gray-800 cursor-pointer">
                                                Mandatory Activity
                                            </label>
                                        </div>
                                    </div>
                                    
                                    <div>
                                        <label class="block mb-2 font-semibold text-gray-800">
                                            <i class="fas fa-info-circle text-blue-600 mr-2"></i>Status
                                        </label>
                                        <select name="status" 
                                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors">
                                            <?php foreach ($status_options as $value => $label): ?>
                                            <option value="<?php echo $value; ?>" 
                                                    <?php echo ($activity['status'] === $value) ? 'selected' : ''; ?>>
                                                <?php echo $label; ?>
                                            </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                
                                <!-- Fine Settings -->
                                <div id="finesSection" class="<?php echo ($activity['mandatory'] == 1) ? '' : 'hidden'; ?>">
                                    <h3 class="font-bold text-gray-800 mb-4 border-b pb-2">Fine Settings</h3>
                                    <div class="space-y-4">
                                        <!-- Check-in Fine -->
                                        <div class="fine-type-card p-4 border-2 border-blue-200 bg-blue-50 rounded-lg">
                                            <div class="flex items-center justify-between mb-2">
                                                <div class="flex items-center">
                                                    <i class="fas fa-sign-in-alt text-blue-600 text-xl mr-3"></i>
                                                    <div>
                                                        <h4 class="font-semibold text-blue-800">Missing Check-in</h4>
                                                        <p class="text-sm text-blue-600">Student didn't check in</p>
                                                    </div>
                                                </div>
                                                <div class="relative w-32">
                                                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                                        <span class="text-gray-500">₱</span>
                                                    </div>
                                                    <input type="number" name="checkin_fine" step="0.01" min="0" 
                                                           value="<?php echo number_format($activity['checkin_fine'] ?? 50.00, 2); ?>"
                                                           class="w-full pl-8 pr-4 py-2 border border-blue-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white">
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <!-- Check-out Fine -->
                                        <div class="fine-type-card p-4 border-2 border-purple-200 bg-purple-50 rounded-lg">
                                            <div class="flex items-center justify-between mb-2">
                                                <div class="flex items-center">
                                                    <i class="fas fa-sign-out-alt text-purple-600 text-xl mr-3"></i>
                                                    <div>
                                                        <h4 class="font-semibold text-purple-800">Missing Check-out</h4>
                                                        <p class="text-sm text-purple-600">Student didn't check out</p>
                                                    </div>
                                                </div>
                                                <div class="relative w-32">
                                                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                                        <span class="text-gray-500">₱</span>
                                                    </div>
                                                    <input type="number" name="checkout_fine" step="0.01" min="0" 
                                                           value="<?php echo number_format($activity['checkout_fine'] ?? 50.00, 2); ?>"
                                                           class="w-full pl-8 pr-4 py-2 border border-purple-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 bg-white">
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <!-- Late Check-in Fine -->
                                        <div class="fine-type-card p-4 border-2 border-yellow-200 bg-yellow-50 rounded-lg">
                                            <div class="flex items-center justify-between mb-2">
                                                <div class="flex items-center">
                                                    <i class="fas fa-clock text-yellow-600 text-xl mr-3"></i>
                                                    <div>
                                                        <h4 class="font-semibold text-yellow-800">Late Check-in</h4>
                                                        <p class="text-sm text-yellow-600">Check-in after 15 minutes</p>
                                                    </div>
                                                </div>
                                                <div class="relative w-32">
                                                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                                        <span class="text-gray-500">₱</span>
                                                    </div>
                                                    <input type="number" name="late_checkin_fine" step="0.01" min="0" 
                                                           value="<?php echo number_format($activity['late_checkin_fine'] ?? 25.00, 2); ?>"
                                                           class="w-full pl-8 pr-4 py-2 border border-yellow-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 bg-white">
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <!-- Late Check-out Fine -->
                                        <div class="fine-type-card p-4 border-2 border-orange-200 bg-orange-50 rounded-lg">
                                            <div class="flex items-center justify-between mb-2">
                                                <div class="flex items-center">
                                                    <i class="fas fa-running text-orange-600 text-xl mr-3"></i>
                                                    <div>
                                                        <h4 class="font-semibold text-orange-800">Early Check-out</h4>
                                                        <p class="text-sm text-orange-600">Left before activity ends</p>
                                                    </div>
                                                </div>
                                                <div class="relative w-32">
                                                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                                        <span class="text-gray-500">₱</span>
                                                    </div>
                                                    <input type="number" name="late_checkout_fine" step="0.01" min="0" 
                                                           value="<?php echo number_format($activity['late_checkout_fine'] ?? 25.00, 2); ?>"
                                                           class="w-full pl-8 pr-4 py-2 border border-orange-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 bg-white">
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <!-- Absent Fine -->
                                        <div class="fine-type-card p-4 border-2 border-red-200 bg-red-50 rounded-lg">
                                            <div class="flex items-center justify-between mb-2">
                                                <div class="flex items-center">
                                                    <i class="fas fa-user-times text-red-600 text-xl mr-3"></i>
                                                    <div>
                                                        <h4 class="font-semibold text-red-800">Completely Absent</h4>
                                                        <p class="text-sm text-red-600">Didn't attend at all</p>
                                                    </div>
                                                </div>
                                                <div class="relative w-32">
                                                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                                        <span class="text-gray-500">₱</span>
                                                    </div>
                                                    <input type="number" name="absent_fine" step="0.01" min="0" 
                                                           value="<?php echo number_format($activity['absent_fine'] ?? 100.00, 2); ?>"
                                                           class="w-full pl-8 pr-4 py-2 border border-red-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 bg-white">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Submit Button -->
                        <div class="pt-8 border-t border-gray-200">
                            <div class="flex justify-between">
                                <a href="activities.php" class="px-6 py-3 bg-gray-100 text-gray-700 rounded-lg font-semibold hover:bg-gray-200 transition-colors">
                                    <i class="fas fa-times mr-2"></i> Cancel
                                </a>
                                <button type="submit" 
                                        class="px-6 py-3 bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-lg font-semibold hover:from-purple-700 hover:to-indigo-700 transition-all shadow-lg hover:shadow-xl">
                                    <i class="fas fa-save mr-2"></i> Save Changes
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Actions Tab -->
            <div id="actions-tab" class="tab-pane hidden">
                <div class="bg-white rounded-2xl shadow-xl p-8">
                    <h2 class="text-2xl font-bold text-gray-800 mb-6 border-b pb-3">
                        <i class="fas fa-cog text-green-600 mr-2"></i> Additional Actions
                    </h2>
                    
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <!-- Duplicate Activity -->
                        <div class="border-2 border-gray-200 rounded-xl p-5">
                            <div class="flex items-center mb-4">
                                <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mr-4">
                                    <i class="fas fa-copy text-blue-600 text-xl"></i>
                                </div>
                                <h3 class="font-bold text-gray-800">Duplicate Activity</h3>
                            </div>
                            <p class="text-gray-600 text-sm mb-4">
                                Create a copy of this activity with a new date. Useful for recurring activities.
                            </p>
                            <form method="POST" action="" class="space-y-3">
                                <input type="hidden" name="action" value="duplicate_activity">
                                <div>
                                    <label class="block mb-2 font-semibold text-gray-800">New Activity Date</label>
                                    <input type="date" 
                                           name="new_date" 
                                           required
                                           min="<?php echo date('Y-m-d'); ?>"
                                           class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                                </div>
                                <button type="submit" 
                                        class="w-full px-4 py-2 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-lg font-semibold hover:from-blue-600 hover:to-blue-700 transition-all">
                                    <i class="fas fa-copy mr-2"></i> Duplicate Activity
                                </button>
                            </form>
                        </div>
                        
                        <!-- Cancel Activity -->
                        <div class="border-2 border-gray-200 rounded-xl p-5">
                            <div class="flex items-center mb-4">
                                <div class="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mr-4">
                                    <i class="fas fa-times-circle text-red-600 text-xl"></i>
                                </div>
                                <h3 class="font-bold text-gray-800">Cancel Activity</h3>
                            </div>
                            <p class="text-gray-600 text-sm mb-4">
                                Cancel this activity. Cancelled activities will remain in the system but marked as cancelled.
                            </p>
                            <form method="POST" action="" class="space-y-3">
                                <input type="hidden" name="action" value="cancel_activity">
                                <div>
                                    <label class="block mb-2 font-semibold text-gray-800">Reason for Cancellation</label>
                                    <textarea name="cancellation_reason" 
                                              rows="3"
                                              placeholder="Provide a reason for cancellation..."
                                              required
                                              class="w-full px-4 py-2 border border-gray-300 rounded-lg"></textarea>
                                </div>
                                <button type="submit" 
                                        onclick="return confirm('Are you sure you want to cancel this activity?')"
                                        class="w-full px-4 py-2 bg-gradient-to-r from-red-500 to-red-600 text-white rounded-lg font-semibold hover:from-red-600 hover:to-red-700 transition-all">
                                    <i class="fas fa-times-circle mr-2"></i> Cancel Activity
                                </button>
                            </form>
                        </div>
                        
                        <!-- Delete Activity -->
                        <div class="border-2 border-gray-200 rounded-xl p-5">
                            <div class="flex items-center mb-4">
                                <div class="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mr-4">
                                    <i class="fas fa-trash text-red-600 text-xl"></i>
                                </div>
                                <h3 class="font-bold text-gray-800">Delete Activity</h3>
                            </div>
                            <p class="text-gray-600 text-sm mb-4">
                                <span class="font-bold text-red-600">Warning:</span> This action cannot be undone. 
                                Activity can only be deleted if no attendance records exist.
                            </p>
                            <form method="POST" action="" id="deleteForm">
                                <input type="hidden" name="action" value="delete_activity">
                                <button type="button" 
                                        onclick="confirmDelete()"
                                        class="w-full px-4 py-2 bg-gradient-to-r from-red-600 to-red-700 text-white rounded-lg font-semibold hover:from-red-700 hover:to-red-800 transition-all">
                                    <i class="fas fa-trash mr-2"></i> Delete Activity
                                </button>
                            </form>
                        </div>
                    </div>
                    
                    <?php if (isset($activity['cancellation_reason'])): ?>
                    <div class="mt-8 p-4 bg-gradient-to-r from-red-50 to-rose-50 border border-red-200 rounded-xl">
                        <div class="flex items-start">
                            <i class="fas fa-info-circle text-red-600 mt-1 mr-3"></i>
                            <div>
                                <h3 class="font-bold text-red-800">Cancellation Reason</h3>
                                <p class="text-red-700 mt-1"><?php echo htmlspecialchars($activity['cancellation_reason']); ?></p>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Tab switching
        function showTab(tabName) {
            // Hide all tab content
            document.querySelectorAll('.tab-pane').forEach(tab => {
                tab.classList.remove('active');
            });
            
            // Remove active class from all tabs
            document.querySelectorAll('button[onclick^="showTab"]').forEach(tab => {
                tab.classList.remove('bg-blue-600', 'text-white');
                tab.classList.add('text-gray-700', 'hover:bg-gray-100');
            });
            
            // Show selected tab content
            const content = document.getElementById(tabName + '-tab');
            if (content) {
                content.classList.add('active');
            }
            
            // Activate selected tab
            const tab = document.getElementById('tab-' + tabName);
            if (tab) {
                tab.classList.remove('text-gray-700', 'hover:bg-gray-100');
                tab.classList.add('bg-blue-600', 'text-white');
            }
        }
        
        // Toggle fines section
        function toggleFinesSection() {
            const mandatory = document.getElementById('mandatory');
            const finesSection = document.getElementById('finesSection');
            if (mandatory.checked) {
                finesSection.classList.remove('hidden');
            } else {
                finesSection.classList.add('hidden');
            }
        }
        
        // Activity type selection styling
        document.querySelectorAll('.activity-type-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                document.querySelectorAll('.activity-type-btn').forEach(b => {
                    b.classList.remove('active', 'border-blue-400', 'bg-blue-50', 'border-green-400', 'bg-green-50');
                });
                this.classList.add('active');
                if (this.htmlFor === 'whole_day') {
                    this.classList.add('border-blue-400', 'bg-blue-50');
                } else {
                    this.classList.add('border-green-400', 'bg-green-50');
                }
                
                // Update scan frequency based on activity type
                const scan4x = document.getElementById('scan_4x');
                const scan4xLabel = document.querySelector('label[for="scan_4x"]');
                if (this.htmlFor === 'half_day') {
                    // For half day, default to 2x and disable 4x
                    document.getElementById('scan_2x').checked = true;
                    scan4x.disabled = true;
                    scan4xLabel.classList.add('opacity-50', 'cursor-not-allowed');
                    document.getElementById('scanInfo').textContent = 'Students will scan QR code twice: Check-in and Check-out';
                } else {
                    // For whole day, enable both options
                    scan4x.disabled = false;
                    scan4xLabel.classList.remove('opacity-50', 'cursor-not-allowed');
                }
            });
        });
        
        // Scan frequency selection styling
        document.querySelectorAll('.scan-frequency-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                document.querySelectorAll('.scan-frequency-btn').forEach(b => {
                    b.classList.remove('active', 'border-purple-400', 'bg-purple-50', 'border-indigo-400', 'bg-indigo-50');
                });
                this.classList.add('active');
                if (this.htmlFor === 'scan_2x') {
                    this.classList.add('border-purple-400', 'bg-purple-50');
                    document.getElementById('scanInfo').textContent = 'Students will scan QR code twice: Check-in and Check-out';
                } else {
                    this.classList.add('border-indigo-400', 'bg-indigo-50');
                    document.getElementById('scanInfo').textContent = 'Students will scan QR code four times: AM Check-in/out & PM Check-in/out';
                }
            });
        });
        
        // Delete confirmation
        function confirmDelete() {
            if (confirm('WARNING: This will permanently delete this activity.\n\n' +
                       'This action cannot be undone.\n\n' +
                       'Are you absolutely sure?')) {
                document.getElementById('deleteForm').submit();
            }
        }
        
        // Form validation
        document.getElementById('activityForm').addEventListener('submit', function(e) {
            const activityType = document.querySelector('input[name="activity_type"]:checked').value;
            const scanFrequency = document.querySelector('input[name="scan_frequency"]:checked').value;
            
            if (activityType === 'half_day' && scanFrequency === '4x') {
                e.preventDefault();
                alert('Half day activities can only use 2X scan frequency (IN & OUT only).');
                return false;
            }
            
            // Validate fine amounts if mandatory
            const mandatory = document.getElementById('mandatory');
            if (mandatory && mandatory.checked) {
                const checkinFine = parseFloat(document.querySelector('input[name="checkin_fine"]').value) || 0;
                const checkoutFine = parseFloat(document.querySelector('input[name="checkout_fine"]').value) || 0;
                const absentFine = parseFloat(document.querySelector('input[name="absent_fine"]').value) || 0;
                
                if (checkinFine < 0 || checkoutFine < 0 || absentFine < 0) {
                    e.preventDefault();
                    alert('Fine amounts cannot be negative.');
                    return false;
                }
                
                if (absentFine < (checkinFine + checkoutFine)) {
                    const confirmProceed = confirm('Absent fine should be equal to or greater than the sum of check-in and check-out fines. Do you want to continue anyway?');
                    if (!confirmProceed) {
                        e.preventDefault();
                        return false;
                    }
                }
            }
        });
        
        // Initialize
        document.addEventListener('DOMContentLoaded', function() {
            // Set initial fine section state
            toggleFinesSection();
            
            // Set default active states for radio buttons
            const activityType = '<?php echo $activity["activity_type"]; ?>';
            const scanFrequency = '<?php echo $activity["scan_frequency"]; ?>';
            
            if (activityType === 'whole_day') {
                document.querySelector('label[for="whole_day"]').click();
            } else {
                document.querySelector('label[for="half_day"]').click();
            }
            
            if (scanFrequency === '2x') {
                document.querySelector('label[for="scan_2x"]').click();
            } else {
                document.querySelector('label[for="scan_4x"]').click();
            }
        });
    </script>
</body>
</html>