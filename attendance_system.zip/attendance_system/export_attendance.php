<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_type']) || !in_array($_SESSION['user_type'], ['admin','coordinator'])) {
    header('Location: index.php');
    exit();
}

// Get filter parameters (same as attendance_records.php)
$campus_id = isset($_GET['campus_id']) ? intval($_GET['campus_id']) : 0;
$activity_id = isset($_GET['activity_id']) ? intval($_GET['activity_id']) : 0;
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : '';
$date_to = isset($_GET['date_to']) ? $_GET['date_to'] : '';
$student_number = isset($_GET['student_number']) ? trim($_GET['student_number']) : '';
$status = isset($_GET['status']) ? $_GET['status'] : '';

// Build query (same as attendance_records.php)
$query = "
    SELECT 
        a.attendance_id,
        a.time_in,
        a.time_out,
        a.status,
        a.late_minutes,
        a.scanned_at,
        s.student_number,
        s.full_name,
        s.email,
        s.course_year,
        s.section,
        ac.activity_name,
        ac.activity_date,
        ac.activity_time,
        ac.venue,
        c.campus_name,
        u.full_name as checked_by_name
    FROM attendance a
    LEFT JOIN students s ON a.student_id = s.student_id
    LEFT JOIN activities ac ON a.activity_id = ac.activity_id
    LEFT JOIN campuses c ON s.campus_id = c.campus_id
    LEFT JOIN users u ON a.checked_by = u.user_id
    WHERE 1=1
";

$params = [];
$types = '';

// Apply filters (same as attendance_records.php)
if ($campus_id > 0) {
    $query .= " AND s.campus_id = ?";
    $params[] = $campus_id;
    $types .= 'i';
}

if ($activity_id > 0) {
    $query .= " AND a.activity_id = ?";
    $params[] = $activity_id;
    $types .= 'i';
}

if (!empty($date_from)) {
    $query .= " AND DATE(a.scanned_at) >= ?";
    $params[] = $date_from;
    $types .= 's';
}

if (!empty($date_to)) {
    $query .= " AND DATE(a.scanned_at) <= ?";
    $params[] = $date_to;
    $types .= 's';
}

if (!empty($student_number)) {
    $query .= " AND s.student_number LIKE ?";
    $params[] = "%$student_number%";
    $types .= 's';
}

if (!empty($status)) {
    $query .= " AND a.status = ?";
    $params[] = $status;
    $types .= 's';
}

$query .= " ORDER BY a.scanned_at DESC";

// Prepare and execute query
$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

// Set headers for Excel download
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="attendance_records_' . date('Y-m-d') . '.xls"');

// Output Excel headers
echo "Attendance ID\tStudent Number\tStudent Name\tEmail\tCourse/Year\tSection\tActivity\tActivity Date\tActivity Time\tVenue\tCampus\tStatus\tTime In\tTime Out\tLate Minutes\tScanned At\tChecked By\n";

// Output data
while ($row = $result->fetch_assoc()) {
    echo $row['attendance_id'] . "\t";
    echo $row['student_number'] . "\t";
    echo $row['full_name'] . "\t";
    echo $row['email'] . "\t";
    echo $row['course_year'] . "\t";
    echo $row['section'] . "\t";
    echo $row['activity_name'] . "\t";
    echo $row['activity_date'] . "\t";
    echo $row['activity_time'] . "\t";
    echo $row['venue'] . "\t";
    echo $row['campus_name'] . "\t";
    echo $row['status'] . "\t";
    echo $row['time_in'] . "\t";
    echo $row['time_out'] . "\t";
    echo $row['late_minutes'] . "\t";
    echo $row['scanned_at'] . "\t";
    echo $row['checked_by_name'] . "\n";
}

$conn->close();
?>