<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_name = $_SESSION['full_name'];
$user_type = $_SESSION['user_type'];
$user_campus_id = $_SESSION['campus_id'];

// Get campuses for filter
$campuses = [];
if ($user_type === 'admin') {
    $result = $conn->query("SELECT * FROM campuses WHERE status = 'active' ORDER BY campus_name");
} else {
    $stmt = $conn->prepare("SELECT * FROM campuses WHERE campus_id = ? AND status = 'active'");
    $stmt->bind_param("i", $user_campus_id);
    $stmt->execute();
    $result = $stmt->get_result();
}

while ($row = $result->fetch_assoc()) {
    $campuses[] = $row;
}

// Process report generation
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $report_type = $_POST['report_type'];
    $campus_id = $_POST['campus_id'] ? intval($_POST['campus_id']) : null;
    $month = $_POST['month'];
    $format = $_POST['format'];
    
    // Redirect to report generation page
    $params = http_build_query([
        'type' => $report_type,
        'campus' => $campus_id,
        'month' => $month,
        'format' => $format
    ]);
    
    header("Location: generate_report.php?$params");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports | Multi-Campus Attendance</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50 min-h-screen">
    <!-- Navigation -->
    <nav class="bg-gradient-to-r from-blue-800 to-cyan-900 text-white shadow-lg">
        <div class="container mx-auto px-4 py-3">
            <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div class="flex items-center space-x-4">
                    <a href="<?php echo $user_type === 'admin' ? 'admin_dashboard.php' : 'coordinator_dashboard.php'; ?>" 
                       class="flex items-center hover:text-blue-200 transition-colors">
                        <i class="fas fa-arrow-left mr-2"></i> Back to Dashboard
                    </a>
                    <h1 class="text-xl font-bold">
                        <i class="fas fa-chart-bar mr-2"></i> Reports
                    </h1>
                </div>
                <div class="flex items-center space-x-4">
                    <span class="text-sm">
                        <i class="fas fa-user mr-1"></i> <?php echo htmlspecialchars($user_name); ?>
                    </span>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-8">
        <!-- Header -->
        <div class="mb-8">
            <h1 class="text-3xl font-bold text-gray-800">Reports & Analytics</h1>
            <p class="text-gray-600">Generate comprehensive reports for attendance and fines</p>
        </div>

        <!-- Report Cards -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <!-- Monthly Report -->
            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-blue-500">
                <div class="flex items-center justify-between mb-4">
                    <div>
                        <h3 class="font-semibold text-gray-800">Monthly Report</h3>
                        <p class="text-sm text-gray-600">Complete monthly summary</p>
                    </div>
                    <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                        <i class="fas fa-calendar-alt text-blue-600 text-xl"></i>
                    </div>
                </div>
                <ul class="text-sm text-gray-600 space-y-2">
                    <li class="flex items-center">
                        <i class="fas fa-check text-green-500 mr-2"></i>
                        Attendance summary
                    </li>
                    <li class="flex items-center">
                        <i class="fas fa-check text-green-500 mr-2"></i>
                        Fines collection
                    </li>
                    <li class="flex items-center">
                        <i class="fas fa-check text-green-500 mr-2"></i>
                        Student participation
                    </li>
                </ul>
            </div>

            <!-- Attendance Report -->
            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-green-500">
                <div class="flex items-center justify-between mb-4">
                    <div>
                        <h3 class="font-semibold text-gray-800">Attendance Report</h3>
                        <p class="text-sm text-gray-600">Detailed attendance records</p>
                    </div>
                    <div class="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                        <i class="fas fa-clipboard-check text-green-600 text-xl"></i>
                    </div>
                </div>
                <ul class="text-sm text-gray-600 space-y-2">
                    <li class="flex items-center">
                        <i class="fas fa-check text-green-500 mr-2"></i>
                        Student-wise attendance
                    </li>
                    <li class="flex items-center">
                        <i class="fas fa-check text-green-500 mr-2"></i>
                        Activity participation
                    </li>
                    <li class="flex items-center">
                        <i class="fas fa-check text-green-500 mr-2"></i>
                        Late arrivals tracking
                    </li>
                </ul>
            </div>

            <!-- Fines Report -->
            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-red-500">
                <div class="flex items-center justify-between mb-4">
                    <div>
                        <h3 class="font-semibold text-gray-800">Fines Report</h3>
                        <p class="text-sm text-gray-600">Financial collection report</p>
                    </div>
                    <div class="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                        <i class="fas fa-file-invoice-dollar text-red-600 text-xl"></i>
                    </div>
                </div>
                <ul class="text-sm text-gray-600 space-y-2">
                    <li class="flex items-center">
                        <i class="fas fa-check text-green-500 mr-2"></i>
                        Fines by status
                    </li>
                    <li class="flex items-center">
                        <i class="fas fa-check text-green-500 mr-2"></i>
                        Payment collection
                    </li>
                    <li class="flex items-center">
                        <i class="fas fa-check text-green-500 mr-2"></i>
                        Outstanding balances
                    </li>
                </ul>
            </div>

            <!-- Campus Report -->
            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-purple-500">
                <div class="flex items-center justify-between mb-4">
                    <div>
                        <h3 class="font-semibold text-gray-800">Campus Report</h3>
                        <p class="text-sm text-gray-600">Campus-wise comparison</p>
                    </div>
                    <div class="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                        <i class="fas fa-school text-purple-600 text-xl"></i>
                    </div>
                </div>
                <ul class="text-sm text-gray-600 space-y-2">
                    <li class="flex items-center">
                        <i class="fas fa-check text-green-500 mr-2"></i>
                        Campus performance
                    </li>
                    <li class="flex items-center">
                        <i class="fas fa-check text-green-500 mr-2"></i>
                        Student distribution
                    </li>
                    <li class="flex items-center">
                        <i class="fas fa-check text-green-500 mr-2"></i>
                        Activity comparison
                    </li>
                </ul>
            </div>
        </div>

        <!-- Report Generator Form -->
        <div class="bg-white rounded-xl shadow-lg p-8">
            <h2 class="text-2xl font-bold text-gray-800 mb-6">Generate Custom Report</h2>
            
            <form method="POST" action="" id="reportForm">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <!-- Report Type -->
                    <div>
                        <label class="block mb-3 font-semibold text-gray-800">
                            <i class="fas fa-file-alt text-blue-600 mr-2"></i>Report Type *
                        </label>
                        <select name="report_type" required 
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors">
                            <option value="">-- Select Report Type --</option>
                            <option value="monthly">Monthly Summary Report</option>
                            <option value="attendance">Detailed Attendance Report</option>
                            <option value="fines">Fines Collection Report</option>
                            <option value="campus">Campus-wise Report</option>
                            <option value="student">Student-wise Report</option>
                            <option value="activity">Activity Participation Report</option>
                        </select>
                    </div>

                    <!-- Campus -->
                    <div>
                        <label class="block mb-3 font-semibold text-gray-800">
                            <i class="fas fa-school text-blue-600 mr-2"></i>Campus
                        </label>
                        <select name="campus_id"
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors">
                            <option value="">All Campuses</option>
                            <?php foreach ($campuses as $campus): ?>
                            <option value="<?php echo $campus['campus_id']; ?>">
                                <?php echo htmlspecialchars($campus['campus_name']); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- Month -->
                    <div>
                        <label class="block mb-3 font-semibold text-gray-800">
                            <i class="fas fa-calendar text-blue-600 mr-2"></i>Month *
                        </label>
                        <input type="month" name="month" required 
                               class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                               value="<?php echo date('Y-m'); ?>">
                    </div>

                    <!-- Format -->
                    <div>
                        <label class="block mb-3 font-semibold text-gray-800">
                            <i class="fas fa-download text-blue-600 mr-2"></i>Output Format *
                        </label>
                        <select name="format" required 
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors">
                            <option value="pdf">PDF Document</option>
                            <option value="excel">Excel Spreadsheet</option>
                            <option value="print">Printable HTML</option>
                        </select>
                    </div>
                </div>

                <!-- Submit Button -->
                <div class="mt-8 pt-6 border-t border-gray-200">
                    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div class="text-sm text-gray-600">
                            <p><i class="fas fa-info-circle text-blue-500 mr-2"></i> 
                            Reports will be generated based on selected criteria</p>
                        </div>
                        <div class="flex gap-3">
                            <button type="reset" 
                                    class="px-6 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors font-semibold">
                                <i class="fas fa-redo mr-2"></i> Reset
                            </button>
                            <button type="submit" 
                                    class="px-6 py-3 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-lg hover:from-blue-700 hover:to-cyan-700 transition-all font-semibold shadow-lg hover:shadow-xl">
                                <i class="fas fa-chart-bar mr-2"></i> Generate Report
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>

        <!-- Quick Reports -->
        <div class="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
            <!-- This Month's Summary -->
            <div class="bg-white rounded-xl shadow-lg p-6">
                <h3 class="text-xl font-bold text-gray-800 mb-4">This Month's Quick Stats</h3>
                <?php
                $current_month = date('Y-m');
                $quick_stats = [];
                
                // Get quick stats
                $stats_query = "SELECT 
                    (SELECT COUNT(DISTINCT a.activity_id) FROM activities a 
                     WHERE DATE_FORMAT(a.activity_date, '%Y-%m') = ?) as activities_count,
                    (SELECT COUNT(DISTINCT at.student_id) FROM attendance at 
                     JOIN activities a2 ON at.activity_id = a2.activity_id 
                     WHERE DATE_FORMAT(a2.activity_date, '%Y-%m') = ? AND at.status = 'Present') as students_present,
                    (SELECT COUNT(DISTINCT f.fine_id) FROM fines f 
                     WHERE DATE_FORMAT(f.created_at, '%Y-%m') = ? AND f.status = 'pending') as pending_fines,
                    (SELECT SUM(f.amount) FROM fines f 
                     WHERE DATE_FORMAT(f.created_at, '%Y-%m') = ? AND f.status = 'paid') as fines_collected";
                
                $stmt = $conn->prepare($stats_query);
                $stmt->bind_param("ssss", $current_month, $current_month, $current_month, $current_month);
                $stmt->execute();
                $quick_stats = $stmt->get_result()->fetch_assoc();
                ?>
                
                <div class="grid grid-cols-2 gap-4">
                    <div class="p-4 bg-blue-50 rounded-lg">
                        <p class="text-sm text-gray-600">Activities</p>
                        <p class="text-2xl font-bold text-blue-600"><?php echo $quick_stats['activities_count'] ?? 0; ?></p>
                    </div>
                    <div class="p-4 bg-green-50 rounded-lg">
                        <p class="text-sm text-gray-600">Students Present</p>
                        <p class="text-2xl font-bold text-green-600"><?php echo $quick_stats['students_present'] ?? 0; ?></p>
                    </div>
                    <div class="p-4 bg-yellow-50 rounded-lg">
                        <p class="text-sm text-gray-600">Pending Fines</p>
                        <p class="text-2xl font-bold text-yellow-600"><?php echo $quick_stats['pending_fines'] ?? 0; ?></p>
                    </div>
                    <div class="p-4 bg-purple-50 rounded-lg">
                        <p class="text-sm text-gray-600">Fines Collected</p>
                        <p class="text-2xl font-bold text-purple-600">₱<?php echo number_format($quick_stats['fines_collected'] ?? 0, 2); ?></p>
                    </div>
                </div>
                
                <div class="mt-4">
                    <a href="generate_report.php?type=monthly&month=<?php echo $current_month; ?>&format=pdf" 
                       class="text-blue-600 hover:text-blue-800 font-medium">
                        <i class="fas fa-download mr-2"></i> Download Monthly Report
                    </a>
                </div>
            </div>

            <!-- Campus Reports -->
            <div class="bg-white rounded-xl shadow-lg p-6">
                <h3 class="text-xl font-bold text-gray-800 mb-4">Campus Reports</h3>
                <div class="space-y-4">
                    <?php foreach ($campuses as $campus): ?>
                    <div class="flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50">
                        <div>
                            <h4 class="font-semibold text-gray-800"><?php echo htmlspecialchars($campus['campus_name']); ?></h4>
                            <p class="text-sm text-gray-600"><?php echo htmlspecialchars($campus['campus_code']); ?></p>
                        </div>
                        <div class="flex gap-2">
                            <a href="generate_report.php?type=campus&campus=<?php echo $campus['campus_id']; ?>&month=<?php echo date('Y-m'); ?>&format=pdf" 
                               class="px-3 py-1 bg-blue-100 text-blue-800 hover:bg-blue-200 rounded text-sm transition-colors">
                                <i class="fas fa-file-pdf"></i>
                            </a>
                            <a href="generate_report.php?type=campus&campus=<?php echo $campus['campus_id']; ?>&month=<?php echo date('Y-m'); ?>&format=excel" 
                               class="px-3 py-1 bg-green-100 text-green-800 hover:bg-green-200 rounded text-sm transition-colors">
                                <i class="fas fa-file-excel"></i>
                            </a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Form validation
        document.getElementById('reportForm').addEventListener('submit', function(e) {
            const reportType = this.querySelector('[name="report_type"]').value;
            const month = this.querySelector('[name="month"]').value;
            
            if (!reportType) {
                e.preventDefault();
                alert('Please select a report type.');
                return false;
            }
            
            if (!month) {
                e.preventDefault();
                alert('Please select a month.');
                return false;
            }
            
            // Show loading state
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Generating Report...';
            submitBtn.disabled = true;
            
            // Re-enable after 3 seconds in case of error
            setTimeout(() => {
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
            }, 3000);
        });
    </script>
</body>
</html>