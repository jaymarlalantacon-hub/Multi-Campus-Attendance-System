<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_type']) || !in_array($_SESSION['user_type'], ['admin','coordinator'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['attendance_id'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid input']);
    exit();
}

$attendance_id = intval($input['attendance_id']);
$status = isset($input['status']) ? $input['status'] : 'Present';
$time_in = isset($input['time_in']) ? $input['time_in'] : null;
$late_minutes = isset($input['late_minutes']) ? intval($input['late_minutes']) : 0;
$updated_by = $_SESSION['user_id'];
$updated_at = date('Y-m-d H:i:s');

$query = "UPDATE attendance SET status = ?, time_in = ?, late_minutes = ?, updated_at = ? WHERE attendance_id = ?";
$stmt = $conn->prepare($query);

if ($time_in) {
    $stmt->bind_param("ssisi", $status, $time_in, $late_minutes, $updated_at, $attendance_id);
} else {
    $stmt->bind_param("ssisi", $status, $time_in, $late_minutes, $updated_at, $attendance_id);
}

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Attendance updated successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
}

$conn->close();
?>