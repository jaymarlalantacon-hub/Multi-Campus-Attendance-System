<?php
session_start();
require_once 'db.php';

// Check if coordinator
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'coordinator' || !$_SESSION['campus_id']) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['full_name'];
$campus_id = $_SESSION['campus_id'];
$current_date = date('Y-m-d');
$today = date('l, F j, Y');

// Get campus info
$stmt = $conn->prepare("SELECT * FROM campuses WHERE campus_id = ?");
$stmt->bind_param("i", $campus_id);
$stmt->execute();
$campus = $stmt->get_result()->fetch_assoc();

// Get statistics for this campus
$stats = [];

// Total students in this campus
$stmt = $conn->prepare("SELECT COUNT(*) as total FROM students WHERE campus_id = ? AND status = 'active'");
$stmt->bind_param("i", $campus_id);
$stmt->execute();
$stats['total_students'] = $stmt->get_result()->fetch_assoc()['total'];

// Activities TODAY for this campus - FIXED QUERY
$stmt = $conn->prepare("
    SELECT COUNT(*) as total 
    FROM activities 
    WHERE campus_id = ?
    AND DATE(activity_date) = ?
    AND status IN ('ongoing', 'upcoming')
");
$stmt->bind_param("is", $campus_id, $current_date);
$stmt->execute();
$stats['today_activities'] = $stmt->get_result()->fetch_assoc()['total'];

// Activities THIS WEEK for this campus
$week_start = date('Y-m-d', strtotime('monday this week'));
$week_end = date('Y-m-d', strtotime('sunday this week'));
$stmt = $conn->prepare("
    SELECT COUNT(*) as total 
    FROM activities 
    WHERE campus_id = ?
    AND activity_date BETWEEN ? AND ?
    AND status IN ('ongoing', 'upcoming')
");
$stmt->bind_param("iss", $campus_id, $week_start, $week_end);
$stmt->execute();
$stats['week_activities'] = $stmt->get_result()->fetch_assoc()['total'];

// Pending fines for this campus - FIXED: Using 'amount' column instead of 'fines_amount'
$stmt = $conn->prepare("
    SELECT COUNT(*) as count, COALESCE(SUM(amount), 0) as total 
    FROM fines 
    JOIN students ON fines.student_id = students.student_id 
    WHERE students.campus_id = ? 
    AND fines.status IN ('pending', 'unpaid')
");
$stmt->bind_param("i", $campus_id);
$stmt->execute();
$fines_result = $stmt->get_result()->fetch_assoc();
$stats['pending_fines_count'] = $fines_result['count'] ?? 0;
$stats['pending_fines_amount'] = $fines_result['total'] ?? 0;

// Today's attendance
$stmt = $conn->prepare("
    SELECT 
        COUNT(DISTINCT a.student_id) as attended
    FROM attendance a
    JOIN students s ON a.student_id = s.student_id
    WHERE s.campus_id = ?
    AND DATE(a.scanned_at) = ?
    AND a.status IN ('Present', 'Late')
");
$stmt->bind_param("is", $campus_id, $current_date);
$stmt->execute();
$attendance_result = $stmt->get_result()->fetch_assoc();
$stats['attended_today'] = $attendance_result['attended'] ?? 0;

// Get total active students for attendance rate
$stmt = $conn->prepare("SELECT COUNT(*) as total FROM students WHERE campus_id = ? AND status = 'active'");
$stmt->bind_param("i", $campus_id);
$stmt->execute();
$total_students_result = $stmt->get_result()->fetch_assoc();
$total_students = $total_students_result['total'] ?? 1;

$stats['attendance_rate'] = $total_students > 0 
    ? round(($stats['attended_today'] / $total_students) * 100, 1) 
    : 0;

// This Week's Activities - FIXED QUERY (using your exact column names)
$stmt = $conn->prepare("
    SELECT 
        activity_id,
        activity_name,
        description,
        campus_id,
        activity_date,
        activity_time,
        venue,
        mandatory,
        fines_amount,
        status,
        created_at
    FROM activities 
    WHERE campus_id = ?
    AND activity_date BETWEEN ? AND ?
    AND status IN ('ongoing', 'upcoming')
    ORDER BY 
        CASE 
            WHEN activity_date = ? THEN 1
            ELSE 2
        END,
        activity_date ASC,
        activity_time ASC
    LIMIT 10
");
$stmt->bind_param("isss", $campus_id, $week_start, $week_end, $current_date);
$stmt->execute();
$weeks_activities = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Recent attendance records
$stmt = $conn->prepare("
    SELECT att.*, a.activity_name, s.full_name as student_name, s.student_number,
           att.scanned_at as attendance_time, att.status
    FROM attendance att
    JOIN activities a ON att.activity_id = a.activity_id
    JOIN students s ON att.student_id = s.student_id
    WHERE s.campus_id = ?
    ORDER BY att.scanned_at DESC
    LIMIT 8
");
$stmt->bind_param("i", $campus_id);
$stmt->execute();
$recent_attendance = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Recent fines
$stmt = $conn->prepare("
    SELECT f.*, s.full_name as student_name, s.student_number
    FROM fines f
    JOIN students s ON f.student_id = s.student_id
    WHERE s.campus_id = ?
    ORDER BY f.created_at DESC
    LIMIT 5
");
$stmt->bind_param("i", $campus_id);
$stmt->execute();
$recent_fines = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Recent students (last registered)
$stmt = $conn->prepare("
    SELECT s.*
    FROM students s
    WHERE s.campus_id = ?
    AND s.status = 'active'
    ORDER BY s.created_at DESC
    LIMIT 5
");
$stmt->bind_param("i", $campus_id);
$stmt->execute();
$recent_students = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Coordinator Dashboard | Multi-Campus Attendance System</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { 
            font-family: 'Segoe UI', 'Inter', system-ui, -apple-system, sans-serif; 
        }
        .animate-in { 
            animation: fadeIn 0.5s ease-out; 
        }
        @keyframes fadeIn { 
            from { opacity: 0; transform: translateY(10px); } 
            to { opacity: 1; transform: translateY(0); } 
        }
        .hover-lift { 
            transition: transform 0.2s ease, box-shadow 0.2s ease; 
        }
        .hover-lift:hover { 
            transform: translateY(-3px); 
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04); 
        }
        .gradient-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        .status-present { background-color: #d1fae5; color: #065f46; }
        .status-late { background-color: #fef3c7; color: #92400e; }
        .status-absent { background-color: #fee2e2; color: #991b1b; }
        .status-excused { background-color: #dbeafe; color: #1e40af; }
        .status-paid { background-color: #dcfce7; color: #166534; }
        .status-pending { background-color: #fef3c7; color: #92400e; }
        .floating-btn {
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.3);
            transition: all 0.3s ease;
        }
        .floating-btn:hover {
            transform: translateY(-5px) scale(1.05);
            box-shadow: 0 20px 40px -10px rgba(0, 0, 0, 0.4);
        }
    </style>
</head>
<body class="bg-gradient-to-br from-gray-50 to-gray-100 min-h-screen">
    
<!-- Header -->
<header class="gradient-header text-white shadow-2xl">
    <div class="container mx-auto px-4 py-5">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div class="flex items-center gap-4">
                <div class="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center shadow-lg">
                    <i class="fas fa-graduation-cap text-white text-3xl"></i>
                </div>
                <div>
                    <h1 class="text-2xl md:text-3xl font-bold"><?php echo htmlspecialchars($campus['campus_name']); ?> Campus</h1>
                    <p class="text-purple-200 text-sm md:text-base">
                        <i class="fas fa-user-tie mr-2"></i>Coordinator Dashboard
                    </p>
                </div>
            </div>
            
            <div class="flex flex-col md:flex-row md:items-center gap-4">
                <div class="text-center md:text-right">
                    <p class="font-medium text-lg"><?php echo htmlspecialchars($user_name); ?></p>
                    <p class="text-sm text-purple-200">Coordinator ID: <?php echo htmlspecialchars($_SESSION['username'] ?? 'N/A'); ?></p>
                </div>
                <div class="flex items-center gap-3">
                    <div class="relative group">
                        <div class="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center font-bold text-xl cursor-pointer">
                            <?php echo strtoupper(substr($user_name, 0, 1)); ?>
                        </div>
                        <div class="absolute right-0 top-full mt-2 w-56 bg-white rounded-xl shadow-2xl py-2 z-50 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
                            <div class="px-4 py-3 border-b">
                                <p class="font-semibold text-gray-800"><?php echo htmlspecialchars($user_name); ?></p>
                                <p class="text-sm text-gray-600"><?php echo htmlspecialchars($campus['campus_name']); ?></p>
                            </div>
                            <a href="profile.php" class="flex items-center px-4 py-3 text-gray-700 hover:bg-gray-100 transition-colors">
                                <i class="fas fa-user-circle mr-3 text-purple-600"></i> Profile Settings
                            </a>
                            <a href="settings.php" class="flex items-center px-4 py-3 text-gray-700 hover:bg-gray-100 transition-colors">
                                <i class="fas fa-cog mr-3 text-blue-600"></i> System Settings
                            </a>
                            <div class="border-t mt-2 pt-2">
                                <a href="logout.php" class="flex items-center px-4 py-3 text-red-600 hover:bg-red-50 transition-colors">
                                    <i class="fas fa-sign-out-alt mr-3"></i> Logout
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

<!-- Top Stats Bar -->
<div class="bg-white shadow-lg border-b">
    <div class="container mx-auto px-4">
        <div class="flex flex-wrap items-center justify-between py-3">
            <div class="flex items-center gap-6">
                <div class="flex items-center gap-2">
                    <i class="fas fa-calendar-day text-blue-600"></i>
                    <span class="font-medium text-gray-800"><?php echo $today; ?></span>
                </div>
                <div class="flex items-center gap-2">
                    <i class="fas fa-clock text-green-600"></i>
                    <span class="font-medium text-gray-800" id="liveClock"><?php echo date('h:i A'); ?></span>
                </div>
                <div class="hidden md:flex items-center gap-2">
                    <i class="fas fa-users text-purple-600"></i>
                    <span class="font-medium text-gray-800"><?php echo $stats['total_students']; ?> Active Students</span>
                </div>
            </div>
            <div class="flex items-center gap-4">
                <a href="scan_attendance.php" class="text-sm bg-gradient-to-r from-green-500 to-emerald-600 text-white px-4 py-2 rounded-lg hover:from-green-600 hover:to-emerald-700 transition-all font-medium flex items-center">
                    <i class="fas fa-qrcode mr-2"></i> Scan Attendance
                </a>
                <a href="scan_fines.php" class="text-sm bg-gradient-to-r from-red-500 to-rose-600 text-white px-4 py-2 rounded-lg hover:from-red-600 hover:to-rose-700 transition-all font-medium flex items-center">
                    <i class="fas fa-money-bill-wave mr-2"></i> Scan Fines
                </a>
                <a href="add_student.php" class="text-sm bg-gradient-to-r from-blue-500 to-blue-600 text-white px-4 py-2 rounded-lg hover:from-blue-600 hover:to-blue-700 transition-all font-medium flex items-center">
                    <i class="fas fa-user-plus mr-2"></i> Add Student
                </a>
            </div>
        </div>
    </div>
</div>

<main class="container mx-auto px-4 py-8">
    <!-- Welcome Section -->
    <div class="mb-10 animate-in">
        <h2 class="text-3xl font-bold text-gray-800 mb-2">Welcome back, <?php echo htmlspecialchars($user_name); ?>! 👋</h2>
        <p class="text-gray-600">Here's what's happening today at <?php echo htmlspecialchars($campus['campus_name']); ?> campus</p>
    </div>

    <!-- Stats Overview -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <!-- Total Students -->
        <div class="bg-white rounded-2xl shadow-xl p-6 border border-gray-200 hover-lift">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500 font-medium mb-1">Total Students</p>
                    <p class="text-3xl font-bold text-gray-900"><?php echo number_format($stats['total_students']); ?></p>
                    <p class="text-xs text-gray-500 mt-2">Active in campus</p>
                </div>
                <div class="w-14 h-14 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg">
                    <i class="fas fa-users text-white text-2xl"></i>
                </div>
            </div>
            <div class="mt-6 pt-4 border-t border-gray-100">
                <a href="students.php" class="text-blue-600 hover:text-blue-800 text-sm font-medium flex items-center justify-between">
                    <span>Manage Students</span>
                    <i class="fas fa-arrow-right transition-transform group-hover:translate-x-1"></i>
                </a>
            </div>
        </div>
        
        <!-- Today's Activities -->
        <div class="bg-white rounded-2xl shadow-xl p-6 border border-gray-200 hover-lift">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500 font-medium mb-1">Today's Activities</p>
                    <p class="text-3xl font-bold text-green-600"><?php echo number_format($stats['today_activities']); ?></p>
                    <p class="text-xs text-gray-500 mt-2">Scheduled for today</p>
                </div>
                <div class="w-14 h-14 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center shadow-lg">
                    <i class="fas fa-calendar-day text-white text-2xl"></i>
                </div>
            </div>
            <div class="mt-6 pt-4 border-t border-gray-100">
                <a href="activities.php?filter=today" class="text-green-600 hover:text-green-800 text-sm font-medium flex items-center justify-between">
                    <span>View Today's Schedule</span>
                    <i class="fas fa-arrow-right transition-transform group-hover:translate-x-1"></i>
                </a>
            </div>
        </div>
        
        <!-- Pending Fines -->
        <div class="bg-white rounded-2xl shadow-xl p-6 border border-gray-200 hover-lift">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500 font-medium mb-1">Pending Fines</p>
                    <p class="text-3xl font-bold text-red-600">₱<?php echo number_format($stats['pending_fines_amount'], 2); ?></p>
                    <p class="text-xs text-gray-500 mt-2"><?php echo $stats['pending_fines_count']; ?> unpaid records</p>
                </div>
                <div class="w-14 h-14 bg-gradient-to-br from-red-500 to-rose-600 rounded-2xl flex items-center justify-center shadow-lg">
                    <i class="fas fa-money-bill-wave text-white text-2xl"></i>
                </div>
            </div>
            <div class="mt-6 pt-4 border-t border-gray-100">
                <a href="fines.php" class="text-red-600 hover:text-red-800 text-sm font-medium flex items-center justify-between">
                    <span>Collect Fines</span>
                    <i class="fas fa-arrow-right transition-transform group-hover:translate-x-1"></i>
                </a>
            </div>
        </div>
        
        <!-- Today's Attendance -->
        <div class="bg-white rounded-2xl shadow-xl p-6 border border-gray-200 hover-lift">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500 font-medium mb-1">Today's Attendance</p>
                    <p class="text-3xl font-bold text-purple-600"><?php echo $stats['attendance_rate']; ?>%</p>
                    <p class="text-xs text-gray-500 mt-2"><?php echo $stats['attended_today']; ?> students attended</p>
                </div>
                <div class="w-14 h-14 bg-gradient-to-br from-purple-500 to-pink-600 rounded-2xl flex items-center justify-center shadow-lg">
                    <i class="fas fa-user-check text-white text-2xl"></i>
                </div>
            </div>
            <div class="mt-6 pt-4 border-t border-gray-100">
                <a href="attendance_report.php?date=<?php echo $current_date; ?>" class="text-purple-600 hover:text-purple-800 text-sm font-medium flex items-center justify-between">
                    <span>View Attendance Report</span>
                    <i class="fas fa-arrow-right transition-transform group-hover:translate-x-1"></i>
                </a>
            </div>
        </div>
    </div>

    <!-- Dashboard Content Grid -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <!-- This Week's Activities -->
        <div class="bg-white rounded-2xl shadow-lg p-6 border animate-in">
            <div class="flex items-center justify-between mb-6">
                <div>
                    <h3 class="text-xl font-bold text-gray-900 flex items-center">
                        <i class="fas fa-calendar-week text-green-600 mr-3"></i>
                        This Week's Activities
                        <span class="ml-2 bg-green-100 text-green-800 text-xs font-semibold px-2 py-1 rounded-full">
                            <?php echo count($weeks_activities); ?> activities
                        </span>
                    </h3>
                    <p class="text-gray-600 text-sm mt-1">Activities scheduled for this week (<?php echo date('M d', strtotime($week_start)); ?> - <?php echo date('M d', strtotime($week_end)); ?>)</p>
                </div>
                <div class="flex gap-2">
                    <a href="activities.php" class="text-sm text-blue-600 hover:text-blue-800 font-medium flex items-center">
                        View All <i class="fas fa-arrow-right ml-2"></i>
                    </a>
                    <a href="create_activity.php" class="text-sm bg-green-600 text-white px-3 py-1 rounded-lg hover:bg-green-700 font-medium flex items-center">
                        <i class="fas fa-plus mr-2"></i> New
                    </a>
                </div>
            </div>
            
            <?php if (!empty($weeks_activities)): ?>
                <div class="space-y-4">
                    <?php foreach ($weeks_activities as $activity): ?>
                        <?php 
                        $is_today = date('Y-m-d', strtotime($activity['activity_date'])) == $current_date;
                        $activity_time = !empty($activity['activity_time']) ? date('h:i A', strtotime($activity['activity_time'])) : 'Time TBA';
                        $activity_date = !empty($activity['activity_date']) ? date('M d, Y', strtotime($activity['activity_date'])) : 'Date TBA';
                        $mandatory = isset($activity['mandatory']) ? (bool)$activity['mandatory'] : false;
                        $status = $activity['status'] ?? 'upcoming';
                        $fines_amount = isset($activity['fines_amount']) ? floatval($activity['fines_amount']) : 0;
                        ?>
                        <div class="flex items-center justify-between p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors group">
                            <div class="flex-1">
                                <div class="flex items-center mb-2">
                                    <h4 class="font-semibold text-gray-800"><?php echo htmlspecialchars($activity['activity_name']); ?></h4>
                                    <?php if ($is_today): ?>
                                        <span class="ml-3 px-2 py-1 bg-green-100 text-green-800 text-xs font-semibold rounded-full">
                                            <i class="fas fa-calendar-day mr-1"></i>Today
                                        </span>
                                    <?php endif; ?>
                                    <?php if ($mandatory): ?>
                                        <span class="ml-2 px-2 py-1 bg-red-100 text-red-800 text-xs font-semibold rounded-full">
                                            <i class="fas fa-exclamation-circle mr-1"></i>Mandatory
                                        </span>
                                    <?php endif; ?>
                                    <span class="ml-2 px-2 py-1 <?php echo $status == 'ongoing' ? 'bg-blue-100 text-blue-800' : 'bg-yellow-100 text-yellow-800'; ?> text-xs font-semibold rounded-full">
                                        <?php echo ucfirst($status); ?>
                                    </span>
                                </div>
                                <div class="flex items-center text-sm text-gray-600 mb-2">
                                    <span class="flex items-center mr-4">
                                        <i class="far fa-calendar mr-2 text-blue-500"></i>
                                        <?php echo $activity_date; ?>
                                    </span>
                                    <span class="flex items-center mr-4">
                                        <i class="far fa-clock mr-2 text-green-500"></i>
                                        <?php echo $activity_time; ?>
                                    </span>
                                    <?php if (!empty($activity['venue'])): ?>
                                        <span class="flex items-center">
                                            <i class="fas fa-map-marker-alt mr-2 text-red-500"></i>
                                            <?php echo htmlspecialchars($activity['venue']); ?>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <?php if (!empty($activity['description'])): ?>
                                    <p class="text-sm text-gray-700 mt-2">
                                        <?php 
                                        if (strlen($activity['description']) > 100) {
                                            echo htmlspecialchars(substr($activity['description'], 0, 100)) . '...';
                                        } else {
                                            echo htmlspecialchars($activity['description']);
                                        }
                                        ?>
                                    </p>
                                <?php endif; ?>
                                <?php if ($fines_amount > 0): ?>
                                    <div class="mt-2 flex items-center">
                                        <span class="text-xs font-medium text-red-600">
                                            <i class="fas fa-money-bill-wave mr-1"></i>
                                            Fine for absence: ₱<?php echo number_format($fines_amount, 2); ?>
                                        </span>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="flex gap-2 ml-4 flex-shrink-0">
                                <a href="scan_attendance.php?activity=<?php echo $activity['activity_id']; ?>" 
                                   class="text-sm bg-gradient-to-r from-blue-500 to-blue-600 text-white px-4 py-2 rounded-lg hover:from-blue-600 hover:to-blue-700 transition-all font-medium flex items-center">
                                    <i class="fas fa-qrcode mr-2"></i> Scan
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="text-center py-8 text-gray-500">
                    <div class="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-calendar-times text-3xl text-gray-400"></i>
                    </div>
                    <p class="text-gray-600 mb-3">No activities scheduled for this week</p>
                    <a href="create_activity.php" class="inline-block text-blue-600 hover:text-blue-800 font-medium">
                        <i class="fas fa-plus-circle mr-2"></i> Create your first activity
                    </a>
                </div>
            <?php endif; ?>
        </div>

        <!-- Recent Attendance -->
        <div class="bg-white rounded-2xl shadow-lg p-6 border animate-in">
            <div class="flex items-center justify-between mb-6">
                <div>
                    <h3 class="text-xl font-bold text-gray-900 flex items-center">
                        <i class="fas fa-history text-blue-600 mr-3"></i>
                        Recent Attendance Records
                    </h3>
                    <p class="text-gray-600 text-sm mt-1">Latest student attendance entries</p>
                </div>
                <a href="attendance_log.php" class="text-sm text-blue-600 hover:text-blue-800 font-medium flex items-center">
                    View All <i class="fas fa-arrow-right ml-2"></i>
                </a>
            </div>
            
            <?php if (!empty($recent_attendance)): ?>
                <div class="space-y-3">
                    <?php foreach ($recent_attendance as $record): ?>
                        <div class="flex items-center p-3 bg-gray-50 rounded-xl hover:bg-blue-50 transition-colors">
                            <div class="w-10 h-10 rounded-full flex items-center justify-center mr-3 
                                <?php echo $record['status'] == 'Present' ? 'bg-green-100' : 
                                          ($record['status'] == 'Late' ? 'bg-yellow-100' : 
                                          ($record['status'] == 'Excused' ? 'bg-blue-100' : 'bg-red-100')); ?>">
                                <i class="fas 
                                    <?php echo $record['status'] == 'Present' ? 'fa-user-check text-green-600' : 
                                              ($record['status'] == 'Late' ? 'fa-user-clock text-yellow-600' : 
                                              ($record['status'] == 'Excused' ? 'fa-user-check text-blue-600' : 'fa-user-slash text-red-600')); ?>">
                                </i>
                            </div>
                            <div class="flex-1">
                                <div class="flex justify-between items-start">
                                    <div>
                                        <p class="font-medium text-gray-800"><?php echo htmlspecialchars($record['student_name']); ?></p>
                                        <p class="text-xs text-gray-600">ID: <?php echo htmlspecialchars($record['student_number']); ?></p>
                                    </div>
                                    <span class="text-xs text-gray-500">
                                        <?php echo !empty($record['attendance_time']) ? date('h:i A', strtotime($record['attendance_time'])) : 'N/A'; ?>
                                    </span>
                                </div>
                                <div class="flex items-center mt-1">
                                    <span class="text-xs font-medium px-2 py-1 rounded-full 
                                        <?php echo $record['status'] == 'Present' ? 'bg-green-100 text-green-800' : 
                                                  ($record['status'] == 'Late' ? 'bg-yellow-100 text-yellow-800' : 
                                                  ($record['status'] == 'Excused' ? 'bg-blue-100 text-blue-800' : 'bg-red-100 text-red-800')); ?>">
                                        <?php echo $record['status']; ?>
                                    </span>
                                    <span class="ml-2 text-xs text-gray-600 truncate"><?php echo htmlspecialchars($record['activity_name'] ?? 'Unknown Activity'); ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="text-center py-8 text-gray-500">
                    <div class="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-user-clock text-3xl text-gray-400"></i>
                    </div>
                    <p class="text-gray-600 mb-3">No attendance records yet</p>
                    <a href="scan_attendance.php" class="inline-block text-blue-600 hover:text-blue-800 font-medium">
                        <i class="fas fa-qrcode mr-2"></i> Start scanning attendance
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</main>

<!-- Footer -->
<footer class="bg-white border-t mt-8">
    <div class="container mx-auto px-4 py-6">
        <div class="flex flex-col md:flex-row justify-between items-center">
            <div class="mb-4 md:mb-0">
                <div class="flex items-center gap-2 mb-2">
                    <i class="fas fa-school text-purple-600"></i>
                    <p class="text-gray-600 font-medium"><?php echo htmlspecialchars($campus['campus_name']); ?> Campus</p>
                </div>
                <p class="text-sm text-gray-500">
                    Multi-Campus Attendance System • Coordinator Panel
                </p>
            </div>
            <div class="text-center md:text-right">
                <div class="flex flex-wrap gap-4 justify-center md:justify-end">
                    <span class="text-xs px-3 py-1 bg-blue-50 text-blue-700 rounded-full">
                        <i class="fas fa-users mr-1"></i> <?php echo $stats['total_students']; ?> Students
                    </span>
                    <span class="text-xs px-3 py-1 bg-green-50 text-green-700 rounded-full">
                        <i class="fas fa-calendar mr-1"></i> <?php echo $stats['today_activities']; ?> Today's Activities
                    </span>
                    <span class="text-xs px-3 py-1 bg-red-50 text-red-700 rounded-full">
                        <i class="fas fa-money-bill-wave mr-1"></i> ₱<?php echo number_format($stats['pending_fines_amount'], 2); ?> Due
                    </span>
                </div>
                <p class="text-xs text-gray-500 mt-3">
                    <i class="far fa-copyright mr-1"></i> <?php echo date('Y'); ?> MCAS • System v2.0
                </p>
            </div>
        </div>
    </div>
</footer>

<!-- JavaScript -->
<script>
// Update live clock
function updateLiveClock() {
    const now = new Date();
    const timeElement = document.getElementById('liveClock');
    if (timeElement) {
        const timeString = now.toLocaleTimeString('en-US', { 
            hour: '2-digit', 
            minute: '2-digit',
            second: '2-digit',
            hour12: true 
        });
        timeElement.textContent = timeString;
    }
}

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    updateLiveClock();
    setInterval(updateLiveClock, 1000);
});
</script>
</body>
</html>