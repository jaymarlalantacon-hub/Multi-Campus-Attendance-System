<?php
session_start();
require_once 'db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['full_name'];
$user_type = $_SESSION['user_type'];
$user_campus_id = $_SESSION['campus_id'] ?? null;

// Get user data
$user_query = "SELECT u.*, c.campus_name, c.campus_code 
               FROM users u 
               LEFT JOIN campuses c ON u.campus_id = c.campus_id 
               WHERE u.user_id = ?";
$user_stmt = $conn->prepare($user_query);
$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();
$user_result = $user_stmt->get_result();
$user_data = $user_result->fetch_assoc();

if (!$user_data) {
    session_destroy();
    header('Location: login.php');
    exit();
}

// Initialize messages
$success_message = '';
$error_message = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        
        if ($action === 'update_profile') {
            $full_name = trim($_POST['full_name']);
            $email = trim($_POST['email']);
            $phone = trim($_POST['phone']) ?: null;
            $designation = trim($_POST['designation']) ?: null;
            
            // Validate
            if (empty($full_name) || empty($email)) {
                $error_message = "Full name and email are required!";
            } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $error_message = "Invalid email format!";
            } else {
                // Check if email is already taken by another user
                $check_email = $conn->prepare("SELECT user_id FROM users WHERE email = ? AND user_id != ?");
                $check_email->bind_param("si", $email, $user_id);
                $check_email->execute();
                
                if ($check_email->get_result()->num_rows > 0) {
                    $error_message = "Email is already in use by another account!";
                } else {
                    // Update profile
                    $update_query = "UPDATE users SET 
                                    full_name = ?, 
                                    email = ?, 
                                    phone = ?, 
                                    designation = ?,
                                    updated_at = NOW()
                                    WHERE user_id = ?";
                    
                    $update_stmt = $conn->prepare($update_query);
                    $update_stmt->bind_param("ssssi", $full_name, $email, $phone, $designation, $user_id);
                    
                    if ($update_stmt->execute()) {
                        // Update session
                        $_SESSION['full_name'] = $full_name;
                        $user_name = $full_name;
                        
                        $success_message = "Profile updated successfully!";
                        // Refresh user data
                        $user_data['full_name'] = $full_name;
                        $user_data['email'] = $email;
                        $user_data['phone'] = $phone;
                        $user_data['designation'] = $designation;
                    } else {
                        $error_message = "Failed to update profile. Please try again.";
                    }
                }
            }
            
        } elseif ($action === 'change_password') {
            $current_password = $_POST['current_password'];
            $new_password = $_POST['new_password'];
            $confirm_password = $_POST['confirm_password'];
            
            // Verify current password
            $check_password = $conn->prepare("SELECT password FROM users WHERE user_id = ?");
            $check_password->bind_param("i", $user_id);
            $check_password->execute();
            $password_result = $check_password->get_result();
            $user_password = $password_result->fetch_assoc();
            
            if (!password_verify($current_password, $user_password['password'])) {
                $error_message = "Current password is incorrect!";
            } elseif (strlen($new_password) < 6) {
                $error_message = "New password must be at least 6 characters long!";
            } elseif ($new_password !== $confirm_password) {
                $error_message = "New passwords do not match!";
            } else {
                // Update password
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $update_password = $conn->prepare("UPDATE users SET password = ?, updated_at = NOW() WHERE user_id = ?");
                $update_password->bind_param("si", $hashed_password, $user_id);
                
                if ($update_password->execute()) {
                    $success_message = "Password changed successfully!";
                    
                    // Log password change
                    $log_query = "INSERT INTO audit_logs (user_id, action, description, ip_address, user_agent) 
                                 VALUES (?, 'password_change', 'User changed their password', ?, ?)";
                    $log_stmt = $conn->prepare($log_query);
                    $log_stmt->bind_param("iss", $user_id, $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT']);
                    $log_stmt->execute();
                } else {
                    $error_message = "Failed to change password. Please try again.";
                }
            }
            
        } elseif ($action === 'update_preferences') {
            $notify_email = isset($_POST['notify_email']) ? 1 : 0;
            $notify_sms = isset($_POST['notify_sms']) ? 1 : 0;
            $theme = $_POST['theme'] ?? 'light';
            $timezone = $_POST['timezone'] ?? 'Asia/Manila';
            $language = $_POST['language'] ?? 'en';
            
            // Update preferences
            $update_prefs = $conn->prepare("UPDATE users SET 
                                           notify_email = ?, 
                                           notify_sms = ?, 
                                           theme = ?, 
                                           timezone = ?,
                                           language = ?,
                                           updated_at = NOW()
                                           WHERE user_id = ?");
            
            $update_prefs->bind_param("iisssi", $notify_email, $notify_sms, $theme, $timezone, $language, $user_id);
            
            if ($update_prefs->execute()) {
                $success_message = "Preferences updated successfully!";
                $user_data['notify_email'] = $notify_email;
                $user_data['notify_sms'] = $notify_sms;
                $user_data['theme'] = $theme;
                $user_data['timezone'] = $timezone;
                $user_data['language'] = $language;
            } else {
                $error_message = "Failed to update preferences.";
            }
        }
    }
}

// Get user's recent activity
$activity_query = "SELECT * FROM audit_logs 
                  WHERE user_id = ? 
                  ORDER BY created_at DESC 
                  LIMIT 10";
$activity_stmt = $conn->prepare($activity_query);
$activity_stmt->bind_param("i", $user_id);
$activity_stmt->execute();
$recent_activity = $activity_stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get user's login history
$login_query = "SELECT * FROM login_history 
               WHERE user_id = ? 
               ORDER BY login_time DESC 
               LIMIT 5";
$login_stmt = $conn->prepare($login_query);
$login_stmt->bind_param("i", $user_id);
$login_stmt->execute();
$login_history = $login_stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get statistics based on user type
$stats = [];
if ($user_type === 'coordinator') {
    $stats_query = "SELECT 
                    (SELECT COUNT(*) FROM students WHERE campus_id = ? AND status = 'active') as total_students,
                    (SELECT COUNT(*) FROM activities WHERE (campus_id = ? OR campus_id IS NULL) AND DATE(activity_date) = CURDATE()) as today_activities,
                    (SELECT COUNT(*) FROM fines f JOIN students s ON f.student_id = s.student_id WHERE s.campus_id = ? AND f.status = 'pending') as pending_fines";
    
    $stats_stmt = $conn->prepare($stats_query);
    $stats_stmt->bind_param("iii", $user_campus_id, $user_campus_id, $user_campus_id);
    $stats_stmt->execute();
    $stats_result = $stats_stmt->get_result();
    $stats = $stats_result->fetch_assoc();
} elseif ($user_type === 'admin') {
    $stats_query = "SELECT 
                    (SELECT COUNT(*) FROM students WHERE status = 'active') as total_students,
                    (SELECT COUNT(*) FROM users WHERE status = 'active') as total_users,
                    (SELECT COUNT(*) FROM campuses WHERE status = 'active') as total_campuses,
                    (SELECT COUNT(*) FROM fines WHERE status = 'pending') as pending_fines";
    
    $stats_result = $conn->query($stats_query);
    $stats = $stats_result->fetch_assoc();
}

// Timezone options
$timezones = [
    'Asia/Manila' => 'Manila (UTC+8)',
    'Asia/Singapore' => 'Singapore (UTC+8)',
    'Asia/Hong_Kong' => 'Hong Kong (UTC+8)',
    'Asia/Tokyo' => 'Tokyo (UTC+9)',
    'Asia/Seoul' => 'Seoul (UTC+9)',
    'Asia/Bangkok' => 'Bangkok (UTC+7)',
    'Asia/Jakarta' => 'Jakarta (UTC+7)',
    'Asia/Kolkata' => 'Kolkata (UTC+5:30)',
    'Asia/Dubai' => 'Dubai (UTC+4)',
    'Europe/London' => 'London (UTC+0)',
    'America/New_York' => 'New York (UTC-5)',
    'America/Los_Angeles' => 'Los Angeles (UTC-8)',
    'Australia/Sydney' => 'Sydney (UTC+10)'
];

// Theme options
$themes = [
    'light' => 'Light Mode',
    'dark' => 'Dark Mode',
    'blue' => 'Blue Theme',
    'green' => 'Green Theme',
    'purple' => 'Purple Theme'
];

// Language options
$languages = [
    'en' => 'English',
    'fil' => 'Filipino',
    'es' => 'Spanish',
    'zh' => 'Chinese',
    'ja' => 'Japanese'
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile | Multi-Campus Attendance System</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #3b82f6;
            --secondary-color: #8b5cf6;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
        }
        
        body {
            font-family: 'Segoe UI', 'Inter', system-ui, -apple-system, sans-serif;
            background: linear-gradient(135deg, #f6f9fc 0%, #edf2f7 100%);
            min-height: 100vh;
        }
        
        .profile-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            border-radius: 1rem;
            box-shadow: 0 10px 30px rgba(59, 130, 246, 0.3);
        }
        
        .profile-avatar {
            width: 120px;
            height: 120px;
            background: linear-gradient(135deg, #ffffff 0%, #f3f4f6 100%);
            border: 4px solid white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            font-weight: bold;
            color: var(--primary-color);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }
        
        .card {
            background: white;
            border-radius: 1rem;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            border: 1px solid #e5e7eb;
        }
        
        .card:hover {
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
            transform: translateY(-2px);
        }
        
        .stat-card {
            background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
            border-left: 4px solid var(--primary-color);
            border-radius: 0.75rem;
            padding: 1.25rem;
        }
        
        .tab {
            padding: 0.75rem 1.5rem;
            border-radius: 0.75rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .tab.active {
            background: var(--primary-color);
            color: white;
        }
        
        .tab:hover:not(.active) {
            background: #f3f4f6;
        }
        
        .btn {
            padding: 0.75rem 1.5rem;
            border-radius: 0.75rem;
            font-weight: 600;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(59, 130, 246, 0.3);
        }
        
        .btn-success {
            background: var(--success-color);
            color: white;
        }
        
        .btn-success:hover {
            background: #0da271;
            transform: translateY(-2px);
        }
        
        .input-group {
            margin-bottom: 1rem;
        }
        
        .input-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: #374151;
        }
        
        .input-group input,
        .input-group select,
        .input-group textarea {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 1px solid #d1d5db;
            border-radius: 0.5rem;
            font-size: 1rem;
            transition: all 0.3s ease;
        }
        
        .input-group input:focus,
        .input-group select:focus,
        .input-group textarea:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        
        .badge {
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        
        .badge-primary {
            background: #dbeafe;
            color: #1e40af;
        }
        
        .badge-success {
            background: #d1fae5;
            color: #065f46;
        }
        
        .badge-warning {
            background: #fef3c7;
            color: #92400e;
        }
        
        .badge-danger {
            background: #fee2e2;
            color: #991b1b;
        }
        
        .activity-item {
            border-left: 3px solid var(--primary-color);
            padding-left: 1rem;
            margin-bottom: 1rem;
        }
        
        .login-item {
            padding: 0.75rem;
            border-radius: 0.5rem;
            background: #f9fafb;
            margin-bottom: 0.5rem;
            border-left: 3px solid #10b981;
        }
    </style>
</head>
<body class="min-h-screen">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg border-b">
        <div class="container mx-auto px-4 py-3">
            <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div class="flex items-center space-x-4">
                    <a href="<?php echo $user_type === 'admin' ? 'admin_dashboard.php' : 'coordinator_dashboard.php'; ?>" 
                       class="flex items-center text-gray-700 hover:text-blue-600 transition-colors">
                        <i class="fas fa-arrow-left mr-2"></i> Back to Dashboard
                    </a>
                    <h1 class="text-xl font-bold text-gray-900">
                        <i class="fas fa-user-circle mr-2"></i> Profile Management
                    </h1>
                </div>
                <div class="flex items-center space-x-4">
                    <span class="text-sm text-gray-600">
                        <i class="fas fa-user mr-1"></i> <?php echo htmlspecialchars($user_name); ?>
                    </span>
                    <a href="logout.php" class="text-sm bg-red-50 text-red-700 px-3 py-1 rounded-lg hover:bg-red-100 transition-colors">
                        <i class="fas fa-sign-out-alt mr-1"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-8">
        <!-- Messages -->
        <?php if ($success_message): ?>
        <div class="mb-6 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-xl flex items-center">
            <i class="fas fa-check-circle mr-3 text-green-600"></i>
            <span><?php echo $success_message; ?></span>
        </div>
        <?php endif; ?>
        
        <?php if ($error_message): ?>
        <div class="mb-6 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl flex items-center">
            <i class="fas fa-exclamation-circle mr-3 text-red-600"></i>
            <span><?php echo $error_message; ?></span>
        </div>
        <?php endif; ?>
        
        <!-- Profile Header -->
        <div class="profile-header p-6 mb-8">
            <div class="flex flex-col md:flex-row md:items-center gap-6">
                <div class="profile-avatar">
                    <?php echo strtoupper(substr($user_data['full_name'], 0, 1)); ?>
                </div>
                <div class="flex-1">
                    <h1 class="text-3xl font-bold mb-2"><?php echo htmlspecialchars($user_data['full_name']); ?></h1>
                    <div class="flex flex-wrap gap-3 mb-4">
                        <span class="badge badge-primary">
                            <i class="fas fa-user-tag mr-1"></i> <?php echo ucfirst($user_type); ?>
                        </span>
                        <?php if ($user_data['campus_name']): ?>
                        <span class="badge badge-success">
                            <i class="fas fa-school mr-1"></i> <?php echo htmlspecialchars($user_data['campus_name']); ?>
                        </span>
                        <?php endif; ?>
                        <?php if ($user_data['designation']): ?>
                        <span class="badge badge-warning">
                            <i class="fas fa-briefcase mr-1"></i> <?php echo htmlspecialchars($user_data['designation']); ?>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div class="flex items-center text-white/90">
                            <i class="fas fa-envelope mr-3"></i>
                            <span><?php echo htmlspecialchars($user_data['email']); ?></span>
                        </div>
                        <?php if ($user_data['phone']): ?>
                        <div class="flex items-center text-white/90">
                            <i class="fas fa-phone mr-3"></i>
                            <span><?php echo htmlspecialchars($user_data['phone']); ?></span>
                        </div>
                        <?php endif; ?>
                        <div class="flex items-center text-white/90">
                            <i class="fas fa-calendar-alt mr-3"></i>
                            <span>Joined <?php echo date('F j, Y', strtotime($user_data['created_at'])); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tabs -->
        <div class="flex flex-wrap gap-2 mb-8">
            <button id="tab-profile" class="tab active" onclick="showTab('profile')">
                <i class="fas fa-user mr-2"></i> Profile
            </button>
            <button id="tab-security" class="tab" onclick="showTab('security')">
                <i class="fas fa-shield-alt mr-2"></i> Security
            </button>
            <button id="tab-preferences" class="tab" onclick="showTab('preferences')">
                <i class="fas fa-cog mr-2"></i> Preferences
            </button>
            <button id="tab-activity" class="tab" onclick="showTab('activity')">
                <i class="fas fa-history mr-2"></i> Activity
            </button>
            <button id="tab-stats" class="tab" onclick="showTab('stats')">
                <i class="fas fa-chart-bar mr-2"></i> Statistics
            </button>
        </div>

        <!-- Tab Content -->
        <div class="tab-content">
            <!-- Profile Tab -->
            <div id="profile-content" class="tab-pane active">
                <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <!-- Profile Form -->
                    <div class="lg:col-span-2">
                        <div class="card p-6">
                            <h2 class="text-xl font-bold text-gray-800 mb-6 flex items-center">
                                <i class="fas fa-edit mr-3 text-blue-600"></i> Edit Profile Information
                            </h2>
                            <form method="POST" action="" class="space-y-4">
                                <input type="hidden" name="action" value="update_profile">
                                
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div class="input-group">
                                        <label for="full_name">Full Name <span class="text-red-500">*</span></label>
                                        <input type="text" 
                                               id="full_name" 
                                               name="full_name" 
                                               value="<?php echo htmlspecialchars($user_data['full_name']); ?>"
                                               required
                                               placeholder="Enter your full name">
                                    </div>
                                    
                                    <div class="input-group">
                                        <label for="email">Email Address <span class="text-red-500">*</span></label>
                                        <input type="email" 
                                               id="email" 
                                               name="email" 
                                               value="<?php echo htmlspecialchars($user_data['email']); ?>"
                                               required
                                               placeholder="Enter your email address">
                                    </div>
                                </div>
                                
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div class="input-group">
                                        <label for="phone">Phone Number</label>
                                        <input type="tel" 
                                               id="phone" 
                                               name="phone" 
                                               value="<?php echo htmlspecialchars($user_data['phone'] ?? ''); ?>"
                                               placeholder="Enter your phone number">
                                    </div>
                                    
                                    <div class="input-group">
                                        <label for="designation">Designation</label>
                                        <input type="text" 
                                               id="designation" 
                                               name="designation" 
                                               value="<?php echo htmlspecialchars($user_data['designation'] ?? ''); ?>"
                                               placeholder="e.g., Senior Coordinator">
                                    </div>
                                </div>
                                
                                <div class="input-group">
                                    <label for="username">Username</label>
                                    <input type="text" 
                                           id="username" 
                                           value="<?php echo htmlspecialchars($user_data['username']); ?>"
                                           readonly
                                           class="bg-gray-50 cursor-not-allowed"
                                           title="Username cannot be changed">
                                    <p class="text-sm text-gray-500 mt-1">Username cannot be changed for security reasons</p>
                                </div>
                                
                                <?php if ($user_data['campus_name']): ?>
                                <div class="input-group">
                                    <label>Campus</label>
                                    <input type="text" 
                                           value="<?php echo htmlspecialchars($user_data['campus_name'] . ' (' . $user_data['campus_code'] . ')'); ?>"
                                           readonly
                                           class="bg-gray-50 cursor-not-allowed">
                                </div>
                                <?php endif; ?>
                                
                                <div class="flex justify-end pt-4">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save mr-2"></i> Save Changes
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                    <!-- Account Information -->
                    <div>
                        <div class="card p-6 mb-6">
                            <h2 class="text-xl font-bold text-gray-800 mb-4 flex items-center">
                                <i class="fas fa-info-circle mr-3 text-green-600"></i> Account Information
                            </h2>
                            <div class="space-y-3">
                                <div class="flex justify-between">
                                    <span class="text-gray-600">Account Type:</span>
                                    <span class="font-semibold"><?php echo ucfirst($user_type); ?></span>
                                </div>
                                <div class="flex justify-between">
                                    <span class="text-gray-600">Account Status:</span>
                                    <span class="font-semibold <?php echo $user_data['status'] === 'active' ? 'text-green-600' : 'text-red-600'; ?>">
                                        <?php echo ucfirst($user_data['status']); ?>
                                    </span>
                                </div>
                                <div class="flex justify-between">
                                    <span class="text-gray-600">Last Login:</span>
                                    <span class="font-semibold">
                                        <?php 
                                        $last_login = $user_data['last_login'] ?? $user_data['created_at'];
                                        echo date('M j, Y g:i A', strtotime($last_login));
                                        ?>
                                    </span>
                                </div>
                                <div class="flex justify-between">
                                    <span class="text-gray-600">Account Created:</span>
                                    <span class="font-semibold"><?php echo date('M j, Y', strtotime($user_data['created_at'])); ?></span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card p-6">
                            <h2 class="text-xl font-bold text-gray-800 mb-4 flex items-center">
                                <i class="fas fa-qrcode mr-3 text-purple-600"></i> Your QR Code
                            </h2>
                            <div class="text-center">
                                <div id="user-qrcode" class="mx-auto mb-4"></div>
                                <p class="text-sm text-gray-600">
                                    Scan this code for quick login on mobile devices
                                </p>
                                <button onclick="downloadQRCode()" class="btn btn-primary mt-4 w-full">
                                    <i class="fas fa-download mr-2"></i> Download QR Code
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Security Tab -->
            <div id="security-content" class="tab-pane hidden">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <!-- Change Password -->
                    <div class="card p-6">
                        <h2 class="text-xl font-bold text-gray-800 mb-6 flex items-center">
                            <i class="fas fa-key mr-3 text-red-600"></i> Change Password
                        </h2>
                        <form method="POST" action="" class="space-y-4">
                            <input type="hidden" name="action" value="change_password">
                            
                            <div class="input-group">
                                <label for="current_password">Current Password <span class="text-red-500">*</span></label>
                                <input type="password" 
                                       id="current_password" 
                                       name="current_password" 
                                       required
                                       placeholder="Enter your current password">
                            </div>
                            
                            <div class="input-group">
                                <label for="new_password">New Password <span class="text-red-500">*</span></label>
                                <input type="password" 
                                       id="new_password" 
                                       name="new_password" 
                                       required
                                       minlength="6"
                                       placeholder="Enter new password (min. 6 characters)">
                                <div class="password-strength mt-2 hidden">
                                    <div class="text-sm font-medium mb-1">Password Strength:</div>
                                    <div class="h-2 bg-gray-200 rounded-full overflow-hidden">
                                        <div class="h-full bg-red-500 password-strength-meter"></div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="input-group">
                                <label for="confirm_password">Confirm New Password <span class="text-red-500">*</span></label>
                                <input type="password" 
                                       id="confirm_password" 
                                       name="confirm_password" 
                                       required
                                       placeholder="Confirm your new password">
                                <div class="password-match mt-2 text-sm hidden">
                                    <i class="fas fa-check text-green-600 mr-1"></i>
                                    <span class="text-green-600">Passwords match</span>
                                </div>
                            </div>
                            
                            <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-6">
                                <h3 class="font-bold text-blue-800 mb-2 flex items-center">
                                    <i class="fas fa-lightbulb mr-2"></i> Password Requirements
                                </h3>
                                <ul class="text-sm text-blue-700 space-y-1">
                                    <li>• Minimum 6 characters</li>
                                    <li>• Use a mix of letters, numbers, and symbols</li>
                                    <li>• Avoid using personal information</li>
                                    <li>• Don't reuse old passwords</li>
                                </ul>
                            </div>
                            
                            <div class="flex justify-end pt-4">
                                <button type="submit" class="btn btn-success">
                                    <i class="fas fa-key mr-2"></i> Change Password
                                </button>
                            </div>
                        </form>
                    </div>
                    
                    <!-- Security Settings & Login History -->
                    <div class="space-y-6">
                        <div class="card p-6">
                            <h2 class="text-xl font-bold text-gray-800 mb-4 flex items-center">
                                <i class="fas fa-shield-alt mr-3 text-orange-600"></i> Security Settings
                            </h2>
                            <div class="space-y-4">
                                <div class="flex items-center justify-between">
                                    <div>
                                        <div class="font-medium">Two-Factor Authentication</div>
                                        <div class="text-sm text-gray-600">Add an extra layer of security</div>
                                    </div>
                                    <label class="relative inline-flex items-center cursor-pointer">
                                        <input type="checkbox" class="sr-only peer" disabled>
                                        <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
                                    </label>
                                </div>
                                
                                <div class="flex items-center justify-between">
                                    <div>
                                        <div class="font-medium">Session Timeout</div>
                                        <div class="text-sm text-gray-600">Auto-logout after 30 minutes</div>
                                    </div>
                                    <span class="badge badge-info">Active</span>
                                </div>
                                
                                <div class="pt-4 border-t">
                                    <button onclick="showAllSessions()" class="btn w-full">
                                        <i class="fas fa-desktop mr-2"></i> View Active Sessions
                                    </button>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card p-6">
                            <h2 class="text-xl font-bold text-gray-800 mb-4 flex items-center">
                                <i class="fas fa-history mr-3 text-blue-600"></i> Recent Login History
                            </h2>
                            <div class="space-y-3">
                                <?php if (!empty($login_history)): ?>
                                    <?php foreach ($login_history as $login): ?>
                                    <div class="login-item">
                                        <div class="flex justify-between items-center">
                                            <div class="font-medium">
                                                <i class="fas fa-sign-in-alt text-green-600 mr-2"></i>
                                                Successful Login
                                            </div>
                                            <span class="text-sm text-gray-500">
                                                <?php echo date('M j, g:i A', strtotime($login['login_time'])); ?>
                                            </span>
                                        </div>
                                        <div class="text-sm text-gray-600 mt-1">
                                            IP: <?php echo htmlspecialchars($login['ip_address']); ?>
                                            <?php if ($login['location']): ?>
                                            • <?php echo htmlspecialchars($login['location']); ?>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <div class="text-center py-4 text-gray-500">
                                        <i class="fas fa-history text-3xl mb-2"></i>
                                        <p>No login history available</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Preferences Tab -->
            <div id="preferences-content" class="tab-pane hidden">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <!-- System Preferences -->
                    <div class="card p-6">
                        <h2 class="text-xl font-bold text-gray-800 mb-6 flex items-center">
                            <i class="fas fa-cog mr-3 text-purple-600"></i> System Preferences
                        </h2>
                        <form method="POST" action="" class="space-y-4">
                            <input type="hidden" name="action" value="update_preferences">
                            
                            <div class="input-group">
                                <label for="theme">Theme</label>
                                <select id="theme" name="theme" class="w-full">
                                    <?php foreach ($themes as $value => $label): ?>
                                    <option value="<?php echo $value; ?>" 
                                            <?php echo ($user_data['theme'] ?? 'light') === $value ? 'selected' : ''; ?>>
                                        <?php echo $label; ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="input-group">
                                <label for="timezone">Timezone</label>
                                <select id="timezone" name="timezone" class="w-full">
                                    <?php foreach ($timezones as $value => $label): ?>
                                    <option value="<?php echo $value; ?>" 
                                            <?php echo ($user_data['timezone'] ?? 'Asia/Manila') === $value ? 'selected' : ''; ?>>
                                        <?php echo $label; ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="input-group">
                                <label for="language">Language</label>
                                <select id="language" name="language" class="w-full">
                                    <?php foreach ($languages as $value => $label): ?>
                                    <option value="<?php echo $value; ?>" 
                                            <?php echo ($user_data['language'] ?? 'en') === $value ? 'selected' : ''; ?>>
                                        <?php echo $label; ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="pt-4 border-t">
                                <h3 class="font-bold text-gray-800 mb-4">Notification Preferences</h3>
                                
                                <div class="space-y-3">
                                    <div class="flex items-center">
                                        <input type="checkbox" 
                                               id="notify_email" 
                                               name="notify_email" 
                                               value="1"
                                               <?php echo ($user_data['notify_email'] ?? 1) ? 'checked' : ''; ?>
                                               class="w-4 h-4 text-blue-600 rounded focus:ring-blue-500">
                                        <label for="notify_email" class="ml-3 font-medium text-gray-700">
                                            Email Notifications
                                        </label>
                                        <span class="ml-auto text-sm text-gray-500">
                                            <i class="fas fa-envelope"></i>
                                        </span>
                                    </div>
                                    
                                    <div class="flex items-center">
                                        <input type="checkbox" 
                                               id="notify_sms" 
                                               name="notify_sms" 
                                               value="1"
                                               <?php echo ($user_data['notify_sms'] ?? 0) ? 'checked' : ''; ?>
                                               class="w-4 h-4 text-blue-600 rounded focus:ring-blue-500">
                                        <label for="notify_sms" class="ml-3 font-medium text-gray-700">
                                            SMS Notifications
                                        </label>
                                        <span class="ml-auto text-sm text-gray-500">
                                            <i class="fas fa-sms"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="flex justify-end pt-6">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save mr-2"></i> Save Preferences
                                </button>
                            </div>
                        </form>
                    </div>
                    
                    <!-- Dashboard Preferences -->
                    <div class="space-y-6">
                        <div class="card p-6">
                            <h2 class="text-xl font-bold text-gray-800 mb-4 flex items-center">
                                <i class="fas fa-tachometer-alt mr-3 text-green-600"></i> Dashboard Preferences
                            </h2>
                            <div class="space-y-4">
                                <div class="flex items-center justify-between">
                                    <div>
                                        <div class="font-medium">Show Statistics</div>
                                        <div class="text-sm text-gray-600">Display stats cards on dashboard</div>
                                    </div>
                                    <label class="relative inline-flex items-center cursor-pointer">
                                        <input type="checkbox" class="sr-only peer" checked>
                                        <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
                                    </label>
                                </div>
                                
                                <div class="flex items-center justify-between">
                                    <div>
                                        <div class="font-medium">Recent Activity</div>
                                        <div class="text-sm text-gray-600">Show recent activity feed</div>
                                    </div>
                                    <label class="relative inline-flex items-center cursor-pointer">
                                        <input type="checkbox" class="sr-only peer" checked>
                                        <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
                                    </label>
                                </div>
                                
                                <div class="flex items-center justify-between">
                                    <div>
                                        <div class="font-medium">Quick Actions</div>
                                        <div class="text-sm text-gray-600">Show quick action buttons</div>
                                    </div>
                                    <label class="relative inline-flex items-center cursor-pointer">
                                        <input type="checkbox" class="sr-only peer" checked>
                                        <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
                                    </label>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card p-6">
                            <h2 class="text-xl font-bold text-gray-800 mb-4 flex items-center">
                                <i class="fas fa-palette mr-3 text-yellow-600"></i> Theme Preview
                            </h2>
                            <div class="grid grid-cols-3 gap-3">
                                <div class="theme-preview theme-light border-2 border-blue-500 p-3 rounded-lg cursor-pointer" onclick="selectTheme('light')">
                                    <div class="h-6 bg-gray-100 rounded mb-2"></div>
                                    <div class="h-4 bg-white rounded border"></div>
                                    <div class="text-xs text-center mt-2">Light</div>
                                </div>
                                <div class="theme-preview theme-dark p-3 rounded-lg cursor-pointer" onclick="selectTheme('dark')">
                                    <div class="h-6 bg-gray-800 rounded mb-2"></div>
                                    <div class="h-4 bg-gray-900 rounded"></div>
                                    <div class="text-xs text-center mt-2 text-white">Dark</div>
                                </div>
                                <div class="theme-preview theme-blue p-3 rounded-lg cursor-pointer" onclick="selectTheme('blue')">
                                    <div class="h-6 bg-blue-600 rounded mb-2"></div>
                                    <div class="h-4 bg-blue-100 rounded"></div>
                                    <div class="text-xs text-center mt-2">Blue</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Activity Tab -->
            <div id="activity-content" class="tab-pane hidden">
                <div class="card p-6">
                    <div class="flex justify-between items-center mb-6">
                        <h2 class="text-xl font-bold text-gray-800 flex items-center">
                            <i class="fas fa-history mr-3 text-orange-600"></i> Recent Activity Log
                        </h2>
                        <button onclick="exportActivity()" class="btn">
                            <i class="fas fa-download mr-2"></i> Export Log
                        </button>
                    </div>
                    
                    <div class="space-y-4">
                        <?php if (!empty($recent_activity)): ?>
                            <?php foreach ($recent_activity as $activity): ?>
                            <div class="activity-item">
                                <div class="flex justify-between items-start">
                                    <div>
                                        <div class="font-medium text-gray-800">
                                            <?php 
                                            $action_icons = [
                                                'login' => 'fas fa-sign-in-alt text-green-600',
                                                'logout' => 'fas fa-sign-out-alt text-red-600',
                                                'profile_update' => 'fas fa-user-edit text-blue-600',
                                                'password_change' => 'fas fa-key text-yellow-600',
                                                'scan' => 'fas fa-qrcode text-purple-600',
                                                'create' => 'fas fa-plus-circle text-green-600',
                                                'update' => 'fas fa-edit text-blue-600',
                                                'delete' => 'fas fa-trash text-red-600'
                                            ];
                                            $icon = $action_icons[$activity['action']] ?? 'fas fa-circle text-gray-600';
                                            ?>
                                            <i class="<?php echo $icon; ?> mr-2"></i>
                                            <?php echo ucfirst(str_replace('_', ' ', $activity['action'])); ?>
                                        </div>
                                        <div class="text-sm text-gray-600 mt-1">
                                            <?php echo htmlspecialchars($activity['description'] ?? ''); ?>
                                        </div>
                                        <div class="text-xs text-gray-500 mt-2">
                                            IP: <?php echo htmlspecialchars($activity['ip_address']); ?> • 
                                            Browser: <?php echo htmlspecialchars($activity['user_agent'] ?? 'Unknown'); ?>
                                        </div>
                                    </div>
                                    <div class="text-sm text-gray-500 whitespace-nowrap">
                                        <?php echo date('M j, g:i A', strtotime($activity['created_at'])); ?>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center py-8 text-gray-500">
                                <i class="fas fa-clipboard-list text-4xl mb-4"></i>
                                <h3 class="text-lg font-semibold mb-2">No Activity Recorded</h3>
                                <p>Your activity log will appear here as you use the system.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <?php if (!empty($recent_activity)): ?>
                    <div class="mt-6 text-center">
                        <a href="activity_log.php" class="btn btn-primary">
                            <i class="fas fa-list mr-2"></i> View Full Activity Log
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Statistics Tab -->
            <div id="stats-content" class="tab-pane hidden">
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                    <?php if ($user_type === 'coordinator'): ?>
                        <div class="stat-card">
                            <div class="text-3xl font-bold text-blue-600"><?php echo $stats['total_students'] ?? 0; ?></div>
                            <div class="stat-label">Total Students</div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="text-3xl font-bold text-green-600"><?php echo $stats['today_activities'] ?? 0; ?></div>
                            <div class="stat-label">Today's Activities</div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="text-3xl font-bold text-red-600"><?php echo $stats['pending_fines'] ?? 0; ?></div>
                            <div class="stat-label">Pending Fines</div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="text-3xl font-bold text-purple-600">
                                <?php 
                                $logins = count($login_history);
                                echo $logins;
                                ?>
                            </div>
                            <div class="stat-label">Recent Logins</div>
                        </div>
                    <?php elseif ($user_type === 'admin'): ?>
                        <div class="stat-card">
                            <div class="text-3xl font-bold text-blue-600"><?php echo $stats['total_students'] ?? 0; ?></div>
                            <div class="stat-label">Total Students</div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="text-3xl font-bold text-green-600"><?php echo $stats['total_users'] ?? 0; ?></div>
                            <div class="stat-label">System Users</div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="text-3xl font-bold text-orange-600"><?php echo $stats['total_campuses'] ?? 0; ?></div>
                            <div class="stat-label">Campuses</div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="text-3xl font-bold text-red-600"><?php echo $stats['pending_fines'] ?? 0; ?></div>
                            <div class="stat-label">Pending Fines</div>
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <!-- Activity Summary -->
                    <div class="card p-6">
                        <h2 class="text-xl font-bold text-gray-800 mb-4 flex items-center">
                            <i class="fas fa-chart-line mr-3 text-blue-600"></i> Activity Summary
                        </h2>
                        <div class="space-y-4">
                            <div class="flex justify-between items-center">
                                <span>Total Logins This Month:</span>
                                <span class="font-bold"><?php echo count($login_history); ?></span>
                            </div>
                            <div class="flex justify-between items-center">
                                <span>Profile Updates:</span>
                                <span class="font-bold">
                                    <?php 
                                    $profile_updates = 0;
                                    foreach ($recent_activity as $activity) {
                                        if ($activity['action'] === 'profile_update') {
                                            $profile_updates++;
                                        }
                                    }
                                    echo $profile_updates;
                                    ?>
                                </span>
                            </div>
                            <div class="flex justify-between items-center">
                                <span>Last Password Change:</span>
                                <span class="font-bold">
                                    <?php 
                                    $last_pw_change = null;
                                    foreach ($recent_activity as $activity) {
                                        if ($activity['action'] === 'password_change') {
                                            $last_pw_change = $activity['created_at'];
                                            break;
                                        }
                                    }
                                    echo $last_pw_change ? date('M j, Y', strtotime($last_pw_change)) : 'Never';
                                    ?>
                                </span>
                            </div>
                        </div>
                    </div>
                    
                    <!-- System Information -->
                    <div class="card p-6">
                        <h2 class="text-xl font-bold text-gray-800 mb-4 flex items-center">
                            <i class="fas fa-info-circle mr-3 text-green-600"></i> System Information
                        </h2>
                        <div class="space-y-3">
                            <div class="flex justify-between">
                                <span class="text-gray-600">Current Timezone:</span>
                                <span class="font-medium"><?php echo $user_data['timezone'] ?? 'Asia/Manila'; ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">Preferred Language:</span>
                                <span class="font-medium"><?php echo $languages[$user_data['language'] ?? 'en']; ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">Account Created:</span>
                                <span class="font-medium"><?php echo date('F j, Y', strtotime($user_data['created_at'])); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">Days Active:</span>
                                <span class="font-medium">
                                    <?php 
                                    $created = new DateTime($user_data['created_at']);
                                    $now = new DateTime();
                                    echo $now->diff($created)->format('%a');
                                    ?> days
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- QR Code Library -->
    <script src="https://cdn.jsdelivr.net/npm/qrcode-generator@1.4.4/qrcode.min.js"></script>
    
    <script>
        // Tab Management
        function showTab(tabName) {
            // Hide all tab contents
            document.querySelectorAll('.tab-pane').forEach(pane => {
                pane.classList.add('hidden');
                pane.classList.remove('active');
            });
            
            // Remove active class from all tabs
            document.querySelectorAll('.tab').forEach(tab => {
                tab.classList.remove('active');
            });
            
            // Show selected tab content
            document.getElementById(`${tabName}-content`).classList.remove('hidden');
            document.getElementById(`${tabName}-content`).classList.add('active');
            
            // Activate selected tab
            document.getElementById(`tab-${tabName}`).classList.add('active');
        }
        
        // Password strength checker
        const newPassword = document.getElementById('new_password');
        const confirmPassword = document.getElementById('confirm_password');
        
        if (newPassword) {
            newPassword.addEventListener('input', function() {
                const strengthDiv = this.parentElement.querySelector('.password-strength');
                const meter = this.parentElement.querySelector('.password-strength-meter');
                
                if (this.value.length > 0) {
                    strengthDiv.classList.remove('hidden');
                    
                    // Simple password strength calculation
                    let strength = 0;
                    if (this.value.length >= 6) strength += 25;
                    if (/[A-Z]/.test(this.value)) strength += 25;
                    if (/[0-9]/.test(this.value)) strength += 25;
                    if (/[^A-Za-z0-9]/.test(this.value)) strength += 25;
                    
                    meter.style.width = strength + '%';
                    meter.className = 'h-full password-strength-meter';
                    
                    if (strength < 50) {
                        meter.style.backgroundColor = '#ef4444'; // red
                    } else if (strength < 75) {
                        meter.style.backgroundColor = '#f59e0b'; // yellow
                    } else {
                        meter.style.backgroundColor = '#10b981'; // green
                    }
                } else {
                    strengthDiv.classList.add('hidden');
                }
            });
        }
        
        if (confirmPassword) {
            confirmPassword.addEventListener('input', function() {
                const matchDiv = this.parentElement.querySelector('.password-match');
                
                if (newPassword.value && this.value) {
                    if (newPassword.value === this.value) {
                        matchDiv.classList.remove('hidden');
                    } else {
                        matchDiv.classList.add('hidden');
                    }
                } else {
                    matchDiv.classList.add('hidden');
                }
            });
        }
        
        // Theme selection
        function selectTheme(theme) {
            document.getElementById('theme').value = theme;
            
            // Update preview borders
            document.querySelectorAll('.theme-preview').forEach(preview => {
                preview.classList.remove('border-2', 'border-blue-500');
            });
            
            const selectedPreview = document.querySelector(`.theme-${theme}`);
            if (selectedPreview) {
                selectedPreview.classList.add('border-2', 'border-blue-500');
            }
        }
        
        // Initialize theme preview borders
        document.addEventListener('DOMContentLoaded', function() {
            const currentTheme = '<?php echo $user_data['theme'] ?? 'light'; ?>';
            selectTheme(currentTheme);
            
            // Generate QR Code
            generateQRCode();
        });
        
        // QR Code Generation
        function generateQRCode() {
            const qrContainer = document.getElementById('user-qrcode');
            if (!qrContainer) return;
            
            // Generate QR code data (user info for mobile scanning)
            const qrData = JSON.stringify({
                user_id: '<?php echo $user_id; ?>',
                username: '<?php echo $user_data['username']; ?>',
                name: '<?php echo $user_data['full_name']; ?>',
                type: '<?php echo $user_type; ?>',
                campus: '<?php echo $user_data['campus_code'] ?? ''; ?>',
                timestamp: Date.now()
            });
            
            // Generate QR code
            const qr = qrcode(0, 'M');
            qr.addData(qrData);
            qr.make();
            
            // Create QR code image
            const qrSvg = qr.createSvgTag({ cellSize: 4, margin: 2 });
            qrContainer.innerHTML = qrSvg;
        }
        
        // Download QR Code
        function downloadQRCode() {
            const qrSvg = document.querySelector('#user-qrcode svg');
            if (!qrSvg) {
                alert('QR Code not available.');
                return;
            }
            
            const serializer = new XMLSerializer();
            const source = serializer.serializeToString(qrSvg);
            const svgBlob = new Blob([source], { type: 'image/svg+xml;charset=utf-8' });
            const url = URL.createObjectURL(svgBlob);
            
            const downloadLink = document.createElement('a');
            downloadLink.href = url;
            downloadLink.download = 'profile-qrcode-<?php echo $user_data['username']; ?>.svg';
            document.body.appendChild(downloadLink);
            downloadLink.click();
            document.body.removeChild(downloadLink);
            URL.revokeObjectURL(url);
        }
        
        // Export Activity
        function exportActivity() {
            alert('Activity export feature will be implemented soon.');
        }
        
        // Show All Sessions
        function showAllSessions() {
            alert('Active sessions feature will be implemented soon.');
        }
        
        // Form validation
        document.addEventListener('DOMContentLoaded', function() {
            const forms = document.querySelectorAll('form');
            forms.forEach(form => {
                form.addEventListener('submit', function(e) {
                    // Simple validation
                    const requiredFields = form.querySelectorAll('[required]');
                    let valid = true;
                    
                    requiredFields.forEach(field => {
                        if (!field.value.trim()) {
                            valid = false;
                            field.classList.add('border-red-500');
                            
                            // Add error message
                            if (!field.nextElementSibling || !field.nextElementSibling.classList.contains('error-message')) {
                                const error = document.createElement('p');
                                error.className = 'error-message text-red-500 text-sm mt-1';
                                error.textContent = 'This field is required';
                                field.parentNode.appendChild(error);
                            }
                        } else {
                            field.classList.remove('border-red-500');
                            const error = field.parentNode.querySelector('.error-message');
                            if (error) error.remove();
                        }
                    });
                    
                    if (!valid) {
                        e.preventDefault();
                        alert('Please fill all required fields.');
                    }
                });
            });
        });
    </script>
</body>
</html>
<?php
$conn->close();
?>