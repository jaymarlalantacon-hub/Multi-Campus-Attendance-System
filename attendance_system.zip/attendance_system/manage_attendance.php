<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_type']) || !in_array($_SESSION['user_type'], ['admin','coordinator'])) {
    header('Location: index.php');
    exit();
}

// Get user info
$user_name = $_SESSION['full_name'] ?? $_SESSION['username'] ?? 'User';
$user_campus_id = $_SESSION['campus_id'] ?? null;

// Handle bulk operations
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['bulk_action'])) {
        $bulk_action = $_POST['bulk_action'];
        $selected_ids = isset($_POST['selected_records']) ? $_POST['selected_records'] : [];
        
        if (empty($selected_ids)) {
            $message = ['type' => 'error', 'text' => 'Please select records to perform this action.'];
        } else {
            $success_count = 0;
            $error_count = 0;
            
            switch ($bulk_action) {
                case 'delete':
                    foreach ($selected_ids as $id) {
                        $stmt = $conn->prepare("DELETE FROM attendance WHERE attendance_id = ?");
                        $stmt->bind_param("i", $id);
                        if ($stmt->execute()) {
                            $success_count++;
                        } else {
                            $error_count++;
                        }
                    }
                    $message = ['type' => 'success', 'text' => "Deleted $success_count records successfully. Failed: $error_count"];
                    break;
                    
                case 'mark_present':
                    foreach ($selected_ids as $id) {
                        $stmt = $conn->prepare("UPDATE attendance SET status = 'Present' WHERE attendance_id = ?");
                        $stmt->bind_param("i", $id);
                        if ($stmt->execute()) {
                            $success_count++;
                        } else {
                            $error_count++;
                        }
                    }
                    $message = ['type' => 'success', 'text' => "Marked $success_count records as Present. Failed: $error_count"];
                    break;
                    
                case 'mark_absent':
                    foreach ($selected_ids as $id) {
                        $stmt = $conn->prepare("UPDATE attendance SET status = 'Absent' WHERE attendance_id = ?");
                        $stmt->bind_param("i", $id);
                        if ($stmt->execute()) {
                            $success_count++;
                        } else {
                            $error_count++;
                        }
                    }
                    $message = ['type' => 'success', 'text' => "Marked $success_count records as Absent. Failed: $error_count"];
                    break;
                    
                case 'mark_late':
                    foreach ($selected_ids as $id) {
                        $stmt = $conn->prepare("UPDATE attendance SET status = 'Late' WHERE attendance_id = ?");
                        $stmt->bind_param("i", $id);
                        if ($stmt->execute()) {
                            $success_count++;
                        } else {
                            $error_count++;
                        }
                    }
                    $message = ['type' => 'success', 'text' => "Marked $success_count records as Late. Failed: $error_count"];
                    break;
                    
                case 'export_selected':
                    // Export selected records to Excel
                    $ids = implode(',', array_map('intval', $selected_ids));
                    $_SESSION['export_ids'] = $ids;
                    header('Location: export_selected_attendance.php');
                    exit();
            }
        }
    }
}

// Get filter parameters
$campus_id = isset($_GET['campus_id']) ? intval($_GET['campus_id']) : ($user_campus_id ?? 0);
$activity_id = isset($_GET['activity_id']) ? intval($_GET['activity_id']) : 0;
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : date('Y-m-d', strtotime('-30 days'));
$date_to = isset($_GET['date_to']) ? $_GET['date_to'] : date('Y-m-d');
$student_number = isset($_GET['student_number']) ? trim($_GET['student_number']) : '';
$status = isset($_GET['status']) ? $_GET['status'] : '';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Build query
$query = "
    SELECT 
        a.attendance_id,
        a.student_id,
        a.activity_id,
        a.time_in,
        a.time_out,
        a.status,
        a.late_minutes,
        a.scanned_at,
        a.checked_by,
        a.updated_at,
        s.student_number,
        s.full_name,
        s.email,
        s.course_year,
        s.section,
        ac.activity_name,
        ac.activity_date,
        ac.activity_time,
        ac.venue,
        c.campus_name,
        c.campus_code,
        u.full_name as checked_by_name
    FROM attendance a
    LEFT JOIN students s ON a.student_id = s.student_id
    LEFT JOIN activities ac ON a.activity_id = ac.activity_id
    LEFT JOIN campuses c ON s.campus_id = c.campus_id
    LEFT JOIN users u ON a.checked_by = u.user_id
    WHERE 1=1
";

$params = [];
$types = '';

// Apply filters
if ($user_campus_id && $_SESSION['user_type'] === 'coordinator') {
    $query .= " AND s.campus_id = ?";
    $params[] = $user_campus_id;
    $types .= 'i';
} elseif ($campus_id > 0) {
    $query .= " AND s.campus_id = ?";
    $params[] = $campus_id;
    $types .= 'i';
}

if ($activity_id > 0) {
    $query .= " AND a.activity_id = ?";
    $params[] = $activity_id;
    $types .= 'i';
}

if (!empty($date_from)) {
    $query .= " AND DATE(a.scanned_at) >= ?";
    $params[] = $date_from;
    $types .= 's';
}

if (!empty($date_to)) {
    $query .= " AND DATE(a.scanned_at) <= ?";
    $params[] = $date_to;
    $types .= 's';
}

if (!empty($student_number)) {
    $query .= " AND s.student_number LIKE ?";
    $params[] = "%$student_number%";
    $types .= 's';
}

if (!empty($status)) {
    $query .= " AND a.status = ?";
    $params[] = $status;
    $types .= 's';
}

if (!empty($search)) {
    $query .= " AND (s.full_name LIKE ? OR s.student_number LIKE ? OR ac.activity_name LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $types .= 'sss';
}

$query .= " ORDER BY a.scanned_at DESC";

// Prepare and execute query
$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
$attendance_records = $result->fetch_all(MYSQLI_ASSOC);
$total_records = count($attendance_records);

// Get campuses for filter dropdown
$campuses_query = "SELECT campus_id, campus_name FROM campuses WHERE status = 'active' ORDER BY campus_name";
$campuses_result = $conn->query($campuses_query);
$campuses = $campuses_result->fetch_all(MYSQLI_ASSOC);

// Get activities for filter dropdown
$activities_query = "SELECT activity_id, activity_name FROM activities WHERE status IN ('upcoming', 'ongoing', 'completed') ORDER BY activity_date DESC";
$activities_result = $conn->query($activities_query);
$activities = $activities_result->fetch_all(MYSQLI_ASSOC);

// Get statistics
$stats_query = "
    SELECT 
        a.status,
        COUNT(*) as count,
        c.campus_name
    FROM attendance a
    LEFT JOIN students s ON a.student_id = s.student_id
    LEFT JOIN campuses c ON s.campus_id = c.campus_id
    WHERE 1=1
";

$stats_params = [];
$stats_types = '';

if ($user_campus_id && $_SESSION['user_type'] === 'coordinator') {
    $stats_query .= " AND s.campus_id = ?";
    $stats_params[] = $user_campus_id;
    $stats_types .= 'i';
} elseif ($campus_id > 0) {
    $stats_query .= " AND s.campus_id = ?";
    $stats_params[] = $campus_id;
    $stats_types .= 'i';
}

if (!empty($date_from)) {
    $stats_query .= " AND DATE(a.scanned_at) >= ?";
    $stats_params[] = $date_from;
    $stats_types .= 's';
}

if (!empty($date_to)) {
    $stats_query .= " AND DATE(a.scanned_at) <= ?";
    $stats_params[] = $date_to;
    $stats_types .= 's';
}

$stats_query .= " GROUP BY a.status, c.campus_name ORDER BY c.campus_name, a.status";

$stats_stmt = $conn->prepare($stats_query);
if (!empty($stats_params)) {
    $stats_stmt->bind_param($stats_types, ...$stats_params);
}
$stats_stmt->execute();
$stats_result = $stats_stmt->get_result();
$statistics = [];

while ($row = $stats_result->fetch_assoc()) {
    $statistics[$row['campus_name']][$row['status']] = $row['count'];
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Attendance | Multi-Campus Attendance</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/select/1.7.0/css/select.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.colVis.min.js"></script>
<script src="https://cdn.datatables.net/select/1.7.0/js/dataTables.select.min.js"></script>
<style>
    .status-badge {
        padding: 0.25rem 0.75rem;
        border-radius: 9999px;
        font-size: 0.75rem;
        font-weight: 600;
        display: inline-block;
    }
    .status-present { background-color: #d1fae5; color: #065f46; }
    .status-late { background-color: #fef3c7; color: #92400e; }
    .status-absent { background-color: #fee2e2; color: #991b1b; }
    .status-excused { background-color: #dbeafe; color: #1e40af; }
    .select-checkbox {
        width: 18px;
        height: 18px;
    }
    .dataTables_wrapper .dt-buttons button {
        border: 1px solid #d1d5db !important;
        border-radius: 0.375rem !important;
        background: white !important;
        color: #374151 !important;
        margin-right: 0.5rem !important;
        margin-bottom: 0.5rem !important;
    }
    .dataTables_wrapper .dt-buttons button:hover {
        background: #f9fafb !important;
    }
    table.dataTable tbody tr.selected {
        background-color: #e0f2fe !important;
    }
</style>
</head>
<body class="bg-gray-50 min-h-screen">

<!-- Navigation -->
<nav class="bg-gradient-to-r from-purple-800 to-indigo-900 text-white shadow-lg">
    <div class="container mx-auto px-4 py-3">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div class="flex items-center space-x-4">
                <a href="admin_dashboard.php" class="flex items-center hover:text-purple-200 transition-colors">
                    <i class="fas fa-arrow-left mr-2"></i> Back to Dashboard
                </a>
                <h1 class="text-xl font-bold">
                    <i class="fas fa-edit mr-2"></i> Manage Attendance
                </h1>
            </div>
            <div class="flex items-center space-x-4">
                <span class="text-sm">
                    <i class="fas fa-user mr-1"></i> <?php echo htmlspecialchars($user_name); ?>
                </span>
                <span class="text-sm text-purple-300">|</span>
                <a href="logout.php" class="text-sm hover:text-purple-200 transition-colors">
                    <i class="fas fa-sign-out-alt mr-1"></i> Logout
                </a>
            </div>
        </div>
    </div>
</nav>

<div class="container mx-auto px-4 py-8">
    <!-- Header -->
    <div class="mb-8">
        <h1 class="text-4xl font-bold text-gray-800 mb-2">Manage Attendance Records</h1>
        <p class="text-gray-600">Edit, delete, and manage attendance records across all campuses</p>
    </div>

    <!-- Quick Navigation -->
    <div class="flex flex-wrap gap-3 mb-8">
        <a href="scan_attendance.php" class="inline-flex items-center px-4 py-2.5 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
            <i class="fas fa-qrcode mr-2"></i> Scan Attendance
        </a>
        <a href="attendance_records.php" class="inline-flex items-center px-4 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
            <i class="fas fa-clipboard-list mr-2"></i> View Records
        </a>
        <a href="reports.php" class="inline-flex items-center px-4 py-2.5 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors">
            <i class="fas fa-chart-bar mr-2"></i> Reports
        </a>
        <a href="bulk_attendance.php" class="inline-flex items-center px-4 py-2.5 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
            <i class="fas fa-upload mr-2"></i> Bulk Upload
        </a>
    </div>

    <!-- Message Display -->
    <?php if (isset($message)): ?>
        <div class="mb-6 p-4 rounded-lg <?php echo $message['type'] === 'success' ? 'bg-green-50 text-green-800 border border-green-200' : 'bg-red-50 text-red-800 border border-red-200'; ?>">
            <div class="flex items-center">
                <i class="fas <?php echo $message['type'] === 'success' ? 'fa-check-circle' : 'fa-exclamation-triangle'; ?> mr-3"></i>
                <span><?php echo htmlspecialchars($message['text']); ?></span>
            </div>
        </div>
    <?php endif; ?>

    <!-- Statistics Cards -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div class="bg-white p-6 rounded-2xl shadow-lg border border-gray-200">
            <div class="flex items-center">
                <div class="w-14 h-14 bg-gradient-to-r from-gray-100 to-gray-200 rounded-full flex items-center justify-center mr-4">
                    <i class="fas fa-database text-gray-600 text-2xl"></i>
                </div>
                <div>
                    <p class="text-sm text-gray-500">Total Records</p>
                    <p class="text-3xl font-bold text-gray-800"><?php echo $total_records; ?></p>
                </div>
            </div>
        </div>
        
        <div class="bg-white p-6 rounded-2xl shadow-lg border border-green-200">
            <div class="flex items-center">
                <div class="w-14 h-14 bg-gradient-to-r from-green-100 to-emerald-100 rounded-full flex items-center justify-center mr-4">
                    <i class="fas fa-user-check text-green-600 text-2xl"></i>
                </div>
                <div>
                    <p class="text-sm text-gray-500">Present</p>
                    <?php
                    $present_count = 0;
                    foreach ($statistics as $campus_stats) {
                        $present_count += $campus_stats['Present'] ?? 0;
                    }
                    ?>
                    <p class="text-3xl font-bold text-gray-800"><?php echo $present_count; ?></p>
                </div>
            </div>
        </div>
        
        <div class="bg-white p-6 rounded-2xl shadow-lg border border-yellow-200">
            <div class="flex items-center">
                <div class="w-14 h-14 bg-gradient-to-r from-yellow-100 to-amber-100 rounded-full flex items-center justify-center mr-4">
                    <i class="fas fa-clock text-yellow-600 text-2xl"></i>
                </div>
                <div>
                    <p class="text-sm text-gray-500">Late</p>
                    <?php
                    $late_count = 0;
                    foreach ($statistics as $campus_stats) {
                        $late_count += $campus_stats['Late'] ?? 0;
                    }
                    ?>
                    <p class="text-3xl font-bold text-gray-800"><?php echo $late_count; ?></p>
                </div>
            </div>
        </div>
        
        <div class="bg-white p-6 rounded-2xl shadow-lg border border-red-200">
            <div class="flex items-center">
                <div class="w-14 h-14 bg-gradient-to-r from-red-100 to-rose-100 rounded-full flex items-center justify-center mr-4">
                    <i class="fas fa-user-times text-red-600 text-2xl"></i>
                </div>
                <div>
                    <p class="text-sm text-gray-500">Absent</p>
                    <?php
                    $absent_count = 0;
                    foreach ($statistics as $campus_stats) {
                        $absent_count += $campus_stats['Absent'] ?? 0;
                    }
                    ?>
                    <p class="text-3xl font-bold text-gray-800"><?php echo $absent_count; ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Filters Card -->
    <div class="bg-white rounded-2xl shadow-xl p-6 mb-8">
        <h2 class="text-2xl font-bold text-gray-800 mb-6 flex items-center">
            <i class="fas fa-filter text-purple-600 mr-3"></i> Filter Records
        </h2>
        
        <form method="GET" action="" class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <!-- Campus Filter -->
            <div>
                <label class="block mb-2 font-medium text-gray-700">Campus</label>
                <select name="campus_id" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors bg-white">
                    <option value="">All Campuses</option>
                    <?php foreach ($campuses as $campus): ?>
                        <option value="<?php echo $campus['campus_id']; ?>" <?php echo $campus_id == $campus['campus_id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($campus['campus_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <!-- Activity Filter -->
            <div>
                <label class="block mb-2 font-medium text-gray-700">Activity</label>
                <select name="activity_id" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors bg-white">
                    <option value="">All Activities</option>
                    <?php foreach ($activities as $activity): ?>
                        <option value="<?php echo $activity['activity_id']; ?>" <?php echo $activity_id == $activity['activity_id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($activity['activity_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <!-- Status Filter -->
            <div>
                <label class="block mb-2 font-medium text-gray-700">Status</label>
                <select name="status" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors bg-white">
                    <option value="">All Status</option>
                    <option value="Present" <?php echo $status == 'Present' ? 'selected' : ''; ?>>Present</option>
                    <option value="Late" <?php echo $status == 'Late' ? 'selected' : ''; ?>>Late</option>
                    <option value="Absent" <?php echo $status == 'Absent' ? 'selected' : ''; ?>>Absent</option>
                    <option value="Excused" <?php echo $status == 'Excused' ? 'selected' : ''; ?>>Excused</option>
                </select>
            </div>
            
            <!-- Search -->
            <div>
                <label class="block mb-2 font-medium text-gray-700">Search</label>
                <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" 
                       placeholder="Name, Student No, Activity"
                       class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors">
            </div>
            
            <!-- Date Range -->
            <div>
                <label class="block mb-2 font-medium text-gray-700">Date From</label>
                <input type="date" name="date_from" value="<?php echo htmlspecialchars($date_from); ?>" 
                       class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors">
            </div>
            
            <div>
                <label class="block mb-2 font-medium text-gray-700">Date To</label>
                <input type="date" name="date_to" value="<?php echo htmlspecialchars($date_to); ?>" 
                       class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors">
            </div>
            
            <!-- Student Number -->
            <div>
                <label class="block mb-2 font-medium text-gray-700">Student Number</label>
                <input type="text" name="student_number" value="<?php echo htmlspecialchars($student_number); ?>" 
                       placeholder="Student number"
                       class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors">
            </div>
            
            <!-- Filter Buttons -->
            <div class="flex items-end">
                <button type="submit" class="w-full px-6 py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-lg hover:from-purple-700 hover:to-indigo-700 transition-all font-semibold shadow-lg hover:shadow-xl flex items-center justify-center">
                    <i class="fas fa-search mr-2"></i> Apply Filters
                </button>
            </div>
        </form>
        
        <div class="mt-4 flex justify-end">
            <a href="manage_attendance.php" class="text-sm text-purple-600 hover:text-purple-800 flex items-center">
                <i class="fas fa-redo mr-1"></i> Reset Filters
            </a>
        </div>
    </div>

    <!-- Bulk Actions -->
    <div class="bg-white rounded-2xl shadow-xl p-6 mb-8">
        <h2 class="text-2xl font-bold text-gray-800 mb-6 flex items-center">
            <i class="fas fa-tasks text-purple-600 mr-3"></i> Bulk Actions
        </h2>
        
        <form id="bulkActionForm" method="POST" action="" class="space-y-4">
            <div class="flex flex-wrap gap-3 items-center">
                <span class="font-medium text-gray-700">With selected records:</span>
                
                <select name="bulk_action" class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors">
                    <option value="">Choose action...</option>
                    <option value="mark_present">Mark as Present</option>
                    <option value="mark_late">Mark as Late</option>
                    <option value="mark_absent">Mark as Absent</option>
                    <option value="delete">Delete Records</option>
                    <option value="export_selected">Export Selected</option>
                </select>
                
                <button type="button" onclick="selectAllRecords()" class="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors">
                    Select All
                </button>
                
                <button type="button" onclick="deselectAllRecords()" class="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors">
                    Deselect All
                </button>
                
                <button type="submit" class="px-6 py-2 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-lg hover:from-green-700 hover:to-emerald-700 transition-all font-semibold">
                    Apply Action
                </button>
            </div>
            
            <div class="text-sm text-gray-500 flex items-center">
                <i class="fas fa-info-circle mr-2"></i>
                <span>Select records using checkboxes in the table below, then choose an action</span>
            </div>
        </form>
    </div>

    <!-- Records Table -->
    <div class="bg-white rounded-2xl shadow-xl p-6">
        <div class="flex flex-col md:flex-row md:items-center justify-between mb-6">
            <h2 class="text-2xl font-bold text-gray-800 mb-4 md:mb-0 flex items-center">
                <i class="fas fa-table text-purple-600 mr-3"></i> Attendance Records
                <span class="ml-3 text-sm font-normal text-gray-500">(<?php echo $total_records; ?> records)</span>
            </h2>
            
            <div class="flex gap-3">
                <button onclick="refreshTable()" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center">
                    <i class="fas fa-sync-alt mr-2"></i> Refresh
                </button>
                <button onclick="exportAll()" class="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors flex items-center">
                    <i class="fas fa-file-excel mr-2"></i> Export All
                </button>
            </div>
        </div>
        
        <?php if ($total_records > 0): ?>
            <div class="overflow-x-auto rounded-xl border border-gray-200">
                <table id="attendanceTable" class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                <input type="checkbox" id="selectAll" class="select-checkbox" onchange="toggleSelectAll(this)">
                            </th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date & Time</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Student</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Activity</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Campus</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Time In</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Late (min)</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php foreach ($attendance_records as $record): ?>
                            <tr class="hover:bg-gray-50 transition-colors" data-id="<?php echo $record['attendance_id']; ?>">
                                <td class="px-4 py-4 whitespace-nowrap">
                                    <input type="checkbox" name="selected_records[]" value="<?php echo $record['attendance_id']; ?>" 
                                           class="record-checkbox select-checkbox">
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm font-medium text-gray-900">
                                        <?php echo date('M d, Y', strtotime($record['scanned_at'])); ?>
                                    </div>
                                    <div class="text-sm text-gray-500">
                                        <?php echo date('h:i A', strtotime($record['scanned_at'])); ?>
                                    </div>
                                </td>
                                <td class="px-6 py-4">
                                    <div class="flex items-center">
                                        <div class="ml-4">
                                            <div class="text-sm font-medium text-gray-900">
                                                <?php echo htmlspecialchars($record['full_name']); ?>
                                            </div>
                                            <div class="text-sm text-gray-500">
                                                <?php echo htmlspecialchars($record['student_number']); ?>
                                            </div>
                                            <?php if ($record['course_year'] || $record['section']): ?>
                                                <div class="text-xs text-gray-400">
                                                    <?php echo htmlspecialchars($record['course_year'] ?? ''); ?>
                                                    <?php echo $record['section'] ? ' - ' . htmlspecialchars($record['section']) : ''; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-4">
                                    <div class="text-sm font-medium text-gray-900">
                                        <?php echo htmlspecialchars($record['activity_name']); ?>
                                    </div>
                                    <div class="text-sm text-gray-500">
                                        <?php echo date('M d, Y', strtotime($record['activity_date'])); ?>
                                        at <?php echo date('h:i A', strtotime($record['activity_time'])); ?>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="px-2 py-1 text-xs font-medium bg-blue-100 text-blue-800 rounded-full">
                                        <?php echo htmlspecialchars($record['campus_name']); ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="status-badge <?php echo getStatusClass($record['status']); ?>">
                                        <?php echo $record['status']; ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                    <?php echo $record['time_in'] ? date('h:i A', strtotime($record['time_in'])) : 'N/A'; ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                    <?php echo $record['late_minutes'] > 0 ? $record['late_minutes'] . ' min' : '-'; ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                    <button onclick="quickEdit(<?php echo $record['attendance_id']; ?>, '<?php echo $record['status']; ?>')" 
                                            class="text-green-600 hover:text-green-900 mr-3" title="Quick Edit">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button onclick="viewDetails(<?php echo $record['attendance_id']; ?>)" 
                                            class="text-blue-600 hover:text-blue-900 mr-3" title="View Details">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button onclick="deleteSingleRecord(<?php echo $record['attendance_id']; ?>)" 
                                            class="text-red-600 hover:text-red-900" title="Delete">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Quick Edit Modal -->
            <div id="quickEditModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
                <div class="relative top-20 mx-auto p-5 border w-full max-w-md shadow-lg rounded-2xl bg-white">
                    <div class="flex justify-between items-center mb-6">
                        <h3 class="text-xl font-bold text-gray-800">Quick Edit Status</h3>
                        <button onclick="closeQuickEdit()" class="text-gray-400 hover:text-gray-600">
                            <i class="fas fa-times text-2xl"></i>
                        </button>
                    </div>
                    <form id="quickEditForm" class="space-y-4">
                        <input type="hidden" id="editRecordId" name="attendance_id">
                        
                        <div>
                            <label class="block mb-2 font-medium text-gray-700">Status</label>
                            <select id="editRecordStatus" name="status" 
                                    class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors">
                                <option value="Present">Present</option>
                                <option value="Late">Late</option>
                                <option value="Absent">Absent</option>
                                <option value="Excused">Excused</option>
                            </select>
                        </div>
                        
                        <div class="flex gap-3 mt-6">
                            <button type="submit" class="flex-1 px-4 py-2.5 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-lg hover:from-green-700 hover:to-emerald-700 transition-all font-semibold">
                                Save Changes
                            </button>
                            <button type="button" onclick="closeQuickEdit()" class="flex-1 px-4 py-2.5 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors">
                                Cancel
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
        <?php else: ?>
            <div class="text-center py-12">
                <div class="w-24 h-24 mx-auto mb-6 bg-gradient-to-r from-gray-100 to-gray-200 rounded-full flex items-center justify-center">
                    <i class="fas fa-clipboard-list text-gray-400 text-4xl"></i>
                </div>
                <h3 class="text-xl font-semibold text-gray-700 mb-2">No Records Found</h3>
                <p class="text-gray-500 mb-6">Try adjusting your filters or scan some attendance first.</p>
                <a href="scan_attendance.php" class="inline-flex items-center px-6 py-3 bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-lg hover:from-purple-700 hover:to-indigo-700 transition-all font-semibold shadow-lg hover:shadow-xl">
                    <i class="fas fa-qrcode mr-2"></i> Go to Scanner
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
// Initialize DataTable with checkboxes
$(document).ready(function() {
    $('#attendanceTable').DataTable({
        pageLength: 25,
        lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, "All"]],
        order: [[1, 'desc']], // Sort by date column (index 1)
        columnDefs: [
            {
                orderable: false,
                className: 'select-checkbox',
                targets: 0
            },
            {
                orderable: false,
                targets: [8] // Actions column
            }
        ],
        select: {
            style: 'multi',
            selector: 'td:first-child'
        },
        language: {
            search: "Search records:",
            lengthMenu: "Show _MENU_ records",
            info: "Showing _START_ to _END_ of _TOTAL_ records",
            paginate: {
                first: "First",
                last: "Last",
                next: "Next",
                previous: "Previous"
            }
        }
    });
});

// Select/Deselect all records
function toggleSelectAll(checkbox) {
    const checkboxes = document.querySelectorAll('.record-checkbox');
    checkboxes.forEach(cb => {
        cb.checked = checkbox.checked;
    });
}

function selectAllRecords() {
    document.querySelectorAll('.record-checkbox').forEach(cb => {
        cb.checked = true;
    });
    document.getElementById('selectAll').checked = true;
}

function deselectAllRecords() {
    document.querySelectorAll('.record-checkbox').forEach(cb => {
        cb.checked = false;
    });
    document.getElementById('selectAll').checked = false;
}

// Update bulk form with selected records
document.getElementById('bulkActionForm').addEventListener('submit', function(e) {
    const selectedCheckboxes = document.querySelectorAll('.record-checkbox:checked');
    if (selectedCheckboxes.length === 0) {
        e.preventDefault();
        alert('Please select at least one record to perform this action.');
        return;
    }
    
    const action = document.querySelector('select[name="bulk_action"]').value;
    if (!action) {
        e.preventDefault();
        alert('Please select an action to perform.');
        return;
    }
    
    if (action === 'delete') {
        if (!confirm(`Are you sure you want to delete ${selectedCheckboxes.length} record(s)? This action cannot be undone.`)) {
            e.preventDefault();
            return;
        }
    }
});

// Quick edit function
function quickEdit(recordId, currentStatus) {
    document.getElementById('editRecordId').value = recordId;
    document.getElementById('editRecordStatus').value = currentStatus;
    document.getElementById('quickEditModal').classList.remove('hidden');
}

// Close quick edit modal
function closeQuickEdit() {
    document.getElementById('quickEditModal').classList.add('hidden');
}

// Submit quick edit form
document.getElementById('quickEditForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    const data = Object.fromEntries(formData);
    
    fetch('update_attendance_status.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            alert('Status updated successfully!');
            closeQuickEdit();
            location.reload();
        } else {
            alert('Error updating status: ' + result.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error updating status');
    });
});

// View record details
function viewDetails(recordId) {
    window.location.href = `attendance_record_details.php?id=${recordId}`;
}

// Delete single record
function deleteSingleRecord(recordId) {
    if (confirm('Are you sure you want to delete this attendance record? This action cannot be undone.')) {
        fetch(`delete_attendance.php?id=${recordId}`, {
            method: 'DELETE'
        })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                alert('Record deleted successfully!');
                location.reload();
            } else {
                alert('Error deleting record: ' + result.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error deleting record');
        });
    }
}

// Refresh table
function refreshTable() {
    location.reload();
}

// Export all records
function exportAll() {
    // Get current filter parameters
    const params = new URLSearchParams(window.location.search);
    window.location.href = `export_attendance.php?${params.toString()}`;
}

// Get status class
function getStatusClass(status) {
    switch(status) {
        case 'Present': return 'status-present';
        case 'Late': return 'status-late';
        case 'Absent': return 'status-absent';
        case 'Excused': return 'status-excused';
        default: return 'bg-gray-100 text-gray-800';
    }
}
</script>
</body>
</html>

<?php
// Helper function for status classes
function getStatusClass($status) {
    switch($status) {
        case 'Present': return 'status-present';
        case 'Late': return 'status-late';
        case 'Absent': return 'status-absent';
        case 'Excused': return 'status-excused';
        default: return 'bg-gray-100 text-gray-800';
    }
}
?>