<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['user_type'], ['admin','coordinator'])) {
    header('Location: login.php');
    exit();
}

$user_name = $_SESSION['full_name'];
$user_type = $_SESSION['user_type'];
$user_campus_id = $_SESSION['campus_id'];
$user_id = $_SESSION['user_id'];

// Get campuses for dropdown
$campuses = [];
if ($user_type === 'admin') {
    $result = $conn->query("SELECT * FROM campuses WHERE status = 'active' ORDER BY campus_name");
} else {
    $stmt = $conn->prepare("SELECT * FROM campuses WHERE campus_id = ? AND status = 'active'");
    $stmt->bind_param("i", $user_campus_id);
    $stmt->execute();
    $result = $stmt->get_result();
}

while ($row = $result->fetch_assoc()) {
    $campuses[] = $row;
}

// Process form submission
$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $activity_name = trim($_POST['activity_name']);
    $description = trim($_POST['description']);
    $activity_date = $_POST['activity_date'];
    $activity_time = $_POST['activity_time'];
    $activity_type = $_POST['activity_type']; // whole_day or half_day
    $scan_frequency = $_POST['scan_frequency']; // 2x or 4x
    $venue = trim($_POST['venue']);
    $mandatory = isset($_POST['mandatory']) ? 1 : 0;
    
    // Fine amounts
    $checkin_fine = floatval($_POST['checkin_fine']);
    $checkout_fine = floatval($_POST['checkout_fine']);
    $late_checkin_fine = floatval($_POST['late_checkin_fine']);
    $late_checkout_fine = floatval($_POST['late_checkout_fine']);
    $absent_fine = floatval($_POST['absent_fine']);
    
    // Campus validation - FIXED SECTION
    if ($user_type === 'coordinator') {
        // Coordinators must use their assigned campus
        $campus_id = $user_campus_id;
    } else {
        // Admins must select a campus
        $campus_id = isset($_POST['campus_id']) ? intval($_POST['campus_id']) : 0;
        if ($campus_id <= 0) {
            $error = "Please select a valid campus.";
        }
    }
    
    // Additional validation
    if (empty($activity_name)) {
        $error = "Activity name is required.";
    } elseif (empty($activity_date)) {
        $error = "Activity date is required.";
    } elseif (empty($activity_time)) {
        $error = "Activity time is required.";
    }
    
    if (!$error) {
        // Handle photo upload
        $photo_path = null;
        if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
            $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
            $file_type = mime_content_type($_FILES['photo']['tmp_name']);
            $max_size = 5 * 1024 * 1024; // 5MB
            
            if (in_array($file_type, $allowed_types) && $_FILES['photo']['size'] <= $max_size) {
                // Create uploads directory if not exists
                if (!file_exists('uploads/activities')) {
                    mkdir('uploads/activities', 0777, true);
                }
                
                // Generate unique filename
                $extension = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
                $filename = 'activity_' . date('Ymd_His') . '_' . uniqid() . '.' . $extension;
                $photo_path = 'uploads/activities/' . $filename;
                
                if (!move_uploaded_file($_FILES['photo']['tmp_name'], $photo_path)) {
                    $photo_path = null;
                }
            }
        }
        
        try {
            // Insert new activity with fine settings
            $stmt = $conn->prepare("INSERT INTO activities 
                                   (activity_name, description, campus_id, activity_date, activity_time, 
                                    activity_type, scan_frequency, venue, mandatory, 
                                    checkin_fine, checkout_fine, late_checkin_fine, late_checkout_fine, absent_fine,
                                    photo, created_by, status) 
                                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'upcoming')");
            $stmt->bind_param("ssisssssidddddsi", 
                $activity_name, $description, $campus_id, $activity_date, $activity_time,
                $activity_type, $scan_frequency, $venue, $mandatory,
                $checkin_fine, $checkout_fine, $late_checkin_fine, $late_checkout_fine, $absent_fine,
                $photo_path, $user_id
            );
            
            if ($stmt->execute()) {
                $activity_id = $stmt->insert_id;
                
                // Auto-generate fines for students who are already marked absent (for past dates)
                if ($mandatory == 1 && strtotime($activity_date) < time()) {
                    generateFinesForAbsentees($conn, $activity_id, $campus_id, $absent_fine, $user_id);
                }
                
                $success = "Activity created successfully with fine settings!";
                
                // Redirect to activities page after 2 seconds
                header("refresh:2;url=activities.php");
            } else {
                $error = "Failed to create activity. Please try again.";
                if ($conn->errno === 1048) { // Column cannot be null error
                    $error .= " Campus selection is required.";
                }
            }
        } catch (Exception $e) {
            $error = "Error: " . $e->getMessage();
        }
    }
}

// Function to generate fines for absent students
function generateFinesForAbsentees($conn, $activity_id, $campus_id, $absent_fine, $user_id) {
    // Get all students for the campus
    if ($campus_id) {
        $query = "SELECT student_id FROM students WHERE campus_id = ? AND status = 'active'";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $campus_id);
    } else {
        $query = "SELECT student_id FROM students WHERE status = 'active'";
        $stmt = $conn->prepare($query);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($student = $result->fetch_assoc()) {
        // Check if student has attendance record
        $attendanceQuery = "SELECT attendance_id FROM attendance WHERE student_id = ? AND activity_id = ?";
        $attendanceStmt = $conn->prepare($attendanceQuery);
        $attendanceStmt->bind_param("ii", $student['student_id'], $activity_id);
        $attendanceStmt->execute();
        $attendanceResult = $attendanceStmt->get_result();
        
        // If no attendance record, create absent fine
        if ($attendanceResult->num_rows === 0) {
            $fineQuery = "INSERT INTO fines (student_id, activity_id, amount, reason, scan_type, status, created_by) 
                         VALUES (?, ?, ?, 'absence', 'absent', 'pending', ?)";
            $fineStmt = $conn->prepare($fineQuery);
            $fineStmt->bind_param("iidi", $student['student_id'], $activity_id, $absent_fine, $user_id);
            $fineStmt->execute();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Activity | Multi-Campus Attendance</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <style>
        .activity-type-btn, .scan-frequency-btn {
            transition: all 0.3s ease;
        }
        .activity-type-btn.active, .scan-frequency-btn.active {
            transform: translateY(-2px);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .fine-type-card {
            transition: all 0.3s ease;
            border: 2px solid transparent;
        }
        .fine-type-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
    <!-- Navigation -->
    <nav class="bg-gradient-to-r from-purple-800 to-indigo-900 text-white shadow-lg">
        <div class="container mx-auto px-4 py-3">
            <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div class="flex items-center space-x-4">
                    <a href="<?php echo $user_type === 'admin' ? 'admin_dashboard.php' : 'coordinator_dashboard.php'; ?>" 
                       class="flex items-center hover:text-purple-200 transition-colors">
                        <i class="fas fa-arrow-left mr-2"></i> Back to Dashboard
                    </a>
                    <h1 class="text-xl font-bold">
                        <i class="fas fa-calendar-plus mr-2"></i> Create Activity
                    </h1>
                </div>
                <div class="flex items-center space-x-4">
                    <span class="text-sm">
                        <i class="fas fa-user mr-1"></i> <?php echo htmlspecialchars($user_name); ?>
                    </span>
                    <a href="activities.php" class="text-sm bg-blue-600 hover:bg-blue-700 px-3 py-1 rounded-lg transition-colors">
                        <i class="fas fa-calendar-alt mr-1"></i> View Activities
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-8">
        <div class="max-w-6xl mx-auto">
            <!-- Header -->
            <div class="mb-8 text-center">
                <h1 class="text-4xl font-bold text-gray-800 mb-3">Create New Activity</h1>
                <p class="text-gray-600 max-w-2xl mx-auto">Schedule activities with customizable fine settings</p>
            </div>

            <?php if ($success): ?>
                <!-- Success Message -->
                <div class="mb-8 p-6 bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-2xl shadow-lg">
                    <div class="flex items-center">
                        <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mr-6">
                            <i class="fas fa-check-circle text-green-600 text-2xl"></i>
                        </div>
                        <div>
                            <h3 class="text-2xl font-bold text-green-800 mb-2">Activity Created!</h3>
                            <p class="text-green-700"><?php echo $success; ?></p>
                            <p class="text-green-600 text-sm mt-2">Redirecting to activities page...</p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <!-- Error Message -->
                <div class="mb-8 p-6 bg-gradient-to-r from-red-50 to-rose-50 border border-red-200 rounded-2xl shadow-lg">
                    <div class="flex items-center">
                        <div class="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mr-6">
                            <i class="fas fa-exclamation-triangle text-red-600 text-2xl"></i>
                        </div>
                        <div>
                            <h3 class="text-2xl font-bold text-red-800 mb-2">Creation Failed</h3>
                            <p class="text-red-700"><?php echo $error; ?></p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Activity Form -->
            <div class="bg-white rounded-2xl shadow-xl p-8">
                <form method="POST" action="" enctype="multipart/form-data" id="activityForm">
                    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                        <!-- Left Column -->
                        <div class="space-y-6">
                            <h2 class="text-2xl font-bold text-gray-800 border-b pb-3">
                                <i class="fas fa-info-circle text-blue-600 mr-2"></i> Activity Details
                            </h2>
                            
                            <!-- Activity Name -->
                            <div>
                                <label class="block mb-2 font-semibold text-gray-800">
                                    <i class="fas fa-calendar-check text-blue-600 mr-2"></i>Activity Name *
                                </label>
                                <input type="text" name="activity_name" required
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                                       placeholder="e.g., Monthly General Assembly">
                            </div>
                            
                            <!-- Description -->
                            <div>
                                <label class="block mb-2 font-semibold text-gray-800">
                                    <i class="fas fa-align-left text-blue-600 mr-2"></i>Description
                                </label>
                                <textarea name="description" rows="4"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                                       placeholder="Describe the activity..."></textarea>
                            </div>
                            
                            <!-- Activity Type -->
                            <div>
                                <label class="block mb-2 font-semibold text-gray-800">
                                    <i class="fas fa-calendar-day text-blue-600 mr-2"></i>Activity Duration *
                                </label>
                                <div class="grid grid-cols-2 gap-3">
                                    <input type="radio" name="activity_type" value="whole_day" id="whole_day" class="hidden" checked>
                                    <label for="whole_day" class="activity-type-btn cursor-pointer p-4 border-2 border-blue-200 rounded-lg text-center hover:border-blue-400 hover:bg-blue-50 transition-colors">
                                        <i class="fas fa-sun text-yellow-500 text-2xl mb-2"></i>
                                        <div class="font-semibold text-blue-800">Whole Day</div>
                                        <div class="text-sm text-blue-600 mt-1">8:00 AM - 5:00 PM</div>
                                    </label>
                                    
                                    <input type="radio" name="activity_type" value="half_day" id="half_day" class="hidden">
                                    <label for="half_day" class="activity-type-btn cursor-pointer p-4 border-2 border-green-200 rounded-lg text-center hover:border-green-400 hover:bg-green-50 transition-colors">
                                        <i class="fas fa-clock text-green-500 text-2xl mb-2"></i>
                                        <div class="font-semibold text-green-800">Half Day</div>
                                        <div class="text-sm text-green-600 mt-1">4 hours only</div>
                                    </label>
                                </div>
                            </div>
                            
                            <!-- Campus - FIXED: Required field -->
                            <div>
                                <label class="block mb-2 font-semibold text-gray-800">
                                    <i class="fas fa-school text-blue-600 mr-2"></i>Campus <?php echo ($user_type === 'admin') ? '*' : ''; ?>
                                </label>
                                <select name="campus_id" 
                                        <?php echo ($user_type === 'admin') ? 'required' : 'disabled'; ?>
                                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors bg-white">
                                    <?php if ($user_type === 'admin'): ?>
                                        <option value="">-- Select Campus --</option>
                                        <?php foreach ($campuses as $campus): ?>
                                        <option value="<?php echo $campus['campus_id']; ?>">
                                            <?php echo htmlspecialchars($campus['campus_name']); ?>
                                        </option>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <!-- For coordinators, show their assigned campus -->
                                        <?php if (!empty($campuses)): ?>
                                            <?php $coordinator_campus = $campuses[0]; ?>
                                            <option value="<?php echo $coordinator_campus['campus_id']; ?>" selected>
                                                <?php echo htmlspecialchars($coordinator_campus['campus_name']); ?>
                                            </option>
                                            <!-- Hidden input to submit campus_id for coordinators -->
                                            <input type="hidden" name="campus_id" value="<?php echo $coordinator_campus['campus_id']; ?>">
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </select>
                                <p class="text-sm text-gray-500 mt-1">
                                    <?php 
                                    if ($user_type === 'coordinator') {
                                        echo "Your assigned campus is automatically selected";
                                    } else {
                                        echo "Please select a campus for this activity";
                                    }
                                    ?>
                                </p>
                            </div>
                            
                            <!-- Photo Upload -->
                            <div>
                                <label class="block mb-2 font-semibold text-gray-800">
                                    <i class="fas fa-image text-blue-600 mr-2"></i>Activity Photo
                                </label>
                                <div class="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-blue-400 transition-colors">
                                    <input type="file" name="photo" accept="image/*" 
                                           class="hidden" id="activityPhoto">
                                    <div id="photoPreview" class="mb-3">
                                        <div class="w-32 h-32 mx-auto bg-gray-100 rounded-lg flex items-center justify-center text-gray-400">
                                            <i class="fas fa-camera text-3xl"></i>
                                        </div>
                                    </div>
                                    <button type="button" onclick="document.getElementById('activityPhoto').click()"
                                            class="px-4 py-2 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition-colors">
                                        <i class="fas fa-upload mr-2"></i> Upload Photo
                                    </button>
                                    <p class="text-sm text-gray-500 mt-2">Optional: JPG, PNG, GIF, WEBP (Max 5MB)</p>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Right Column -->
                        <div class="space-y-6">
                            <h2 class="text-2xl font-bold text-gray-800 border-b pb-3">
                                <i class="fas fa-cogs text-green-600 mr-2"></i> Schedule & Settings
                            </h2>
                            
                            <!-- Date & Time -->
                            <div class="grid grid-cols-2 gap-4">
                                <div>
                                    <label class="block mb-2 font-semibold text-gray-800">
                                        <i class="fas fa-calendar-day text-green-600 mr-2"></i>Date *
                                    </label>
                                    <input type="date" name="activity_date" required
                                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-colors"
                                           id="activityDate">
                                </div>
                                <div>
                                    <label class="block mb-2 font-semibold text-gray-800">
                                        <i class="fas fa-clock text-green-600 mr-2"></i>Start Time *
                                    </label>
                                    <input type="time" name="activity_time" required
                                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-colors"
                                           id="activityTime">
                                </div>
                            </div>
                            
                            <!-- Scan Frequency -->
                            <div>
                                <label class="block mb-2 font-semibold text-gray-800">
                                    <i class="fas fa-qrcode text-green-600 mr-2"></i>Scan Frequency *
                                </label>
                                <div class="grid grid-cols-2 gap-3">
                                    <input type="radio" name="scan_frequency" value="2x" id="scan_2x" class="hidden" checked>
                                    <label for="scan_2x" class="scan-frequency-btn cursor-pointer p-4 border-2 border-purple-200 rounded-lg text-center hover:border-purple-400 hover:bg-purple-50 transition-colors">
                                        <i class="fas fa-exchange-alt text-purple-500 text-2xl mb-2"></i>
                                        <div class="font-semibold text-purple-800">2X Scan</div>
                                        <div class="text-sm text-purple-600 mt-1">IN & OUT only</div>
                                    </label>
                                    
                                    <input type="radio" name="scan_frequency" value="4x" id="scan_4x" class="hidden">
                                    <label for="scan_4x" class="scan-frequency-btn cursor-pointer p-4 border-2 border-indigo-200 rounded-lg text-center hover:border-indigo-400 hover:bg-indigo-50 transition-colors">
                                        <i class="fas fa-retweet text-indigo-500 text-2xl mb-2"></i>
                                        <div class="font-semibold text-indigo-800">4X Scan</div>
                                        <div class="text-sm text-indigo-600 mt-1">AM IN/OUT & PM IN/OUT</div>
                                    </label>
                                </div>
                                <p class="text-sm text-gray-500 mt-2" id="scanInfo">
                                    Students will scan QR code twice: Check-in and Check-out
                                </p>
                            </div>
                            
                            <!-- Venue -->
                            <div>
                                <label class="block mb-2 font-semibold text-gray-800">
                                    <i class="fas fa-map-marker-alt text-green-600 mr-2"></i>Venue
                                </label>
                                <input type="text" name="venue"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-colors"
                                       placeholder="e.g., Main Auditorium">
                            </div>
                            
                            <!-- Mandatory & Fines -->
                            <div class="p-6 bg-gradient-to-r from-gray-50 to-gray-100 rounded-xl border border-gray-200">
                                <div class="flex items-center mb-4">
                                    <input type="checkbox" name="mandatory" id="mandatory" value="1" 
                                           class="w-5 h-5 text-red-600 rounded focus:ring-red-500" checked
                                           onchange="toggleFinesSection()">
                                    <label for="mandatory" class="ml-3 font-semibold text-gray-800 cursor-pointer">
                                        <i class="fas fa-exclamation-circle text-red-600 mr-2"></i>Mandatory Activity
                                    </label>
                                </div>
                                <p class="text-sm text-gray-600 mb-6">
                                    Mandatory activities require attendance. Set fine amounts for different violations.
                                </p>
                                
                                <div id="finesSection" class="space-y-4">
                                    <!-- Check-in Fine -->
                                    <div class="fine-type-card p-4 border-2 border-blue-200 bg-blue-50 rounded-lg">
                                        <div class="flex items-center justify-between mb-2">
                                            <div class="flex items-center">
                                                <i class="fas fa-sign-in-alt text-blue-600 text-xl mr-3"></i>
                                                <div>
                                                    <h4 class="font-semibold text-blue-800">Missing Check-in</h4>
                                                    <p class="text-sm text-blue-600">Student didn't check in</p>
                                                </div>
                                            </div>
                                            <div class="relative w-32">
                                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                                    <span class="text-gray-500">₱</span>
                                                </div>
                                                <input type="number" name="checkin_fine" step="0.01" min="0" value="50.00"
                                                       class="w-full pl-8 pr-4 py-2 border border-blue-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white">
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- Check-out Fine -->
                                    <div class="fine-type-card p-4 border-2 border-purple-200 bg-purple-50 rounded-lg">
                                        <div class="flex items-center justify-between mb-2">
                                            <div class="flex items-center">
                                                <i class="fas fa-sign-out-alt text-purple-600 text-xl mr-3"></i>
                                                <div>
                                                    <h4 class="font-semibold text-purple-800">Missing Check-out</h4>
                                                    <p class="text-sm text-purple-600">Student didn't check out</p>
                                                </div>
                                            </div>
                                            <div class="relative w-32">
                                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                                    <span class="text-gray-500">₱</span>
                                                </div>
                                                <input type="number" name="checkout_fine" step="0.01" min="0" value="50.00"
                                                       class="w-full pl-8 pr-4 py-2 border border-purple-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 bg-white">
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- Late Check-in Fine -->
                                    <div class="fine-type-card p-4 border-2 border-yellow-200 bg-yellow-50 rounded-lg">
                                        <div class="flex items-center justify-between mb-2">
                                            <div class="flex items-center">
                                                <i class="fas fa-clock text-yellow-600 text-xl mr-3"></i>
                                                <div>
                                                    <h4 class="font-semibold text-yellow-800">Late Check-in</h4>
                                                    <p class="text-sm text-yellow-600">Check-in after 15 minutes</p>
                                                </div>
                                            </div>
                                            <div class="relative w-32">
                                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                                    <span class="text-gray-500">₱</span>
                                                </div>
                                                <input type="number" name="late_checkin_fine" step="0.01" min="0" value="25.00"
                                                       class="w-full pl-8 pr-4 py-2 border border-yellow-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 bg-white">
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- Late Check-out Fine -->
                                    <div class="fine-type-card p-4 border-2 border-orange-200 bg-orange-50 rounded-lg">
                                        <div class="flex items-center justify-between mb-2">
                                            <div class="flex items-center">
                                                <i class="fas fa-running text-orange-600 text-xl mr-3"></i>
                                                <div>
                                                    <h4 class="font-semibold text-orange-800">Early Check-out</h4>
                                                    <p class="text-sm text-orange-600">Left before activity ends</p>
                                                </div>
                                            </div>
                                            <div class="relative w-32">
                                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                                    <span class="text-gray-500">₱</span>
                                                </div>
                                                <input type="number" name="late_checkout_fine" step="0.01" min="0" value="25.00"
                                                       class="w-full pl-8 pr-4 py-2 border border-orange-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 bg-white">
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- Absent Fine -->
                                    <div class="fine-type-card p-4 border-2 border-red-200 bg-red-50 rounded-lg">
                                        <div class="flex items-center justify-between mb-2">
                                            <div class="flex items-center">
                                                <i class="fas fa-user-times text-red-600 text-xl mr-3"></i>
                                                <div>
                                                    <h4 class="font-semibold text-red-800">Completely Absent</h4>
                                                    <p class="text-sm text-red-600">Didn't attend at all</p>
                                                </div>
                                            </div>
                                            <div class="relative w-32">
                                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                                    <span class="text-gray-500">₱</span>
                                                </div>
                                                <input type="number" name="absent_fine" step="0.01" min="0" value="100.00"
                                                       class="w-full pl-8 pr-4 py-2 border border-red-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 bg-white">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Auto-Generate Fines -->
                            <div class="p-4 bg-gradient-to-r from-yellow-50 to-amber-50 rounded-xl border border-yellow-200">
                                <h4 class="font-semibold text-yellow-800 mb-2 flex items-center">
                                    <i class="fas fa-robot text-yellow-600 mr-2"></i> Auto-Fines Generation
                                </h4>
                                <ul class="text-sm text-yellow-700 space-y-1">
                                    <li class="flex items-start">
                                        <i class="fas fa-check mt-1 mr-2"></i>
                                        <span>For past dates, system automatically generates fines for absent students</span>
                                    </li>
                                    <li class="flex items-start">
                                        <i class="fas fa-check mt-1 mr-2"></i>
                                        <span>Missing scans (check-in/out) automatically generate appropriate fines</span>
                                    </li>
                                    <li class="flex items-start">
                                        <i class="fas fa-check mt-1 mr-2"></i>
                                        <span>Late arrivals (15+ minutes) are automatically detected</span>
                                    </li>
                                </ul>
                            </div>
                            
                            <!-- Submit Button -->
                            <div class="pt-4">
                                <button type="submit"
                                        class="w-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white py-3.5 rounded-lg font-semibold hover:from-purple-700 hover:to-indigo-700 transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-0.5">
                                    <i class="fas fa-calendar-plus mr-2"></i> Create Activity with Fine Settings
                                </button>
                                <p class="text-sm text-gray-500 text-center mt-3">
                                    * Required fields. Activity will be immediately available for attendance.
                                </p>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            
            <!-- Instructions -->
            <div class="mt-8 bg-gradient-to-r from-blue-50 to-cyan-50 p-6 rounded-2xl border border-blue-200">
                <h3 class="text-xl font-bold text-blue-800 mb-4 flex items-center">
                    <i class="fas fa-lightbulb text-blue-600 mr-3"></i> Fine Settings Guide
                </h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <h4 class="font-semibold text-blue-700 mb-2">Fine Types Explained:</h4>
                        <ul class="text-sm text-gray-600 space-y-2">
                            <li class="flex items-start">
                                <i class="fas fa-sign-in-alt text-blue-500 mt-1 mr-2"></i>
                                <div>
                                    <span class="font-medium">Missing Check-in:</span>
                                    <p class="text-gray-500">Student scanned check-out but never checked in</p>
                                </div>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-sign-out-alt text-purple-500 mt-1 mr-2"></i>
                                <div>
                                    <span class="font-medium">Missing Check-out:</span>
                                    <p class="text-gray-500">Student checked in but never checked out</p>
                                </div>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-clock text-yellow-500 mt-1 mr-2"></i>
                                <div>
                                    <span class="font-medium">Late Check-in:</span>
                                    <p class="text-gray-500">Student checked in 15+ minutes after activity start</p>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div>
                        <h4 class="font-semibold text-blue-700 mb-2">Fine Calculation:</h4>
                        <ul class="text-sm text-gray-600 space-y-2">
                            <li class="flex items-start">
                                <i class="fas fa-running text-orange-500 mt-1 mr-2"></i>
                                <div>
                                    <span class="font-medium">Early Check-out:</span>
                                    <p class="text-gray-500">Student checked out before activity ended</p>
                                </div>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-user-times text-red-500 mt-1 mr-2"></i>
                                <div>
                                    <span class="font-medium">Completely Absent:</span>
                                    <p class="text-gray-500">Student didn't scan at all (highest fine)</p>
                                </div>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-calculator text-green-500 mt-1 mr-2"></i>
                                <div>
                                    <span class="font-medium">Automatic Calculation:</span>
                                    <p class="text-gray-500">System calculates appropriate fines automatically</p>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Initialize date picker
        flatpickr("#activityDate", {
            minDate: "today",
            dateFormat: "Y-m-d",
        });
        
        // Initialize time picker
        flatpickr("#activityTime", {
            enableTime: true,
            noCalendar: true,
            dateFormat: "H:i",
            time_24hr: true,
            defaultHour: 8,
            defaultMinute: 0,
        });
        
        // Photo preview
        document.getElementById('activityPhoto').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const preview = document.getElementById('photoPreview');
                    preview.innerHTML = `
                        <img src="${e.target.result}" 
                             alt="Preview" 
                             class="w-32 h-32 mx-auto object-cover rounded-lg shadow">
                    `;
                }
                reader.readAsDataURL(file);
            }
        });
        
        // Toggle fines section
        function toggleFinesSection() {
            const mandatory = document.getElementById('mandatory');
            const finesSection = document.getElementById('finesSection');
            if (mandatory.checked) {
                finesSection.style.display = 'block';
            } else {
                finesSection.style.display = 'none';
            }
        }
        
        // Activity type selection styling
        document.querySelectorAll('.activity-type-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                document.querySelectorAll('.activity-type-btn').forEach(b => {
                    b.classList.remove('active', 'border-blue-400', 'bg-blue-50', 'border-green-400', 'bg-green-50');
                });
                this.classList.add('active');
                if (this.htmlFor === 'whole_day') {
                    this.classList.add('border-blue-400', 'bg-blue-50');
                } else {
                    this.classList.add('border-green-400', 'bg-green-50');
                }
            });
        });
        
        // Scan frequency selection styling
        document.querySelectorAll('.scan-frequency-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                document.querySelectorAll('.scan-frequency-btn').forEach(b => {
                    b.classList.remove('active', 'border-purple-400', 'bg-purple-50', 'border-indigo-400', 'bg-indigo-50');
                });
                this.classList.add('active');
                if (this.htmlFor === 'scan_2x') {
                    this.classList.add('border-purple-400', 'bg-purple-50');
                    document.getElementById('scanInfo').textContent = 'Students will scan QR code twice: Check-in and Check-out';
                } else {
                    this.classList.add('border-indigo-400', 'bg-indigo-50');
                    document.getElementById('scanInfo').textContent = 'Students will scan QR code four times: AM Check-in/out & PM Check-in/out';
                }
            });
        });
        
        // Update time based on activity type
        document.querySelectorAll('input[name="activity_type"]').forEach(radio => {
            radio.addEventListener('change', function() {
                const timeInput = document.getElementById('activityTime');
                if (this.value === 'whole_day') {
                    timeInput.value = '08:00';
                } else {
                    timeInput.value = '08:00'; // Or any default for half day
                }
            });
        });
        
        // Update scan frequency based on activity type
        document.querySelectorAll('input[name="activity_type"]').forEach(radio => {
            radio.addEventListener('change', function() {
                const scan2x = document.getElementById('scan_2x');
                const scan4x = document.getElementById('scan_4x');
                
                if (this.value === 'half_day') {
                    // For half day, default to 2x and disable 4x
                    scan2x.checked = true;
                    scan4x.disabled = true;
                    document.querySelector('label[for="scan_4x"]').classList.add('opacity-50', 'cursor-not-allowed');
                    
                    // Trigger click event for 2x
                    document.querySelector('label[for="scan_2x"]').click();
                } else {
                    // For whole day, enable both options
                    scan4x.disabled = false;
                    document.querySelector('label[for="scan_4x"]').classList.remove('opacity-50', 'cursor-not-allowed');
                }
            });
        });
        
        // Initialize
        document.addEventListener('DOMContentLoaded', function() {
            toggleFinesSection();
            
            // Set default active states
            document.querySelector('label[for="whole_day"]').click();
            document.querySelector('label[for="scan_2x"]').click();
            
            // Set default date to tomorrow
            const tomorrow = new Date();
            tomorrow.setDate(tomorrow.getDate() + 1);
            const formattedDate = tomorrow.toISOString().split('T')[0];
            document.getElementById('activityDate').value = formattedDate;
            
            // Set default time to 8:00 AM
            document.getElementById('activityTime').value = '08:00';
        });
        
        // Form validation
        document.getElementById('activityForm').addEventListener('submit', function(e) {
            const date = document.getElementById('activityDate').value;
            const time = document.getElementById('activityTime').value;
            
            if (!date || !time) {
                e.preventDefault();
                alert('Please select both date and time for the activity.');
                return false;
            }
            
            // Validate scan frequency for half day
            const activityType = document.querySelector('input[name="activity_type"]:checked').value;
            const scanFrequency = document.querySelector('input[name="scan_frequency"]:checked').value;
            
            if (activityType === 'half_day' && scanFrequency === '4x') {
                e.preventDefault();
                alert('Half day activities can only use 2X scan frequency (IN & OUT only).');
                return false;
            }
            
            // Validate fine amounts if mandatory
            const mandatory = document.getElementById('mandatory').checked;
            if (mandatory) {
                const checkinFine = parseFloat(document.querySelector('input[name="checkin_fine"]').value) || 0;
                const checkoutFine = parseFloat(document.querySelector('input[name="checkout_fine"]').value) || 0;
                const absentFine = parseFloat(document.querySelector('input[name="absent_fine"]').value) || 0;
                
                if (checkinFine < 0 || checkoutFine < 0 || absentFine < 0) {
                    e.preventDefault();
                    alert('Fine amounts cannot be negative.');
                    return false;
                }
                
                if (absentFine < (checkinFine + checkoutFine)) {
                    const confirmProceed = confirm('Absent fine should be equal to or greater than the sum of check-in and check-out fines. Do you want to continue anyway?');
                    if (!confirmProceed) {
                        e.preventDefault();
                        return false;
                    }
                }
            }
            
            // Show loading state
            const submitBtn = this.querySelector('button[type="submit"]');
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Creating Activity...';
            submitBtn.disabled = true;
        });
    </script>
</body>
</html>