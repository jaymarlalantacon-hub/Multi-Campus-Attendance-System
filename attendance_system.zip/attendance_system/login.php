<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once 'db.php';

// Check database connection
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    header('Location: ' . ($_SESSION['user_type'] === 'admin' ? 'admin_dashboard.php' : 'coordinator_dashboard.php'));
    exit();
}

$error = '';

// Handle Login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    
    // Input validation
    if (empty($username) || empty($password)) {
        $error = 'Please enter both username and password!';
    } else {
        // Check user with status verification (CRITICAL FIX)
        // Assuming status field has values: 'active', 'inactive', 'pending', etc.
        $stmt = $conn->prepare("SELECT * FROM users WHERE username = ? AND status = 'active'");
        
        // If status uses numeric values (1 for active, 0 for inactive), use:
        // $stmt = $conn->prepare("SELECT * FROM users WHERE username = ? AND status = 1");
        
        $stmt->bind_param("s", $username);
        
        if ($stmt->execute()) {
            $result = $stmt->get_result();
            
            if ($result->num_rows === 1) {
                $user = $result->fetch_assoc();
                
                // Debug output (remove in production)
                // echo "<pre>User data: ";
                // print_r($user);
                // echo "</pre>";
                
                // Verify password
                if (password_verify($password, $user['password'])) {
                    // Set session variables
                    $_SESSION['user_id'] = $user['user_id'];
                    $_SESSION['full_name'] = $user['full_name'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['user_type'] = $user['user_type'];
                    $_SESSION['campus_id'] = $user['campus_id'];
                    $_SESSION['email'] = $user['email'];
                    
                    // Update last login
                    $update = $conn->prepare("UPDATE users SET last_login = NOW() WHERE user_id = ?");
                    $update->bind_param("i", $user['user_id']);
                    $update->execute();
                    $update->close();
                    
                    // Debug: Check where we're redirecting
                    // echo "Redirecting to: " . ($user['user_type'] === 'admin' ? 'admin_dashboard.php' : 'coordinator_dashboard.php');
                    // exit();
                    
                    // Redirect based on user type
                    if ($user['user_type'] === 'admin') {
                        header('Location: admin_dashboard.php');
                    } else if ($user['user_type'] === 'coordinator') {
                        header('Location: coordinator_dashboard.php');
                    } else {
                        // Default redirect for other user types
                        header('Location: dashboard.php');
                    }
                    exit();
                } else {
                    $error = 'Invalid username or password!';
                }
            } else {
                $error = 'Account not found or inactive! Please contact administrator.';
            }
        } else {
            $error = 'Database error! Please try again.';
            // Log the error for debugging
            error_log("Login SQL Error: " . $stmt->error);
        }
        
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Multi-Campus Attendance System</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .login-box {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        .shake {
            animation: shake 0.5s ease-in-out;
        }
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-10px); }
            75% { transform: translateX(10px); }
        }
    </style>
    <script>
        // Add shake animation to error message
        document.addEventListener('DOMContentLoaded', function() {
            const errorDiv = document.querySelector('.error-message');
            if (errorDiv) {
                errorDiv.classList.add('shake');
            }
        });
    </script>
</head>
<body class="flex items-center justify-center p-4">
    <div class="w-full max-w-md">
        <div class="login-box rounded-2xl shadow-2xl overflow-hidden">
            <!-- Header -->
            <div class="bg-gradient-to-r from-purple-800 to-indigo-900 text-white p-8 text-center">
                <div class="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-graduation-cap text-3xl"></i>
                </div>
                <h1 class="text-3xl font-bold mb-2">Multi-Campus Attendance System</h1>
                <p class="text-purple-200 text-sm">Track attendance and fines across SKSU 7 campuses</p>
            </div>
            
            <!-- Login Form -->
            <div class="p-8">
                <?php if ($error): ?>
                <div class="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center text-red-700 error-message">
                    <i class="fas fa-exclamation-circle mr-3"></i>
                    <span><?php echo htmlspecialchars($error); ?></span>
                </div>
                <?php endif; ?>
                
                <form method="POST" action="" id="loginForm">
                    <div class="space-y-6">
                        <div>
                            <label class="block text-gray-700 mb-2 font-medium">
                                <i class="fas fa-user text-purple-600 mr-2"></i>Username
                            </label>
                            <input type="text" name="username" required
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition duration-200"
                                   placeholder="Enter username"
                                   value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>"
                                   autocomplete="username">
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 mb-2 font-medium">
                                <i class="fas fa-lock text-purple-600 mr-2"></i>Password
                            </label>
                            <div class="relative">
                                <input type="password" name="password" required
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition duration-200"
                                       placeholder="Enter password"
                                       autocomplete="current-password"
                                       id="passwordField">
                                <button type="button" onclick="togglePassword()" class="absolute right-3 top-3 text-gray-500 hover:text-gray-700">
                                    <i class="fas fa-eye" id="toggleIcon"></i>
                                </button>
                            </div>
                        </div>
                        
                        <div class="flex items-center justify-between">
                            <div class="flex items-center">
                                <input type="checkbox" id="remember" name="remember" class="h-4 w-4 text-purple-600 rounded">
                                <label for="remember" class="ml-2 text-gray-700">Remember me</label>
                            </div>
                            <a href="forgot_password.php" class="text-purple-600 hover:text-purple-800 text-sm font-medium">
                                Forgot Password?
                            </a>
                        </div>
                        
                        <button type="submit"
                                class="w-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white py-3 rounded-lg font-semibold hover:from-purple-700 hover:to-indigo-700 transition duration-200 transform hover:-translate-y-0.5 shadow-lg hover:shadow-xl">
                            <i class="fas fa-sign-in-alt mr-2"></i>Login
                        </button>
                        
                        <div class="text-center pt-4 border-t border-gray-200">
                            <p class="text-gray-600">
                                Don't have an account?
                                <a href="register.php" class="text-purple-600 font-semibold hover:text-purple-800 ml-1 transition duration-200">
                                    Register here
                                </a>
                            </p>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Debug Info (Remove in production) -->
        <div class="mt-4 text-center text-white/80 text-sm">
            <p>System Status: <span class="font-semibold">Operational</span></p>
            <p class="mt-1">Need help? Contact: admin@attendance-system.edu</p>
        </div>
    </div>
    
    <script>
        // Toggle password visibility
        function togglePassword() {
            const passwordField = document.getElementById('passwordField');
            const toggleIcon = document.getElementById('toggleIcon');
            
            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                toggleIcon.classList.remove('fa-eye');
                toggleIcon.classList.add('fa-eye-slash');
            } else {
                passwordField.type = 'password';
                toggleIcon.classList.remove('fa-eye-slash');
                toggleIcon.classList.add('fa-eye');
            }
        }
        
        // Form validation
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            const username = this.username.value.trim();
            const password = this.password.value.trim();
            
            if (!username || !password) {
                e.preventDefault();
                alert('Please fill in both username and password fields.');
                return false;
            }
        });
    </script>
</body>
</html>