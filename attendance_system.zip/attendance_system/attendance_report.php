<?php
session_start();
require_once 'db.php';

// Check if coordinator
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'coordinator' || !$_SESSION['campus_id']) {
    header('Location: login.php');
    exit();
}

$campus_id = $_SESSION['campus_id'];
$report_type = isset($_GET['type']) ? $_GET['type'] : 'daily';

// Set headers for CSV download
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=attendance_report_' . date('Y-m-d') . '.csv');

// Create output stream
$output = fopen('php://output', 'w');

// Add UTF-8 BOM for Excel compatibility
fputs($output, $bom = (chr(0xEF) . chr(0xBB) . chr(0xBF)));

// Daily Report Export
if ($report_type == 'daily') {
    $date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');
    $activity_id = isset($_GET['activity_id']) ? intval($_GET['activity_id']) : 0;
    
    $query = "SELECT att.*, 
                     s.full_name as student_name, 
                     s.student_number,
                     s.email,
                     s.phone,
                     a.activity_name,
                     a.activity_date,
                     a.venue,
                     DATE(att.scanned_at) as attendance_date,
                     TIME(att.scanned_at) as attendance_time
              FROM attendance att
              JOIN students s ON att.student_id = s.student_id
              JOIN activities a ON att.activity_id = a.activity_id
              WHERE s.campus_id = ? 
              AND DATE(att.scanned_at) = ?
              " . ($activity_id > 0 ? " AND att.activity_id = ?" : "") . "
              ORDER BY att.scanned_at DESC";
    
    $stmt = $conn->prepare($query);
    if ($activity_id > 0) {
        $stmt->bind_param("isi", $campus_id, $date, $activity_id);
    } else {
        $stmt->bind_param("is", $campus_id, $date);
    }
    $stmt->execute();
    $records = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    
    // Write CSV header
    fputcsv($output, [
        'Date',
        'Student Number',
        'Student Name',
        'Email',
        'Phone',
        'Activity Name',
        'Activity Date',
        'Venue',
        'Attendance Time',
        'Status',
        'Notes'
    ]);
    
    // Write data rows
    foreach ($records as $record) {
        fputcsv($output, [
            $record['attendance_date'],
            $record['student_number'],
            $record['student_name'],
            $record['email'],
            $record['phone'],
            $record['activity_name'],
            $record['activity_date'],
            $record['venue'],
            $record['attendance_time'],
            $record['status'],
            $record['notes'] ?? ''
        ]);
    }
}

// Monthly Report Export
elseif ($report_type == 'monthly') {
    $month = isset($_GET['month']) ? $_GET['month'] : date('Y-m');
    $month_start = date('Y-m-01', strtotime($month));
    $month_end = date('Y-m-t', strtotime($month));
    
    $query = "SELECT 
              DATE(att.scanned_at) as date,
              COUNT(*) as total,
              SUM(CASE WHEN att.status = 'Present' THEN 1 ELSE 0 END) as present,
              SUM(CASE WHEN att.status = 'Late' THEN 1 ELSE 0 END) as late,
              SUM(CASE WHEN att.status = 'Absent' THEN 1 ELSE 0 END) as absent,
              SUM(CASE WHEN att.status = 'Excused' THEN 1 ELSE 0 END) as excused
              FROM attendance att
              JOIN students s ON att.student_id = s.student_id
              WHERE s.campus_id = ? 
              AND DATE(att.scanned_at) BETWEEN ? AND ?
              GROUP BY DATE(att.scanned_at)
              ORDER BY DATE(att.scanned_at) DESC";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("iss", $campus_id, $month_start, $month_end);
    $stmt->execute();
    $records = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    
    // Write CSV header
    fputcsv($output, [
        'Date',
        'Day',
        'Present',
        'Late',
        'Absent',
        'Excused',
        'Total',
        'Attendance Rate'
    ]);
    
    // Write data rows
    foreach ($records as $record) {
        $attendance_rate = $record['total'] > 0 ? round((($record['present'] + $record['late']) / $record['total']) * 100, 1) : 0;
        
        fputcsv($output, [
            $record['date'],
            date('l', strtotime($record['date'])),
            $record['present'],
            $record['late'],
            $record['absent'],
            $record['excused'],
            $record['total'],
            $attendance_rate . '%'
        ]);
    }
}

// Activity Report Export
elseif ($report_type == 'activity') {
    $activity_id = isset($_GET['activity_id']) ? intval($_GET['activity_id']) : 0;
    
    if ($activity_id > 0) {
        $query = "SELECT att.*, 
                         s.full_name as student_name, 
                         s.student_number,
                         s.email,
                         s.phone,
                         a.activity_name,
                         a.activity_date,
                         a.venue,
                         DATE(att.scanned_at) as attendance_date,
                         TIME(att.scanned_at) as attendance_time
                  FROM attendance att
                  JOIN students s ON att.student_id = s.student_id
                  JOIN activities a ON att.activity_id = a.activity_id
                  WHERE a.activity_id = ? 
                  AND s.campus_id = ?
                  ORDER BY att.scanned_at DESC";
        
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ii", $activity_id, $campus_id);
        $stmt->execute();
        $records = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        
        // Get activity details
        $activity_query = "SELECT * FROM activities WHERE activity_id = ? AND campus_id = ?";
        $stmt = $conn->prepare($activity_query);
        $stmt->bind_param("ii", $activity_id, $campus_id);
        $stmt->execute();
        $activity = $stmt->get_result()->fetch_assoc();
        
        // Write CSV header with activity info
        fputcsv($output, ['Activity Report']);
        fputcsv($output, ['Activity Name:', $activity['activity_name'] ?? '']);
        fputcsv($output, ['Activity Date:', $activity['activity_date'] ?? '']);
        fputcsv($output, ['Venue:', $activity['venue'] ?? '']);
        fputcsv($output, []); // Empty row
        
        // Write attendance header
        fputcsv($output, [
            'Student Number',
            'Student Name',
            'Email',
            'Phone',
            'Attendance Time',
            'Status',
            'Notes'
        ]);
        
        // Write data rows
        foreach ($records as $record) {
            fputcsv($output, [
                $record['student_number'],
                $record['student_name'],
                $record['email'],
                $record['phone'],
                $record['attendance_time'],
                $record['status'],
                $record['notes'] ?? ''
            ]);
        }
    }
}

fclose($output);
exit();