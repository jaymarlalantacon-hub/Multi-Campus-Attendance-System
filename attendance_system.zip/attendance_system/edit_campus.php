<?php
session_start();
require_once 'db.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['full_name'];
$user_type = $_SESSION['user_type'];

// Check if campus ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: campuses.php');
    exit();
}

$campus_id = intval($_GET['id']);

// Get campus details
$campus_query = "SELECT * FROM campuses WHERE campus_id = ?";
$campus_stmt = $conn->prepare($campus_query);
$campus_stmt->bind_param("i", $campus_id);
$campus_stmt->execute();
$campus_result = $campus_stmt->get_result();
$campus = $campus_result->fetch_assoc();

// Check if campus exists
if (!$campus) {
    header('Location: campuses.php');
    exit();
}

// Handle form submission
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'update_campus') {
        $campus_name = trim($_POST['campus_name']);
        $campus_code = trim($_POST['campus_code']);
        $address = trim($_POST['address']);
        $contact_person = trim($_POST['contact_person']);
        $contact_number = trim($_POST['contact_number']);
        $fines_per_absence = floatval($_POST['fines_per_absence']);
        $status = $_POST['status'];
        
        // Validation
        $errors = [];
        
        if (empty($campus_name)) {
            $errors[] = "Campus name is required.";
        }
        
        if (empty($campus_code)) {
            $errors[] = "Campus code is required.";
        }
        
        if (empty($address)) {
            $errors[] = "Address is required.";
        }
        
        if ($fines_per_absence < 0) {
            $errors[] = "Fines per absence cannot be negative.";
        }
        
        // Check if campus code already exists (excluding current campus)
        $check_code = $conn->prepare("SELECT campus_id FROM campuses WHERE campus_code = ? AND campus_id != ?");
        $check_code->bind_param("si", $campus_code, $campus_id);
        $check_code->execute();
        if ($check_code->get_result()->num_rows > 0) {
            $errors[] = "Campus code already exists.";
        }
        
        if (empty($errors)) {
            // Update campus
            $update_query = "UPDATE campuses SET 
                            campus_name = ?, 
                            campus_code = ?, 
                            address = ?, 
                            contact_person = ?, 
                            contact_number = ?, 
                            fines_per_absence = ?, 
                            status = ?,
                            updated_at = NOW()
                            WHERE campus_id = ?";
            
            $update_stmt = $conn->prepare($update_query);
            $update_stmt->bind_param("sssssdsi", 
                $campus_name, 
                $campus_code, 
                $address, 
                $contact_person, 
                $contact_number,
                $fines_per_absence,
                $status,
                $campus_id
            );
            
            if ($update_stmt->execute()) {
                $success_message = "Campus updated successfully!";
                
                // Update campus data for display
                $campus['campus_name'] = $campus_name;
                $campus['campus_code'] = $campus_code;
                $campus['address'] = $address;
                $campus['contact_person'] = $contact_person;
                $campus['contact_number'] = $contact_number;
                $campus['fines_per_absence'] = $fines_per_absence;
                $campus['status'] = $status;
                
                // Log the action
                $log_query = "INSERT INTO admin_logs (admin_id, action, details) 
                              VALUES (?, 'updated_campus', 'Updated campus: " . $conn->real_escape_string($campus_name) . "')";
                $log_stmt = $conn->prepare($log_query);
                $log_stmt->bind_param("i", $user_id);
                $log_stmt->execute();
                
            } else {
                $error_message = "Failed to update campus. Please try again.";
            }
        } else {
            $error_message = implode("<br>", $errors);
        }
        
    } elseif ($action === 'delete_campus') {
        // Check if campus has users
        $check_users = $conn->prepare("SELECT COUNT(*) as count FROM users WHERE campus_id = ?");
        $check_users->bind_param("i", $campus_id);
        $check_users->execute();
        $user_count = $check_users->get_result()->fetch_assoc()['count'];
        
        // Check if campus has activities
        $check_activities = $conn->prepare("SELECT COUNT(*) as count FROM activities WHERE campus_id = ?");
        $check_activities->bind_param("i", $campus_id);
        $check_activities->execute();
        $activity_count = $check_activities->get_result()->fetch_assoc()['count'];
        
        if ($user_count > 0 || $activity_count > 0) {
            $error_message = "Cannot delete campus that has users or activities. Please deactivate it instead.";
        } else {
            // Delete the campus
            $delete_query = "DELETE FROM campuses WHERE campus_id = ?";
            $delete_stmt = $conn->prepare($delete_query);
            $delete_stmt->bind_param("i", $campus_id);
            
            if ($delete_stmt->execute()) {
                header("Location: campuses.php?deleted=1");
                exit();
            } else {
                $error_message = "Failed to delete campus.";
            }
        }
    } elseif ($action === 'duplicate_campus') {
        // Duplicate the campus with a new code
        $new_campus_code = trim($_POST['new_campus_code']);
        
        if (empty($new_campus_code)) {
            $error_message = "Please enter a new campus code.";
        } else {
            // Check if new campus code already exists
            $check_new_code = $conn->prepare("SELECT campus_id FROM campuses WHERE campus_code = ?");
            $check_new_code->bind_param("s", $new_campus_code);
            $check_new_code->execute();
            if ($check_new_code->get_result()->num_rows > 0) {
                $error_message = "Campus code already exists.";
            } else {
                // Duplicate campus
                $duplicate_query = "INSERT INTO campuses (campus_name, campus_code, address, contact_person, contact_number, fines_per_absence, status, created_at) 
                                   VALUES (CONCAT(?, ' (Copy)'), ?, ?, ?, ?, ?, 'active', NOW())";
                $duplicate_stmt = $conn->prepare($duplicate_query);
                $duplicate_stmt->bind_param("sssssd", 
                    $campus['campus_name'],
                    $new_campus_code,
                    $campus['address'],
                    $campus['contact_person'],
                    $campus['contact_number'],
                    $campus['fines_per_absence']
                );
                
                if ($duplicate_stmt->execute()) {
                    $new_campus_id = $conn->insert_id;
                    $success_message = "Campus duplicated successfully! New Campus ID: #" . $new_campus_id;
                    
                    // Log the action
                    $log_query = "INSERT INTO admin_logs (admin_id, action, details) 
                                  VALUES (?, 'duplicated_campus', 'Duplicated campus from " . $campus['campus_code'] . " to " . $new_campus_code . "')";
                    $log_stmt = $conn->prepare($log_query);
                    $log_stmt->bind_param("i", $user_id);
                    $log_stmt->execute();
                    
                } else {
                    $error_message = "Failed to duplicate campus.";
                }
            }
        }
    }
}

// Get campus statistics
$stats = [
    'total_users' => 0,
    'total_activities' => 0,
    'active_users' => 0,
    'upcoming_activities' => 0
];

// Get user statistics for this campus
$user_stats_query = "SELECT 
                    COUNT(*) as total_users,
                    COUNT(CASE WHEN status = 'active' THEN 1 END) as active_users
                    FROM users 
                    WHERE campus_id = ?";
$user_stats_stmt = $conn->prepare($user_stats_query);
$user_stats_stmt->bind_param("i", $campus_id);
$user_stats_stmt->execute();
$user_stats_result = $user_stats_stmt->get_result();
if ($user_stats = $user_stats_result->fetch_assoc()) {
    $stats['total_users'] = $user_stats['total_users'];
    $stats['active_users'] = $user_stats['active_users'];
}

// Get activity statistics for this campus
$activity_stats_query = "SELECT 
                        COUNT(*) as total_activities,
                        COUNT(CASE WHEN status = 'upcoming' THEN 1 END) as upcoming_activities
                        FROM activities 
                        WHERE campus_id = ?";
$activity_stats_stmt = $conn->prepare($activity_stats_query);
$activity_stats_stmt->bind_param("i", $campus_id);
$activity_stats_stmt->execute();
$activity_stats_result = $activity_stats_stmt->get_result();
if ($activity_stats = $activity_stats_result->fetch_assoc()) {
    $stats['total_activities'] = $activity_stats['total_activities'];
    $stats['upcoming_activities'] = $activity_stats['upcoming_activities'];
}

// Get recent activities for this campus
$recent_activities = [];
$activities_query = "SELECT activity_id, activity_name, activity_date, status 
                     FROM activities 
                     WHERE campus_id = ? 
                     ORDER BY activity_date DESC 
                     LIMIT 5";
$activities_stmt = $conn->prepare($activities_query);
$activities_stmt->bind_param("i", $campus_id);
$activities_stmt->execute();
$activities_result = $activities_stmt->get_result();
while ($activity = $activities_result->fetch_assoc()) {
    $recent_activities[] = $activity;
}

// Campus status options
$status_options = [
    'active' => 'Active',
    'inactive' => 'Inactive',
    'maintenance' => 'Under Maintenance'
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Campus | Multi-Campus Attendance System</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #3b82f6;
            --secondary-color: #8b5cf6;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
        }
        
        body {
            font-family: 'Segoe UI', 'Inter', system-ui, -apple-system, sans-serif;
            background: linear-gradient(135deg, #f6f9fc 0%, #edf2f7 100%);
            min-height: 100vh;
        }
        
        .card {
            background: white;
            border-radius: 1rem;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            border: 1px solid #e5e7eb;
        }
        
        .card:hover {
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
        }
        
        .campus-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            border-radius: 1rem;
            box-shadow: 0 10px 30px rgba(59, 130, 246, 0.3);
        }
        
        .btn {
            padding: 0.75rem 1.5rem;
            border-radius: 0.75rem;
            font-weight: 600;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(59, 130, 246, 0.3);
        }
        
        .btn-success {
            background: var(--success-color);
            color: white;
        }
        
        .btn-danger {
            background: var(--danger-color);
            color: white;
        }
        
        .btn-warning {
            background: var(--warning-color);
            color: white;
        }
        
        .badge {
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        
        .badge-active { background: #d1fae5; color: #065f46; }
        .badge-inactive { background: #e5e7eb; color: #374151; }
        .badge-maintenance { background: #fef3c7; color: #92400e; }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }
        
        .modal.active {
            display: flex;
        }
        
        .modal-content {
            background: white;
            border-radius: 1rem;
            width: 90%;
            max-width: 500px;
            max-height: 90vh;
            overflow-y: auto;
        }
        
        .input-group {
            margin-bottom: 1rem;
        }
        
        .input-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: #374151;
        }
        
        .input-group .label-required::after {
            content: " *";
            color: #ef4444;
        }
        
        .input-group input,
        .input-group select,
        .input-group textarea {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 1px solid #d1d5db;
            border-radius: 0.5rem;
            font-size: 1rem;
            transition: all 0.3s ease;
        }
        
        .input-group input:focus,
        .input-group select:focus,
        .input-group textarea:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        
        .tab {
            padding: 0.75rem 1.5rem;
            border-radius: 0.75rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .tab.active {
            background: var(--primary-color);
            color: white;
        }
        
        .tab:hover:not(.active) {
            background: #f3f4f6;
        }
        
        .tab-pane {
            display: none;
        }
        
        .tab-pane.active {
            display: block;
        }
        
        .stat-card {
            background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
            border-radius: 0.75rem;
            padding: 1.25rem;
            text-align: center;
        }
        
        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            line-height: 1;
        }
        
        .stat-label {
            color: #6b7280;
            font-size: 0.875rem;
            margin-top: 0.5rem;
        }
        
        .activity-item {
            border-left: 4px solid var(--primary-color);
            padding-left: 1rem;
            transition: all 0.3s ease;
        }
        
        .activity-item:hover {
            background: #f9fafb;
            transform: translateX(5px);
        }
        
        .amount-display {
            font-size: 2rem;
            font-weight: 700;
            color: #ef4444;
        }
    </style>
</head>
<body class="min-h-screen p-4 md:p-8">
    <!-- Header -->
    <div class="max-w-6xl mx-auto">
        <div class="campus-header p-6 mb-8">
            <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <div class="flex items-center gap-3 mb-2">
                        <h1 class="text-3xl font-bold">Edit Campus</h1>
                        <span class="badge badge-<?php echo $campus['status']; ?>">
                            <?php echo $status_options[$campus['status']] ?? ucfirst($campus['status']); ?>
                        </span>
                    </div>
                    <div class="flex flex-wrap items-center gap-2">
                        <span class="text-white/90">
                            <i class="fas fa-university mr-2"></i>
                            <?php echo htmlspecialchars($campus['campus_name']); ?>
                        </span>
                        <span class="text-white/90">
                            <i class="fas fa-hashtag mr-2"></i>
                            Code: <?php echo htmlspecialchars($campus['campus_code']); ?>
                        </span>
                        <?php if ($campus['created_at']): ?>
                        <span class="text-white/90">
                            <i class="fas fa-calendar-alt mr-2"></i>
                            Created: <?php echo date('M d, Y', strtotime($campus['created_at'])); ?>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="flex flex-wrap gap-2">
                    <a href="campuses.php" class="btn bg-white/20 hover:bg-white/30 text-white">
                        <i class="fas fa-arrow-left"></i> Back to Campuses
                    </a>
                    <a href="campus_users.php?id=<?php echo $campus_id; ?>" class="btn bg-green-500/80 hover:bg-green-600/80 text-white">
                        <i class="fas fa-users mr-2"></i> View Users
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Messages -->
        <?php if ($success_message): ?>
        <div class="mb-6 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-xl flex items-center">
            <i class="fas fa-check-circle mr-3 text-green-600"></i>
            <span><?php echo $success_message; ?></span>
        </div>
        <?php endif; ?>
        
        <?php if ($error_message): ?>
        <div class="mb-6 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl flex items-center">
            <i class="fas fa-exclamation-circle mr-3 text-red-600"></i>
            <span><?php echo $error_message; ?></span>
        </div>
        <?php endif; ?>
        
        <!-- Campus Statistics -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div class="stat-card">
                <div class="stat-value text-blue-600"><?php echo number_format($stats['total_users']); ?></div>
                <div class="stat-label">Total Users</div>
            </div>
            <div class="stat-card">
                <div class="stat-value text-green-600"><?php echo number_format($stats['active_users']); ?></div>
                <div class="stat-label">Active Users</div>
            </div>
            <div class="stat-card">
                <div class="stat-value text-yellow-600"><?php echo number_format($stats['total_activities']); ?></div>
                <div class="stat-label">Total Activities</div>
            </div>
            <div class="stat-card">
                <div class="stat-value text-purple-600"><?php echo number_format($stats['upcoming_activities']); ?></div>
                <div class="stat-label">Upcoming Activities</div>
            </div>
        </div>
        
        <!-- Fine Rate Display -->
        <div class="mb-8">
            <div class="card p-6">
                <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                        <h3 class="text-lg font-bold text-gray-800">Fine Rate for Absences</h3>
                        <p class="text-gray-600">This rate applies to all mandatory activities in this campus</p>
                    </div>
                    <div class="amount-display">₱<?php echo number_format($campus['fines_per_absence'], 2); ?></div>
                </div>
            </div>
        </div>
        
        <!-- Tabs -->
        <div class="flex flex-wrap gap-2 mb-8">
            <button id="tab-details" class="tab active" onclick="showTab('details')">
                <i class="fas fa-edit mr-2"></i> Edit Details
            </button>
            <button id="tab-activities" class="tab" onclick="showTab('activities')">
                <i class="fas fa-calendar-alt mr-2"></i> Recent Activities
            </button>
            <button id="tab-actions" class="tab" onclick="showTab('actions')">
                <i class="fas fa-cog mr-2"></i> Actions
            </button>
        </div>
        
        <!-- Tab Content -->
        <div class="tab-content">
            <!-- Edit Details Tab -->
            <div id="details-content" class="tab-pane active">
                <div class="card p-6">
                    <h2 class="text-xl font-bold text-gray-800 mb-6 flex items-center">
                        <i class="fas fa-edit text-blue-600 mr-2"></i> Campus Details
                    </h2>
                    
                    <form method="POST" action="" class="space-y-6">
                        <input type="hidden" name="action" value="update_campus">
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <!-- Left Column -->
                            <div>
                                <h3 class="font-bold text-gray-800 mb-4 border-b pb-2">Basic Information</h3>
                                
                                <div class="input-group">
                                    <label for="campus_name" class="label-required">Campus Name</label>
                                    <input type="text" 
                                           id="campus_name" 
                                           name="campus_name" 
                                           value="<?php echo htmlspecialchars($campus['campus_name']); ?>"
                                           required
                                           placeholder="e.g., Main Campus, South Campus"
                                           class="w-full">
                                </div>
                                
                                <div class="input-group">
                                    <label for="campus_code" class="label-required">Campus Code</label>
                                    <input type="text" 
                                           id="campus_code" 
                                           name="campus_code" 
                                           value="<?php echo htmlspecialchars($campus['campus_code']); ?>"
                                           required
                                           placeholder="e.g., MC, SC"
                                           class="w-full">
                                    <p class="text-sm text-gray-500 mt-1">Short code used for identification</p>
                                </div>
                                
                                <div class="input-group">
                                    <label for="fines_per_absence" class="label-required">Fines per Absence (₱)</label>
                                    <input type="number" 
                                           id="fines_per_absence" 
                                           name="fines_per_absence" 
                                           value="<?php echo number_format($campus['fines_per_absence'], 2); ?>"
                                           step="0.01"
                                           min="0"
                                           required
                                           class="w-full">
                                    <p class="text-sm text-gray-500 mt-1">Default fine amount for mandatory activity absences</p>
                                </div>
                            </div>
                            
                            <!-- Right Column -->
                            <div>
                                <h3 class="font-bold text-gray-800 mb-4 border-b pb-2">Contact Information</h3>
                                
                                <div class="input-group">
                                    <label for="address" class="label-required">Address</label>
                                    <textarea id="address" 
                                              name="address" 
                                              rows="3"
                                              required
                                              class="w-full"><?php echo htmlspecialchars($campus['address']); ?></textarea>
                                </div>
                                
                                <div class="input-group">
                                    <label for="contact_person">Contact Person</label>
                                    <input type="text" 
                                           id="contact_person" 
                                           name="contact_person" 
                                           value="<?php echo htmlspecialchars($campus['contact_person']); ?>"
                                           placeholder="e.g., Campus Director"
                                           class="w-full">
                                </div>
                                
                                <div class="input-group">
                                    <label for="contact_number">Contact Number</label>
                                    <input type="tel" 
                                           id="contact_number" 
                                           name="contact_number" 
                                           value="<?php echo htmlspecialchars($campus['contact_number']); ?>"
                                           placeholder="e.g., 09123456789"
                                           class="w-full">
                                </div>
                                
                                <div class="input-group">
                                    <label for="status" class="label-required">Status</label>
                                    <select id="status" name="status" required class="w-full">
                                        <?php foreach ($status_options as $value => $label): ?>
                                        <option value="<?php echo $value; ?>" 
                                                <?php echo $campus['status'] === $value ? 'selected' : ''; ?>>
                                            <?php echo $label; ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="pt-6 border-t border-gray-200 flex justify-end gap-3">
                            <a href="campuses.php" class="btn bg-gray-100 text-gray-700 hover:bg-gray-200">
                                Cancel
                            </a>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save mr-2"></i> Save Changes
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Activities Tab -->
            <div id="activities-content" class="tab-pane hidden">
                <div class="card p-6">
                    <div class="flex justify-between items-center mb-6">
                        <h2 class="text-xl font-bold text-gray-800 flex items-center">
                            <i class="fas fa-calendar-alt text-blue-600 mr-2"></i> Recent Activities
                        </h2>
                        <a href="activities.php?campus=<?php echo $campus_id; ?>" class="btn bg-blue-500 hover:bg-blue-600 text-white">
                            <i class="fas fa-eye mr-2"></i> View All Activities
                        </a>
                    </div>
                    
                    <?php if (count($recent_activities) > 0): ?>
                        <div class="space-y-4">
                            <?php foreach ($recent_activities as $activity): ?>
                            <div class="activity-item">
                                <div class="flex justify-between items-start">
                                    <div>
                                        <a href="edit_activity.php?id=<?php echo $activity['activity_id']; ?>" 
                                           class="font-medium text-gray-900 hover:text-blue-600">
                                            <?php echo htmlspecialchars($activity['activity_name']); ?>
                                        </a>
                                        <div class="text-sm text-gray-600 mt-1">
                                            <i class="fas fa-calendar-day mr-1"></i>
                                            <?php echo date('F j, Y', strtotime($activity['activity_date'])); ?>
                                        </div>
                                    </div>
                                    <div>
                                        <?php
                                        $activity_status_badge = [
                                            'upcoming' => 'bg-blue-100 text-blue-800',
                                            'ongoing' => 'bg-yellow-100 text-yellow-800',
                                            'completed' => 'bg-green-100 text-green-800',
                                            'cancelled' => 'bg-red-100 text-red-800'
                                        ];
                                        ?>
                                        <span class="px-3 py-1 text-xs rounded-full <?php echo $activity_status_badge[$activity['status']] ?? 'bg-gray-100 text-gray-800'; ?>">
                                            <?php echo ucfirst($activity['status']); ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-8 text-gray-500">
                            <i class="fas fa-calendar-times text-4xl mb-4 text-gray-300"></i>
                            <p>No activities found for this campus.</p>
                            <a href="add_activity.php?campus=<?php echo $campus_id; ?>" class="btn btn-primary mt-4">
                                <i class="fas fa-plus mr-2"></i> Add New Activity
                            </a>
                        </div>
                    <?php endif; ?>
                    
                    <!-- Quick Stats -->
                    <div class="mt-8 pt-6 border-t border-gray-200">
                        <h3 class="font-bold text-gray-800 mb-4">Activity Statistics</h3>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div class="bg-blue-50 p-4 rounded-lg">
                                <div class="text-2xl font-bold text-blue-700"><?php echo $stats['total_activities']; ?></div>
                                <div class="text-sm text-blue-600">Total Activities</div>
                            </div>
                            <div class="bg-green-50 p-4 rounded-lg">
                                <div class="text-2xl font-bold text-green-700"><?php echo $stats['upcoming_activities']; ?></div>
                                <div class="text-sm text-green-600">Upcoming</div>
                            </div>
                            <div class="bg-gray-50 p-4 rounded-lg">
                                <div class="text-2xl font-bold text-gray-700">
                                    <?php echo $stats['total_activities'] - $stats['upcoming_activities']; ?>
                                </div>
                                <div class="text-sm text-gray-600">Past Activities</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Actions Tab -->
            <div id="actions-content" class="tab-pane hidden">
                <div class="card p-6">
                    <h2 class="text-xl font-bold text-gray-800 mb-6 flex items-center">
                        <i class="fas fa-cog text-gray-600 mr-2"></i> Additional Actions
                    </h2>
                    
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <!-- Duplicate Campus -->
                        <div class="border border-gray-200 rounded-xl p-5">
                            <div class="flex items-center mb-4">
                                <div class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-4">
                                    <i class="fas fa-copy text-blue-600"></i>
                                </div>
                                <h3 class="font-bold text-gray-800">Duplicate Campus</h3>
                            </div>
                            <p class="text-gray-600 text-sm mb-4">
                                Create a copy of this campus with a new code. Useful for creating similar campuses.
                            </p>
                            <form method="POST" action="" class="space-y-3">
                                <input type="hidden" name="action" value="duplicate_campus">
                                <div class="input-group">
                                    <label for="new_campus_code">New Campus Code</label>
                                    <input type="text" 
                                           id="new_campus_code" 
                                           name="new_campus_code" 
                                           required
                                           placeholder="e.g., NC"
                                           class="w-full">
                                </div>
                                <button type="submit" class="btn bg-blue-500 hover:bg-blue-600 text-white w-full">
                                    <i class="fas fa-copy mr-2"></i> Duplicate Campus
                                </button>
                            </form>
                        </div>
                        
                        <!-- Deactivate/Activate -->
                        <div class="border border-gray-200 rounded-xl p-5">
                            <div class="flex items-center mb-4">
                                <div class="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center mr-4">
                                    <i class="fas fa-power-off text-yellow-600"></i>
                                </div>
                                <h3 class="font-bold text-gray-800">
                                    <?php echo $campus['status'] === 'active' ? 'Deactivate' : 'Activate'; ?> Campus
                                </h3>
                            </div>
                            <p class="text-gray-600 text-sm mb-4">
                                <?php if ($campus['status'] === 'active'): ?>
                                Deactivate this campus. Users won't be able to select it for new activities.
                                <?php else: ?>
                                Activate this campus. It will be available for selection again.
                                <?php endif; ?>
                            </p>
                            <form method="POST" action="">
                                <input type="hidden" name="action" value="update_campus">
                                <input type="hidden" name="campus_name" value="<?php echo htmlspecialchars($campus['campus_name']); ?>">
                                <input type="hidden" name="campus_code" value="<?php echo htmlspecialchars($campus['campus_code']); ?>">
                                <input type="hidden" name="address" value="<?php echo htmlspecialchars($campus['address']); ?>">
                                <input type="hidden" name="contact_person" value="<?php echo htmlspecialchars($campus['contact_person']); ?>">
                                <input type="hidden" name="contact_number" value="<?php echo htmlspecialchars($campus['contact_number']); ?>">
                                <input type="hidden" name="fines_per_absence" value="<?php echo $campus['fines_per_absence']; ?>">
                                <input type="hidden" name="status" value="<?php echo $campus['status'] === 'active' ? 'inactive' : 'active'; ?>">
                                
                                <button type="submit" 
                                        class="btn bg-yellow-500 hover:bg-yellow-600 text-white w-full"
                                        onclick="return confirm('Are you sure you want to <?php echo $campus['status'] === 'active' ? 'deactivate' : 'activate'; ?> this campus?')">
                                    <i class="fas fa-power-off mr-2"></i>
                                    <?php echo $campus['status'] === 'active' ? 'Deactivate' : 'Activate'; ?> Campus
                                </button>
                            </form>
                        </div>
                        
                        <!-- Delete Campus -->
                        <div class="border border-gray-200 rounded-xl p-5">
                            <div class="flex items-center mb-4">
                                <div class="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center mr-4">
                                    <i class="fas fa-trash text-red-600"></i>
                                </div>
                                <h3 class="font-bold text-gray-800">Delete Campus</h3>
                            </div>
                            <p class="text-gray-600 text-sm mb-4">
                                <span class="text-red-600 font-bold">Warning:</span> This will permanently delete the campus record.
                                Cannot delete if campus has users or activities.
                            </p>
                            <form method="POST" action="" id="deleteForm">
                                <input type="hidden" name="action" value="delete_campus">
                                <button type="button" 
                                        onclick="confirmDelete()"
                                        class="btn bg-red-500 hover:bg-red-600 text-white w-full">
                                    <i class="fas fa-trash mr-2"></i> Delete Campus
                                </button>
                            </form>
                        </div>
                    </div>
                    
                    <!-- Danger Zone -->
                    <div class="mt-8 border border-red-200 rounded-xl p-5">
                        <h3 class="font-bold text-red-800 mb-4 flex items-center">
                            <i class="fas fa-exclamation-triangle mr-2"></i> Danger Zone
                        </h3>
                        
                        <div class="space-y-4">
                            <!-- Reset All Fines -->
                            <div class="border border-red-100 rounded-lg p-4">
                                <h4 class="font-bold text-red-700 mb-2">Reset All Campus Fines</h4>
                                <p class="text-sm text-red-600 mb-3">
                                    Reset all fine amounts for this campus to the current default rate.
                                </p>
                                <button type="button" 
                                        onclick="resetCampusFines()"
                                        class="btn bg-red-100 text-red-700 hover:bg-red-200">
                                    <i class="fas fa-redo-alt mr-2"></i> Reset Campus Fines
                                </button>
                            </div>
                            
                            <!-- Export Campus Data -->
                            <div class="border border-blue-100 rounded-lg p-4">
                                <h4 class="font-bold text-blue-700 mb-2">Export Campus Data</h4>
                                <p class="text-sm text-blue-600 mb-3">
                                    Export all campus data including users, activities, and attendance records.
                                </p>
                                <a href="export_campus.php?id=<?php echo $campus_id; ?>" 
                                   class="btn bg-blue-100 text-blue-700 hover:bg-blue-200">
                                    <i class="fas fa-download mr-2"></i> Export Campus Data
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Reset Fines Confirmation Modal -->
    <div id="resetFinesModal" class="modal">
        <div class="modal-content">
            <div class="p-6">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-lg font-bold text-gray-800">Reset Campus Fines</h3>
                    <button onclick="closeModal('resetFinesModal')" class="text-gray-500 hover:text-gray-700">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                
                <div class="mb-6 bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                    <div class="flex items-center">
                        <i class="fas fa-exclamation-triangle text-yellow-600 mr-3"></i>
                        <div>
                            <p class="text-yellow-800 font-medium">Warning: This action will affect all activities in this campus.</p>
                            <p class="text-yellow-700 text-sm mt-1">
                                All activity fine amounts will be reset to: ₱<?php echo number_format($campus['fines_per_absence'], 2); ?>
                            </p>
                        </div>
                    </div>
                </div>
                
                <div class="mb-6">
                    <p class="text-gray-700">This will update the fine amount for all activities in the "<strong><?php echo htmlspecialchars($campus['campus_name']); ?></strong>" campus to the current default rate.</p>
                    <p class="text-gray-600 text-sm mt-2">Affected activities: <strong><?php echo $stats['total_activities']; ?></strong></p>
                </div>
                
                <div class="flex justify-end gap-3 mt-6">
                    <button type="button" 
                            onclick="closeModal('resetFinesModal')" 
                            class="btn bg-gray-100 text-gray-700 hover:bg-gray-200">
                        Cancel
                    </button>
                    <button type="button" onclick="submitResetFines()" class="btn bg-yellow-500 hover:bg-yellow-600 text-white">
                        <i class="fas fa-redo-alt mr-2"></i> Reset Fines
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Tab switching
        function showTab(tabName) {
            // Hide all tab content
            document.querySelectorAll('.tab-pane').forEach(tab => {
                tab.classList.add('hidden');
                tab.classList.remove('active');
            });
            
            // Remove active class from all tabs
            document.querySelectorAll('.tab').forEach(tab => {
                tab.classList.remove('active');
            });
            
            // Show selected tab content
            document.getElementById(tabName + '-content').classList.remove('hidden');
            document.getElementById(tabName + '-content').classList.add('active');
            
            // Activate selected tab
            document.getElementById('tab-' + tabName).classList.add('active');
        }
        
        // Modal functions
        function openResetFinesModal() {
            document.getElementById('resetFinesModal').classList.add('active');
        }
        
        function closeModal(modalId) {
            document.getElementById(modalId).classList.remove('active');
        }
        
        // Reset campus fines
        function resetCampusFines() {
            openResetFinesModal();
        }
        
        function submitResetFines() {
            // This would typically be an AJAX call to a PHP script
            fetch('reset_campus_fines.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'campus_id=' + <?php echo $campus_id; ?> + '&new_amount=' + <?php echo $campus['fines_per_absence']; ?>
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Campus fines reset successfully!');
                    closeModal('resetFinesModal');
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error resetting fines:', error);
                alert('Error resetting fines. Please try again.');
            });
        }
        
        // Delete confirmation
        function confirmDelete() {
            if (confirm('WARNING: This will permanently delete this campus record.\n\n' +
                       'This action cannot be undone.\n\n' +
                       'Are you absolutely sure?')) {
                document.getElementById('deleteForm').submit();
            }
        }
        
        // Close modal when clicking outside
        window.addEventListener('click', function(e) {
            if (e.target.classList.contains('modal')) {
                e.target.classList.remove('active');
            }
        });
        
        // Initialize
        document.addEventListener('DOMContentLoaded', function() {
            // Any initialization code can go here
        });
    </script>
</body>
</html>