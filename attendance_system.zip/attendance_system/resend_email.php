<?php
// resend_email.php
session_start();
require_once 'db.php';

// Check authentication
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['user_type'], ['admin', 'coordinator'])) {
    header('HTTP/1.1 403 Forbidden');
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['student_id'])) {
    echo json_encode(['success' => false, 'error' => 'Invalid request']);
    exit();
}

$student_id = intval($_POST['student_id']);

// Get student data
$stmt = $conn->prepare("SELECT s.*, c.campus_name FROM students s 
                       JOIN campuses c ON s.campus_id = c.campus_id 
                       WHERE s.student_id = ?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'error' => 'Student not found']);
    exit();
}

$student = $result->fetch_assoc();

if (empty($student['email'])) {
    echo json_encode(['success' => false, 'error' => 'No email address for this student']);
    exit();
}

// Check if QR code exists, if not generate it
if (empty($student['qr_code_path']) || !file_exists($student['qr_code_path'])) {
    // Include PHP QR Code library
    if (file_exists('phpqrcode/qrlib.php')) {
        require_once 'phpqrcode/qrlib.php';
    } else {
        echo json_encode(['success' => false, 'error' => 'QR Code library not found']);
        exit();
    }
    
    // Create QR code data
    $qr_data = [
        'type' => 'student',
        'student_id' => $student['student_id'],
        'student_number' => $student['student_number'],
        'full_name' => $student['full_name'],
        'campus_id' => $student['campus_id'],
        'campus_name' => $student['campus_name']
    ];
    
    $qr_json = json_encode($qr_data);
    
    // Create QR codes directory if not exists
    if (!file_exists('qr_codes')) {
        mkdir('qr_codes', 0777, true);
    }
    
    $qr_filename = "qr_codes/{$student['student_number']}.png";
    QRcode::png($qr_json, $qr_filename, QR_ECLEVEL_L, 10, 2);
    
    // Update database
    $update_stmt = $conn->prepare("UPDATE students SET qr_code_path = ? WHERE student_id = ?");
    $update_stmt->bind_param("si", $qr_filename, $student_id);
    $update_stmt->execute();
    
    $student['qr_code_path'] = $qr_filename;
}

// Function to send email using PHPMailer
function resendWelcomeEmail($student_data, $qr_filename, $conn) {
    try {
        // Try to find PHPMailer in different possible locations
        $phpmailer_found = false;
        $possible_paths = [
            'PHPMailer-master/src/PHPMailer.php',
            'PHPMailer/src/PHPMailer.php',
            'vendor/phpmailer/phpmailer/src/PHPMailer.php'
        ];
        
        foreach ($possible_paths as $path) {
            if (file_exists($path)) {
                require_once $path;
                $smtp_path = str_replace('PHPMailer.php', 'SMTP.php', $path);
                $exception_path = str_replace('PHPMailer.php', 'Exception.php', $path);
                
                if (file_exists($smtp_path) && file_exists($exception_path)) {
                    require_once $smtp_path;
                    require_once $exception_path;
                    $phpmailer_found = true;
                    break;
                }
            }
        }
        
        if (!$phpmailer_found) {
            file_put_contents('email_attempts.log', date('Y-m-d H:i:s') . " - PHPMailer not found for resend\n", FILE_APPEND);
            return false;
        }
        
        $mail = new PHPMailer\PHPMailer\PHPMailer(true);
        
        // SMTP Configuration - UPDATE THESE!
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'jaymarlalantacon@gmail.com';     // UPDATE THIS
        $mail->Password   = 'jaymar03072004';        // UPDATE THIS
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;
        
        // Sender and recipient
        $mail->setFrom('noreply@attendance-system.com', 'Attendance System');
        $mail->addAddress($student_data['email'], $student_data['full_name']);
        
        // Attach QR code
        if (file_exists($qr_filename)) {
            $mail->addAttachment($qr_filename, $student_data['student_number'] . '_qr.png');
        }
        
        // Email content
        $mail->isHTML(true);
        $mail->Subject = "QR Code Resent - " . htmlspecialchars($student_data['campus_name']) . " Attendance";
        
        $mail->Body = '
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #4a6fa5;">QR Code Resent</h2>
            <p>Dear ' . htmlspecialchars($student_data['full_name']) . ',</p>
            <p>Your QR code has been resent as requested.</p>
            
            <div style="background: #f5f5f5; padding: 15px; border-radius: 5px; margin: 20px 0;">
                <p><strong>Student Details:</strong></p>
                <p>Student Number: ' . htmlspecialchars($student_data['student_number']) . '</p>
                <p>Name: ' . htmlspecialchars($student_data['full_name']) . '</p>
                <p>Campus: ' . htmlspecialchars($student_data['campus_name']) . '</p>
            </div>
            
            <p>Your QR code is attached to this email.</p>
            <p><strong>Important:</strong> Do not share your QR code.</p>
            
            <p>Best regards,<br>
            Attendance System</p>
        </div>';
        
        $mail->AltBody = "QR Code Resent\n\n" .
                        "Dear " . $student_data['full_name'] . ",\n\n" .
                        "Your QR code has been resent.\n\n" .
                        "Student Number: " . $student_data['student_number'] . "\n" .
                        "QR code is attached.\n\n" .
                        "Do not share your QR code.";
        
        // Send email
        if ($mail->send()) {
            // Log to database
            $log_stmt = $conn->prepare("INSERT INTO email_logs (student_id, email_type, status, sent_at) VALUES (?, 'resent', 'sent', NOW())");
            $log_stmt->bind_param("i", $student_data['student_id']);
            $log_stmt->execute();
            
            return true;
        } else {
            $error_msg = $mail->ErrorInfo;
            // Log error
            $log_stmt = $conn->prepare("INSERT INTO email_logs (student_id, email_type, status, error_message, sent_at) VALUES (?, 'resent', 'failed', ?, NOW())");
            $log_stmt->bind_param("is", $student_data['student_id'], $error_msg);
            $log_stmt->execute();
            
            return false;
        }
        
    } catch (Exception $e) {
        $error_msg = $e->getMessage();
        file_put_contents('email_attempts.log', date('Y-m-d H:i:s') . " - Resend exception: " . $error_msg . "\n", FILE_APPEND);
        return false;
    }
}

// Send the email
if (resendWelcomeEmail($student, $student['qr_code_path'], $conn)) {
    echo json_encode(['success' => true, 'message' => 'Email resent successfully']);
} else {
    echo json_encode(['success' => false, 'error' => 'Failed to send email. Check email logs.']);
}
?>