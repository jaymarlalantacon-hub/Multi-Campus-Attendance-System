<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_type']) || !in_array($_SESSION['user_type'], ['admin','coordinator'])) {
    header('Location: index.php');
    exit();
}

// Get user info
$user_name = $_SESSION['full_name'] ?? $_SESSION['username'] ?? 'User';
$user_campus_id = $_SESSION['campus_id'] ?? null;

// Initialize variables
$message = null;
$success_count = 0;
$error_count = 0;
$imported_data = [];
$activity_id = 0;

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle CSV upload
    if (isset($_FILES['csv_file']) && $_FILES['csv_file']['error'] === UPLOAD_ERR_OK) {
        $activity_id = intval($_POST['activity_id']);
        $date_override = !empty($_POST['date_override']) ? $_POST['date_override'] : null;
        $time_override = !empty($_POST['time_override']) ? $_POST['time_override'] : null;
        
        if ($activity_id <= 0) {
            $message = ['type' => 'error', 'text' => 'Please select an activity'];
        } else {
            // Process CSV file
            $csv_file = $_FILES['csv_file']['tmp_name'];
            $handle = fopen($csv_file, 'r');
            
            if ($handle !== false) {
                $header = fgetcsv($handle); // Skip header row
                $imported_data = [];
                
                while (($row = fgetcsv($handle)) !== false) {
                    if (count($row) >= 2) { // At least student_number and status
                        $imported_data[] = [
                            'student_number' => trim($row[0]),
                            'status' => trim($row[1]),
                            'time_in' => isset($row[2]) ? trim($row[2]) : null,
                            'notes' => isset($row[3]) ? trim($row[3]) : null
                        ];
                    }
                }
                fclose($handle);
                
                if (!empty($imported_data)) {
                    $message = ['type' => 'success', 'text' => 'CSV file loaded successfully. ' . count($imported_data) . ' records found.'];
                } else {
                    $message = ['type' => 'error', 'text' => 'No valid data found in CSV file.'];
                }
            } else {
                $message = ['type' => 'error', 'text' => 'Failed to open CSV file.'];
            }
        }
    }
    
    // Handle bulk import submission
    if (isset($_POST['import_records']) && isset($_POST['import_data'])) {
        $activity_id = intval($_POST['activity_id']);
        $import_data = json_decode($_POST['import_data'], true);
        
        if ($activity_id <= 0) {
            $message = ['type' => 'error', 'text' => 'Please select an activity'];
        } elseif (empty($import_data)) {
            $message = ['type' => 'error', 'text' => 'No data to import'];
        } else {
            // Get activity details
            $stmt = $conn->prepare("SELECT * FROM activities WHERE activity_id = ?");
            $stmt->bind_param("i", $activity_id);
            $stmt->execute();
            $activity = $stmt->get_result()->fetch_assoc();
            
            if (!$activity) {
                $message = ['type' => 'error', 'text' => 'Activity not found'];
            } else {
                // Start transaction
                $conn->begin_transaction();
                
                foreach ($import_data as $record) {
                    $student_number = trim($record['student_number']);
                    $status = trim($record['status']);
                    $time_in = !empty($record['time_in']) ? $record['time_in'] : null;
                    
                    // Validate student exists
                    $stmt = $conn->prepare("SELECT student_id, campus_id FROM students WHERE student_number = ? AND status = 'active'");
                    $stmt->bind_param("s", $student_number);
                    $stmt->execute();
                    $student_result = $stmt->get_result();
                    
                    if ($student_result->num_rows > 0) {
                        $student = $student_result->fetch_assoc();
                        
                        // Check campus match
                        if ($student['campus_id'] != $activity['campus_id']) {
                            $error_count++;
                            continue;
                        }
                        
                        // Determine time_in
                        if ($time_in) {
                            $attendance_time = $time_in;
                        } else {
                            $attendance_time = date('Y-m-d H:i:s');
                        }
                        
                        // Check existing attendance
                        $stmt = $conn->prepare("SELECT attendance_id FROM attendance WHERE student_id = ? AND activity_id = ?");
                        $stmt->bind_param("ii", $student['student_id'], $activity_id);
                        $stmt->execute();
                        $existing = $stmt->get_result()->fetch_assoc();
                        
                        if ($existing) {
                            // Update existing record
                            $stmt = $conn->prepare("UPDATE attendance SET status = ?, time_in = ?, updated_at = NOW() WHERE attendance_id = ?");
                            $stmt->bind_param("ssi", $status, $attendance_time, $existing['attendance_id']);
                        } else {
                            // Insert new record
                            $stmt = $conn->prepare("INSERT INTO attendance (student_id, activity_id, time_in, status, checked_by, scanned_at) VALUES (?, ?, ?, ?, ?, NOW())");
                            $stmt->bind_param("iissi", $student['student_id'], $activity_id, $attendance_time, $status, $_SESSION['user_id']);
                        }
                        
                        if ($stmt->execute()) {
                            $success_count++;
                        } else {
                            $error_count++;
                        }
                    } else {
                        $error_count++;
                    }
                }
                
                // Commit transaction
                $conn->commit();
                
                $message = [
                    'type' => 'success',
                    'text' => "Bulk import completed. Successfully imported: $success_count records. Failed: $error_count records."
                ];
                
                // Clear imported data after successful import
                $imported_data = [];
            }
        }
    }
    
    // Handle manual entry
    if (isset($_POST['manual_entries'])) {
        $activity_id = intval($_POST['activity_id']);
        $entries = $_POST['manual_entries'];
        
        if ($activity_id <= 0) {
            $message = ['type' => 'error', 'text' => 'Please select an activity'];
        } elseif (empty($entries)) {
            $message = ['type' => 'error', 'text' => 'No manual entries provided'];
        } else {
            // Get activity details
            $stmt = $conn->prepare("SELECT * FROM activities WHERE activity_id = ?");
            $stmt->bind_param("i", $activity_id);
            $stmt->execute();
            $activity = $stmt->get_result()->fetch_assoc();
            
            if (!$activity) {
                $message = ['type' => 'error', 'text' => 'Activity not found'];
            } else {
                // Start transaction
                $conn->begin_transaction();
                
                foreach ($entries as $entry) {
                    if (!empty($entry['student_number'])) {
                        $student_number = trim($entry['student_number']);
                        $status = !empty($entry['status']) ? $entry['status'] : 'Present';
                        
                        // Validate student exists
                        $stmt = $conn->prepare("SELECT student_id, campus_id FROM students WHERE student_number = ? AND status = 'active'");
                        $stmt->bind_param("s", $student_number);
                        $stmt->execute();
                        $student_result = $stmt->get_result();
                        
                        if ($student_result->num_rows > 0) {
                            $student = $student_result->fetch_assoc();
                            
                            // Check campus match
                            if ($student['campus_id'] != $activity['campus_id']) {
                                $error_count++;
                                continue;
                            }
                            
                            // Check existing attendance
                            $stmt = $conn->prepare("SELECT attendance_id FROM attendance WHERE student_id = ? AND activity_id = ?");
                            $stmt->bind_param("ii", $student['student_id'], $activity_id);
                            $stmt->execute();
                            $existing = $stmt->get_result()->fetch_assoc();
                            
                            $attendance_time = date('Y-m-d H:i:s');
                            
                            if ($existing) {
                                // Update existing record
                                $stmt = $conn->prepare("UPDATE attendance SET status = ?, time_in = ?, updated_at = NOW() WHERE attendance_id = ?");
                                $stmt->bind_param("ssi", $status, $attendance_time, $existing['attendance_id']);
                            } else {
                                // Insert new record
                                $stmt = $conn->prepare("INSERT INTO attendance (student_id, activity_id, time_in, status, checked_by, scanned_at) VALUES (?, ?, ?, ?, ?, NOW())");
                                $stmt->bind_param("iissi", $student['student_id'], $activity_id, $attendance_time, $status, $_SESSION['user_id']);
                            }
                            
                            if ($stmt->execute()) {
                                $success_count++;
                            } else {
                                $error_count++;
                            }
                        } else {
                            $error_count++;
                        }
                    }
                }
                
                // Commit transaction
                $conn->commit();
                
                $message = [
                    'type' => 'success',
                    'text' => "Manual entries processed. Successfully added: $success_count records. Failed: $error_count records."
                ];
            }
        }
    }
}

// Get campuses for filter
$campuses_query = "SELECT campus_id, campus_name FROM campuses WHERE status = 'active' ORDER BY campus_name";
$campuses_result = $conn->query($campuses_query);
$campuses = $campuses_result->fetch_all(MYSQLI_ASSOC);

// Get activities based on user role
if ($user_campus_id && $_SESSION['user_type'] === 'coordinator') {
    $activities_query = "SELECT activity_id, activity_name, activity_date FROM activities WHERE campus_id = ? AND status IN ('upcoming', 'ongoing') ORDER BY activity_date DESC";
    $stmt = $conn->prepare($activities_query);
    $stmt->bind_param("i", $user_campus_id);
    $stmt->execute();
    $activities_result = $stmt->get_result();
} else {
    $activities_query = "SELECT activity_id, activity_name, activity_date FROM activities WHERE status IN ('upcoming', 'ongoing') ORDER BY activity_date DESC";
    $activities_result = $conn->query($activities_query);
}

$activities = $activities_result->fetch_all(MYSQLI_ASSOC);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Bulk Attendance | Multi-Campus Attendance</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<style>
    .status-badge {
        padding: 0.25rem 0.75rem;
        border-radius: 9999px;
        font-size: 0.75rem;
        font-weight: 600;
        display: inline-block;
    }
    .status-present { background-color: #d1fae5; color: #065f46; }
    .status-late { background-color: #fef3c7; color: #92400e; }
    .status-absent { background-color: #fee2e2; color: #991b1b; }
    .status-excused { background-color: #dbeafe; color: #1e40af; }
    .tab-content { display: none; }
    .tab-content.active { display: block; }
    .tab-button {
        padding: 1rem 1.5rem;
        border-bottom: 3px solid transparent;
        transition: all 0.3s ease;
    }
    .tab-button.active {
        border-bottom-color: #8b5cf6;
        color: #8b5cf6;
        font-weight: 600;
    }
</style>
</head>
<body class="bg-gray-50 min-h-screen">

<!-- Navigation -->
<nav class="bg-gradient-to-r from-purple-800 to-indigo-900 text-white shadow-lg">
    <div class="container mx-auto px-4 py-3">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div class="flex items-center space-x-4">
                <a href="admin_dashboard.php" class="flex items-center hover:text-purple-200 transition-colors">
                    <i class="fas fa-arrow-left mr-2"></i> Back to Dashboard
                </a>
                <h1 class="text-xl font-bold">
                    <i class="fas fa-upload mr-2"></i> Bulk Attendance
                </h1>
            </div>
            <div class="flex items-center space-x-4">
                <span class="text-sm">
                    <i class="fas fa-user mr-1"></i> <?php echo htmlspecialchars($user_name); ?>
                </span>
                <span class="text-sm text-purple-300">|</span>
                <a href="logout.php" class="text-sm hover:text-purple-200 transition-colors">
                    <i class="fas fa-sign-out-alt mr-1"></i> Logout
                </a>
            </div>
        </div>
    </div>
</nav>

<div class="container mx-auto px-4 py-8">
    <!-- Header -->
    <div class="mb-8">
        <h1 class="text-4xl font-bold text-gray-800 mb-2">Bulk Attendance Management</h1>
        <p class="text-gray-600">Upload CSV files or manually enter multiple attendance records at once</p>
    </div>

    <!-- Quick Navigation -->
    <div class="flex flex-wrap gap-3 mb-8">
        <a href="scan.php" class="inline-flex items-center px-4 py-2.5 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
            <i class="fas fa-qrcode mr-2"></i> Scan Attendance
        </a>
        <a href="attendance_records.php" class="inline-flex items-center px-4 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
            <i class="fas fa-clipboard-list mr-2"></i> View Records
        </a>
        <a href="manage_attendance.php" class="inline-flex items-center px-4 py-2.5 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors">
            <i class="fas fa-edit mr-2"></i> Manage Records
        </a>
        <a href="reports.php" class="inline-flex items-center px-4 py-2.5 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors">
            <i class="fas fa-chart-bar mr-2"></i> Reports
        </a>
    </div>

    <!-- Message Display -->
    <?php if ($message): ?>
        <div class="mb-6 p-4 rounded-lg <?php echo $message['type'] === 'success' ? 'bg-green-50 text-green-800 border border-green-200' : 'bg-red-50 text-red-800 border border-red-200'; ?>">
            <div class="flex items-center">
                <i class="fas <?php echo $message['type'] === 'success' ? 'fa-check-circle' : 'fa-exclamation-triangle'; ?> mr-3"></i>
                <span><?php echo htmlspecialchars($message['text']); ?></span>
            </div>
        </div>
    <?php endif; ?>

    <!-- Tabs -->
    <div class="mb-8 border-b border-gray-200">
        <div class="flex flex-wrap -mb-px">
            <button onclick="showTab('csv-tab')" id="csv-tab-btn" class="tab-button active">
                <i class="fas fa-file-csv mr-2"></i> CSV Upload
            </button>
            <button onclick="showTab('manual-tab')" id="manual-tab-btn" class="tab-button">
                <i class="fas fa-keyboard mr-2"></i> Manual Entry
            </button>
            <button onclick="showTab('template-tab')" id="template-tab-btn" class="tab-button">
                <i class="fas fa-download mr-2"></i> Download Template
            </button>
        </div>
    </div>

    <!-- CSV Upload Tab -->
    <div id="csv-tab" class="tab-content active">
        <div class="bg-white rounded-2xl shadow-xl p-8">
            <h2 class="text-2xl font-bold text-gray-800 mb-6 flex items-center">
                <i class="fas fa-file-upload text-purple-600 mr-3"></i> Upload CSV File
            </h2>
            
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <!-- Upload Form -->
                <div>
                    <form method="POST" action="" enctype="multipart/form-data" class="space-y-6">
                        <!-- Activity Selection -->
                        <div>
                            <label class="block mb-2 font-medium text-gray-700">
                                <i class="fas fa-calendar-alt text-purple-600 mr-2"></i> Select Activity *
                            </label>
                            <select name="activity_id" required
                                    class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors bg-white">
                                <option value="">-- Select Activity --</option>
                                <?php foreach ($activities as $activity): ?>
                                    <option value="<?php echo $activity['activity_id']; ?>" <?php echo $activity_id == $activity['activity_id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($activity['activity_name']); ?> 
                                        (<?php echo date('M d, Y', strtotime($activity['activity_date'])); ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <!-- CSV File Upload -->
                        <div>
                            <label class="block mb-2 font-medium text-gray-700">
                                <i class="fas fa-file-csv text-purple-600 mr-2"></i> CSV File *
                            </label>
                            <div class="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-purple-400 transition-colors">
                                <div class="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-purple-100 to-indigo-100 rounded-full flex items-center justify-center">
                                    <i class="fas fa-cloud-upload-alt text-purple-600 text-2xl"></i>
                                </div>
                                <p class="text-lg font-semibold text-gray-700 mb-2">Drop your CSV file here</p>
                                <p class="text-gray-500 mb-4">or click to browse files</p>
                                <input type="file" name="csv_file" accept=".csv" required
                                       class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-purple-50 file:text-purple-700 hover:file:bg-purple-100">
                                <p class="text-xs text-gray-400 mt-4">
                                    <i class="fas fa-info-circle mr-1"></i>
                                    Maximum file size: 10MB. CSV format required.
                                </p>
                            </div>
                        </div>
                        
                        <!-- Date/Time Override (Optional) -->
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block mb-2 font-medium text-gray-700">Date Override (Optional)</label>
                                <input type="date" name="date_override"
                                       class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors">
                            </div>
                            <div>
                                <label class="block mb-2 font-medium text-gray-700">Time Override (Optional)</label>
                                <input type="time" name="time_override"
                                       class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors">
                            </div>
                        </div>
                        
                        <!-- Submit Button -->
                        <div>
                            <button type="submit" 
                                    class="w-full px-6 py-3 bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-lg hover:from-purple-700 hover:to-indigo-700 transition-all font-semibold shadow-lg hover:shadow-xl flex items-center justify-center">
                                <i class="fas fa-upload mr-2"></i> Upload & Preview CSV
                            </button>
                        </div>
                    </form>
                </div>
                
                <!-- Preview & Instructions -->
                <div>
                    <div class="bg-gradient-to-r from-blue-50 to-cyan-50 p-6 rounded-xl border border-blue-200 mb-6">
                        <h3 class="text-lg font-semibold text-blue-800 mb-3 flex items-center">
                            <i class="fas fa-info-circle text-blue-600 mr-2"></i> CSV Format Instructions
                        </h3>
                        <p class="text-sm text-blue-700 mb-3">
                            Your CSV file should have the following columns (in order):
                        </p>
                        <ol class="text-sm text-blue-700 space-y-1 list-decimal list-inside">
                            <li><strong>student_number</strong> - Student ID number (required)</li>
                            <li><strong>status</strong> - Present, Late, Absent, or Excused (required)</li>
                            <li><strong>time_in</strong> - Time in format: YYYY-MM-DD HH:MM:SS (optional)</li>
                            <li><strong>notes</strong> - Additional notes (optional)</li>
                        </ol>
                        <div class="mt-4 p-3 bg-white rounded-lg border border-blue-100">
                            <p class="text-xs font-mono text-gray-600">
                                student_number,status,time_in,notes<br>
                                2024-001,Present,2024-01-15 08:30:00,On time<br>
                                2024-002,Late,2024-01-15 08:45:00,15 mins late<br>
                                2024-003,Absent,,,Excused with medical certificate
                            </p>
                        </div>
                    </div>
                    
                    <!-- Preview of Imported Data -->
                    <?php if (!empty($imported_data)): ?>
                        <div class="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
                            <h3 class="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                                <i class="fas fa-eye text-purple-600 mr-2"></i> Preview Imported Data
                            </h3>
                            <div class="overflow-x-auto">
                                <table class="min-w-full divide-y divide-gray-200">
                                    <thead class="bg-gray-50">
                                        <tr>
                                            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Student No.</th>
                                            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Time In</th>
                                            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Notes</th>
                                        </tr>
                                    </thead>
                                    <tbody class="bg-white divide-y divide-gray-200">
                                        <?php foreach (array_slice($imported_data, 0, 5) as $index => $record): ?>
                                            <tr>
                                                <td class="px-4 py-2 text-sm"><?php echo htmlspecialchars($record['student_number']); ?></td>
                                                <td class="px-4 py-2">
                                                    <span class="status-badge <?php echo getStatusClass($record['status']); ?>">
                                                        <?php echo $record['status']; ?>
                                                    </span>
                                                </td>
                                                <td class="px-4 py-2 text-sm"><?php echo $record['time_in'] ?? 'Current time'; ?></td>
                                                <td class="px-4 py-2 text-sm"><?php echo htmlspecialchars($record['notes'] ?? ''); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                        <?php if (count($imported_data) > 5): ?>
                                            <tr>
                                                <td colspan="4" class="px-4 py-2 text-center text-sm text-gray-500">
                                                    ... and <?php echo count($imported_data) - 5; ?> more records
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <!-- Import Button -->
                            <form method="POST" action="" class="mt-4">
                                <input type="hidden" name="activity_id" value="<?php echo $activity_id; ?>">
                                <input type="hidden" name="import_data" value="<?php echo htmlspecialchars(json_encode($imported_data)); ?>">
                                <button type="submit" name="import_records" 
                                        class="w-full px-6 py-3 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-lg hover:from-green-700 hover:to-emerald-700 transition-all font-semibold shadow-lg hover:shadow-xl flex items-center justify-center">
                                    <i class="fas fa-database mr-2"></i> Import <?php echo count($imported_data); ?> Records
                                </button>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Manual Entry Tab -->
    <div id="manual-tab" class="tab-content">
        <div class="bg-white rounded-2xl shadow-xl p-8">
            <h2 class="text-2xl font-bold text-gray-800 mb-6 flex items-center">
                <i class="fas fa-keyboard text-purple-600 mr-3"></i> Manual Bulk Entry
            </h2>
            
            <form id="manualEntryForm" method="POST" action="" class="space-y-6">
                <!-- Activity Selection -->
                <div>
                    <label class="block mb-2 font-medium text-gray-700">
                        <i class="fas fa-calendar-alt text-purple-600 mr-2"></i> Select Activity *
                    </label>
                    <select name="activity_id" required
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors bg-white">
                        <option value="">-- Select Activity --</option>
                        <?php foreach ($activities as $activity): ?>
                            <option value="<?php echo $activity['activity_id']; ?>">
                                <?php echo htmlspecialchars($activity['activity_name']); ?> 
                                (<?php echo date('M d, Y', strtotime($activity['activity_date'])); ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <!-- Manual Entry Table -->
                <div>
                    <div class="flex justify-between items-center mb-4">
                        <h3 class="text-lg font-semibold text-gray-800">Enter Student Records</h3>
                        <button type="button" onclick="addEntryRow()" 
                                class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center">
                            <i class="fas fa-plus mr-2"></i> Add Row
                        </button>
                    </div>
                    
                    <div class="overflow-x-auto rounded-xl border border-gray-200">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">#</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Student Number *</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Time In (Optional)</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                                </tr>
                            </thead>
                            <tbody id="manualEntries" class="bg-white divide-y divide-gray-200">
                                <!-- Rows will be added here by JavaScript -->
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <!-- Submit Button -->
                <div class="flex gap-3">
                    <button type="submit" 
                            class="flex-1 px-6 py-3 bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-lg hover:from-purple-700 hover:to-indigo-700 transition-all font-semibold shadow-lg hover:shadow-xl flex items-center justify-center">
                        <i class="fas fa-save mr-2"></i> Save All Entries
                    </button>
                    <button type="button" onclick="clearAllEntries()" 
                            class="px-6 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors">
                        Clear All
                    </button>
                </div>
            </form>
            
            <!-- Quick Help -->
            <div class="mt-8 p-6 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl border border-green-200">
                <h3 class="text-lg font-semibold text-green-800 mb-3 flex items-center">
                    <i class="fas fa-lightbulb text-green-600 mr-2"></i> Quick Tips
                </h3>
                <ul class="text-sm text-green-700 space-y-2">
                    <li><i class="fas fa-check mr-2"></i> Student numbers must exist in the system</li>
                    <li><i class="fas fa-check mr-2"></i> Leave Time In blank to use current time</li>
                    <li><i class="fas fa-check mr-2"></i> Default status is "Present" if not specified</li>
                    <li><i class="fas fa-check mr-2"></i> You can add up to 100 records at once</li>
                </ul>
            </div>
        </div>
    </div>

    <!-- Template Download Tab -->
    <div id="template-tab" class="tab-content">
        <div class="bg-white rounded-2xl shadow-xl p-8">
            <h2 class="text-2xl font-bold text-gray-800 mb-6 flex items-center">
                <i class="fas fa-download text-purple-600 mr-3"></i> Download CSV Template
            </h2>
            
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <!-- Template Options -->
                <div class="space-y-6">
                    <div class="p-6 bg-gradient-to-r from-purple-50 to-indigo-50 rounded-xl border border-purple-200">
                        <h3 class="text-lg font-semibold text-purple-800 mb-4">Download Template</h3>
                        <p class="text-purple-700 mb-4">Download a pre-formatted CSV template to ensure your data imports correctly.</p>
                        
                        <div class="space-y-3">
                            <button onclick="downloadTemplate('basic')" 
                                    class="w-full px-6 py-3 bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-lg hover:from-purple-700 hover:to-indigo-700 transition-all font-semibold flex items-center justify-center">
                                <i class="fas fa-file-csv mr-2"></i> Basic Template
                            </button>
                            
                            <button onclick="downloadTemplate('with_sample')" 
                                    class="w-full px-6 py-3 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-lg hover:from-blue-700 hover:to-cyan-700 transition-all font-semibold flex items-center justify-center">
                                <i class="fas fa-file-excel mr-2"></i> Template with Sample Data
                            </button>
                            
                            <button onclick="exportStudentList()" 
                                    class="w-full px-6 py-3 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-lg hover:from-green-700 hover:to-emerald-700 transition-all font-semibold flex items-center justify-center">
                                <i class="fas fa-users mr-2"></i> Export Student List
                            </button>
                        </div>
                    </div>
                    
                    <!-- Bulk Update Template -->
                    <div class="p-6 bg-gradient-to-r from-blue-50 to-cyan-50 rounded-xl border border-blue-200">
                        <h3 class="text-lg font-semibold text-blue-800 mb-4">Bulk Update Template</h3>
                        <p class="text-blue-700 mb-4">Update existing attendance records in bulk using this template.</p>
                        
                        <form method="POST" action="download_update_template.php" class="space-y-4">
                            <div>
                                <label class="block mb-2 font-medium text-gray-700">Select Activity</label>
                                <select name="activity_id" required
                                        class="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors bg-white">
                                    <option value="">-- Select Activity --</option>
                                    <?php foreach ($activities as $activity): ?>
                                        <option value="<?php echo $activity['activity_id']; ?>">
                                            <?php echo htmlspecialchars($activity['activity_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <button type="submit" 
                                    class="w-full px-6 py-3 bg-gradient-to-r from-orange-600 to-amber-600 text-white rounded-lg hover:from-orange-700 hover:to-amber-700 transition-all font-semibold flex items-center justify-center">
                                <i class="fas fa-file-export mr-2"></i> Download Update Template
                            </button>
                        </form>
                    </div>
                </div>
                
                <!-- Instructions -->
                <div class="space-y-6">
                    <div class="p-6 bg-gradient-to-r from-gray-50 to-gray-100 rounded-xl border border-gray-200">
                        <h3 class="text-lg font-semibold text-gray-800 mb-4">Template Instructions</h3>
                        
                        <div class="space-y-4">
                            <div>
                                <h4 class="font-medium text-gray-700 mb-2">Basic Template Includes:</h4>
                                <ul class="text-sm text-gray-600 space-y-1 list-disc list-inside">
                                    <li>Column headers only</li>
                                    <li>Proper CSV formatting</li>
                                    <li>UTF-8 encoding</li>
                                    <li>Comma-separated values</li>
                                </ul>
                            </div>
                            
                            <div>
                                <h4 class="font-medium text-gray-700 mb-2">Template with Sample Data:</h4>
                                <ul class="text-sm text-gray-600 space-y-1 list-disc list-inside">
                                    <li>Sample student numbers</li>
                                    <li>Example status values</li>
                                    <li>Sample time entries</li>
                                    <li>Demonstrates proper format</li>
                                </ul>
                            </div>
                            
                            <div>
                                <h4 class="font-medium text-gray-700 mb-2">Export Student List:</h4>
                                <ul class="text-sm text-gray-600 space-y-1 list-disc list-inside">
                                    <li>All active students</li>
                                    <li>Student numbers and names</li>
                                    <li>Campus information</li>
                                    <li>Course/year details</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                    <!-- CSV Format Example -->
                    <div class="p-6 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl border border-indigo-200">
                        <h3 class="text-lg font-semibold text-indigo-800 mb-3">CSV Format Example</h3>
                        <div class="bg-white p-4 rounded-lg border border-indigo-100 overflow-x-auto">
                            <pre class="text-xs text-gray-700 font-mono">
student_number,status,time_in,notes
2024-001,Present,2024-01-15 08:30:00,On time
2024-002,Late,2024-01-15 08:45:00,15 minutes late
2024-003,Absent,,Excused - Medical
2024-004,Present,2024-01-15 08:25:00,
2024-005,Excused,,Field trip
                            </pre>
                        </div>
                        <p class="text-sm text-indigo-700 mt-3">
                            <i class="fas fa-info-circle mr-1"></i>
                            Save your CSV file with UTF-8 encoding to preserve special characters.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript -->
<script>
// Tab Navigation
function showTab(tabId) {
    // Hide all tabs
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Deactivate all tab buttons
    document.querySelectorAll('.tab-button').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Show selected tab
    document.getElementById(tabId).classList.add('active');
    
    // Activate selected tab button
    document.getElementById(tabId + '-btn').classList.add('active');
}

// Manual Entry Management
let entryCount = 0;

function addEntryRow(studentNumber = '', status = 'Present', timeIn = '') {
    const tbody = document.getElementById('manualEntries');
    const rowId = 'entry-' + entryCount;
    
    const row = document.createElement('tr');
    row.id = rowId;
    row.innerHTML = `
        <td class="px-6 py-3 whitespace-nowrap text-sm text-gray-500">${entryCount + 1}</td>
        <td class="px-6 py-3">
            <input type="text" 
                   name="manual_entries[${entryCount}][student_number]" 
                   value="${studentNumber}"
                   placeholder="e.g., 2024-001"
                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors"
                   required>
        </td>
        <td class="px-6 py-3">
            <select name="manual_entries[${entryCount}][status]"
                    class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors">
                <option value="Present" ${status === 'Present' ? 'selected' : ''}>Present</option>
                <option value="Late" ${status === 'Late' ? 'selected' : ''}>Late</option>
                <option value="Absent" ${status === 'Absent' ? 'selected' : ''}>Absent</option>
                <option value="Excused" ${status === 'Excused' ? 'selected' : ''}>Excused</option>
            </select>
        </td>
        <td class="px-6 py-3">
            <input type="datetime-local" 
                   name="manual_entries[${entryCount}][time_in]" 
                   value="${timeIn}"
                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-colors">
        </td>
        <td class="px-6 py-3 whitespace-nowrap">
            <button type="button" onclick="removeEntryRow('${rowId}')" 
                    class="text-red-600 hover:text-red-800">
                <i class="fas fa-trash"></i>
            </button>
        </td>
    `;
    
    tbody.appendChild(row);
    entryCount++;
    
    // Limit to 100 rows
    if (entryCount >= 100) {
        document.querySelector('button[onclick="addEntryRow()"]').disabled = true;
    }
}

function removeEntryRow(rowId) {
    const row = document.getElementById(rowId);
    if (row) {
        row.remove();
        entryCount--;
        updateRowNumbers();
        document.querySelector('button[onclick="addEntryRow()"]').disabled = false;
    }
}

function updateRowNumbers() {
    const rows = document.querySelectorAll('#manualEntries tr');
    rows.forEach((row, index) => {
        const numberCell = row.querySelector('td:first-child');
        if (numberCell) {
            numberCell.textContent = index + 1;
        }
    });
}

function clearAllEntries() {
    if (confirm('Are you sure you want to clear all entries?')) {
        document.getElementById('manualEntries').innerHTML = '';
        entryCount = 0;
        document.querySelector('button[onclick="addEntryRow()"]').disabled = false;
    }
}

// Template Downloads
function downloadTemplate(type) {
    let csvContent = '';
    
    if (type === 'basic') {
        csvContent = 'student_number,status,time_in,notes\n';
    } else if (type === 'with_sample') {
        const now = new Date();
        const dateStr = now.toISOString().split('T')[0];
        const timeStr = now.toTimeString().split(' ')[0];
        
        csvContent = `student_number,status,time_in,notes\n` +
                     `2024-001,Present,${dateStr} 08:30:00,On time\n` +
                     `2024-002,Late,${dateStr} 08:45:00,15 minutes late\n` +
                     `2024-003,Absent,,Excused - Medical\n` +
                     `2024-004,Present,${dateStr} 08:25:00,\n` +
                     `2024-005,Excused,,Field trip`;
    }
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `attendance_template_${type}_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
}

function exportStudentList() {
    // This would typically be a server-side operation
    // For now, we'll redirect to a PHP script
    window.location.href = 'export_student_list.php';
}

// Form Validation
document.getElementById('manualEntryForm').addEventListener('submit', function(e) {
    const entries = document.querySelectorAll('input[name^="manual_entries"]');
    if (entries.length === 0) {
        e.preventDefault();
        alert('Please add at least one student entry.');
        return;
    }
    
    // Validate student numbers are not empty
    let hasEmpty = false;
    document.querySelectorAll('input[name$="[student_number]"]').forEach(input => {
        if (!input.value.trim()) {
            hasEmpty = true;
            input.classList.add('border-red-500');
        } else {
            input.classList.remove('border-red-500');
        }
    });
    
    if (hasEmpty) {
        e.preventDefault();
        alert('Please fill in all student numbers.');
    }
});

// Initialize with 3 empty rows when manual tab is shown
document.getElementById('manual-tab-btn').addEventListener('click', function() {
    if (entryCount === 0) {
        for (let i = 0; i < 3; i++) {
            addEntryRow();
        }
    }
});

// Status badge class helper
function getStatusClass(status) {
    switch(status) {
        case 'Present': return 'status-present';
        case 'Late': return 'status-late';
        case 'Absent': return 'status-absent';
        case 'Excused': return 'status-excused';
        default: return 'bg-gray-100 text-gray-800';
    }
}
</script>
</body>
</html>

<?php
// Helper function for status classes
function getStatusClass($status) {
    switch($status) {
        case 'Present': return 'status-present';
        case 'Late': return 'status-late';
        case 'Absent': return 'status-absent';
        case 'Excused': return 'status-excused';
        default: return 'bg-gray-100 text-gray-800';
    }
}
?>