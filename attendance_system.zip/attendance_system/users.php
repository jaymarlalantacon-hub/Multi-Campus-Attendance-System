<?php
session_start();
require_once 'db.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['full_name'];
$user_type = $_SESSION['user_type'];

// Get campuses for filters
$campuses = [];
$campus_query = "SELECT * FROM campuses WHERE status = 'active' ORDER BY campus_name";
$campus_result = $conn->query($campus_query);
while ($campus = $campus_result->fetch_assoc()) {
    $campuses[] = $campus;
}

// Handle search and filters
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$campus_filter = isset($_GET['campus']) ? intval($_GET['campus']) : 0;
$type_filter = isset($_GET['type']) ? $_GET['type'] : '';
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';

// Build WHERE clause for filtering
$where_conditions = [];
$params = [];
$param_types = "";

if (!empty($search)) {
    $where_conditions[] = "(u.full_name LIKE ? OR u.email LIKE ? OR u.username LIKE ?)";
    $search_term = "%{$search}%";
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
    $param_types .= "sss";
}

if ($campus_filter > 0) {
    $where_conditions[] = "u.campus_id = ?";
    $params[] = $campus_filter;
    $param_types .= "i";
}

if (!empty($type_filter)) {
    $where_conditions[] = "u.user_type = ?";
    $params[] = $type_filter;
    $param_types .= "s";
}

if (!empty($status_filter)) {
    $where_conditions[] = "u.status = ?";
    $params[] = $status_filter;
    $param_types .= "s";
}

$where_clause = "";
if (!empty($where_conditions)) {
    $where_clause = "WHERE " . implode(" AND ", $where_conditions);
}

// Pagination
$limit = 20;
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($page - 1) * $limit;

// Get total count
$count_query = "SELECT COUNT(*) as total FROM users u 
                LEFT JOIN campuses c ON u.campus_id = c.campus_id 
                {$where_clause}";
$count_stmt = $conn->prepare($count_query);
if (!empty($params)) {
    $count_stmt->bind_param($param_types, ...$params);
}
$count_stmt->execute();
$count_result = $count_stmt->get_result();
$total_users = $count_result->fetch_assoc()['total'];
$total_pages = ceil($total_users / $limit);

// Get users with pagination - fixed query to match your table structure
$users_query = "SELECT u.*, c.campus_name, 
                (SELECT COUNT(*) FROM attendance WHERE user_id = u.user_id) as attendance_count,
                (SELECT COUNT(*) FROM fines WHERE user_id = u.user_id AND status IN ('pending', 'partial')) as pending_fines
                FROM users u 
                LEFT JOIN campuses c ON u.campus_id = c.campus_id 
                {$where_clause}
                ORDER BY u.created_at DESC
                LIMIT ? OFFSET ?";

$params[] = $limit;
$params[] = $offset;
$param_types .= "ii";

$users_stmt = $conn->prepare($users_query);
$users_stmt->bind_param($param_types, ...$params);
$users_stmt->execute();
$users_result = $users_stmt->get_result();
$users = $users_result->fetch_all(MYSQLI_ASSOC);

// Handle form submissions
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add_user') {
        // Add new user
        $full_name = trim($_POST['full_name']);
        $email = trim($_POST['email']);
        $username = trim($_POST['username']);
        $user_type = $_POST['user_type'];
        $phone = trim($_POST['phone']);
        $campus_id = !empty($_POST['campus_id']) ? intval($_POST['campus_id']) : null;
        $status = $_POST['status'];
        
        // Generate default password (first 4 letters of name + last 4 of phone)
        $default_password = substr(str_replace(' ', '', $full_name), 0, 4) . substr($phone, -4);
        $hashed_password = password_hash($default_password, PASSWORD_DEFAULT);
        
        // Validation
        $errors = [];
        
        if (empty($full_name)) {
            $errors[] = "Full name is required.";
        }
        
        if (empty($email)) {
            $errors[] = "Email is required.";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Invalid email format.";
        } else {
            // Check if email already exists
            $check_email = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
            $check_email->bind_param("s", $email);
            $check_email->execute();
            if ($check_email->get_result()->num_rows > 0) {
                $errors[] = "Email already exists.";
            }
        }
        
        if (empty($username)) {
            $errors[] = "Username is required.";
        } else {
            // Check if username already exists
            $check_username = $conn->prepare("SELECT user_id FROM users WHERE username = ?");
            $check_username->bind_param("s", $username);
            $check_username->execute();
            if ($check_username->get_result()->num_rows > 0) {
                $errors[] = "Username already exists.";
            }
        }
        
        if (empty($phone)) {
            $errors[] = "Phone number is required.";
        }
        
        if (empty($errors)) {
            $add_query = "INSERT INTO users (full_name, email, username, password, user_type, phone, campus_id, status, created_at) 
                          VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())";
            $add_stmt = $conn->prepare($add_query);
            $add_stmt->bind_param("ssssssis", $full_name, $email, $username, $hashed_password, $user_type, $phone, $campus_id, $status);
            
            if ($add_stmt->execute()) {
                $new_user_id = $conn->insert_id;
                $success_message = "User added successfully! Default password: " . htmlspecialchars($default_password);
                
                // Log the action
                $log_query = "INSERT INTO user_logs (user_id, action, details, admin_id) VALUES (?, 'created', 'New user created by admin', ?)";
                $log_stmt = $conn->prepare($log_query);
                $log_stmt->bind_param("ii", $new_user_id, $_SESSION['user_id']);
                $log_stmt->execute();
                
            } else {
                $error_message = "Failed to add user. Please try again.";
            }
        } else {
            $error_message = implode("<br>", $errors);
        }
        
    } elseif ($action === 'bulk_delete') {
        // Bulk delete users
        if (isset($_POST['user_ids']) && is_array($_POST['user_ids'])) {
            $user_ids = array_map('intval', $_POST['user_ids']);
            $placeholders = implode(',', array_fill(0, count($user_ids), '?'));
            
            // Check if any users have attendance records
            $check_query = "SELECT COUNT(*) as count FROM attendance WHERE user_id IN ($placeholders)";
            $check_stmt = $conn->prepare($check_query);
            $check_stmt->bind_param(str_repeat('i', count($user_ids)), ...$user_ids);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            $has_records = $check_result->fetch_assoc()['count'] > 0;
            
            if ($has_records) {
                $error_message = "Cannot delete users with attendance records. Please deactivate them instead.";
            } else {
                $delete_query = "DELETE FROM users WHERE user_id IN ($placeholders)";
                $delete_stmt = $conn->prepare($delete_query);
                $delete_stmt->bind_param(str_repeat('i', count($user_ids)), ...$user_ids);
                
                if ($delete_stmt->execute()) {
                    $success_message = count($user_ids) . " users deleted successfully.";
                } else {
                    $error_message = "Failed to delete users.";
                }
            }
        } else {
            $error_message = "No users selected for deletion.";
        }
    } elseif ($action === 'import_users') {
        // Handle CSV import
        if (isset($_FILES['csv_file']) && $_FILES['csv_file']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['csv_file']['tmp_name'];
            $handle = fopen($file, 'r');
            
            if ($handle !== false) {
                $success_count = 0;
                $error_count = 0;
                $row = 0;
                
                // Skip header row
                fgetcsv($handle);
                
                while (($data = fgetcsv($handle)) !== false) {
                    $row++;
                    
                    // Validate required fields
                    if (count($data) < 6) {
                        $error_count++;
                        continue;
                    }
                    
                    $full_name = trim($data[0]);
                    $email = trim($data[1]);
                    $username = trim($data[2]);
                    $user_type = trim($data[3]);
                    $phone = trim($data[4]);
                    $campus_id = !empty($data[5]) ? intval($data[5]) : null;
                    $status = isset($data[6]) ? trim($data[6]) : 'active';
                    
                    // Skip if email already exists
                    $check_email = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
                    $check_email->bind_param("s", $email);
                    $check_email->execute();
                    if ($check_email->get_result()->num_rows > 0) {
                        $error_count++;
                        continue;
                    }
                    
                    // Skip if username already exists
                    $check_username = $conn->prepare("SELECT user_id FROM users WHERE username = ?");
                    $check_username->bind_param("s", $username);
                    $check_username->execute();
                    if ($check_username->get_result()->num_rows > 0) {
                        $error_count++;
                        continue;
                    }
                    
                    // Generate default password
                    $default_password = substr(str_replace(' ', '', $full_name), 0, 4) . substr($phone, -4);
                    $hashed_password = password_hash($default_password, PASSWORD_DEFAULT);
                    
                    // Insert user
                    $insert_query = "INSERT INTO users (full_name, email, username, password, user_type, phone, campus_id, status, created_at) 
                                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())";
                    $insert_stmt = $conn->prepare($insert_query);
                    $insert_stmt->bind_param("ssssssis", $full_name, $email, $username, $hashed_password, $user_type, $phone, $campus_id, $status);
                    
                    if ($insert_stmt->execute()) {
                        $success_count++;
                    } else {
                        $error_count++;
                    }
                }
                
                fclose($handle);
                $success_message = "CSV import completed. Successfully imported: {$success_count} users. Failed: {$error_count} rows.";
            } else {
                $error_message = "Failed to read CSV file.";
            }
        } else {
            $error_message = "Please select a valid CSV file.";
        }
    }
}

// User types and statuses
$user_types = [
    'student' => 'Student',
    'faculty' => 'Faculty',
    'staff' => 'Staff',
    'coordinator' => 'Coordinator',
    'admin' => 'Administrator'
];

$user_statuses = [
    'active' => 'Active',
    'inactive' => 'Inactive',
    'suspended' => 'Suspended'
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users | Multi-Campus Attendance System</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #3b82f6;
            --secondary-color: #8b5cf6;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
        }
        
        body {
            font-family: 'Segoe UI', 'Inter', system-ui, -apple-system, sans-serif;
            background: linear-gradient(135deg, #f6f9fc 0%, #edf2f7 100%);
            min-height: 100vh;
        }
        
        .card {
            background: white;
            border-radius: 1rem;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            border: 1px solid #e5e7eb;
        }
        
        .card:hover {
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
        }
        
        .header-gradient {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
        }
        
        .btn {
            padding: 0.75rem 1.5rem;
            border-radius: 0.75rem;
            font-weight: 600;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(59, 130, 246, 0.3);
        }
        
        .btn-success {
            background: var(--success-color);
            color: white;
        }
        
        .btn-danger {
            background: var(--danger-color);
            color: white;
        }
        
        .btn-warning {
            background: var(--warning-color);
            color: white;
        }
        
        .badge {
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        
        .badge-student { background: #dbeafe; color: #1e40af; }
        .badge-faculty { background: #fef3c7; color: #92400e; }
        .badge-staff { background: #d1fae5; color: #065f46; }
        .badge-coordinator { background: #e0e7ff; color: #3730a3; }
        .badge-admin { background: #fce7f3; color: #9d174d; }
        
        .badge-active { background: #d1fae5; color: #065f46; }
        .badge-inactive { background: #e5e7eb; color: #374151; }
        .badge-suspended { background: #fee2e2; color: #991b1b; }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }
        
        .modal.active {
            display: flex;
        }
        
        .modal-content {
            background: white;
            border-radius: 1rem;
            width: 90%;
            max-width: 600px;
            max-height: 90vh;
            overflow-y: auto;
        }
        
        .table-container {
            overflow-x: auto;
            border-radius: 0.75rem;
            border: 1px solid #e5e7eb;
        }
        
        .table {
            width: 100%;
            min-width: 1000px;
        }
        
        .table th {
            background: #f9fafb;
            padding: 1rem;
            text-align: left;
            font-weight: 600;
            color: #374151;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .table td {
            padding: 1rem;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .table tr:hover {
            background: #f9fafb;
        }
        
        .checkbox-cell {
            width: 50px;
            text-align: center;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            gap: 0.5rem;
            margin-top: 2rem;
        }
        
        .page-link {
            padding: 0.5rem 1rem;
            border-radius: 0.5rem;
            color: #374151;
            text-decoration: none;
            transition: all 0.2s ease;
        }
        
        .page-link:hover {
            background: #f3f4f6;
        }
        
        .page-link.active {
            background: var(--primary-color);
            color: white;
        }
        
        .filter-card {
            background: white;
            border-radius: 1rem;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: white;
            border-radius: 1rem;
            padding: 1.5rem;
            text-align: center;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        
        .stat-value {
            font-size: 2.5rem;
            font-weight: 700;
            line-height: 1;
        }
        
        .stat-label {
            color: #6b7280;
            font-size: 0.875rem;
            margin-top: 0.5rem;
        }
    </style>
</head>
<body class="min-h-screen p-4 md:p-8">
    <!-- Header -->
    <div class="max-w-7xl mx-auto">
        <div class="header-gradient text-white p-6 mb-8 rounded-2xl shadow-lg">
            <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h1 class="text-3xl font-bold mb-2">Manage Users</h1>
                    <p class="text-white/90">Total Users: <?php echo number_format($total_users); ?></p>
                </div>
                <div class="flex flex-wrap gap-2">
                    <a href="admin_dashboard.php" class="btn bg-white/20 hover:bg-white/30 text-white">
                        <i class="fas fa-arrow-left mr-2"></i> Back to Dashboard
                    </a>
                    <button onclick="openAddUserModal()" class="btn bg-green-500 hover:bg-green-600 text-white">
                        <i class="fas fa-user-plus mr-2"></i> Add User
                    </button>
                    <button onclick="openImportModal()" class="btn bg-purple-500 hover:bg-purple-600 text-white">
                        <i class="fas fa-file-import mr-2"></i> Import CSV
                    </button>
                </div>
            </div>
        </div>
        
        <!-- Messages -->
        <?php if ($success_message): ?>
        <div class="mb-6 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-xl flex items-center">
            <i class="fas fa-check-circle mr-3 text-green-600"></i>
            <span><?php echo $success_message; ?></span>
        </div>
        <?php endif; ?>
        
        <?php if ($error_message): ?>
        <div class="mb-6 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl flex items-center">
            <i class="fas fa-exclamation-circle mr-3 text-red-600"></i>
            <span><?php echo $error_message; ?></span>
        </div>
        <?php endif; ?>
        
        <!-- User Statistics -->
        <div class="stats-grid mb-8">
            <?php
            // Get user statistics
            $stats_query = "SELECT 
                            COUNT(*) as total_users,
                            COUNT(CASE WHEN user_type = 'student' THEN 1 END) as students,
                            COUNT(CASE WHEN user_type = 'faculty' THEN 1 END) as faculty,
                            COUNT(CASE WHEN user_type = 'staff' THEN 1 END) as staff,
                            COUNT(CASE WHEN status = 'active' THEN 1 END) as active_users
                            FROM users";
            $stats_result = $conn->query($stats_query);
            $stats = $stats_result->fetch_assoc();
            ?>
            
            <div class="stat-card">
                <div class="stat-value text-blue-600"><?php echo number_format($stats['total_users']); ?></div>
                <div class="stat-label">Total Users</div>
            </div>
            <div class="stat-card">
                <div class="stat-value text-green-600"><?php echo number_format($stats['students']); ?></div>
                <div class="stat-label">Students</div>
            </div>
            <div class="stat-card">
                <div class="stat-value text-yellow-600"><?php echo number_format($stats['faculty']); ?></div>
                <div class="stat-label">Faculty</div>
            </div>
            <div class="stat-card">
                <div class="stat-value text-purple-600"><?php echo number_format($stats['staff']); ?></div>
                <div class="stat-label">Staff</div>
            </div>
            <div class="stat-card">
                <div class="stat-value text-teal-600"><?php echo number_format($stats['active_users']); ?></div>
                <div class="stat-label">Active Users</div>
            </div>
        </div>
        
        <!-- Filters -->
        <div class="filter-card mb-6">
            <form method="GET" action="" class="space-y-4">
                <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Search</label>
                        <input type="text" 
                               name="search" 
                               value="<?php echo htmlspecialchars($search); ?>"
                               placeholder="Name, Email, or Username"
                               class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Campus</label>
                        <select name="campus" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                            <option value="">All Campuses</option>
                            <?php foreach ($campuses as $campus): ?>
                            <option value="<?php echo $campus['campus_id']; ?>" <?php echo $campus_filter == $campus['campus_id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($campus['campus_name']); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">User Type</label>
                        <select name="type" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                            <option value="">All Types</option>
                            <?php foreach ($user_types as $value => $label): ?>
                            <option value="<?php echo $value; ?>" <?php echo $type_filter === $value ? 'selected' : ''; ?>>
                                <?php echo $label; ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Status</label>
                        <select name="status" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                            <option value="">All Statuses</option>
                            <?php foreach ($user_statuses as $value => $label): ?>
                            <option value="<?php echo $value; ?>" <?php echo $status_filter === $value ? 'selected' : ''; ?>>
                                <?php echo $label; ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="flex gap-3">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-search mr-2"></i> Search
                    </button>
                    <a href="users.php" class="btn bg-gray-100 text-gray-700 hover:bg-gray-200">
                        <i class="fas fa-times mr-2"></i> Clear
                    </a>
                </div>
            </form>
        </div>
        
        <!-- Bulk Actions -->
        <div class="flex justify-between items-center mb-4">
            <div>
                <button onclick="selectAllUsers()" class="btn bg-gray-100 text-gray-700 hover:bg-gray-200 mr-2">
                    <i class="fas fa-check-square mr-2"></i> Select All
                </button>
                <button onclick="clearSelection()" class="btn bg-gray-100 text-gray-700 hover:bg-gray-200">
                    <i class="fas fa-times-circle mr-2"></i> Clear
                </button>
            </div>
            <div>
                <form method="POST" action="" id="bulkDeleteForm" onsubmit="return confirmBulkDelete()">
                    <input type="hidden" name="action" value="bulk_delete">
                    <button type="submit" class="btn bg-red-500 hover:bg-red-600 text-white">
                        <i class="fas fa-trash mr-2"></i> Delete Selected
                    </button>
                </form>
            </div>
        </div>
        
        <!-- Users Table -->
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th class="checkbox-cell">
                            <input type="checkbox" id="selectAll" onchange="toggleSelectAll()">
                        </th>
                        <th>User Info</th>
                        <th>Type & Campus</th>
                        <th>Activity Stats</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($users) > 0): ?>
                        <?php foreach ($users as $user): ?>
                        <tr>
                            <td class="checkbox-cell">
                                <input type="checkbox" name="user_ids[]" value="<?php echo $user['user_id']; ?>" class="user-checkbox">
                            </td>
                            <td>
                                <div class="flex items-center">
                                    <div class="flex-shrink-0 h-12 w-12 bg-blue-100 rounded-lg flex items-center justify-center">
                                        <?php if (!empty($user['photo'])): ?>
                                            <img src="<?php echo htmlspecialchars($user['photo']); ?>" 
                                                 alt="<?php echo htmlspecialchars($user['full_name']); ?>" 
                                                 class="h-12 w-12 rounded-lg object-cover">
                                        <?php else: ?>
                                            <i class="fas fa-user text-blue-600 text-xl"></i>
                                        <?php endif; ?>
                                    </div>
                                    <div class="ml-4">
                                        <div class="font-medium text-gray-900"><?php echo htmlspecialchars($user['full_name']); ?></div>
                                        <div class="text-sm text-gray-500"><?php echo htmlspecialchars($user['email']); ?></div>
                                        <div class="text-sm text-gray-400">Username: <?php echo htmlspecialchars($user['username']); ?></div>
                                        <?php if (!empty($user['phone'])): ?>
                                        <div class="text-sm text-gray-400">Phone: <?php echo htmlspecialchars($user['phone']); ?></div>
                                        <?php endif; ?>
                                        <?php if (!empty($user['last_login'])): ?>
                                        <div class="text-xs text-gray-400">
                                            Last login: <?php echo date('M d, Y H:i', strtotime($user['last_login'])); ?>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="space-y-2">
                                    <span class="badge badge-<?php echo $user['user_type']; ?>">
                                        <?php echo $user_types[$user['user_type']] ?? ucfirst($user['user_type']); ?>
                                    </span>
                                    <?php if ($user['campus_name']): ?>
                                    <div class="text-sm text-gray-600">
                                        <i class="fas fa-school mr-1"></i>
                                        <?php echo htmlspecialchars($user['campus_name']); ?>
                                    </div>
                                    <?php endif; ?>
                                    <div class="text-xs text-gray-400">
                                        Joined: <?php echo date('M d, Y', strtotime($user['created_at'])); ?>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="space-y-1">
                                    <div class="flex items-center text-sm">
                                        <i class="fas fa-calendar-check text-green-600 mr-2"></i>
                                        <span class="font-medium"><?php echo $user['attendance_count']; ?></span>
                                        <span class="text-gray-500 ml-1">attendance(s)</span>
                                    </div>
                                    <?php if ($user['pending_fines'] > 0): ?>
                                    <div class="flex items-center text-sm">
                                        <i class="fas fa-exclamation-triangle text-red-600 mr-2"></i>
                                        <span class="font-medium"><?php echo $user['pending_fines']; ?></span>
                                        <span class="text-gray-500 ml-1">pending fine(s)</span>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td>
                                <span class="badge badge-<?php echo $user['status']; ?>">
                                    <?php echo $user_statuses[$user['status']] ?? ucfirst($user['status']); ?>
                                </span>
                            </td>
                            <td>
                                <div class="flex space-x-2">
                                    <a href="edit_user.php?id=<?php echo $user['user_id']; ?>" 
                                       class="text-blue-600 hover:text-blue-900" 
                                       title="Edit User">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="user_details.php?id=<?php echo $user['user_id']; ?>" 
                                       class="text-green-600 hover:text-green-900"
                                       title="View Details">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="reset_password.php?id=<?php echo $user['user_id']; ?>" 
                                       class="text-purple-600 hover:text-purple-900"
                                       title="Reset Password">
                                        <i class="fas fa-key"></i>
                                    </a>
                                    <?php if ($user['status'] === 'active'): ?>
                                    <a href="deactivate_user.php?id=<?php echo $user['user_id']; ?>" 
                                       class="text-yellow-600 hover:text-yellow-900"
                                       title="Deactivate"
                                       onclick="return confirm('Deactivate this user?')">
                                        <i class="fas fa-user-slash"></i>
                                    </a>
                                    <?php else: ?>
                                    <a href="activate_user.php?id=<?php echo $user['user_id']; ?>" 
                                       class="text-green-600 hover:text-green-900"
                                       title="Activate"
                                       onclick="return confirm('Activate this user?')">
                                        <i class="fas fa-user-check"></i>
                                    </a>
                                    <?php endif; ?>
                                    <a href="delete_user.php?id=<?php echo $user['user_id']; ?>" 
                                       class="text-red-600 hover:text-red-900"
                                       title="Delete"
                                       onclick="return confirm('Delete this user? This action cannot be undone.')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="px-6 py-8 text-center text-gray-500">
                                <i class="fas fa-users-slash text-4xl mb-4 text-gray-300"></i>
                                <p class="text-lg mb-2">No users found</p>
                                <p class="text-gray-400 mb-4">Try adjusting your search filters or add new users.</p>
                                <button onclick="openAddUserModal()" class="btn btn-primary">
                                    <i class="fas fa-user-plus mr-2"></i> Add New User
                                </button>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
        <div class="pagination mt-6">
            <?php if ($page > 1): ?>
            <a href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>&campus=<?php echo $campus_filter; ?>&type=<?php echo $type_filter; ?>&status=<?php echo $status_filter; ?>" 
               class="page-link">
                <i class="fas fa-chevron-left mr-1"></i> Previous
            </a>
            <?php endif; ?>
            
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <?php if ($i == 1 || $i == $total_pages || ($i >= $page - 2 && $i <= $page + 2)): ?>
                <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&campus=<?php echo $campus_filter; ?>&type=<?php echo $type_filter; ?>&status=<?php echo $status_filter; ?>" 
                   class="page-link <?php echo $i == $page ? 'active' : ''; ?>">
                    <?php echo $i; ?>
                </a>
                <?php elseif ($i == $page - 3 || $i == $page + 3): ?>
                <span class="page-link">...</span>
                <?php endif; ?>
            <?php endfor; ?>
            
            <?php if ($page < $total_pages): ?>
            <a href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>&campus=<?php echo $campus_filter; ?>&type=<?php echo $type_filter; ?>&status=<?php echo $status_filter; ?>" 
               class="page-link">
                Next <i class="fas fa-chevron-right ml-1"></i>
            </a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        
        <div class="mt-6 text-sm text-gray-500 text-center">
            Showing <?php echo min($limit, count($users)); ?> of <?php echo number_format($total_users); ?> users
        </div>
    </div>
    
    <!-- Add User Modal -->
    <div id="addUserModal" class="modal">
        <div class="modal-content">
            <div class="p-6">
                <div class="flex justify-between items-center mb-6">
                    <h3 class="text-xl font-bold text-gray-800">Add New User</h3>
                    <button onclick="closeModal('addUserModal')" class="text-gray-500 hover:text-gray-700">
                        <i class="fas fa-times text-xl"></i>
                    </button>
                </div>
                
                <form method="POST" action="" class="space-y-4">
                    <input type="hidden" name="action" value="add_user">
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Full Name *</label>
                            <input type="text" 
                                   name="full_name" 
                                   required
                                   class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Email *</label>
                            <input type="email" 
                                   name="email" 
                                   required
                                   class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Username *</label>
                            <input type="text" 
                                   name="username" 
                                   required
                                   class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Phone Number *</label>
                            <input type="tel" 
                                   name="phone" 
                                   required
                                   placeholder="e.g., 09123456789"
                                   class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">User Type *</label>
                            <select name="user_type" 
                                    required
                                    class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                <?php foreach ($user_types as $value => $label): ?>
                                <option value="<?php echo $value; ?>"><?php echo $label; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Campus</label>
                            <select name="campus_id" 
                                    class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                <option value="">-- Select Campus --</option>
                                <?php foreach ($campuses as $campus): ?>
                                <option value="<?php echo $campus['campus_id']; ?>">
                                    <?php echo htmlspecialchars($campus['campus_name']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Status *</label>
                            <select name="status" 
                                    required
                                    class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                <?php foreach ($user_statuses as $value => $label): ?>
                                <option value="<?php echo $value; ?>" <?php echo $value === 'active' ? 'selected' : ''; ?>>
                                    <?php echo $label; ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="bg-blue-50 p-4 rounded-lg">
                            <div class="flex items-center">
                                <i class="fas fa-info-circle text-blue-600 mr-2"></i>
                                <span class="text-sm text-blue-700">
                                    Default password will be generated automatically (first 4 letters of name + last 4 digits of phone).
                                </span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="flex justify-end gap-3 pt-6 border-t">
                        <button type="button" 
                                onclick="closeModal('addUserModal')" 
                                class="btn bg-gray-100 text-gray-700 hover:bg-gray-200">
                            Cancel
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save mr-2"></i> Save User
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Import Users Modal -->
    <div id="importModal" class="modal">
        <div class="modal-content">
            <div class="p-6">
                <div class="flex justify-between items-center mb-6">
                    <h3 class="text-xl font-bold text-gray-800">Import Users from CSV</h3>
                    <button onclick="closeModal('importModal')" class="text-gray-500 hover:text-gray-700">
                        <i class="fas fa-times text-xl"></i>
                    </button>
                </div>
                
                <div class="mb-6 bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                    <div class="flex items-start">
                        <i class="fas fa-exclamation-triangle text-yellow-600 mr-3 mt-1"></i>
                        <div>
                            <h4 class="font-bold text-yellow-800">CSV Format Requirements</h4>
                            <ul class="text-sm text-yellow-700 mt-2 space-y-1">
                                <li>• Required columns: Full Name, Email, Username, User Type, Phone, Campus ID</li>
                                <li>• Optional column: Status (default: active)</li>
                                <li>• First row should contain column headers</li>
                                <li>• User types: student, faculty, staff, coordinator, admin</li>
                                <li>• Status: active, inactive, suspended</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div class="mb-6">
                    <a href="sample_users.csv" 
                       download 
                       class="inline-flex items-center text-blue-600 hover:text-blue-800">
                        <i class="fas fa-download mr-2"></i>
                        Download Sample CSV File
                    </a>
                </div>
                
                <form method="POST" action="" enctype="multipart/form-data" class="space-y-6">
                    <input type="hidden" name="action" value="import_users">
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">CSV File *</label>
                        <div class="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-blue-500 transition-colors">
                            <i class="fas fa-file-csv text-4xl text-gray-400 mb-4"></i>
                            <p class="text-gray-600 mb-2">Drag & drop your CSV file here or click to browse</p>
                            <input type="file" 
                                   name="csv_file" 
                                   accept=".csv" 
                                   required
                                   class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100">
                        </div>
                    </div>
                    
                    <div class="flex justify-end gap-3 pt-6 border-t">
                        <button type="button" 
                                onclick="closeModal('importModal')" 
                                class="btn bg-gray-100 text-gray-700 hover:bg-gray-200">
                            Cancel
                        </button>
                        <button type="submit" class="btn bg-purple-500 hover:bg-purple-600 text-white">
                            <i class="fas fa-file-import mr-2"></i> Import Users
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script>
        // Modal functions
        function openAddUserModal() {
            document.getElementById('addUserModal').classList.add('active');
        }
        
        function openImportModal() {
            document.getElementById('importModal').classList.add('active');
        }
        
        function closeModal(modalId) {
            document.getElementById(modalId).classList.remove('active');
        }
        
        // Bulk selection functions
        function toggleSelectAll() {
            const selectAll = document.getElementById('selectAll');
            const checkboxes = document.querySelectorAll('.user-checkbox');
            
            checkboxes.forEach(checkbox => {
                checkbox.checked = selectAll.checked;
            });
        }
        
        function selectAllUsers() {
            const checkboxes = document.querySelectorAll('.user-checkbox');
            checkboxes.forEach(checkbox => {
                checkbox.checked = true;
            });
            document.getElementById('selectAll').checked = true;
        }
        
        function clearSelection() {
            const checkboxes = document.querySelectorAll('.user-checkbox');
            checkboxes.forEach(checkbox => {
                checkbox.checked = false;
            });
            document.getElementById('selectAll').checked = false;
        }
        
        function confirmBulkDelete() {
            const selectedCount = document.querySelectorAll('.user-checkbox:checked').length;
            if (selectedCount === 0) {
                alert('Please select at least one user to delete.');
                return false;
            }
            
            return confirm(`Are you sure you want to delete ${selectedCount} user(s)? This action cannot be undone.`);
        }
        
        // Update bulk delete form with selected user IDs
        document.addEventListener('DOMContentLoaded', function() {
            const bulkDeleteForm = document.getElementById('bulkDeleteForm');
            if (bulkDeleteForm) {
                bulkDeleteForm.addEventListener('submit', function(e) {
                    const checkboxes = document.querySelectorAll('.user-checkbox:checked');
                    const userIds = Array.from(checkboxes).map(cb => cb.value);
                    
                    // Add hidden inputs for each selected user ID
                    userIds.forEach(userId => {
                        const input = document.createElement('input');
                        input.type = 'hidden';
                        input.name = 'user_ids[]';
                        input.value = userId;
                        bulkDeleteForm.appendChild(input);
                    });
                });
            }
        });
        
        // Close modal when clicking outside
        window.addEventListener('click', function(e) {
            if (e.target.classList.contains('modal')) {
                e.target.classList.remove('active');
            }
        });
    </script>
</body>
</html>