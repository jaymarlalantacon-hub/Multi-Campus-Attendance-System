<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['full_name'];
$user_type = $_SESSION['user_type'];
$user_campus_id = $_SESSION['campus_id'];

// Check if user has permission to edit students
if ($user_type !== 'admin' && $user_type !== 'coordinator') {
    $_SESSION['error_message'] = "Access denied: You don't have permission to edit students.";
    header('Location: students.php');
    exit();
}

// Get student ID from URL
$student_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($student_id <= 0) {
    header('Location: students.php');
    exit();
}

// Get current student information
$student_query = "SELECT s.*, c.campus_name 
                  FROM students s 
                  LEFT JOIN campuses c ON s.campus_id = c.campus_id 
                  WHERE s.student_id = ?";
$student_stmt = $conn->prepare($student_query);
$student_stmt->bind_param("i", $student_id);
$student_stmt->execute();
$student_result = $student_stmt->get_result();

if ($student_result->num_rows === 0) {
    $_SESSION['error_message'] = "Student not found.";
    header('Location: students.php');
    exit();
}

$student = $student_result->fetch_assoc();

// Check if coordinator has access to this student's campus
if ($user_type === 'coordinator' && $student['campus_id'] != $user_campus_id) {
    $_SESSION['error_message'] = "Access denied: You don't have permission to edit this student.";
    header('Location: students.php');
    exit();
}

// Get campuses for dropdown
$campuses_query = "SELECT * FROM campuses WHERE status = 'active'";
if ($user_type === 'coordinator') {
    $campuses_query .= " AND campus_id = ?";
    $campuses_stmt = $conn->prepare($campuses_query);
    $campuses_stmt->bind_param("i", $user_campus_id);
} else {
    $campuses_stmt = $conn->prepare($campuses_query);
}
$campuses_stmt->execute();
$campuses_result = $campuses_stmt->get_result();
$campuses = [];
while ($campus = $campuses_result->fetch_assoc()) {
    $campuses[] = $campus;
}

// Handle form submission
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $full_name = trim($_POST['full_name']);
    $student_number = trim($_POST['student_number']);
    $email = trim($_POST['email']) ?: null;
    $phone = trim($_POST['phone']) ?: null;
    $campus_id = intval($_POST['campus_id']);
    $course_year = trim($_POST['course_year']) ?: null;
    $section = trim($_POST['section']) ?: null;
    $status = $_POST['status'] ?? 'active';
    
    // Validate required fields
    if (empty($full_name) || empty($student_number) || empty($campus_id)) {
        $error_message = "Please fill in all required fields.";
    } else {
        // Check if student number already exists (excluding current student)
        $check_query = "SELECT student_id FROM students WHERE student_number = ? AND student_id != ?";
        $check_stmt = $conn->prepare($check_query);
        $check_stmt->bind_param("si", $student_number, $student_id);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        
        if ($check_result->num_rows > 0) {
            $error_message = "Student number already exists. Please use a different student number.";
        } else {
            // Handle photo upload
            $photo_path = $student['photo']; // Keep existing photo by default
            
            if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
                $photo = $_FILES['photo'];
                
                // Validate file type
                $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
                if (!in_array($photo['type'], $allowed_types)) {
                    $error_message = "Invalid file type. Only JPG, PNG, and GIF images are allowed.";
                } elseif ($photo['size'] > 5 * 1024 * 1024) { // 5MB limit
                    $error_message = "File is too large. Maximum size is 5MB.";
                } else {
                    // Generate unique filename
                    $file_extension = pathinfo($photo['name'], PATHINFO_EXTENSION);
                    $new_filename = 'student_' . $student_id . '_' . time() . '.' . $file_extension;
                    $upload_path = 'uploads/students/' . $new_filename;
                    
                    // Create directory if it doesn't exist
                    if (!file_exists('uploads/students')) {
                        mkdir('uploads/students', 0777, true);
                    }
                    
                    if (move_uploaded_file($photo['tmp_name'], $upload_path)) {
                        // Delete old photo if it exists and is not default
                        if ($student['photo'] && file_exists($student['photo']) && 
                            !str_contains($student['photo'], 'default_avatar.png')) {
                            unlink($student['photo']);
                        }
                        $photo_path = $upload_path;
                    } else {
                        $error_message = "Failed to upload photo. Please try again.";
                    }
                }
            } elseif ($_FILES['photo']['error'] !== UPLOAD_ERR_NO_FILE) {
                $error_message = "Error uploading photo. Error code: " . $_FILES['photo']['error'];
            }
            
            if (empty($error_message)) {
                // Update student information
                $update_query = "UPDATE students SET 
                                full_name = ?, 
                                student_number = ?, 
                                email = ?, 
                                phone = ?, 
                                campus_id = ?, 
                                course_year = ?, 
                                section = ?, 
                                status = ?, 
                                photo = ?,
                                updated_at = NOW()
                                WHERE student_id = ?";
                
                $update_stmt = $conn->prepare($update_query);
                $update_stmt->bind_param("ssssissssi", 
                    $full_name, 
                    $student_number, 
                    $email, 
                    $phone, 
                    $campus_id, 
                    $course_year, 
                    $section, 
                    $status, 
                    $photo_path,
                    $student_id
                );
                
                if ($update_stmt->execute()) {
                    $success_message = "Student information updated successfully!";
                    
                    // Update session if editing own profile
                    if ($user_type === 'student' && $student_id == $_SESSION['user_id']) {
                        $_SESSION['full_name'] = $full_name;
                        $_SESSION['student_number'] = $student_number;
                        $_SESSION['campus_id'] = $campus_id;
                        if ($photo_path) {
                            $_SESSION['photo'] = $photo_path;
                        }
                    }
                    
                    // Refresh student data
                    $student_stmt->execute();
                    $student_result = $student_stmt->get_result();
                    $student = $student_result->fetch_assoc();
                } else {
                    $error_message = "Failed to update student information. Please try again.";
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Student | <?php echo htmlspecialchars($student['full_name']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #3b82f6;
            --secondary-color: #8b5cf6;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
        }
        
        .card {
            background: white;
            border-radius: 1rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        
        .card:hover {
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }
        
        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        
        .status-active { background-color: #d1fae5; color: #065f46; }
        .status-inactive { background-color: #fee2e2; color: #991b1b; }
        .status-graduated { background-color: #dbeafe; color: #1e40af; }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }
        
        .modal.active {
            display: flex;
        }
        
        .modal-content {
            background: white;
            border-radius: 1rem;
            width: 90%;
            max-width: 500px;
            max-height: 90vh;
            overflow-y: auto;
        }
        
        .tab {
            padding: 0.75rem 1.5rem;
            border-radius: 0.75rem;
            font-weight: 600;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        
        .tab.active {
            background: var(--primary-color);
            color: white;
        }
        
        .tab:hover:not(.active) {
            background: #f3f4f6;
        }
        
        .hidden {
            display: none !important;
        }
        
        .photo-preview {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid #e5e7eb;
            transition: all 0.3s ease;
        }
        
        .photo-preview:hover {
            border-color: var(--primary-color);
            transform: scale(1.05);
        }
        
        .photo-upload-area {
            border: 2px dashed #d1d5db;
            border-radius: 0.75rem;
            padding: 2rem;
            text-align: center;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        
        .photo-upload-area:hover {
            border-color: var(--primary-color);
            background-color: #f0f9ff;
        }
        
        .photo-upload-area.dragover {
            border-color: var(--primary-color);
            background-color: #e0f2fe;
        }
        
        .required::after {
            content: " *";
            color: var(--danger-color);
        }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
    <!-- Navigation -->
    <nav class="bg-gradient-to-r from-blue-800 to-indigo-900 text-white shadow-lg">
        <div class="container mx-auto px-4 py-3">
            <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div class="flex items-center space-x-4">
                    <a href="student_profile.php?id=<?php echo $student_id; ?>" class="flex items-center hover:text-blue-200 transition-colors">
                        <i class="fas fa-arrow-left mr-2"></i> Back to Profile
                    </a>
                    <h1 class="text-xl font-bold">
                        <i class="fas fa-user-edit mr-2"></i> Edit Student
                    </h1>
                </div>
                <div class="flex items-center space-x-4">
                    <span class="text-sm">
                        <i class="fas fa-user mr-1"></i> <?php echo htmlspecialchars($user_name); ?>
                    </span>
                    <span class="px-3 py-1 bg-blue-600 rounded-full text-sm">
                        <i class="fas fa-shield-alt mr-1"></i> <?php echo ucfirst($user_type); ?>
                    </span>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-8">
        <!-- Messages -->
        <?php if ($success_message): ?>
        <div class="mb-6 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg animate-in">
            <div class="flex items-center">
                <i class="fas fa-check-circle mr-3 text-green-600"></i>
                <span><?php echo htmlspecialchars($success_message); ?></span>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if ($error_message): ?>
        <div class="mb-6 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg animate-in">
            <div class="flex items-center">
                <i class="fas fa-exclamation-circle mr-3 text-red-600"></i>
                <span><?php echo htmlspecialchars($error_message); ?></span>
            </div>
        </div>
        <?php endif; ?>

        <!-- Edit Form -->
        <div class="card p-6 mb-8">
            <h2 class="text-2xl font-bold text-gray-800 mb-6">Edit Student Information</h2>
            
            <form method="POST" action="" enctype="multipart/form-data" class="space-y-6">
                <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <!-- Left Column - Photo -->
                    <div class="md:col-span-1">
                        <div class="space-y-4">
                            <div class="text-center">
                                <div class="relative inline-block">
                                    <img id="photoPreview" 
                                         src="<?php echo htmlspecialchars($student['photo'] ?? 'images/default_avatar.png'); ?>" 
                                         alt="Student Photo" 
                                         class="photo-preview mx-auto mb-4">
                                    
                                    <?php if ($student['photo'] && !str_contains($student['photo'], 'default_avatar.png')): ?>
                                    <button type="button" 
                                            onclick="removePhoto()" 
                                            class="absolute top-0 right-0 bg-red-500 text-white rounded-full w-8 h-8 flex items-center justify-center hover:bg-red-600">
                                        <i class="fas fa-times"></i>
                                    </button>
                                    <?php endif; ?>
                                </div>
                                
                                <div id="photoUploadArea" class="photo-upload-area mb-4">
                                    <i class="fas fa-camera text-3xl text-gray-400 mb-3"></i>
                                    <p class="text-gray-600 mb-2">Click to upload or drag and drop</p>
                                    <p class="text-sm text-gray-500">JPG, PNG or GIF (Max 5MB)</p>
                                    <input type="file" 
                                           id="photoInput" 
                                           name="photo" 
                                           accept="image/*" 
                                           class="hidden">
                                </div>
                                
                                <div id="currentPhotoInfo" class="text-sm text-gray-500">
                                    <?php if ($student['photo'] && !str_contains($student['photo'], 'default_avatar.png')): ?>
                                    <p>Current photo uploaded</p>
                                    <?php else: ?>
                                    <p>Using default avatar</p>
                                    <?php endif; ?>
                                </div>
                                
                                <input type="hidden" id="removePhotoFlag" name="remove_photo" value="0">
                            </div>
                        </div>
                    </div>
                    
                    <!-- Right Column - Form Fields -->
                    <div class="md:col-span-2">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <!-- Full Name -->
                            <div class="col-span-2">
                                <label for="full_name" class="block text-sm font-medium text-gray-700 mb-2 required">
                                    Full Name
                                </label>
                                <input type="text" 
                                       id="full_name" 
                                       name="full_name" 
                                       value="<?php echo htmlspecialchars($student['full_name']); ?>" 
                                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                       required>
                            </div>
                            
                            <!-- Student Number -->
                            <div>
                                <label for="student_number" class="block text-sm font-medium text-gray-700 mb-2 required">
                                    Student Number
                                </label>
                                <input type="text" 
                                       id="student_number" 
                                       name="student_number" 
                                       value="<?php echo htmlspecialchars($student['student_number']); ?>" 
                                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                       required>
                            </div>
                            
                            <!-- Campus -->
                            <div>
                                <label for="campus_id" class="block text-sm font-medium text-gray-700 mb-2 required">
                                    Campus
                                </label>
                                <select id="campus_id" 
                                        name="campus_id" 
                                        class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                        required
                                        <?php echo $user_type === 'coordinator' ? 'disabled' : ''; ?>>
                                    <option value="">Select Campus</option>
                                    <?php foreach ($campuses as $campus): ?>
                                    <option value="<?php echo $campus['campus_id']; ?>" 
                                            <?php echo $student['campus_id'] == $campus['campus_id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($campus['campus_name']); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                                <?php if ($user_type === 'coordinator'): ?>
                                <input type="hidden" name="campus_id" value="<?php echo $student['campus_id']; ?>">
                                <?php endif; ?>
                            </div>
                            
                            <!-- Email -->
                            <div>
                                <label for="email" class="block text-sm font-medium text-gray-700 mb-2">
                                    Email Address
                                </label>
                                <input type="email" 
                                       id="email" 
                                       name="email" 
                                       value="<?php echo htmlspecialchars($student['email'] ?? ''); ?>" 
                                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                            </div>
                            
                            <!-- Phone -->
                            <div>
                                <label for="phone" class="block text-sm font-medium text-gray-700 mb-2">
                                    Phone Number
                                </label>
                                <input type="tel" 
                                       id="phone" 
                                       name="phone" 
                                       value="<?php echo htmlspecialchars($student['phone'] ?? ''); ?>" 
                                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                            </div>
                            
                            <!-- Course/Year -->
                            <div>
                                <label for="course_year" class="block text-sm font-medium text-gray-700 mb-2">
                                    Course/Year Level
                                </label>
                                <input type="text" 
                                       id="course_year" 
                                       name="course_year" 
                                       value="<?php echo htmlspecialchars($student['course_year'] ?? ''); ?>" 
                                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                       placeholder="e.g., BSIT-3">
                            </div>
                            
                            <!-- Section -->
                            <div>
                                <label for="section" class="block text-sm font-medium text-gray-700 mb-2">
                                    Section
                                </label>
                                <input type="text" 
                                       id="section" 
                                       name="section" 
                                       value="<?php echo htmlspecialchars($student['section'] ?? ''); ?>" 
                                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                       placeholder="e.g., A">
                            </div>
                            
                            <!-- Status -->
                            <div>
                                <label for="status" class="block text-sm font-medium text-gray-700 mb-2">
                                    Status
                                </label>
                                <select id="status" 
                                        name="status" 
                                        class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                    <option value="active" <?php echo $student['status'] === 'active' ? 'selected' : ''; ?>>Active</option>
                                    <option value="inactive" <?php echo $student['status'] === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                                    <option value="graduated" <?php echo $student['status'] === 'graduated' ? 'selected' : ''; ?>>Graduated</option>
                                </select>
                            </div>
                        </div>
                        
                        <!-- Timestamps (Readonly) -->
                        <div class="mt-8 pt-6 border-t border-gray-200">
                            <h3 class="text-lg font-semibold text-gray-700 mb-4">Account Information</h3>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-1">Created At</label>
                                    <input type="text" 
                                           value="<?php echo date('F j, Y g:i A', strtotime($student['created_at'])); ?>" 
                                           class="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-50" 
                                           readonly>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-1">Last Updated</label>
                                    <input type="text" 
                                           value="<?php echo date('F j, Y g:i A', strtotime($student['updated_at'])); ?>" 
                                           class="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-50" 
                                           readonly>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Action Buttons -->
                <div class="flex justify-between items-center pt-6 border-t border-gray-200">
                    <div>
                        <a href="student_profile.php?id=<?php echo $student_id; ?>" 
                           class="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
                            <i class="fas fa-times mr-2"></i> Cancel
                        </a>
                    </div>
                    <div class="flex gap-3">
                        <button type="button" 
                                onclick="showResetModal()" 
                                class="px-4 py-2 border border-yellow-300 text-yellow-700 rounded-lg hover:bg-yellow-50 transition-colors">
                            <i class="fas fa-undo mr-2"></i> Reset Changes
                        </button>
                        <button type="submit" 
                                class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                            <i class="fas fa-save mr-2"></i> Save Changes
                        </button>
                    </div>
                </div>
            </form>
        </div>

        <!-- Additional Options Card -->
        <div class="card p-6">
            <h3 class="text-xl font-bold text-gray-800 mb-6">Additional Options</h3>
            
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <!-- View QR Code -->
                <a href="view_qr.php?student_id=<?php echo $student_id; ?>" 
                   class="p-4 border border-gray-200 rounded-lg hover:border-blue-300 hover:bg-blue-50 transition-all">
                    <div class="flex items-center space-x-3">
                        <div class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                            <i class="fas fa-qrcode text-blue-600"></i>
                        </div>
                        <div>
                            <h4 class="font-semibold text-gray-800">View QR Code</h4>
                            <p class="text-sm text-gray-600">View student's QR code</p>
                        </div>
                    </div>
                </a>
                
                <!-- Generate New QR Code -->
                <button type="button" 
                        onclick="showGenerateQRModal()"
                        class="p-4 border border-gray-200 rounded-lg hover:border-green-300 hover:bg-green-50 transition-all text-left">
                    <div class="flex items-center space-x-3">
                        <div class="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                            <i class="fas fa-sync-alt text-green-600"></i>
                        </div>
                        <div>
                            <h4 class="font-semibold text-gray-800">Generate New QR</h4>
                            <p class="text-sm text-gray-600">Create new QR code</p>
                        </div>
                    </div>
                </button>
                
                <!-- Reset Password -->
                <?php if ($user_type === 'admin' || $user_type === 'coordinator'): ?>
                <button type="button" 
                        onclick="showResetPasswordModal()"
                        class="p-4 border border-gray-200 rounded-lg hover:border-red-300 hover:bg-red-50 transition-all text-left">
                    <div class="flex items-center space-x-3">
                        <div class="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                            <i class="fas fa-key text-red-600"></i>
                        </div>
                        <div>
                            <h4 class="font-semibold text-gray-800">Reset Password</h4>
                            <p class="text-sm text-gray-600">Reset student's password</p>
                        </div>
                    </div>
                </button>
                <?php endif; ?>
                
                <!-- View Fines -->
                <a href="student_profile.php?id=<?php echo $student_id; ?>#fines" 
                   class="p-4 border border-gray-200 rounded-lg hover:border-yellow-300 hover:bg-yellow-50 transition-all">
                    <div class="flex items-center space-x-3">
                        <div class="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
                            <i class="fas fa-file-invoice-dollar text-yellow-600"></i>
                        </div>
                        <div>
                            <h4 class="font-semibold text-gray-800">View Fines</h4>
                            <p class="text-sm text-gray-600">Check fines history</p>
                        </div>
                    </div>
                </a>
                
                <!-- View Attendance -->
                <a href="student_profile.php?id=<?php echo $student_id; ?>#attendance" 
                   class="p-4 border border-gray-200 rounded-lg hover:border-purple-300 hover:bg-purple-50 transition-all">
                    <div class="flex items-center space-x-3">
                        <div class="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                            <i class="fas fa-calendar-check text-purple-600"></i>
                        </div>
                        <div>
                            <h4 class="font-semibold text-gray-800">View Attendance</h4>
                            <p class="text-sm text-gray-600">Check attendance records</p>
                        </div>
                    </div>
                </a>
                
                <!-- Delete Student (Admin only) -->
                <?php if ($user_type === 'admin'): ?>
                <button type="button" 
                        onclick="showDeleteModal()"
                        class="p-4 border border-gray-200 rounded-lg hover:border-red-300 hover:bg-red-50 transition-all text-left">
                    <div class="flex items-center space-x-3">
                        <div class="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                            <i class="fas fa-trash-alt text-red-600"></i>
                        </div>
                        <div>
                            <h4 class="font-semibold text-gray-800">Delete Student</h4>
                            <p class="text-sm text-gray-600">Permanently remove student</p>
                        </div>
                    </div>
                </button>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Modals -->
    
    <!-- Reset Confirmation Modal -->
    <div id="resetModal" class="modal">
        <div class="modal-content">
            <div class="p-6">
                <div class="flex justify-between items-center mb-6">
                    <h3 class="text-xl font-bold text-gray-800">Reset Changes</h3>
                    <button onclick="closeModal('resetModal')" class="text-gray-400 hover:text-gray-600">
                        <i class="fas fa-times text-xl"></i>
                    </button>
                </div>
                
                <div class="space-y-4">
                    <p class="text-gray-700">Are you sure you want to reset all changes? This will restore the original values.</p>
                    
                    <div class="flex justify-end gap-3 mt-8">
                        <button type="button" onclick="closeModal('resetModal')" 
                                class="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
                            Cancel
                        </button>
                        <button type="button" onclick="resetForm()" 
                                class="px-4 py-2 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700 transition-colors">
                            <i class="fas fa-undo mr-2"></i> Reset
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Generate QR Code Modal -->
    <div id="generateQRModal" class="modal">
        <div class="modal-content">
            <div class="p-6">
                <div class="flex justify-between items-center mb-6">
                    <h3 class="text-xl font-bold text-gray-800">Generate New QR Code</h3>
                    <button onclick="closeModal('generateQRModal')" class="text-gray-400 hover:text-gray-600">
                        <i class="fas fa-times text-xl"></i>
                    </button>
                </div>
                
                <form id="generateQRForm" method="POST" action="generate_qr.php">
                    <input type="hidden" name="student_id" value="<?php echo $student_id; ?>">
                    
                    <div class="space-y-4">
                        <p class="text-gray-700">This will generate a new QR code for <?php echo htmlspecialchars($student['full_name']); ?>. The old QR code will no longer work.</p>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">QR Code Type</label>
                            <select name="qr_type" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                <option value="attendance">Attendance QR Code</option>
                                <option value="payment">Payment QR Code</option>
                                <option value="both">Both Attendance and Payment</option>
                            </select>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Expiration (Optional)</label>
                            <input type="date" name="expiry_date" 
                                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                   min="<?php echo date('Y-m-d'); ?>">
                            <p class="text-xs text-gray-500 mt-1">Leave empty for no expiration</p>
                        </div>
                    </div>
                    
                    <div class="flex justify-end gap-3 mt-8">
                        <button type="button" onclick="closeModal('generateQRModal')" 
                                class="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
                            Cancel
                        </button>
                        <button type="submit" 
                                class="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                            <i class="fas fa-sync-alt mr-2"></i> Generate QR
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Reset Password Modal -->
    <div id="resetPasswordModal" class="modal">
        <div class="modal-content">
            <div class="p-6">
                <div class="flex justify-between items-center mb-6">
                    <h3 class="text-xl font-bold text-gray-800">Reset Password</h3>
                    <button onclick="closeModal('resetPasswordModal')" class="text-gray-400 hover:text-gray-600">
                        <i class="fas fa-times text-xl"></i>
                    </button>
                </div>
                
                <form id="resetPasswordForm" method="POST" action="reset_password.php">
                    <input type="hidden" name="student_id" value="<?php echo $student_id; ?>">
                    
                    <div class="space-y-4">
                        <p class="text-gray-700">Reset password for <?php echo htmlspecialchars($student['full_name']); ?> (<?php echo htmlspecialchars($student['student_number']); ?>)</p>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">New Password</label>
                            <div class="relative">
                                <input type="password" name="new_password" id="newPassword" 
                                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                       required>
                                <button type="button" onclick="togglePassword('newPassword')" 
                                        class="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Confirm Password</label>
                            <div class="relative">
                                <input type="password" name="confirm_password" id="confirmPassword" 
                                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                       required>
                                <button type="button" onclick="togglePassword('confirmPassword')" 
                                        class="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        
                        <div class="bg-yellow-50 border border-yellow-200 p-4 rounded-lg">
                            <div class="flex items-start">
                                <i class="fas fa-exclamation-triangle text-yellow-600 mt-1 mr-3"></i>
                                <div>
                                    <p class="text-sm text-yellow-800 font-semibold">Important</p>
                                    <p class="text-sm text-yellow-700 mt-1">The student will need to use this new password to log in. Make sure to share it securely.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="flex justify-end gap-3 mt-8">
                        <button type="button" onclick="closeModal('resetPasswordModal')" 
                                class="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
                            Cancel
                        </button>
                        <button type="submit" 
                                class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
                            <i class="fas fa-key mr-2"></i> Reset Password
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Delete Student Modal -->
    <div id="deleteModal" class="modal">
        <div class="modal-content">
            <div class="p-6">
                <div class="flex justify-between items-center mb-6">
                    <h3 class="text-xl font-bold text-gray-800">Delete Student</h3>
                    <button onclick="closeModal('deleteModal')" class="text-gray-400 hover:text-gray-600">
                        <i class="fas fa-times text-xl"></i>
                    </button>
                </div>
                
                <div class="space-y-4">
                    <div class="bg-red-50 border border-red-200 p-4 rounded-lg">
                        <div class="flex items-start">
                            <i class="fas fa-exclamation-circle text-red-600 mt-1 mr-3"></i>
                            <div>
                                <p class="text-sm text-red-800 font-semibold">Warning: This action cannot be undone!</p>
                                <p class="text-sm text-red-700 mt-1">You are about to permanently delete <?php echo htmlspecialchars($student['full_name']); ?> from the system.</p>
                            </div>
                        </div>
                    </div>
                    
                    <div>
                        <p class="text-gray-700 mb-2">Please type the student's name to confirm deletion:</p>
                        <input type="text" id="confirmDelete" 
                               placeholder="Type '<?php echo htmlspecialchars($student['full_name']); ?>' to confirm" 
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    </div>
                    
                    <div>
                        <label class="flex items-center">
                            <input type="checkbox" id="deleteAttendance" class="mr-2">
                            <span class="text-sm text-gray-700">Also delete all attendance records</span>
                        </label>
                    </div>
                    
                    <div>
                        <label class="flex items-center">
                            <input type="checkbox" id="deleteFines" class="mr-2">
                            <span class="text-sm text-gray-700">Also delete all fines and payment records</span>
                        </label>
                    </div>
                    
                    <div class="flex justify-end gap-3 mt-8">
                        <button type="button" onclick="closeModal('deleteModal')" 
                                class="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
                            Cancel
                        </button>
                        <button type="button" onclick="deleteStudent()" id="deleteButton" 
                                disabled
                                class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors opacity-50 cursor-not-allowed">
                            <i class="fas fa-trash-alt mr-2"></i> Delete Student
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>

    <script>
        // Photo upload functionality
        const photoInput = document.getElementById('photoInput');
        const photoPreview = document.getElementById('photoPreview');
        const photoUploadArea = document.getElementById('photoUploadArea');
        const removePhotoFlag = document.getElementById('removePhotoFlag');
        const currentPhotoInfo = document.getElementById('currentPhotoInfo');
        
        // Click to upload
        photoUploadArea.addEventListener('click', () => {
            photoInput.click();
        });
        
        // Drag and drop
        photoUploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            photoUploadArea.classList.add('dragover');
        });
        
        photoUploadArea.addEventListener('dragleave', () => {
            photoUploadArea.classList.remove('dragover');
        });
        
        photoUploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            photoUploadArea.classList.remove('dragover');
            
            if (e.dataTransfer.files.length) {
                photoInput.files = e.dataTransfer.files;
                previewPhoto(e.dataTransfer.files[0]);
            }
        });
        
        // File input change
        photoInput.addEventListener('change', (e) => {
            if (e.target.files.length) {
                previewPhoto(e.target.files[0]);
            }
        });
        
        function previewPhoto(file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                photoPreview.src = e.target.result;
                removePhotoFlag.value = '0';
                currentPhotoInfo.innerHTML = '<p class="text-green-600">New photo selected</p>';
            };
            reader.readAsDataURL(file);
        }
        
        function removePhoto() {
            photoPreview.src = 'images/default_avatar.png';
            photoInput.value = '';
            removePhotoFlag.value = '1';
            currentPhotoInfo.innerHTML = '<p class="text-red-600">Photo will be removed</p>';
        }
        
        // Form reset
        function resetForm() {
            document.querySelector('form').reset();
            photoPreview.src = '<?php echo htmlspecialchars($student['photo'] ?? 'images/default_avatar.png'); ?>';
            photoInput.value = '';
            removePhotoFlag.value = '0';
            currentPhotoInfo.innerHTML = '<?php 
                if ($student['photo'] && !str_contains($student['photo'], 'default_avatar.png')) {
                    echo "<p>Current photo uploaded</p>";
                } else {
                    echo "<p>Using default avatar</p>";
                }
            ?>';
            closeModal('resetModal');
        }
        
        // Password toggle
        function togglePassword(inputId) {
            const input = document.getElementById(inputId);
            const icon = input.nextElementSibling.querySelector('i');
            
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }
        
        // Delete confirmation
        document.getElementById('confirmDelete').addEventListener('input', function() {
            const deleteButton = document.getElementById('deleteButton');
            const studentName = '<?php echo htmlspecialchars($student['full_name']); ?>';
            
            if (this.value === studentName) {
                deleteButton.disabled = false;
                deleteButton.classList.remove('opacity-50', 'cursor-not-allowed');
            } else {
                deleteButton.disabled = true;
                deleteButton.classList.add('opacity-50', 'cursor-not-allowed');
            }
        });
        
        function deleteStudent() {
            const deleteAttendance = document.getElementById('deleteAttendance').checked;
            const deleteFines = document.getElementById('deleteFines').checked;
            
            // Redirect to delete script with parameters
            window.location.href = `delete_student.php?id=<?php echo $student_id; ?>&attendance=${deleteAttendance ? 1 : 0}&fines=${deleteFines ? 1 : 0}`;
        }
        
        // Modal functions
        function showResetModal() {
            document.getElementById('resetModal').classList.add('active');
        }
        
        function showGenerateQRModal() {
            document.getElementById('generateQRModal').classList.add('active');
        }
        
        function showResetPasswordModal() {
            document.getElementById('resetPasswordModal').classList.add('active');
        }
        
        function showDeleteModal() {
            document.getElementById('deleteModal').classList.add('active');
        }
        
        function closeModal(modalId) {
            document.getElementById(modalId).classList.remove('active');
        }
        
        // Close modal when clicking outside
        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('click', function(e) {
                if (e.target === this) {
                    this.classList.remove('active');
                }
            });
        });
        
        // Form validation
        document.querySelector('form').addEventListener('submit', function(e) {
            const studentNumber = document.getElementById('student_number').value;
            const email = document.getElementById('email').value;
            
            // Validate student number format (customize as needed)
            if (!/^[A-Za-z0-9\-]+$/.test(studentNumber)) {
                alert('Student number can only contain letters, numbers, and hyphens.');
                e.preventDefault();
                return;
            }
            
            // Validate email if provided
            if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                alert('Please enter a valid email address.');
                e.preventDefault();
                return;
            }
        });
        
        // Auto-format phone number
        document.getElementById('phone').addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length > 10) value = value.substring(0, 10);
            
            if (value.length >= 4) {
                value = value.replace(/(\d{3})(\d{3})(\d{4})/, '($1) $2-$3');
            } else if (value.length >= 3) {
                value = value.replace(/(\d{3})(\d{1,})/, '($1) $2');
            }
            
            e.target.value = value;
        });
    </script>
</body>
</html>