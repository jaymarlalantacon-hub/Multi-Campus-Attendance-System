<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_type']) || !in_array($_SESSION['user_type'], ['admin','coordinator'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$attendance_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($attendance_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid attendance ID']);
    exit();
}

$query = "
    SELECT 
        a.*,
        s.student_number,
        s.full_name,
        s.email,
        s.course_year,
        s.section,
        ac.activity_name,
        ac.activity_date,
        ac.activity_time,
        ac.venue,
        c.campus_name,
        u.full_name as checked_by_name
    FROM attendance a
    LEFT JOIN students s ON a.student_id = s.student_id
    LEFT JOIN activities ac ON a.activity_id = ac.activity_id
    LEFT JOIN campuses c ON s.campus_id = c.campus_id
    LEFT JOIN users u ON a.checked_by = u.user_id
    WHERE a.attendance_id = ?
";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $attendance_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $record = $result->fetch_assoc();
    echo json_encode(['success' => true, 'record' => $record]);
} else {
    echo json_encode(['success' => false, 'message' => 'Record not found']);
}

$conn->close();
?>