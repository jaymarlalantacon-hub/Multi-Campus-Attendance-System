<?php
session_start();
require_once 'db.php';

// PHPMailer namespaces at the top of the file
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Check authentication
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Check permission (admin or coordinator)
if (!in_array($_SESSION['user_type'], ['admin', 'coordinator'])) {
    header('Location: login.php');
    exit();
}

$user_name = $_SESSION['full_name'];
$user_type = $_SESSION['user_type'];
$user_campus_id = $_SESSION['campus_id'];

// Load campuses
$campuses = [];
if ($_SESSION['user_type'] === 'admin') {
    $result = $conn->query("SELECT * FROM campuses WHERE status = 'active' ORDER BY campus_name");
} else {
    // Coordinator can only add students for their campus
    $stmt = $conn->prepare("SELECT * FROM campuses WHERE campus_id = ? AND status = 'active'");
    $stmt->bind_param("i", $user_campus_id);
    $stmt->execute();
    $result = $stmt->get_result();
}

while ($row = $result->fetch_assoc()) {
    $campuses[] = $row;
}

// Process form submission
$success = $error = '';
$student_data = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_student'])) {
    // Use isset() to check if fields exist before accessing them
    $full_name = isset($_POST['full_name']) ? trim($_POST['full_name']) : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $phone = isset($_POST['phone']) ? trim($_POST['phone']) : '';
    $campus_id = isset($_POST['campus_id']) ? intval($_POST['campus_id']) : 0;
    $course_year = isset($_POST['course_year']) ? trim($_POST['course_year']) : '';
    $section = isset($_POST['section']) ? trim($_POST['section']) : '';
    $student_number = isset($_POST['student_number']) ? trim($_POST['student_number']) : '';
    
    // Validate permission
    if ($user_type === 'coordinator' && $campus_id != $user_campus_id) {
        $error = "You can only add students for your assigned campus.";
    } elseif (empty($full_name) || empty($campus_id) || empty($course_year)) {
        $error = "Please fill all required fields!";
    } else {
        // Generate student number if not provided
        if (empty($student_number)) {
            $year = date('Y');
            $random = rand(10000, 99999);
            $student_number = "STU{$year}{$random}";
        } else {
            // Check if student number already exists
            $checkStmt = $conn->prepare("SELECT student_id FROM students WHERE student_number = ?");
            $checkStmt->bind_param("s", $student_number);
            $checkStmt->execute();
            $checkResult = $checkStmt->get_result();
            
            if ($checkResult->num_rows > 0) {
                $error = "Student number already exists!";
            }
        }
        
        // Check if email already exists (only if email is provided)
        if (empty($error) && !empty($email)) {
            $checkEmail = $conn->prepare("SELECT student_id FROM students WHERE email = ?");
            $checkEmail->bind_param("s", $email);
            $checkEmail->execute();
            $checkEmailResult = $checkEmail->get_result();
            
            if ($checkEmailResult->num_rows > 0) {
                $error = "Email already registered!";
            }
        }
        
        if (empty($error)) {
            try {
                $conn->begin_transaction();
                
                // Handle photo upload
                $photo_path = null;
                if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
                    $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
                    $file_type = mime_content_type($_FILES['photo']['tmp_name']);
                    $max_size = 5 * 1024 * 1024; // 5MB
                    
                    if (in_array($file_type, $allowed_types) && $_FILES['photo']['size'] <= $max_size) {
                        // Create uploads directory if not exists
                        if (!file_exists('uploads/students')) {
                            mkdir('uploads/students', 0777, true);
                        }
                        
                        // Generate unique filename
                        $extension = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
                        $filename = strtolower(str_replace(' ', '_', $student_number)) . '.' . $extension;
                        $photo_path = 'uploads/students/' . $filename;
                        
                        // Move uploaded file
                        if (move_uploaded_file($_FILES['photo']['tmp_name'], $photo_path)) {
                            // Resize image to 300x300
                            resizeImage($photo_path, 300, 300);
                        } else {
                            $photo_path = null;
                        }
                    }
                }
                
                // Insert new student
                $stmt = $conn->prepare("INSERT INTO students (student_number, full_name, email, phone, photo, campus_id, course_year, section, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active', NOW())");
                $stmt->bind_param("sssssiss", $student_number, $full_name, $email, $phone, $photo_path, $campus_id, $course_year, $section);
                
                if ($stmt->execute()) {
                    $student_id = $stmt->insert_id;
                    
                    // Generate QR code
                    $qr_filename = generateQRCode($student_id, $student_number, $full_name, $campus_id);
                    
                    // Update student with QR code path
                    $update_qr = $conn->prepare("UPDATE students SET qr_code_path = ? WHERE student_id = ?");
                    $update_qr->bind_param("si", $qr_filename, $student_id);
                    $update_qr->execute();
                    
                    // Get campus name for display
                    $campus_stmt = $conn->prepare("SELECT campus_name FROM campuses WHERE campus_id = ?");
                    $campus_stmt->bind_param("i", $campus_id);
                    $campus_stmt->execute();
                    $campus_result = $campus_stmt->get_result();
                    $campus = $campus_result->fetch_assoc();
                    
                    $student_data = [
                        'student_id' => $student_id,
                        'student_number' => $student_number,
                        'full_name' => $full_name,
                        'email' => $email,
                        'phone' => $phone,
                        'campus_name' => $campus['campus_name'],
                        'course_year' => $course_year,
                        'section' => $section,
                        'photo_path' => $photo_path,
                        'qr_path' => $qr_filename,
                        'created_by' => $_SESSION['user_id']
                    ];
                    
                    // Send QR code to student's email if email is provided
                    $email_sent = false;
                    $email_message = '';
                    if (!empty($email) && filter_var($email, FILTER_VALIDATE_EMAIL)) {
                        $email_sent = sendQRCodeWithPHPMailer($email, $full_name, $student_number, $qr_filename, $campus['campus_name'], $course_year, $section);
                        if ($email_sent) {
                            $email_message = " QR code has been sent to $email.";
                        } else {
                            $email_message = " QR code generated but email could not be sent (check SMTP settings).";
                        }
                    } elseif (!empty($email)) {
                        $email_message = " Invalid email format. QR code generated but not sent.";
                    }
                    
                    // Log the action
                    $log_stmt = $conn->prepare("INSERT INTO scan_logs (student_code, student_id, action, user_id, user_type, created_at) VALUES (?, ?, 'student_added', ?, ?, NOW())");
                    $log_stmt->bind_param("siis", $student_number, $student_id, $_SESSION['user_id'], $_SESSION['user_type']);
                    $log_stmt->execute();
                    
                    $success = "Student added successfully!" . $email_message;
                    $conn->commit();
                } else {
                    $error = "Failed to add student. Please try again.";
                    $conn->rollback();
                }
            } catch (Exception $e) {
                $conn->rollback();
                $error = "Error: " . $e->getMessage();
            }
        }
    }
}

// Function to resize image
function resizeImage($file, $width, $height) {
    $info = getimagesize($file);
    $mime = $info['mime'];
    
    switch ($mime) {
        case 'image/jpeg':
            $image = imagecreatefromjpeg($file);
            break;
        case 'image/png':
            $image = imagecreatefrompng($file);
            break;
        case 'image/gif':
            $image = imagecreatefromgif($file);
            break;
        default:
            return false;
    }
    
    $original_width = imagesx($image);
    $original_height = imagesy($image);
    
    $resized = imagecreatetruecolor($width, $height);
    
    // Preserve transparency for PNG and GIF
    if ($mime == 'image/png' || $mime == 'image/gif') {
        imagecolortransparent($resized, imagecolorallocatealpha($resized, 0, 0, 0, 127));
        imagealphablending($resized, false);
        imagesavealpha($resized, true);
    }
    
    imagecopyresampled($resized, $image, 0, 0, 0, 0, $width, $height, $original_width, $original_height);
    
    switch ($mime) {
        case 'image/jpeg':
            imagejpeg($resized, $file, 90);
            break;
        case 'image/png':
            imagepng($resized, $file, 9);
            break;
        case 'image/gif':
            imagegif($resized, $file);
            break;
    }
    
    imagedestroy($image);
    imagedestroy($resized);
    
    return true;
}

// Function to generate QR code
function generateQRCode($student_id, $student_number, $full_name, $campus_id) {
    global $conn;
    
    // Get campus name
    $campus_stmt = $conn->prepare("SELECT campus_name FROM campuses WHERE campus_id = ?");
    $campus_stmt->bind_param("i", $campus_id);
    $campus_stmt->execute();
    $campus_result = $campus_stmt->get_result();
    $campus = $campus_result->fetch_assoc();
    
    // Create QR code data
    $qr_data = [
        'type' => 'student',
        'student_id' => $student_id,
        'student_number' => $student_number,
        'full_name' => $full_name,
        'campus_id' => $campus_id,
        'campus_name' => $campus['campus_name']
    ];
    
    $qr_json = json_encode($qr_data);
    
    // Include PHP QR Code library
    if (file_exists('phpqrcode/qrlib.php')) {
        require_once 'phpqrcode/qrlib.php';
    } else {
        // Create a simple text file as fallback
        $qr_filename = "qr_codes/{$student_number}.txt";
        if (!file_exists('qr_codes')) {
            mkdir('qr_codes', 0777, true);
        }
        file_put_contents($qr_filename, $qr_json);
        return $qr_filename;
    }
    
    // Create QR codes directory
    if (!file_exists('qr_codes')) {
        mkdir('qr_codes', 0777, true);
    }
    
    $qr_filename = "qr_codes/{$student_number}.png";
    QRcode::png($qr_json, $qr_filename, QR_ECLEVEL_L, 10, 2);
    
    return $qr_filename;
}

// Function to send QR code email using PHPMailer
function sendQRCodeWithPHPMailer($to_email, $student_name, $student_number, $qr_file_path, $campus_name, $course_year, $section) {
    // Validate email
    if (!filter_var($to_email, FILTER_VALIDATE_EMAIL)) {
        return false;
    }
    
    // Check if QR file exists
    if (!file_exists($qr_file_path)) {
        return false;
    }
    
    // Try multiple possible PHPMailer paths
    $possible_paths = [
        'PHPMailer-master/src/',
        'PHPMailer-master/',
        'PHPMailer/',
        '../PHPMailer-master/src/',
        '../PHPMailer/',
    ];
    
    $phpmailer_path = null;
    foreach ($possible_paths as $path) {
        if (file_exists($path . 'PHPMailer.php') || file_exists($path . 'src/PHPMailer.php')) {
            $phpmailer_path = $path;
            break;
        }
    }
    
    if (!$phpmailer_path) {
        // Check if PHPMailer files are in the same directory
        if (file_exists('PHPMailer.php')) {
            // PHPMailer files are in root directory
            require_once 'PHPMailer.php';
            require_once 'SMTP.php';
            require_once 'Exception.php';
        } else {
            error_log("PHPMailer not found in any of the expected locations.");
            return false;
        }
    } else {
        // Check if PHPMailer.php is directly in the path or in src/ subdirectory
        if (file_exists($phpmailer_path . 'PHPMailer.php')) {
            require_once $phpmailer_path . 'PHPMailer.php';
            require_once $phpmailer_path . 'SMTP.php';
            require_once $phpmailer_path . 'Exception.php';
        } elseif (file_exists($phpmailer_path . 'src/PHPMailer.php')) {
            require_once $phpmailer_path . 'src/PHPMailer.php';
            require_once $phpmailer_path . 'src/SMTP.php';
            require_once $phpmailer_path . 'src/Exception.php';
        } else {
            error_log("PHPMailer files not found at: $phpmailer_path");
            return false;
        }
    }
    
    try {
        $mail = new PHPMailer(true);
        
        // Server settings - UPDATE THESE WITH YOUR SMTP SETTINGS
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';          // SMTP server
        $mail->SMTPAuth   = true;                     // Enable SMTP authentication
        $mail->Username   = 'jayamarlalantacon@gmail.com';   // SMTP username
        $mail->Password   = 'jaymar03072004';      // SMTP password (use App Password for Gmail)
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Enable TLS encryption
        $mail->Port       = 587;                      // TCP port to connect to
        
        // Alternative SMTP settings (uncomment and modify as needed)
        /*
        // For Yahoo Mail
        $mail->Host = 'smtp.mail.yahoo.com';
        $mail->Port = 465;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SSL;
        
        // For Outlook/Hotmail
        $mail->Host = 'smtp-mail.outlook.com';
        $mail->Port = 587;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        */
        
        // Recipients
        $mail->setFrom('noreply@university.edu', 'University Attendance System');
        $mail->addAddress($to_email, $student_name);
        $mail->addReplyTo('support@university.edu', 'Support Team');
        
        // Attach QR code
        $mail->addAttachment($qr_file_path, "QR_Code_{$student_number}.png");
        
        // Content
        $mail->isHTML(true);
        $mail->Subject = "Your Student QR Code - University Attendance System";
        
        // HTML email body
        $mail->Body = '
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Your Student QR Code</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    line-height: 1.6;
                    color: #333;
                    max-width: 600px;
                    margin: 0 auto;
                    padding: 20px;
                }
                .header {
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                    padding: 30px;
                    text-align: center;
                    border-radius: 10px 10px 0 0;
                }
                .content {
                    background: #f9f9f9;
                    padding: 30px;
                    border-radius: 0 0 10px 10px;
                }
                .info-box {
                    background: white;
                    padding: 20px;
                    border-radius: 8px;
                    margin: 20px 0;
                    border-left: 4px solid #667eea;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                }
                .qr-instructions {
                    background: #e8f4ff;
                    padding: 20px;
                    border-radius: 8px;
                    margin: 20px 0;
                }
                .footer {
                    text-align: center;
                    margin-top: 30px;
                    color: #666;
                    font-size: 12px;
                    padding-top: 20px;
                    border-top: 1px solid #eee;
                }
                h1 { margin: 0; font-size: 24px; }
                h2 { color: #444; margin-top: 0; }
                h3 { color: #667eea; margin-top: 0; }
                ul, ol { padding-left: 20px; }
                .highlight { background: #fffacd; padding: 10px; border-radius: 5px; margin: 15px 0; }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>Welcome to University Attendance System</h1>
                <p>Your QR Code for Attendance Tracking</p>
            </div>
            
            <div class="content">
                <p>Dear <strong>' . htmlspecialchars($student_name) . '</strong>,</p>
                
                <div class="info-box">
                    <h2>Student Information</h2>
                    <p><strong>Student Number:</strong> ' . htmlspecialchars($student_number) . '</p>
                    <p><strong>Campus:</strong> ' . htmlspecialchars($campus_name) . '</p>
                    <p><strong>Course/Year:</strong> ' . htmlspecialchars($course_year) . '</p>
                    <p><strong>Section:</strong> ' . htmlspecialchars($section) . '</p>
                </div>
                
                <div class="qr-instructions">
                    <h3>📱 How to Use Your QR Code</h3>
                    <ol>
                        <li><strong>Save the QR code</strong> attached to this email</li>
                        <li><strong>Print it</strong> and keep it with your ID card</li>
                        <li><strong>Show it to the scanner</strong> when attending classes/events</li>
                        <li><strong>Keep it secure</strong> - don\'t share your QR code with others</li>
                    </ol>
                </div>
                
                <div class="highlight">
                    <p><strong>Important Notes:</strong></p>
                    <ul>
                        <li>This QR code is unique to you and cannot be replaced easily</li>
                        <li>You will use this QR code for all attendance tracking</li>
                        <li>If you lose your QR code, contact your coordinator immediately</li>
                        <li>Never share your QR code with anyone</li>
                    </ul>
                </div>
                
                <p>Best regards,<br>
                <strong>University Attendance System Team</strong></p>
            </div>
            
            <div class="footer">
                <p>This is an automated message. Please do not reply to this email.</p>
                <p>© ' . date('Y') . ' University Attendance System. All rights reserved.</p>
            </div>
        </body>
        </html>';
        
        // Plain text version for non-HTML email clients
        $mail->AltBody = "Welcome to University Attendance System\n\n" .
                        "Student Information:\n" .
                        "====================\n" .
                        "Student Number: " . $student_number . "\n" .
                        "Full Name: " . $student_name . "\n" .
                        "Campus: " . $campus_name . "\n" .
                        "Course/Year: " . $course_year . "\n" .
                        "Section: " . $section . "\n\n" .
                        "Your QR code is attached to this email. Please save it and use it for attendance tracking.\n\n" .
                        "Important Instructions:\n" .
                        "=======================\n" .
                        "1. Save the attached QR code to your phone\n" .
                        "2. Print it and keep it with your ID card\n" .
                        "3. Show it to the scanner when attending classes/events\n" .
                        "4. Keep it secure - don't share your QR code with others\n\n" .
                        "Important Notes:\n" .
                        "================\n" .
                        "- This QR code is unique to you\n" .
                        "- You will use this QR code for all attendance tracking\n" .
                        "- If you lose your QR code, contact your coordinator immediately\n" .
                        "- Never share your QR code with anyone\n\n" .
                        "Best regards,\n" .
                        "University Attendance System Team\n\n" .
                        "© " . date('Y') . " University Attendance System. All rights reserved.";
        
        $mail->send();
        return true;
        
    } catch (Exception $e) {
        // Log error but don't show to user
        error_log("PHPMailer Error: " . $e->getMessage());
        return false;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Student | Multi-Campus Attendance</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .photo-preview {
            width: 200px;
            height: 200px;
            border: 3px dashed #ddd;
            border-radius: 10px;
            background: #f9fafb;
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        .photo-preview:hover {
            border-color: #8b5cf6;
            transform: scale(1.02);
        }
        .photo-overlay {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(0,0,0,0.7);
            color: white;
            padding: 8px;
            text-align: center;
            font-size: 12px;
        }
        .student-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 15px;
            color: white;
        }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
    <!-- Navigation -->
    <nav class="bg-gradient-to-r from-purple-800 to-indigo-900 text-white shadow-lg">
        <div class="container mx-auto px-4 py-3">
            <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div class="flex items-center space-x-4">
                    <a href="<?php echo $_SESSION['user_type'] === 'admin' ? 'admin_dashboard.php' : 'coordinator_dashboard.php'; ?>" 
                       class="flex items-center hover:text-purple-200 transition-colors">
                        <i class="fas fa-arrow-left mr-2"></i> Back to Dashboard
                    </a>
                    <h1 class="text-xl font-bold">
                        <i class="fas fa-user-graduate mr-2"></i> Add New Student
                    </h1>
                </div>
                <div class="flex items-center space-x-4">
                    <span class="text-sm">
                        <i class="fas fa-user mr-1"></i> <?php echo htmlspecialchars($user_name); ?>
                        <span class="text-purple-300 ml-1">(<?php echo ucfirst($user_type); ?>)</span>
                    </span>
                    <span class="text-sm text-purple-300">|</span>
                    <a href="logout.php" class="text-sm hover:text-purple-200 transition-colors">
                        <i class="fas fa-sign-out-alt mr-1"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-8">
        <div class="max-w-6xl mx-auto">
            <!-- Header -->
            <div class="mb-8 text-center">
                <h1 class="text-4xl font-bold text-gray-800 mb-3">Add New Student</h1>
                <p class="text-gray-600 max-w-2xl mx-auto">Register a new student with photo and generate QR code for attendance tracking</p>
            </div>

            <?php if ($success): ?>
                <!-- Success Message -->
                <div class="mb-8 p-6 bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-2xl shadow-lg">
                    <div class="flex items-center">
                        <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mr-6">
                            <i class="fas fa-check-circle text-green-600 text-2xl"></i>
                        </div>
                        <div class="flex-1">
                            <h3 class="text-2xl font-bold text-green-800 mb-2">Student Added Successfully!</h3>
                            <p class="text-green-700"><?php echo $success; ?></p>
                            <div class="mt-4 flex flex-wrap gap-3">
                                <button onclick="window.location.href='add_student.php'" 
                                        class="px-5 py-2.5 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                                    <i class="fas fa-user-plus mr-2"></i> Add Another Student
                                </button>
                                <a href="students.php" 
                                   class="px-5 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                                    <i class="fas fa-users mr-2"></i> View All Students
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Student Card -->
                    <?php if ($student_data): ?>
                    <div class="mt-6 p-6 student-card rounded-xl">
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <div class="flex flex-col items-center justify-center">
                                <?php if ($student_data['photo_path'] && file_exists($student_data['photo_path'])): ?>
                                <img src="<?php echo $student_data['photo_path']; ?>" 
                                     alt="Student Photo" 
                                     class="w-32 h-32 rounded-full border-4 border-white shadow-lg mb-4 object-cover">
                                <?php else: ?>
                                <div class="w-32 h-32 bg-white/20 rounded-full border-4 border-white flex items-center justify-center shadow-lg mb-4">
                                    <i class="fas fa-user text-white text-4xl"></i>
                                </div>
                                <?php endif; ?>
                                <h3 class="text-xl font-bold text-center"><?php echo htmlspecialchars($student_data['full_name']); ?></h3>
                                <p class="text-white/80"><?php echo htmlspecialchars($student_data['student_number']); ?></p>
                            </div>
                            
                            <div class="flex flex-col justify-center space-y-3">
                                <div>
                                    <p class="text-sm text-white/80">Campus</p>
                                    <p class="text-lg font-semibold"><?php echo htmlspecialchars($student_data['campus_name']); ?></p>
                                </div>
                                <div>
                                    <p class="text-sm text-white/80">Course/Year</p>
                                    <p class="text-lg font-semibold"><?php echo htmlspecialchars($student_data['course_year']); ?></p>
                                </div>
                                <div>
                                    <p class="text-sm text-white/80">Section</p>
                                    <p class="text-lg font-semibold"><?php echo htmlspecialchars($student_data['section']); ?></p>
                                </div>
                            </div>
                            
                            <div class="flex flex-col items-center justify-center">
                                <?php if ($student_data['qr_path'] && file_exists($student_data['qr_path'])): ?>
                                <img src="<?php echo $student_data['qr_path']; ?>" 
                                     alt="QR Code" 
                                     class="w-32 h-32 bg-white p-2 rounded-lg mb-4">
                                <?php endif; ?>
                                <p class="text-sm text-center text-white/80">Scan this QR code for attendance</p>
                                <?php if ($student_data['qr_path'] && file_exists($student_data['qr_path'])): ?>
                                <a href="<?php echo $student_data['qr_path']; ?>" 
                                   download="<?php echo $student_data['student_number']; ?>_qr.png"
                                   class="mt-2 px-4 py-2 bg-white text-purple-600 rounded-lg text-sm font-semibold hover:bg-gray-100">
                                    <i class="fas fa-download mr-1"></i> Download QR
                                </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <!-- Error Message -->
                <div class="mb-8 p-6 bg-gradient-to-r from-red-50 to-rose-50 border border-red-200 rounded-2xl shadow-lg">
                    <div class="flex items-center">
                        <div class="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mr-6">
                            <i class="fas fa-exclamation-triangle text-red-600 text-2xl"></i>
                        </div>
                        <div>
                            <h3 class="text-2xl font-bold text-red-800 mb-2">Error Adding Student</h3>
                            <p class="text-red-700"><?php echo $error; ?></p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Student Form -->
            <div class="bg-white rounded-2xl shadow-xl p-8">
                <form method="POST" action="" enctype="multipart/form-data" id="studentForm">
                    <input type="hidden" name="add_student" value="1">
                    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                        <!-- Left Column - Personal Info -->
                        <div class="space-y-6">
                            <h2 class="text-2xl font-bold text-gray-800 border-b pb-3">
                                <i class="fas fa-user-circle text-blue-600 mr-2"></i> Personal Information
                            </h2>
                            
                            <!-- Student Photo -->
                            <div class="flex flex-col items-center">
                                <div id="photoPreview" class="photo-preview" onclick="document.getElementById('photo').click()">
                                    <div class="w-full h-full flex flex-col items-center justify-center text-gray-500">
                                        <i class="fas fa-camera text-4xl mb-2"></i>
                                        <span>Click to upload photo</span>
                                        <span class="text-sm mt-1">(300x300, Max 5MB)</span>
                                    </div>
                                    <div class="photo-overlay hidden">Change Photo</div>
                                </div>
                                <input type="file" id="photo" name="photo" accept="image/*" class="hidden" onchange="previewPhoto(event)">
                                <p class="text-sm text-gray-500 mt-2">JPG, PNG, GIF, or WEBP format</p>
                            </div>
                            
                            <!-- Student Number -->
                            <div>
                                <label class="block mb-2 font-semibold text-gray-800">
                                    <i class="fas fa-id-card text-blue-600 mr-2"></i>Student Number
                                </label>
                                <input type="text" name="student_number"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                                       placeholder="Leave empty to auto-generate">
                                <p class="text-sm text-gray-500 mt-1">If left empty, system will generate one automatically</p>
                            </div>
                            
                            <!-- Full Name -->
                            <div>
                                <label class="block mb-2 font-semibold text-gray-800">
                                    <i class="fas fa-user text-blue-600 mr-2"></i>Full Name *
                                </label>
                                <input type="text" name="full_name" required
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                                       placeholder="Enter student's full name">
                            </div>
                            
                            <!-- Email -->
                            <div>
                                <label class="block mb-2 font-semibold text-gray-800">
                                    <i class="fas fa-envelope text-blue-600 mr-2"></i>Email Address
                                </label>
                                <input type="email" name="email"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                                       placeholder="student@example.com">
                                <p class="text-sm text-gray-500 mt-1">QR code will be sent to this email</p>
                            </div>
                            
                            <!-- Phone -->
                            <div>
                                <label class="block mb-2 font-semibold text-gray-800">
                                    <i class="fas fa-phone text-blue-600 mr-2"></i>Phone Number
                                </label>
                                <input type="tel" name="phone"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                                       placeholder="0912 345 6789">
                            </div>
                        </div>
                        
                        <!-- Right Column - Academic Info -->
                        <div class="space-y-6">
                            <h2 class="text-2xl font-bold text-gray-800 border-b pb-3">
                                <i class="fas fa-graduation-cap text-green-600 mr-2"></i> Academic Information
                            </h2>
                            
                            <!-- Campus -->
                            <div>
                                <label class="block mb-2 font-semibold text-gray-800">
                                    <i class="fas fa-school text-green-600 mr-2"></i>Campus *
                                </label>
                                <select name="campus_id" required
                                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-colors bg-white">
                                    <option value="">-- Select Campus --</option>
                                    <?php foreach ($campuses as $campus): ?>
                                    <option value="<?php echo $campus['campus_id']; ?>" 
                                            <?php echo ($user_type === 'coordinator' && $campus['campus_id'] == $user_campus_id) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($campus['campus_name']); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                                <?php if ($user_type === 'coordinator'): ?>
                                <p class="text-sm text-gray-500 mt-1">You can only add students for your assigned campus</p>
                                <?php endif; ?>
                            </div>
                            
                            <!-- Course/Year -->
                            <div>
                                <label class="block mb-2 font-semibold text-gray-800">
                                    <i class="fas fa-book text-green-600 mr-2"></i>Course/Year Level *
                                </label>
                                <input type="text" name="course_year" required
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-colors"
                                       placeholder="e.g., BSIT 3rd Year">
                            </div>
                            
                            <!-- Section -->
                            <div>
                                <label class="block mb-2 font-semibold text-gray-800">
                                    <i class="fas fa-users text-green-600 mr-2"></i>Section
                                </label>
                                <input type="text" name="section"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-colors"
                                       placeholder="e.g., Section A">
                            </div>
                            
                            <!-- QR Code Preview -->
                            <div class="mt-8 p-4 bg-gray-50 rounded-lg border border-gray-200">
                                <h3 class="font-semibold text-gray-800 mb-2">
                                    <i class="fas fa-qrcode text-purple-600 mr-2"></i>QR Code Preview
                                </h3>
                                <div id="qrPreview" class="w-48 h-48 mx-auto bg-white p-4 rounded-lg border border-gray-300 flex items-center justify-center">
                                    <div class="text-center text-gray-500">
                                        <i class="fas fa-qrcode text-4xl mb-2"></i>
                                        <p class="text-sm">QR code will be generated after adding student</p>
                                    </div>
                                </div>
                                <p class="text-sm text-gray-600 text-center mt-2">
                                    Students will use this QR code for attendance scanning
                                </p>
                            </div>
                            
                            <!-- Submit Button -->
                            <div class="pt-4">
                                <button type="submit" name="add_student"
                                        class="w-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white py-3.5 rounded-lg font-semibold hover:from-purple-700 hover:to-indigo-700 transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-0.5">
                                    <i class="fas fa-user-plus mr-2"></i> Add Student
                                </button>
                                <p class="text-sm text-gray-500 text-center mt-3">
                                    * Required fields. All fields marked with * are mandatory.
                                </p>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            
            <!-- Instructions -->
            <div class="mt-8 bg-gradient-to-r from-blue-50 to-cyan-50 p-6 rounded-2xl border border-blue-200">
                <h3 class="text-xl font-bold text-blue-800 mb-4 flex items-center">
                    <i class="fas fa-info-circle text-blue-600 mr-3"></i> Adding Student Instructions
                </h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="p-4 bg-white rounded-lg border border-blue-100">
                        <h4 class="font-semibold text-blue-700 mb-2 flex items-center">
                            <i class="fas fa-camera mr-2"></i> Photo Requirements
                        </h4>
                        <ul class="text-sm text-gray-600 space-y-1">
                            <li><i class="fas fa-check text-green-500 mr-1"></i> Clear front-facing photo</li>
                            <li><i class="fas fa-check text-green-500 mr-1"></i> Good lighting, no shadows</li>
                            <li><i class="fas fa-check text-green-500 mr-1"></i> Max file size: 5MB</li>
                            <li><i class="fas fa-check text-green-500 mr-1"></i> Supported formats: JPG, PNG, GIF, WEBP</li>
                        </ul>
                    </div>
                    <div class="p-4 bg-white rounded-lg border border-blue-100">
                        <h4 class="font-semibold text-blue-700 mb-2 flex items-center">
                            <i class="fas fa-qrcode mr-2"></i> After Adding Student
                        </h4>
                        <ul class="text-sm text-gray-600 space-y-1">
                            <li><i class="fas fa-check text-green-500 mr-1"></i> QR code will be automatically generated</li>
                            <li><i class="fas fa-check text-green-500 mr-1"></i> QR code will be emailed to the student</li>
                            <li><i class="fas fa-check text-green-500 mr-1"></i> Student can use QR for attendance</li>
                            <li><i class="fas fa-check text-green-500 mr-1"></i> Student profile will be created</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Photo preview
        function previewPhoto(event) {
            const input = event.target;
            const preview = document.getElementById('photoPreview');
            const overlay = preview.querySelector('.photo-overlay');
            
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    preview.style.backgroundImage = `url(${e.target.result})`;
                    preview.querySelector('.fa-camera').classList.add('hidden');
                    preview.querySelector('span').classList.add('hidden');
                    overlay.classList.remove('hidden');
                }
                
                reader.readAsDataURL(input.files[0]);
                
                // Validate file size
                if (input.files[0].size > 5 * 1024 * 1024) {
                    alert('File size must be less than 5MB');
                    input.value = '';
                    preview.style.backgroundImage = '';
                    preview.querySelector('.fa-camera').classList.remove('hidden');
                    preview.querySelector('span').classList.remove('hidden');
                    overlay.classList.add('hidden');
                }
            }
        }
        
        // Form validation
        document.getElementById('studentForm').addEventListener('submit', function(e) {
            const photo = document.getElementById('photo');
            const campus = document.querySelector('[name="campus_id"]');
            const studentNumber = document.querySelector('[name="student_number"]');
            
            // Validate campus selection (for coordinators)
            <?php if ($user_type === 'coordinator'): ?>
            if (campus.value != <?php echo $user_campus_id; ?>) {
                e.preventDefault();
                alert('You can only add students for your assigned campus.');
                return false;
            }
            <?php endif; ?>
            
            // Validate student number format if provided
            if (studentNumber.value.trim() !== '') {
                const studentNumRegex = /^[A-Z0-9]+$/i;
                if (!studentNumRegex.test(studentNumber.value.trim())) {
                    e.preventDefault();
                    alert('Student number can only contain letters and numbers.');
                    studentNumber.focus();
                    return false;
                }
            }
            
            // Optional: Validate photo
            if (photo.files.length > 0) {
                const file = photo.files[0];
                const validTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
                
                if (!validTypes.includes(file.type)) {
                    e.preventDefault();
                    alert('Please upload a valid image file (JPG, PNG, GIF, or WEBP).');
                    return false;
                }
            }
            
            // Show loading state
            const submitBtn = this.querySelector('button[type="submit"]');
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Adding Student...';
            submitBtn.disabled = true;
        });
        
        // Drag and drop for photo
        const photoPreview = document.getElementById('photoPreview');
        if (photoPreview) {
            photoPreview.addEventListener('dragover', (e) => {
                e.preventDefault();
                photoPreview.style.borderColor = '#8b5cf6';
                photoPreview.style.backgroundColor = '#f5f3ff';
            });
            
            photoPreview.addEventListener('dragleave', () => {
                photoPreview.style.borderColor = '';
                photoPreview.style.backgroundColor = '';
            });
            
            photoPreview.addEventListener('drop', (e) => {
                e.preventDefault();
                photoPreview.style.borderColor = '';
                photoPreview.style.backgroundColor = '';
                
                const files = e.dataTransfer.files;
                if (files.length > 0) {
                    document.getElementById('photo').files = files;
                    previewPhoto({ target: document.getElementById('photo') });
                }
            });
        }
        
        // Auto-generate student number suggestion
        document.querySelector('[name="full_name"]').addEventListener('blur', function() {
            const studentNumberField = document.querySelector('[name="student_number"]');
            if (studentNumberField.value.trim() === '') {
                const name = this.value.trim();
                if (name.length > 3) {
                    const year = new Date().getFullYear();
                    const initials = name.split(' ').map(n => n[0]).join('').toUpperCase();
                    const randomNum = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
                    studentNumberField.placeholder = `${initials}${year}${randomNum}`;
                }
            }
        });
    </script>
</body>
</html>