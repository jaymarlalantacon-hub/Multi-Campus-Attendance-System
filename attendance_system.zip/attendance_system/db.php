<?php
// Database configuration
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'multi_campus_attendance';

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set timezone to Philippines
date_default_timezone_set('Asia/Manila');

// Set charset
$conn->set_charset("utf8mb4");

// Error reporting (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Create necessary directories if they don't exist
$directories = ['uploads/students', 'uploads/activities', 'qr_codes', 'reports'];
foreach ($directories as $dir) {
    if (!file_exists($dir)) {
        mkdir($dir, 0777, true);
    }
}

// Function to generate random password
function generatePassword($length = 12) {
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()';
    return substr(str_shuffle($chars), 0, $length);
}

// Function to sanitize input
function sanitizeInput($input) {
    global $conn;
    return htmlspecialchars(strip_tags(trim($input)));
}

// Function to format date
function formatDate($date, $format = 'F j, Y') {
    return date($format, strtotime($date));
}

// Function to format time
function formatTime($time, $format = 'h:i A') {
    return date($format, strtotime($time));
}

// Function to get campus name by ID
function getCampusName($campus_id) {
    global $conn;
    if (!$campus_id) return 'All Campuses';
    
    $stmt = $conn->prepare("SELECT campus_name FROM campuses WHERE campus_id = ?");
    $stmt->bind_param("i", $campus_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        return $row['campus_name'];
    }
    return 'Unknown Campus';
}
?>