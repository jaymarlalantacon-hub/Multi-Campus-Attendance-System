<?php
session_start();
require_once 'db.php';

// Check if admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: login.php');
    exit();
}

$user_name = $_SESSION['full_name'];

// Get statistics
$stats = [];

// Total students
$result = $conn->query("SELECT COUNT(*) as total FROM students WHERE status = 'active'");
$stats['total_students'] = $result->fetch_assoc()['total'];

// Total activities this month
$month_start = date('Y-m-01');
$result = $conn->query("SELECT COUNT(*) as total FROM activities WHERE created_at >= '$month_start'");
$stats['month_activities'] = $result->fetch_assoc()['total'];

// Total fines this month
$result = $conn->query("SELECT SUM(amount) as total FROM fines WHERE status = 'pending' AND MONTH(created_at) = MONTH(CURRENT_DATE())");
$stats['pending_fines'] = $result->fetch_assoc()['total'] ?? 0;

// Total coordinators
$result = $conn->query("SELECT COUNT(*) as total FROM users WHERE user_type = 'coordinator' AND status = 'active'");
$stats['total_coordinators'] = $result->fetch_assoc()['total'];

// Campus-wise students
$result = $conn->query("
    SELECT c.campus_name, COUNT(s.student_id) as student_count 
    FROM campuses c 
    LEFT JOIN students s ON c.campus_id = s.campus_id AND s.status = 'active'
    WHERE c.status = 'active'
    GROUP BY c.campus_id
    ORDER BY c.campus_name
");
$campus_stats = [];
while ($row = $result->fetch_assoc()) {
    $campus_stats[] = $row;
}

// Recent activities
$result = $conn->query("
    SELECT a.*, c.campus_name, u.full_name as created_by_name 
    FROM activities a 
    LEFT JOIN campuses c ON a.campus_id = c.campus_id 
    LEFT JOIN users u ON a.created_by = u.user_id 
    ORDER BY a.activity_date DESC 
    LIMIT 5
");
$recent_activities = [];
while ($row = $result->fetch_assoc()) {
    $recent_activities[] = $row;
}

// Recent scans
$result = $conn->query("
    SELECT sl.*, s.full_name as student_name, a.activity_name, u.full_name as user_name 
    FROM scan_logs sl 
    LEFT JOIN students s ON sl.student_id = s.student_id 
    LEFT JOIN activities a ON sl.activity_id = a.activity_id 
    LEFT JOIN users u ON sl.user_id = u.user_id 
    ORDER BY sl.created_at DESC 
    LIMIT 10
");
$recent_scans = [];
while ($row = $result->fetch_assoc()) {
    $recent_scans[] = $row;
}

// Get current page for active menu highlighting
$current_page = basename($_SERVER['PHP_SELF']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | Multi-Campus Attendance</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .sidebar {
            transition: all 0.3s ease;
        }
        .sidebar-mini {
            width: 70px;
        }
        .sidebar-full {
            width: 260px;
        }
        .main-content {
            transition: all 0.3s ease;
        }
        .menu-item {
            transition: all 0.2s ease;
        }
        .menu-item:hover {
            transform: translateX(5px);
        }
        .menu-item.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .notification-badge {
            animation: pulse 2s infinite;
        }
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
    </style>
</head>
<body class="bg-gray-50 min-h-screen flex">
    <!-- Sidebar -->
    <div class="sidebar sidebar-full bg-gradient-to-b from-purple-900 to-indigo-900 text-white flex flex-col">
        <!-- Logo -->
        <div class="p-6 border-b border-purple-700 flex items-center space-x-3">
            <div class="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                <i class="fas fa-graduation-cap text-xl"></i>
            </div>
            <div>
                <h1 class="font-bold text-lg">Multi-Campus</h1>
                <p class="text-purple-300 text-xs">Attendance System</p>
            </div>
            <button id="toggleSidebar" class="ml-auto text-purple-300 hover:text-white">
                <i class="fas fa-bars"></i>
            </button>
        </div>

        <!-- User Profile -->
        <div class="p-6 border-b border-purple-700 flex items-center space-x-4">
            <div class="relative">
                <div class="w-12 h-12 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full flex items-center justify-center font-bold text-xl">
                    <?php echo strtoupper(substr($user_name, 0, 1)); ?>
                </div>
                <span class="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-purple-900"></span>
            </div>
            <div>
                <div class="font-semibold truncate"><?php echo htmlspecialchars($user_name); ?></div>
                <div class="text-sm text-purple-300">Administrator</div>
            </div>
        </div>

        <!-- Navigation Menu -->
        <nav class="flex-1 p-4 space-y-1 overflow-y-auto">
            <a href="admin_dashboard.php" class="menu-item flex items-center space-x-3 p-3 rounded-lg <?php echo $current_page == 'admin_dashboard.php' ? 'active' : 'hover:bg-purple-800'; ?>">
                <i class="fas fa-tachometer-alt w-6 text-center"></i>
                <span class="sidebar-text">Dashboard</span>
            </a>

            <div class="mt-6 mb-2 px-3 text-xs font-semibold text-purple-400 uppercase tracking-wider">Management</div>
            
            <a href="students.php" class="menu-item flex items-center space-x-3 p-3 rounded-lg <?php echo $current_page == 'students.php' ? 'active' : 'hover:bg-purple-800'; ?>">
                <i class="fas fa-users w-6 text-center"></i>
                <span class="sidebar-text">Students</span>
                <span class="ml-auto bg-purple-700 text-xs px-2 py-1 rounded-full"><?php echo $stats['total_students']; ?></span>
            </a>
                         <a href="manage_attendance.php" class="menu-item flex items-center space-x-3 p-3 rounded-lg <?php echo $current_page == 'register.php' ? 'active' : 'hover:bg-purple-800'; ?>">
                <i class="fas fa-user-plus w-6 text-center"></i>
                <span class="sidebar-text">Manage Attendance</span>
            </a>


            <a href="users.php" class="menu-item flex items-center space-x-3 p-3 rounded-lg <?php echo $current_page == 'users.php' ? 'active' : 'hover:bg-purple-800'; ?>">
                <i class="fas fa-user-cog w-6 text-center"></i>
                <span class="sidebar-text">Coordinators</span>
                <span class="ml-auto bg-blue-700 text-xs px-2 py-1 rounded-full"><?php echo $stats['total_coordinators']; ?></span>
            </a>

            <a href="activities.php" class="menu-item flex items-center space-x-3 p-3 rounded-lg <?php echo $current_page == 'activities.php' ? 'active' : 'hover:bg-purple-800'; ?>">
                <i class="fas fa-calendar-alt w-6 text-center"></i>
                <span class="sidebar-text">Activities</span>
                <span class="ml-auto bg-green-700 text-xs px-2 py-1 rounded-full"><?php echo $stats['month_activities']; ?></span>
            </a>

            <a href="fines.php" class="menu-item flex items-center space-x-3 p-3 rounded-lg <?php echo $current_page == 'fines.php' ? 'active' : 'hover:bg-purple-800'; ?>">
                <i class="fas fa-money-check-alt w-6 text-center"></i>
                <span class="sidebar-text">Fines</span>
                <span class="ml-auto bg-red-700 text-xs px-2 py-1 rounded-full">₱<?php echo number_format($stats['pending_fines']); ?></span>
            </a>

            <a href="campuses.php" class="menu-item flex items-center space-x-3 p-3 rounded-lg <?php echo $current_page == 'campuses.php' ? 'active' : 'hover:bg-purple-800'; ?>">
                <i class="fas fa-school w-6 text-center"></i>
                <span class="sidebar-text">Campuses</span>
                <span class="ml-auto bg-indigo-700 text-xs px-2 py-1 rounded-full">7</span>
            </a>

            <div class="mt-6 mb-2 px-3 text-xs font-semibold text-purple-400 uppercase tracking-wider">Operations</div>

            <a href="add_student.php" class="menu-item flex items-center space-x-3 p-3 rounded-lg <?php echo $current_page == 'register.php' ? 'active' : 'hover:bg-purple-800'; ?>">
                <i class="fas fa-user-plus w-6 text-center"></i>
                <span class="sidebar-text">Add Student</span>
            </a>

            <a href="create_activity.php" class="menu-item flex items-center space-x-3 p-3 rounded-lg <?php echo $current_page == 'create_activity.php' ? 'active' : 'hover:bg-purple-800'; ?>">
                <i class="fas fa-calendar-plus w-6 text-center"></i>
                <span class="sidebar-text">Create Activity</span>
            </a>

            <a href="scan_attendance.php" class="menu-item flex items-center space-x-3 p-3 rounded-lg <?php echo $current_page == 'scan_attendance.php' ? 'active' : 'hover:bg-purple-800'; ?>">
                <i class="fas fa-qrcode w-6 text-center"></i>
                <span class="sidebar-text">Scan Attendance</span>
            </a>

            <a href="scan_fines.php" class="menu-item flex items-center space-x-3 p-3 rounded-lg <?php echo $current_page == 'scan_fines.php' ? 'active' : 'hover:bg-purple-800'; ?>">
                <i class="fas fa-money-bill-wave w-6 text-center"></i>
                <span class="sidebar-text">Scan Fines</span>
            </a>

            <div class="mt-6 mb-2 px-3 text-xs font-semibold text-purple-400 uppercase tracking-wider">Reports</div>

            <a href="reports.php" class="menu-item flex items-center space-x-3 p-3 rounded-lg <?php echo $current_page == 'reports.php' ? 'active' : 'hover:bg-purple-800'; ?>">
                <i class="fas fa-chart-bar w-6 text-center"></i>
                <span class="sidebar-text">Reports</span>
            </a>

            <a href="monthly_report.php" class="menu-item flex items-center space-x-3 p-3 rounded-lg <?php echo $current_page == 'monthly_report.php' ? 'active' : 'hover:bg-purple-800'; ?>">
                <i class="fas fa-file-invoice-dollar w-6 text-center"></i>
                <span class="sidebar-text">Monthly Report</span>
            </a>

            <a href="audit_logs.php" class="menu-item flex items-center space-x-3 p-3 rounded-lg <?php echo $current_page == 'audit_logs.php' ? 'active' : 'hover:bg-purple-800'; ?>">
                <i class="fas fa-history w-6 text-center"></i>
                <span class="sidebar-text">Audit Logs</span>
            </a>

            <a href="settings.php" class="menu-item flex items-center space-x-3 p-3 rounded-lg <?php echo $current_page == 'settings.php' ? 'active' : 'hover:bg-purple-800'; ?>">
                <i class="fas fa-cog w-6 text-center"></i>
                <span class="sidebar-text">Settings</span>
            </a>
        </nav>

        <!-- Sidebar Footer -->
        <div class="p-4 border-t border-purple-700">
            <div class="text-center">
                <div class="text-xs text-purple-400 mb-2">System Status</div>
                <div class="flex items-center justify-center space-x-2">
                    <span class="w-2 h-2 bg-green-500 rounded-full"></span>
                    <span class="text-sm text-green-400">Online</span>
                </div>
            </div>
            <a href="logout.php" class="menu-item flex items-center justify-center space-x-2 p-3 mt-4 rounded-lg bg-red-900/30 hover:bg-red-800 transition-colors">
                <i class="fas fa-sign-out-alt"></i>
                <span class="sidebar-text">Logout</span>
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="flex-1 flex flex-col overflow-hidden">
        <!-- Top Navigation -->
        <div class="bg-white shadow-sm border-b">
            <div class="px-6 py-4 flex items-center justify-between">
                <div class="flex items-center space-x-4">
                    <h1 class="text-2xl font-bold text-gray-800">
                        <?php echo $current_page == 'admin_dashboard.php' ? 'Dashboard' : getPageTitle($current_page); ?>
                    </h1>
                    <?php if ($current_page == 'admin_dashboard.php'): ?>
                    <span class="text-sm text-gray-500">Welcome back, <?php echo htmlspecialchars($user_name); ?>!</span>
                    <?php endif; ?>
                </div>
                <div class="flex items-center space-x-4">
                    <!-- Notifications -->
                    <div class="relative">
                        <button class="p-2 text-gray-600 hover:text-purple-600 relative">
                            <i class="fas fa-bell text-xl"></i>
                            <span class="notification-badge absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">3</span>
                        </button>
                    </div>
                    <!-- Quick Actions -->
                    <div class="flex space-x-2">
                        <a href="scan_attendance.php" class="px-4 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-lg hover:from-purple-700 hover:to-indigo-700 transition-all shadow flex items-center space-x-2">
                            <i class="fas fa-qrcode"></i>
                            <span>Scan QR</span>
                        </a>
                        <button onclick="window.print()" class="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors flex items-center space-x-2">
                            <i class="fas fa-print"></i>
                            <span>Print</span>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Breadcrumb -->
            <div class="px-6 py-2 bg-gray-50">
                <nav class="flex" aria-label="Breadcrumb">
                    <ol class="flex items-center space-x-2 text-sm">
                        <li>
                            <a href="admin_dashboard.php" class="text-purple-600 hover:text-purple-800">
                                <i class="fas fa-home"></i>
                            </a>
                        </li>
                        <?php if ($current_page != 'admin_dashboard.php'): ?>
                        <li class="flex items-center">
                            <i class="fas fa-chevron-right text-gray-400 mx-2"></i>
                            <span class="text-gray-600"><?php echo getPageTitle($current_page); ?></span>
                        </li>
                        <?php endif; ?>
                    </ol>
                </nav>
            </div>
        </div>

        <!-- Main Content Area -->
        <div class="flex-1 overflow-auto p-6">
            <?php if ($current_page == 'admin_dashboard.php'): ?>
            <!-- Dashboard Content -->
            <div class="mb-6">
                <h2 class="text-2xl font-bold text-gray-800">Overview</h2>
                <p class="text-gray-600">Quick summary of system activities</p>
            </div>

            <!-- Stats Cards -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <!-- Total Students -->
                <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-blue-500 hover:shadow-xl transition-shadow">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-gray-600">Total Students</p>
                            <h3 class="text-2xl font-bold text-gray-800"><?php echo number_format($stats['total_students']); ?></h3>
                        </div>
                        <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-users text-blue-600 text-xl"></i>
                        </div>
                    </div>
                    <div class="mt-4">
                        <a href="students.php" class="text-blue-600 hover:text-blue-800 text-sm font-medium flex items-center">
                            View All Students <i class="fas fa-arrow-right ml-2"></i>
                        </a>
                    </div>
                </div>

                <!-- Activities This Month -->
                <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-green-500 hover:shadow-xl transition-shadow">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-gray-600">Activities This Month</p>
                            <h3 class="text-2xl font-bold text-gray-800"><?php echo number_format($stats['month_activities']); ?></h3>
                        </div>
                        <div class="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-calendar-alt text-green-600 text-xl"></i>
                        </div>
                    </div>
                    <div class="mt-4">
                        <a href="activities.php" class="text-green-600 hover:text-green-800 text-sm font-medium flex items-center">
                            View Activities <i class="fas fa-arrow-right ml-2"></i>
                        </a>
                    </div>
                </div>

                <!-- Pending Fines -->
                <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-red-500 hover:shadow-xl transition-shadow">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-gray-600">Pending Fines</p>
                            <h3 class="text-2xl font-bold text-gray-800">₱<?php echo number_format($stats['pending_fines'], 2); ?></h3>
                        </div>
                        <div class="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-money-bill-wave text-red-600 text-xl"></i>
                        </div>
                    </div>
                    <div class="mt-4">
                        <a href="fines.php" class="text-red-600 hover:text-red-800 text-sm font-medium flex items-center">
                            Manage Fines <i class="fas fa-arrow-right ml-2"></i>
                        </a>
                    </div>
                </div>

                <!-- Coordinators -->
                <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-purple-500 hover:shadow-xl transition-shadow">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm text-gray-600">Coordinators</p>
                            <h3 class="text-2xl font-bold text-gray-800"><?php echo number_format($stats['total_coordinators']); ?></h3>
                        </div>
                        <div class="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-user-cog text-purple-600 text-xl"></i>
                        </div>
                    </div>
                    <div class="mt-4">
                        <a href="users.php" class="text-purple-600 hover:text-purple-800 text-sm font-medium flex items-center">
                            Manage Users <i class="fas fa-arrow-right ml-2"></i>
                        </a>
                    </div>
                </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <!-- Campus Distribution -->
                <div class="bg-white rounded-xl shadow-lg p-6">
                    <div class="flex items-center justify-between mb-4">
                        <h2 class="text-xl font-bold text-gray-800 flex items-center">
                            <i class="fas fa-chart-pie text-blue-600 mr-2"></i> Students by Campus
                        </h2>
                        <a href="reports.php" class="text-sm text-purple-600 hover:text-purple-800">View Details →</a>
                    </div>
                    <div class="h-64">
                        <canvas id="campusChart"></canvas>
                    </div>
                    <div class="mt-4 grid grid-cols-2 gap-2">
                        <?php foreach ($campus_stats as $campus): ?>
                        <div class="flex items-center justify-between p-2 hover:bg-gray-50 rounded transition-colors">
                            <span class="text-sm font-medium truncate"><?php echo htmlspecialchars($campus['campus_name']); ?></span>
                            <span class="px-2 py-1 bg-blue-100 text-blue-800 rounded text-sm font-bold">
                                <?php echo number_format($campus['student_count']); ?>
                            </span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Recent Activities -->
                <div class="bg-white rounded-xl shadow-lg p-6">
                    <div class="flex items-center justify-between mb-4">
                        <h2 class="text-xl font-bold text-gray-800 flex items-center">
                            <i class="fas fa-history text-green-600 mr-2"></i> Recent Activities
                        </h2>
                        <a href="activities.php" class="text-sm text-purple-600 hover:text-purple-800">View All →</a>
                    </div>
                    <div class="space-y-3">
                        <?php foreach ($recent_activities as $activity): ?>
                        <a href="activity_details.php?id=<?php echo $activity['activity_id']; ?>" class="block p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors hover:shadow">
                            <div class="flex justify-between items-start">
                                <div class="flex-1">
                                    <h4 class="font-semibold text-gray-800"><?php echo htmlspecialchars($activity['activity_name']); ?></h4>
                                    <div class="flex items-center space-x-3 mt-1 text-sm text-gray-600">
                                        <span><i class="fas fa-calendar-day mr-1"></i><?php echo formatDate($activity['activity_date']); ?></span>
                                        <span><i class="fas fa-clock mr-1"></i><?php echo formatTime($activity['activity_time']); ?></span>
                                        <?php if ($activity['campus_name']): ?>
                                        <span><i class="fas fa-school mr-1"></i><?php echo htmlspecialchars($activity['campus_name']); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <span class="px-2 py-1 <?php echo $activity['mandatory'] ? 'bg-red-100 text-red-800' : 'bg-blue-100 text-blue-800'; ?> rounded text-xs font-semibold">
                                    <?php echo $activity['mandatory'] ? 'Mandatory' : 'Optional'; ?>
                                </span>
                            </div>
                            <div class="mt-2 text-xs text-gray-500">
                                <i class="fas fa-user mr-1"></i>Created by <?php echo htmlspecialchars($activity['created_by_name']); ?>
                            </div>
                        </a>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Recent Scans -->
                <div class="bg-white rounded-xl shadow-lg p-6 lg:col-span-2">
                    <div class="flex items-center justify-between mb-4">
                        <h2 class="text-xl font-bold text-gray-800 flex items-center">
                            <i class="fas fa-qrcode text-purple-600 mr-2"></i> Recent Scan Logs
                        </h2>
                        <a href="audit_logs.php" class="text-sm text-purple-600 hover:text-purple-800">View All →</a>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="w-full">
                            <thead>
                                <tr class="bg-gray-50">
                                    <th class="py-3 px-4 text-left text-sm font-semibold text-gray-600">Student</th>
                                    <th class="py-3 px-4 text-left text-sm font-semibold text-gray-600">Activity</th>
                                    <th class="py-3 px-4 text-left text-sm font-semibold text-gray-600">Type</th>
                                    <th class="py-3 px-4 text-left text-sm font-semibold text-gray-600">Status</th>
                                    <th class="py-3 px-4 text-left text-sm font-semibold text-gray-600">User</th>
                                    <th class="py-3 px-4 text-left text-sm font-semibold text-gray-600">Time</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-200">
                                <?php foreach ($recent_scans as $scan): ?>
                                <tr class="hover:bg-gray-50 transition-colors">
                                    <td class="py-3 px-4">
                                        <div class="font-medium text-gray-900"><?php echo htmlspecialchars($scan['student_name'] ?? 'N/A'); ?></div>
                                        <div class="text-sm text-gray-600"><?php echo htmlspecialchars($scan['student_code']); ?></div>
                                    </td>
                                    <td class="py-3 px-4 text-sm text-gray-700"><?php echo htmlspecialchars($scan['activity_name'] ?? 'N/A'); ?></td>
                                    <td class="py-3 px-4">
                                        <?php if ($scan['scan_type'] === 'attendance'): ?>
                                        <span class="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs font-semibold">
                                            Attendance
                                        </span>
                                        <?php else: ?>
                                        <span class="px-2 py-1 bg-red-100 text-red-800 rounded text-xs font-semibold">
                                            Fines
                                        </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="py-3 px-4">
                                        <?php if ($scan['action'] === 'success'): ?>
                                        <span class="px-2 py-1 bg-green-100 text-green-800 rounded text-xs font-semibold">
                                            Success
                                        </span>
                                        <?php else: ?>
                                        <span class="px-2 py-1 bg-yellow-100 text-yellow-800 rounded text-xs font-semibold">
                                            <?php echo htmlspecialchars($scan['action']); ?>
                                        </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="py-3 px-4 text-sm text-gray-700"><?php echo htmlspecialchars($scan['user_name'] ?? 'System'); ?></td>
                                    <td class="py-3 px-4 text-sm text-gray-500"><?php echo formatDate($scan['created_at'], 'h:i A'); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="mt-8 bg-white rounded-xl shadow-lg p-6">
                <h2 class="text-xl font-bold text-gray-800 mb-4">Quick Actions</h2>
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <a href="register.php" class="p-4 bg-gradient-to-r from-green-50 to-green-100 border border-green-200 rounded-lg hover:shadow-md transition-shadow text-center">
                        <i class="fas fa-user-plus text-green-600 text-2xl mb-2"></i>
                        <div class="font-semibold text-gray-800">Register Student</div>
                        <div class="text-sm text-gray-600">Add new student</div>
                    </a>
                    <a href="create_activity.php" class="p-4 bg-gradient-to-r from-blue-50 to-blue-100 border border-blue-200 rounded-lg hover:shadow-md transition-shadow text-center">
                        <i class="fas fa-calendar-plus text-blue-600 text-2xl mb-2"></i>
                        <div class="font-semibold text-gray-800">Create Activity</div>
                        <div class="text-sm text-gray-600">Schedule event</div>
                    </a>
                    <a href="scan_attendance.php" class="p-4 bg-gradient-to-r from-purple-50 to-purple-100 border border-purple-200 rounded-lg hover:shadow-md transition-shadow text-center">
                        <i class="fas fa-qrcode text-purple-600 text-2xl mb-2"></i>
                        <div class="font-semibold text-gray-800">Scan Attendance</div>
                        <div class="text-sm text-gray-600">QR code scanning</div>
                    </a>
                    <a href="monthly_report.php" class="p-4 bg-gradient-to-r from-orange-50 to-orange-100 border border-orange-200 rounded-lg hover:shadow-md transition-shadow text-center">
                        <i class="fas fa-file-invoice-dollar text-orange-600 text-2xl mb-2"></i>
                        <div class="font-semibold text-gray-800">Generate Report</div>
                        <div class="text-sm text-gray-600">Monthly summary</div>
                    </a>
                </div>
            </div>
            <?php else: ?>
            <!-- Content for other pages will be loaded here -->
            <div class="text-center py-12">
                <i class="fas fa-cogs text-4xl text-gray-400 mb-4"></i>
                <h3 class="text-xl font-semibold text-gray-700">Page Content</h3>
                <p class="text-gray-600">Content for <?php echo getPageTitle($current_page); ?> will be displayed here.</p>
            </div>
            <?php endif; ?>
        </div>

        <!-- Footer -->
        <div class="bg-white border-t px-6 py-4">
            <div class="flex flex-col md:flex-row justify-between items-center">
                <div class="text-sm text-gray-600">
                    <span class="font-semibold">Multi-Campus Attendance System</span> © 2025
                </div>
                <div class="flex items-center space-x-4 mt-2 md:mt-0">
                    <span class="text-sm text-gray-600">Server Time:</span>
                    <span class="font-mono text-sm text-gray-800" id="serverTime"><?php echo date('Y-m-d H:i:s'); ?></span>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Toggle Sidebar
        document.getElementById('toggleSidebar').addEventListener('click', function() {
            const sidebar = document.querySelector('.sidebar');
            const sidebarTexts = document.querySelectorAll('.sidebar-text');
            
            if (sidebar.classList.contains('sidebar-full')) {
                sidebar.classList.remove('sidebar-full');
                sidebar.classList.add('sidebar-mini');
                sidebarTexts.forEach(text => text.classList.add('hidden'));
            } else {
                sidebar.classList.remove('sidebar-mini');
                sidebar.classList.add('sidebar-full');
                sidebarTexts.forEach(text => text.classList.remove('hidden'));
            }
        });

        // Update server time
        function updateServerTime() {
            const now = new Date();
            const formatted = now.getFullYear() + '-' + 
                            String(now.getMonth() + 1).padStart(2, '0') + '-' + 
                            String(now.getDate()).padStart(2, '0') + ' ' + 
                            String(now.getHours()).padStart(2, '0') + ':' + 
                            String(now.getMinutes()).padStart(2, '0') + ':' + 
                            String(now.getSeconds()).padStart(2, '0');
            document.getElementById('serverTime').textContent = formatted;
        }
        setInterval(updateServerTime, 1000);

        <?php if ($current_page == 'admin_dashboard.php'): ?>
        // Campus Distribution Chart
        const campusCtx = document.getElementById('campusChart')?.getContext('2d');
        if (campusCtx) {
            const campusChart = new Chart(campusCtx, {
                type: 'doughnut',
                data: {
                    labels: [
                        <?php foreach ($campus_stats as $campus): ?>
                        '<?php echo $campus['campus_name']; ?>',
                        <?php endforeach; ?>
                    ],
                    datasets: [{
                        data: [
                            <?php foreach ($campus_stats as $campus): ?>
                            <?php echo $campus['student_count']; ?>,
                            <?php endforeach; ?>
                        ],
                        backgroundColor: [
                            '#3B82F6', '#10B981', '#F59E0B', '#EF4444', 
                            '#8B5CF6', '#EC4899', '#06B6D4'
                        ],
                        borderWidth: 2,
                        borderColor: '#fff',
                        hoverOffset: 15
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    cutout: '70%',
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    const label = context.label || '';
                                    const value = context.raw || 0;
                                    const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                    const percentage = Math.round((value / total) * 100);
                                    return `${label}: ${value} students (${percentage}%)`;
                                }
                            }
                        }
                    }
                }
            });
        }
        <?php endif; ?>
    </script>
</body>
</html>