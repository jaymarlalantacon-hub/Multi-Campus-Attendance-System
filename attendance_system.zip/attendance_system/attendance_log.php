<?php
session_start();
require_once 'db.php';

// Check if coordinator
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'coordinator' || !$_SESSION['campus_id']) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['full_name'];
$campus_id = $_SESSION['campus_id'];

// Get campus info
$stmt = $conn->prepare("SELECT * FROM campuses WHERE campus_id = ?");
$stmt->bind_param("i", $campus_id);
$stmt->execute();
$campus = $stmt->get_result()->fetch_assoc();

// Initialize filters
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$activity_id = isset($_GET['activity_id']) ? intval($_GET['activity_id']) : 0;
$status = isset($_GET['status']) ? $_GET['status'] : '';
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : '';
$date_to = isset($_GET['date_to']) ? $_GET['date_to'] : '';
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

// Build query with filters
$where_conditions = ["s.campus_id = ?"];
$params = [$campus_id];
$param_types = "i";

// Activity filter
if ($activity_id > 0) {
    $where_conditions[] = "att.activity_id = ?";
    $params[] = $activity_id;
    $param_types .= "i";
}

// Status filter
if (!empty($status) && in_array($status, ['Present', 'Late', 'Absent', 'Excused'])) {
    $where_conditions[] = "att.status = ?";
    $params[] = $status;
    $param_types .= "s";
}

// Date range filter
if (!empty($date_from)) {
    $where_conditions[] = "DATE(att.scanned_at) >= ?";
    $params[] = $date_from;
    $param_types .= "s";
}
if (!empty($date_to)) {
    $where_conditions[] = "DATE(att.scanned_at) <= ?";
    $params[] = $date_to;
    $param_types .= "s";
}

// Search filter
if (!empty($search)) {
    $where_conditions[] = "(s.full_name LIKE ? OR s.student_number LIKE ? OR a.activity_name LIKE ?)";
    $search_term = "%$search%";
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
    $param_types .= "sss";
}

$where_clause = !empty($where_conditions) ? "WHERE " . implode(" AND ", $where_conditions) : "";

// Get total count for pagination
$count_query = "SELECT COUNT(*) as total FROM attendance att
                JOIN students s ON att.student_id = s.student_id
                JOIN activities a ON att.activity_id = a.activity_id
                $where_clause";

$stmt = $conn->prepare($count_query);
if (!empty($params)) {
    $stmt->bind_param($param_types, ...$params);
}
$stmt->execute();
$total_result = $stmt->get_result()->fetch_assoc();
$total_records = $total_result['total'] ?? 0;
$total_pages = ceil($total_records / $limit);

// Get attendance records - UPDATED: Removed course, year_level, section
$query = "SELECT att.*, 
                 s.full_name as student_name, 
                 s.student_number,
                 a.activity_name,
                 a.activity_date,
                 a.activity_time,
                 a.venue,
                 DATE(att.scanned_at) as attendance_date,
                 TIME(att.scanned_at) as attendance_time
          FROM attendance att
          JOIN students s ON att.student_id = s.student_id
          JOIN activities a ON att.activity_id = a.activity_id
          $where_clause
          ORDER BY att.scanned_at DESC
          LIMIT ? OFFSET ?";

// Add limit and offset to params
$params[] = $limit;
$params[] = $offset;
$param_types .= "ii";

$stmt = $conn->prepare($query);
$stmt->bind_param($param_types, ...$params);
$stmt->execute();
$attendance_records = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get activities for filter dropdown
$activity_query = "SELECT activity_id, activity_name, activity_date 
                   FROM activities 
                   WHERE campus_id = ? 
                   ORDER BY activity_date DESC 
                   LIMIT 50";
$stmt = $conn->prepare($activity_query);
$stmt->bind_param("i", $campus_id);
$stmt->execute();
$activities = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get statistics
$stats_query = "SELECT 
                COUNT(*) as total_attendance,
                SUM(CASE WHEN att.status = 'Present' THEN 1 ELSE 0 END) as total_present,
                SUM(CASE WHEN att.status = 'Late' THEN 1 ELSE 0 END) as total_late,
                SUM(CASE WHEN att.status = 'Absent' THEN 1 ELSE 0 END) as total_absent,
                SUM(CASE WHEN att.status = 'Excused' THEN 1 ELSE 0 END) as total_excused,
                COUNT(DISTINCT att.student_id) as unique_students,
                COUNT(DISTINCT att.activity_id) as unique_activities
                FROM attendance att
                JOIN students s ON att.student_id = s.student_id
                WHERE s.campus_id = ?";

// Add date filters to stats if applicable
$stats_params = [$campus_id];
$stats_types = "i";

if (!empty($date_from)) {
    $stats_query .= " AND DATE(att.scanned_at) >= ?";
    $stats_params[] = $date_from;
    $stats_types .= "s";
}
if (!empty($date_to)) {
    $stats_query .= " AND DATE(att.scanned_at) <= ?";
    $stats_params[] = $date_to;
    $stats_types .= "s";
}

$stmt = $conn->prepare($stats_query);
if (!empty($stats_params)) {
    $stmt->bind_param($stats_types, ...$stats_params);
}
$stmt->execute();
$stats = $stmt->get_result()->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Log | Multi-Campus Attendance System</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <style>
        * { 
            font-family: 'Segoe UI', 'Inter', system-ui, -apple-system, sans-serif; 
        }
        .gradient-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        .status-present { background-color: #d1fae5; color: #065f46; }
        .status-late { background-color: #fef3c7; color: #92400e; }
        .status-absent { background-color: #fee2e2; color: #991b1b; }
        .status-excused { background-color: #dbeafe; color: #1e40af; }
        .dataTables_wrapper .dataTables_filter input {
            border: 1px solid #d1d5db;
            border-radius: 0.375rem;
            padding: 0.5rem 0.75rem;
            margin-left: 0.5rem;
        }
        .dataTables_wrapper .dataTables_length select {
            border: 1px solid #d1d5db;
            border-radius: 0.375rem;
            padding: 0.25rem 0.5rem;
        }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">

<!-- Header -->
<header class="gradient-header text-white shadow-lg">
    <div class="container mx-auto px-4 py-4">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div class="flex items-center gap-3">
                <a href="coordinator_dashboard.php" class="text-white hover:text-gray-200">
                    <i class="fas fa-arrow-left text-xl"></i>
                </a>
                <div>
                    <h1 class="text-2xl font-bold">Attendance Log</h1>
                    <p class="text-purple-200 text-sm"><?php echo htmlspecialchars($campus['campus_name']); ?> Campus</p>
                </div>
            </div>
            <div class="flex items-center gap-4">
                <a href="export_attendance.php?<?php echo http_build_query($_GET); ?>" 
                   class="bg-white/20 backdrop-blur-sm hover:bg-white/30 px-4 py-2 rounded-lg transition-all">
                    <i class="fas fa-file-export mr-2"></i>Export CSV
                </a>
                <a href="dashboard.php" class="bg-white/20 backdrop-blur-sm hover:bg-white/30 px-4 py-2 rounded-lg transition-all">
                    <i class="fas fa-tachometer-alt mr-2"></i>Dashboard
                </a>
            </div>
        </div>
    </div>
</header>

<main class="container mx-auto px-4 py-8">
    <!-- Stats Overview -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <div class="bg-white rounded-xl shadow p-4 border">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500">Total Records</p>
                    <p class="text-2xl font-bold text-gray-900"><?php echo number_format($stats['total_attendance'] ?? 0); ?></p>
                </div>
                <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-history text-blue-600 text-xl"></i>
                </div>
            </div>
        </div>
        
        <div class="bg-white rounded-xl shadow p-4 border">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500">Present</p>
                    <p class="text-2xl font-bold text-green-600"><?php echo number_format($stats['total_present'] ?? 0); ?></p>
                </div>
                <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-user-check text-green-600 text-xl"></i>
                </div>
            </div>
        </div>
        
        <div class="bg-white rounded-xl shadow p-4 border">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500">Late</p>
                    <p class="text-2xl font-bold text-yellow-600"><?php echo number_format($stats['total_late'] ?? 0); ?></p>
                </div>
                <div class="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-user-clock text-yellow-600 text-xl"></i>
                </div>
            </div>
        </div>
        
        <div class="bg-white rounded-xl shadow p-4 border">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500">Unique Students</p>
                    <p class="text-2xl font-bold text-purple-600"><?php echo number_format($stats['unique_students'] ?? 0); ?></p>
                </div>
                <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-users text-purple-600 text-xl"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Filters Card -->
    <div class="bg-white rounded-2xl shadow-lg p-6 border mb-8">
        <h3 class="text-lg font-bold text-gray-900 mb-4 flex items-center">
            <i class="fas fa-filter text-blue-600 mr-3"></i>
            Filter Attendance Records
        </h3>
        
        <form method="GET" action="" class="space-y-4">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <!-- Search -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        <i class="fas fa-search text-gray-500 mr-2"></i>
                        Search
                    </label>
                    <input type="text" 
                           name="search" 
                           value="<?php echo htmlspecialchars($search); ?>"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                           placeholder="Name, Student ID, or Activity">
                </div>
                
                <!-- Activity Filter -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        <i class="fas fa-calendar text-blue-500 mr-2"></i>
                        Activity
                    </label>
                    <select name="activity_id" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                        <option value="">All Activities</option>
                        <?php foreach ($activities as $activity): ?>
                            <option value="<?php echo $activity['activity_id']; ?>" 
                                <?php echo $activity_id == $activity['activity_id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($activity['activity_name'] . ' (' . date('M d, Y', strtotime($activity['activity_date'])) . ')'); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <!-- Status Filter -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        <i class="fas fa-user-check text-green-500 mr-2"></i>
                        Status
                    </label>
                    <select name="status" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                        <option value="">All Status</option>
                        <option value="Present" <?php echo $status == 'Present' ? 'selected' : ''; ?>>Present</option>
                        <option value="Late" <?php echo $status == 'Late' ? 'selected' : ''; ?>>Late</option>
                        <option value="Absent" <?php echo $status == 'Absent' ? 'selected' : ''; ?>>Absent</option>
                        <option value="Excused" <?php echo $status == 'Excused' ? 'selected' : ''; ?>>Excused</option>
                    </select>
                </div>
                
                <!-- Date Range -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        <i class="fas fa-calendar-alt text-purple-500 mr-2"></i>
                        Date Range
                    </label>
                    <div class="flex space-x-2">
                        <input type="date" 
                               name="date_from" 
                               value="<?php echo htmlspecialchars($date_from); ?>"
                               class="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                        <input type="date" 
                               name="date_to" 
                               value="<?php echo htmlspecialchars($date_to); ?>"
                               class="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    </div>
                </div>
            </div>
            
            <div class="flex justify-between items-center pt-4 border-t">
                <div class="text-sm text-gray-600">
                    <?php if (!empty($search) || !empty($activity_id) || !empty($status) || !empty($date_from) || !empty($date_to)): ?>
                        <span class="text-blue-600">
                            <i class="fas fa-filter mr-1"></i>
                            Filters Applied: <?php echo $total_records; ?> records found
                        </span>
                    <?php else: ?>
                        Showing all <?php echo $total_records; ?> attendance records
                    <?php endif; ?>
                </div>
                <div class="flex space-x-2">
                    <button type="submit" 
                            class="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium">
                        <i class="fas fa-filter mr-2"></i>Apply Filters
                    </button>
                    <a href="attendance_log.php" 
                       class="px-6 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors font-medium">
                        <i class="fas fa-redo mr-2"></i>Reset
                    </a>
                </div>
            </div>
        </form>
    </div>

    <!-- Attendance Records Table -->
    <div class="bg-white rounded-2xl shadow-lg overflow-hidden border">
        <div class="px-6 py-4 border-b bg-gray-50 flex justify-between items-center">
            <div>
                <h3 class="text-lg font-bold text-gray-900 flex items-center">
                    <i class="fas fa-list-alt text-blue-600 mr-3"></i>
                    Attendance Records
                </h3>
                <p class="text-sm text-gray-600 mt-1">Showing <?php echo min($limit, count($attendance_records)); ?> of <?php echo number_format($total_records); ?> records</p>
            </div>
            <div class="flex items-center space-x-2">
                <button onclick="window.print()" class="px-4 py-2 text-sm border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                    <i class="fas fa-print mr-2"></i>Print
                </button>
                <button id="exportBtn" class="px-4 py-2 text-sm bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                    <i class="fas fa-file-excel mr-2"></i>Export
                </button>
            </div>
        </div>
        
        <?php if (!empty($attendance_records)): ?>
            <div class="overflow-x-auto">
                <table id="attendanceTable" class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Student
                            </th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Activity
                            </th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Date & Time
                            </th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Status
                            </th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Actions
                            </th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php foreach ($attendance_records as $record): ?>
                            <tr class="hover:bg-gray-50 transition-colors">
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="flex items-center">
                                        <div class="flex-shrink-0 h-10 w-10 bg-blue-100 rounded-lg flex items-center justify-center">
                                            <i class="fas fa-user text-blue-600"></i>
                                        </div>
                                        <div class="ml-4">
                                            <div class="text-sm font-medium text-gray-900">
                                                <?php echo htmlspecialchars($record['student_name']); ?>
                                            </div>
                                            <div class="text-sm text-gray-500">
                                                <?php echo htmlspecialchars($record['student_number']); ?>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm font-medium text-gray-900">
                                        <?php echo htmlspecialchars($record['activity_name']); ?>
                                    </div>
                                    <div class="text-sm text-gray-500">
                                        <?php echo !empty($record['venue']) ? htmlspecialchars($record['venue']) : 'Venue not specified'; ?>
                                    </div>
                                    <div class="text-xs text-gray-500 mt-1">
                                        <?php echo !empty($record['activity_date']) ? date('M d, Y', strtotime($record['activity_date'])) : 'Date not set'; ?>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-gray-900">
                                        <?php echo !empty($record['attendance_date']) ? date('M d, Y', strtotime($record['attendance_date'])) : 'N/A'; ?>
                                    </div>
                                    <div class="text-sm text-gray-500">
                                        <?php echo !empty($record['attendance_time']) ? date('h:i A', strtotime($record['attendance_time'])) : 'N/A'; ?>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full 
                                        <?php echo $record['status'] == 'Present' ? 'bg-green-100 text-green-800' : 
                                                  ($record['status'] == 'Late' ? 'bg-yellow-100 text-yellow-800' : 
                                                  ($record['status'] == 'Excused' ? 'bg-blue-100 text-blue-800' : 'bg-red-100 text-red-800')); ?>">
                                        <?php echo $record['status']; ?>
                                    </span>
                                    <?php if ($record['status'] == 'Late'): ?>
                                        <div class="text-xs text-gray-500 mt-1">
                                            <i class="fas fa-clock mr-1"></i>
                                            <?php 
                                            if (!empty($record['attendance_time']) && !empty($record['activity_time'])) {
                                                $attendance_time = strtotime($record['attendance_time']);
                                                $activity_time = strtotime($record['activity_time']);
                                                $late_minutes = round(($attendance_time - $activity_time) / 60);
                                                if ($late_minutes > 0) {
                                                    echo $late_minutes . ' minutes late';
                                                }
                                            }
                                            ?>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                    <div class="flex space-x-2">
                                        <button onclick="viewAttendanceDetails(<?php echo $record['attendance_id']; ?>)" 
                                                class="text-blue-600 hover:text-blue-900 transition-colors"
                                                title="View Details">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button onclick="editAttendance(<?php echo $record['attendance_id']; ?>)" 
                                                class="text-green-600 hover:text-green-900 transition-colors"
                                                title="Edit Status">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button onclick="deleteAttendance(<?php echo $record['attendance_id']; ?>)" 
                                                class="text-red-600 hover:text-red-900 transition-colors"
                                                title="Delete Record">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
                <div class="px-6 py-4 border-t bg-gray-50">
                    <div class="flex flex-col md:flex-row justify-between items-center">
                        <div class="text-sm text-gray-700 mb-4 md:mb-0">
                            Showing <?php echo ($offset + 1); ?> to <?php echo min($offset + $limit, $total_records); ?> of <?php echo number_format($total_records); ?> entries
                        </div>
                        <div class="flex items-center space-x-2">
                            <?php if ($page > 1): ?>
                                <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => 1])); ?>" 
                                   class="px-3 py-2 border rounded-lg hover:bg-gray-50 transition-colors">
                                    <i class="fas fa-angle-double-left"></i>
                                </a>
                                <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>" 
                                   class="px-3 py-2 border rounded-lg hover:bg-gray-50 transition-colors">
                                    <i class="fas fa-angle-left"></i>
                                </a>
                            <?php endif; ?>
                            
                            <?php
                            $start_page = max(1, $page - 2);
                            $end_page = min($total_pages, $page + 2);
                            
                            for ($i = $start_page; $i <= $end_page; $i++):
                            ?>
                                <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>" 
                                   class="px-3 py-2 border rounded-lg transition-colors <?php echo $i == $page ? 'bg-blue-600 text-white border-blue-600' : 'hover:bg-gray-50'; ?>">
                                    <?php echo $i; ?>
                                </a>
                            <?php endfor; ?>
                            
                            <?php if ($page < $total_pages): ?>
                                <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>" 
                                   class="px-3 py-2 border rounded-lg hover:bg-gray-50 transition-colors">
                                    <i class="fas fa-angle-right"></i>
                                </a>
                                <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $total_pages])); ?>" 
                                   class="px-3 py-2 border rounded-lg hover:bg-gray-50 transition-colors">
                                    <i class="fas fa-angle-double-right"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            
        <?php else: ?>
            <div class="text-center py-12">
                <div class="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <i class="fas fa-clipboard-list text-3xl text-gray-400"></i>
                </div>
                <h3 class="text-lg font-medium text-gray-900 mb-2">No attendance records found</h3>
                <p class="text-gray-600 mb-6">
                    <?php if (!empty($search) || !empty($activity_id) || !empty($status) || !empty($date_from) || !empty($date_to)): ?>
                        No records match your filters. Try adjusting your search criteria.
                    <?php else: ?>
                        No attendance has been recorded yet.
                    <?php endif; ?>
                </p>
                <div class="space-x-4">
                    <a href="scan_attendance.php" class="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                        <i class="fas fa-qrcode mr-2"></i>
                        Start Scanning Attendance
                    </a>
                    <a href="attendance_log.php" class="inline-flex items-center px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors">
                        <i class="fas fa-redo mr-2"></i>
                        Clear Filters
                    </a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</main>

<!-- Footer -->
<footer class="bg-white border-t mt-8">
    <div class="container mx-auto px-4 py-6">
        <div class="text-center">
            <p class="text-gray-600">
                <i class="fas fa-school mr-2"></i>
                <?php echo htmlspecialchars($campus['campus_name']); ?> Campus • Attendance Management
            </p>
            <p class="text-sm text-gray-500 mt-2">
                <i class="far fa-copyright mr-1"></i> <?php echo date('Y'); ?> Multi-Campus Attendance System
            </p>
        </div>
    </div>
</footer>

<!-- Modal for Viewing Details -->
<div id="detailsModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50 hidden">
    <div class="relative top-20 mx-auto p-5 border w-full max-w-2xl shadow-lg rounded-2xl bg-white">
        <!-- Modal content will be loaded here via AJAX -->
    </div>
</div>

<script>
// Initialize DataTable
$(document).ready(function() {
    $('#attendanceTable').DataTable({
        paging: false,
        searching: false,
        info: false,
        ordering: true,
        responsive: true,
        order: [[2, 'desc']] // Sort by date descending by default
    });
});

// Export button functionality
document.getElementById('exportBtn').addEventListener('click', function() {
    const queryParams = new URLSearchParams(window.location.search);
    window.location.href = 'export_attendance.php?' + queryParams.toString();
});

// View attendance details - UPDATED to match your database schema
function viewAttendanceDetails(attendanceId) {
    // Create a simple modal with basic information since get_attendance_details.php expects course field
    fetch(`get_attendance_simple.php?id=${attendanceId}`)
        .then(response => response.text())
        .then(html => {
            document.getElementById('detailsModal').innerHTML = `
                <div class="relative top-20 mx-auto p-5 border w-full max-w-2xl shadow-lg rounded-2xl bg-white">
                    <div class="flex justify-between items-center mb-6">
                        <h3 class="text-xl font-bold text-gray-900">Attendance Details</h3>
                        <button onclick="closeModal()" class="text-gray-400 hover:text-gray-600">
                            <i class="fas fa-times text-2xl"></i>
                        </button>
                    </div>
                    <div class="modal-content">
                        ${html}
                    </div>
                    <div class="mt-6 pt-6 border-t flex justify-end">
                        <button onclick="closeModal()" class="px-6 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors">
                            Close
                        </button>
                    </div>
                </div>`;
            document.getElementById('detailsModal').classList.remove('hidden');
        })
        .catch(error => {
            console.error('Error:', error);
            // Fallback to basic modal
            showBasicAttendanceDetails(attendanceId);
        });
}

// Fallback function if AJAX fails
function showBasicAttendanceDetails(attendanceId) {
    // You can implement a basic modal here or redirect to a details page
    alert('Unable to load details. Please try again or contact support.');
}

// Edit attendance
function editAttendance(attendanceId) {
    const newStatus = prompt('Enter new status (Present, Late, Absent, Excused):');
    if (newStatus && ['Present', 'Late', 'Absent', 'Excused'].includes(newStatus)) {
        fetch('update_attendance.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `id=${attendanceId}&status=${newStatus}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Attendance status updated successfully!');
                location.reload();
            } else {
                alert('Error: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Failed to update attendance status.');
        });
    }
}

// Delete attendance
function deleteAttendance(attendanceId) {
    if (confirm('Are you sure you want to delete this attendance record? This action cannot be undone.')) {
        fetch('delete_attendance.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `id=${attendanceId}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Attendance record deleted successfully!');
                location.reload();
            } else {
                alert('Error: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Failed to delete attendance record.');
        });
    }
}

// Close modal
function closeModal() {
    document.getElementById('detailsModal').classList.add('hidden');
}

// Close modal when clicking outside
document.getElementById('detailsModal').addEventListener('click', function(e) {
    if (e.target === this) {
        closeModal();
    }
});
</script>
</body>
</html>