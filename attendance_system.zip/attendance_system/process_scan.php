<?php
session_start();
require_once 'db.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit();
}

if (!isset($_POST['activity_id']) || !isset($_POST['qr_data'])) {
    echo json_encode(['success' => false, 'message' => 'Missing parameters']);
    exit();
}

$activity_id = intval($_POST['activity_id']);
$qr_data = trim($_POST['qr_data']);
$user_id = intval($_POST['user_id']);

// Extract student ID from QR data (could be just ID or JSON)
$student_id = null;
$student_number = null;

// Try to parse as JSON first
$decoded = json_decode($qr_data, true);
if ($decoded && isset($decoded['student_id'])) {
    $student_id = intval($decoded['student_id']);
} elseif ($decoded && isset($decoded['student_number'])) {
    $student_number = $decoded['student_number'];
} else {
    // Try as direct student ID
    if (is_numeric($qr_data)) {
        $student_id = intval($qr_data);
    } else {
        // Try as student number
        $student_number = $qr_data;
    }
}

// Find student
$student = null;
if ($student_id) {
    $stmt = $conn->prepare("SELECT * FROM students WHERE student_id = ? AND status = 'active'");
    $stmt->bind_param("i", $student_id);
} elseif ($student_number) {
    $stmt = $conn->prepare("SELECT * FROM students WHERE student_number = ? AND status = 'active'");
    $stmt->bind_param("s", $student_number);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid QR code format']);
    exit();
}

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Student not found or inactive']);
    exit();
}

$student = $result->fetch_assoc();
$student_id = $student['student_id'];

// Check if activity exists and is active
$activity_stmt = $conn->prepare("SELECT * FROM activities WHERE activity_id = ? AND status = 'active'");
$activity_stmt->bind_param("i", $activity_id);
$activity_stmt->execute();
$activity_result = $activity_stmt->get_result();

if ($activity_result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Activity not found or inactive']);
    exit();
}

$activity = $activity_result->fetch_assoc();

// Check if student is already scanned for this activity
$check_stmt = $conn->prepare("SELECT * FROM scan_logs WHERE student_id = ? AND activity_id = ? AND scan_type = 'attendance'");
$check_stmt->bind_param("ii", $student_id, $activity_id);
$check_stmt->execute();
$check_result = $check_stmt->get_result();

if ($check_result->num_rows > 0) {
    echo json_encode([
        'success' => false, 
        'message' => 'Already scanned',
        'details' => 'Student already scanned for this activity'
    ]);
    exit();
}

// Record the scan
$insert_stmt = $conn->prepare("INSERT INTO scan_logs (student_id, activity_id, user_id, scan_type, action, remarks) VALUES (?, ?, ?, 'attendance', 'success', 'Attendance recorded')");
$insert_stmt->bind_param("iii", $student_id, $activity_id, $user_id);

if ($insert_stmt->execute()) {
    echo json_encode([
        'success' => true,
        'message' => 'Attendance recorded successfully',
        'student_name' => $student['full_name'],
        'student_number' => $student['student_number']
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
}

$insert_stmt->close();
?>