<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['full_name'];
$user_type = $_SESSION['user_type'];
$user_campus_id = $_SESSION['campus_id'];

// Get student ID from URL
$student_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($student_id <= 0) {
    header('Location: fines.php');
    exit();
}

// Get student information
$student_query = "SELECT s.*, c.campus_name, 
                  (SELECT COUNT(*) FROM fines f WHERE f.student_id = s.student_id) as total_fines,
                  (SELECT COUNT(*) FROM fines f WHERE f.student_id = s.student_id AND f.status IN ('pending', 'partial')) as pending_fines,
                  (SELECT COALESCE(SUM(amount), 0) FROM fines f WHERE f.student_id = s.student_id AND f.status IN ('pending', 'partial')) as pending_amount
                  FROM students s 
                  LEFT JOIN campuses c ON s.campus_id = c.campus_id 
                  WHERE s.student_id = ? AND s.status = 'active'";
$student_stmt = $conn->prepare($student_query);
$student_stmt->bind_param("i", $student_id);
$student_stmt->execute();
$student_result = $student_stmt->get_result();

if ($student_result->num_rows === 0) {
    $_SESSION['error_message'] = "Student not found or inactive.";
    header('Location: fines.php');
    exit();
}

$student = $student_result->fetch_assoc();

// Check if user has access to this student's campus
if ($user_type === 'coordinator' && $student['campus_id'] != $user_campus_id) {
    $_SESSION['error_message'] = "Access denied: You don't have permission to view this student.";
    header('Location: fines.php');
    exit();
}

// Get student's fines
$fines_query = "SELECT f.*, a.activity_name, a.activity_date,
                (SELECT COALESCE(SUM(fp.amount_paid), 0) FROM fine_payments fp WHERE fp.fine_id = f.fine_id) as paid_amount,
                u.full_name as created_by_name
                FROM fines f
                LEFT JOIN activities a ON f.activity_id = a.activity_id
                LEFT JOIN users u ON f.created_by = u.user_id
                WHERE f.student_id = ?
                ORDER BY f.created_at DESC";
$fines_stmt = $conn->prepare($fines_query);
$fines_stmt->bind_param("i", $student_id);
$fines_stmt->execute();
$fines_result = $fines_stmt->get_result();

// Get student's attendance records (recent 10) - UPDATED with correct column names
$attendance_query = "SELECT a.*, ac.activity_name, ac.activity_date,
                     u.full_name as checked_by_name
                     FROM attendance a
                     LEFT JOIN activities ac ON a.activity_id = ac.activity_id
                     LEFT JOIN users u ON a.checked_by = u.user_id
                     WHERE a.student_id = ?
                     ORDER BY a.scanned_at DESC
                     LIMIT 10";
$attendance_stmt = $conn->prepare($attendance_query);
$attendance_stmt->bind_param("i", $student_id);
$attendance_stmt->execute();
$attendance_result = $attendance_stmt->get_result();

// Get student's payment history
$payments_query = "SELECT fp.*, f.amount as fine_amount, f.reason,
                   a.activity_name,
                   u.full_name as received_by_name
                   FROM fine_payments fp
                   JOIN fines f ON fp.fine_id = f.fine_id
                   LEFT JOIN activities a ON f.activity_id = a.activity_id
                   LEFT JOIN users u ON fp.received_by = u.user_id
                   WHERE f.student_id = ?
                   ORDER BY fp.payment_date DESC, fp.created_at DESC
                   LIMIT 10";
$payments_stmt = $conn->prepare($payments_query);
$payments_stmt->bind_param("i", $student_id);
$payments_stmt->execute();
$payments_result = $payments_stmt->get_result();

// Calculate statistics - UPDATED with correct column names
$stats_query = "SELECT 
                COUNT(*) as total_activities,
                SUM(CASE WHEN status = 'Present' THEN 1 ELSE 0 END) as present_count,
                SUM(CASE WHEN status = 'Absent' THEN 1 ELSE 0 END) as absent_count,
                SUM(CASE WHEN status = 'Excused' THEN 1 ELSE 0 END) as excused_count,
                SUM(CASE WHEN status = 'Late' THEN 1 ELSE 0 END) as late_count
                FROM attendance 
                WHERE student_id = ?";
$stats_stmt = $conn->prepare($stats_query);
$stats_stmt->bind_param("i", $student_id);
$stats_stmt->execute();
$stats_result = $stats_stmt->get_result();
$attendance_stats = $stats_result->fetch_assoc();

// Get total fines amount
$total_fines_query = "SELECT 
                      COUNT(*) as fines_count,
                      COALESCE(SUM(amount), 0) as total_fines_amount,
                      COALESCE(SUM(CASE WHEN status IN ('pending', 'partial') THEN amount ELSE 0 END), 0) as pending_fines_amount,
                      COALESCE(SUM(CASE WHEN status = 'paid' THEN amount ELSE 0 END), 0) as paid_fines_amount
                      FROM fines 
                      WHERE student_id = ?";
$total_fines_stmt = $conn->prepare($total_fines_query);
$total_fines_stmt->bind_param("i", $student_id);
$total_fines_stmt->execute();
$total_fines_result = $total_fines_stmt->get_result();
$fines_stats = $total_fines_result->fetch_assoc();

// Get total payments
$total_payments_query = "SELECT 
                         COUNT(*) as payments_count,
                         COALESCE(SUM(fp.amount_paid), 0) as total_paid_amount
                         FROM fine_payments fp
                         JOIN fines f ON fp.fine_id = f.fine_id
                         WHERE f.student_id = ?";
$total_payments_stmt = $conn->prepare($total_payments_query);
$total_payments_stmt->bind_param("i", $student_id);
$total_payments_stmt->execute();
$total_payments_result = $total_payments_stmt->get_result();
$payments_stats = $total_payments_result->fetch_assoc();

// Handle actions
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        
        if ($action === 'add_fine') {
            $activity_id = intval($_POST['activity_id']) ?: null;
            $amount = floatval($_POST['amount']);
            $reason = $_POST['reason'] ?? 'absence';
            $description = $_POST['description'] ?? '';
            
            if ($amount > 0) {
                $add_fine_query = "INSERT INTO fines 
                                  (student_id, activity_id, amount, reason, description, status, created_by) 
                                  VALUES (?, ?, ?, ?, ?, 'pending', ?)";
                $add_fine_stmt = $conn->prepare($add_fine_query);
                $add_fine_stmt->bind_param("iidssi", $student_id, $activity_id, $amount, $reason, $description, $user_id);
                
                if ($add_fine_stmt->execute()) {
                    $success_message = "Fine added successfully!";
                    header("Location: student_profile.php?id=$student_id&success=" . urlencode($success_message));
                    exit();
                } else {
                    $error_message = "Failed to add fine. Please try again.";
                }
            } else {
                $error_message = "Amount must be greater than 0.";
            }
        }
        elseif ($action === 'record_payment') {
            $fine_id = intval($_POST['fine_id']);
            $amount_paid = floatval($_POST['amount_paid']);
            $payment_method = $_POST['payment_method'] ?? 'cash';
            $reference_no = $_POST['reference_no'] ?? '';
            
            // Get fine details
            $fine_check_query = "SELECT amount FROM fines WHERE fine_id = ? AND student_id = ?";
            $fine_check_stmt = $conn->prepare($fine_check_query);
            $fine_check_stmt->bind_param("ii", $fine_id, $student_id);
            $fine_check_stmt->execute();
            $fine_check_result = $fine_check_stmt->get_result();
            $fine = $fine_check_result->fetch_assoc();
            
            if ($fine && $amount_paid > 0 && $amount_paid <= $fine['amount']) {
                // Start transaction
                $conn->begin_transaction();
                
                try {
                    // Insert payment record
                    $payment_query = "INSERT INTO fine_payments 
                                     (fine_id, amount_paid, payment_date, payment_method, reference_no, received_by) 
                                     VALUES (?, ?, CURDATE(), ?, ?, ?)";
                    $payment_stmt = $conn->prepare($payment_query);
                    $payment_stmt->bind_param("idssi", $fine_id, $amount_paid, $payment_method, $reference_no, $user_id);
                    $payment_stmt->execute();
                    
                    // Calculate total paid amount
                    $total_paid_query = "SELECT SUM(amount_paid) as total_paid FROM fine_payments WHERE fine_id = ?";
                    $total_paid_stmt = $conn->prepare($total_paid_query);
                    $total_paid_stmt->bind_param("i", $fine_id);
                    $total_paid_stmt->execute();
                    $total_paid_result = $total_paid_stmt->get_result();
                    $total_paid_row = $total_paid_result->fetch_assoc();
                    $total_paid = $total_paid_row['total_paid'] ?? 0;
                    
                    // Update fine status
                    if ($total_paid >= $fine['amount']) {
                        $status = 'paid';
                    } elseif ($total_paid > 0) {
                        $status = 'partial';
                    } else {
                        $status = 'pending';
                    }
                    
                    $update_query = "UPDATE fines SET status = ?, updated_at = NOW() WHERE fine_id = ?";
                    $update_stmt = $conn->prepare($update_query);
                    $update_stmt->bind_param("si", $status, $fine_id);
                    $update_stmt->execute();
                    
                    $conn->commit();
                    
                    $success_message = "Payment of ₱" . number_format($amount_paid, 2) . " recorded successfully!";
                    header("Location: student_profile.php?id=$student_id&success=" . urlencode($success_message));
                    exit();
                    
                } catch (Exception $e) {
                    $conn->rollback();
                    $error_message = "Failed to record payment: " . $e->getMessage();
                }
            } else {
                $error_message = "Invalid payment amount or fine not found.";
            }
        }
        elseif ($action === 'update_status') {
            $fine_id = intval($_POST['fine_id']);
            $status = $_POST['status'] ?? 'pending';
            
            $update_query = "UPDATE fines SET status = ?, updated_at = NOW() WHERE fine_id = ? AND student_id = ?";
            $update_stmt = $conn->prepare($update_query);
            $update_stmt->bind_param("sii", $status, $fine_id, $student_id);
            
            if ($update_stmt->execute()) {
                $success_message = "Fine status updated successfully!";
                header("Location: student_profile.php?id=$student_id&success=" . urlencode($success_message));
                exit();
            } else {
                $error_message = "Failed to update fine status.";
            }
        }
    }
}

// Get activities for adding fines
$activities_query = "SELECT activity_id, activity_name, activity_date 
                     FROM activities 
                     WHERE (campus_id = ? OR campus_id IS NULL) 
                     AND status = 'active'
                     ORDER BY activity_date DESC";
$activities_stmt = $conn->prepare($activities_query);
$activities_stmt->bind_param("i", $student['campus_id']);
$activities_stmt->execute();
$activities_result = $activities_stmt->get_result();
$activities = [];
while ($activity = $activities_result->fetch_assoc()) {
    $activities[] = $activity;
}

// Get success message from URL
if (isset($_GET['success'])) {
    $success_message = urldecode($_GET['success']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Profile | <?php echo htmlspecialchars($student['full_name']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #3b82f6;
            --secondary-color: #8b5cf6;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
        }
        
        .card {
            background: white;
            border-radius: 1rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        
        .card:hover {
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }
        
        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        
        .status-pending { background-color: #fee2e2; color: #991b1b; }
        .status-partial { background-color: #fef3c7; color: #92400e; }
        .status-paid { background-color: #d1fae5; color: #065f46; }
        .status-cancelled { background-color: #e5e7eb; color: #374151; }
        
        .attendance-present { background-color: #d1fae5; color: #065f46; }
        .attendance-absent { background-color: #fee2e2; color: #991b1b; }
        .attendance-excused { background-color: #dbeafe; color: #1e40af; }
        .attendance-late { background-color: #fef3c7; color: #92400e; }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }
        
        .modal.active {
            display: flex;
        }
        
        .modal-content {
            background: white;
            border-radius: 1rem;
            width: 90%;
            max-width: 500px;
            max-height: 90vh;
            overflow-y: auto;
        }
        
        .tab {
            padding: 0.75rem 1.5rem;
            border-radius: 0.75rem;
            font-weight: 600;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        
        .tab.active {
            background: var(--primary-color);
            color: white;
        }
        
        .tab:hover:not(.active) {
            background: #f3f4f6;
        }
        
        .hidden {
            display: none !important;
        }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
    <!-- Navigation -->
    <nav class="bg-gradient-to-r from-blue-800 to-indigo-900 text-white shadow-lg">
        <div class="container mx-auto px-4 py-3">
            <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div class="flex items-center space-x-4">
                    <a href="fines.php" class="flex items-center hover:text-blue-200 transition-colors">
                        <i class="fas fa-arrow-left mr-2"></i> Back to Fines
                    </a>
                    <h1 class="text-xl font-bold">
                        <i class="fas fa-user-graduate mr-2"></i> Student Profile
                    </h1>
                </div>
                <div class="flex items-center space-x-4">
                    <span class="text-sm">
                        <i class="fas fa-user mr-1"></i> <?php echo htmlspecialchars($user_name); ?>
                    </span>
                    <span class="px-3 py-1 bg-blue-600 rounded-full text-sm">
                        <i class="fas fa-shield-alt mr-1"></i> <?php echo ucfirst($user_type); ?>
                    </span>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-8">
        <!-- Messages -->
        <?php if ($success_message): ?>
        <div class="mb-6 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg animate-in">
            <div class="flex items-center">
                <i class="fas fa-check-circle mr-3 text-green-600"></i>
                <span><?php echo htmlspecialchars($success_message); ?></span>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if ($error_message): ?>
        <div class="mb-6 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg animate-in">
            <div class="flex items-center">
                <i class="fas fa-exclamation-circle mr-3 text-red-600"></i>
                <span><?php echo htmlspecialchars($error_message); ?></span>
            </div>
        </div>
        <?php endif; ?>

        <!-- Student Header -->
        <div class="card p-6 mb-8">
            <div class="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
                <div class="flex items-start gap-4">
                    <div class="w-20 h-20 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center">
                        <i class="fas fa-user-graduate text-white text-3xl"></i>
                    </div>
                    <div>
                        <h1 class="text-3xl font-bold text-gray-900 mb-2"><?php echo htmlspecialchars($student['full_name']); ?></h1>
                        <div class="flex flex-wrap gap-3">
                            <span class="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-semibold">
                                <i class="fas fa-id-card mr-1"></i> <?php echo htmlspecialchars($student['student_number']); ?>
                            </span>
                            <span class="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-semibold">
                                <i class="fas fa-school mr-1"></i> <?php echo htmlspecialchars($student['campus_name']); ?>
                            </span>
                            <?php if ($student['course_year']): ?>
                            <span class="px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm font-semibold">
                                <i class="fas fa-graduation-cap mr-1"></i> <?php echo htmlspecialchars($student['course_year']); ?>
                            </span>
                            <?php endif; ?>
                            <?php if ($student['section']): ?>
                            <span class="px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full text-sm font-semibold">
                                <i class="fas fa-users mr-1"></i> Section: <?php echo htmlspecialchars($student['section']); ?>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="flex flex-col items-end">
                    <div class="text-right mb-4">
                        <div class="text-2xl font-bold text-red-600">
                            ₱<?php echo number_format($student['pending_amount'] ?? 0, 2); ?>
                        </div>
                        <div class="text-sm text-gray-600">Pending Fines Amount</div>
                    </div>
                    <div class="flex gap-2">
                        <button onclick="showAddFineModal()" class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
                            <i class="fas fa-plus-circle mr-2"></i> Add Fine
                        </button>
                        <a href="scan_fines.php?student_id=<?php echo $student_id; ?>" 
                           class="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                            <i class="fas fa-qrcode mr-2"></i> Scan Payment
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Stats -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div class="card p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm text-gray-600">Total Fines</p>
                        <h3 class="text-2xl font-bold text-gray-800"><?php echo $fines_stats['fines_count'] ?? 0; ?></h3>
                    </div>
                    <div class="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                        <i class="fas fa-file-invoice-dollar text-red-600 text-xl"></i>
                    </div>
                </div>
                <div class="mt-2">
                    <p class="text-sm text-gray-600">Total Amount: <span class="font-bold">₱<?php echo number_format($fines_stats['total_fines_amount'] ?? 0, 2); ?></span></p>
                </div>
            </div>

            <div class="card p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm text-gray-600">Pending Fines</p>
                        <h3 class="text-2xl font-bold text-gray-800"><?php echo $student['pending_fines'] ?? 0; ?></h3>
                    </div>
                    <div class="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center">
                        <i class="fas fa-clock text-yellow-600 text-xl"></i>
                    </div>
                </div>
                <div class="mt-2">
                    <p class="text-sm text-gray-600">Amount: <span class="font-bold text-yellow-600">₱<?php echo number_format($student['pending_amount'] ?? 0, 2); ?></span></p>
                </div>
            </div>

            <div class="card p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm text-gray-600">Total Payments</p>
                        <h3 class="text-2xl font-bold text-gray-800"><?php echo $payments_stats['payments_count'] ?? 0; ?></h3>
                    </div>
                    <div class="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                        <i class="fas fa-money-bill-wave text-green-600 text-xl"></i>
                    </div>
                </div>
                <div class="mt-2">
                    <p class="text-sm text-gray-600">Amount: <span class="font-bold text-green-600">₱<?php echo number_format($payments_stats['total_paid_amount'] ?? 0, 2); ?></span></p>
                </div>
            </div>

            <div class="card p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm text-gray-600">Attendance Rate</p>
                        <h3 class="text-2xl font-bold text-gray-800">
                            <?php 
                            $total = $attendance_stats['total_activities'] ?? 0;
                            $present = $attendance_stats['present_count'] ?? 0;
                            echo $total > 0 ? number_format(($present / $total) * 100, 1) : '0';
                            ?>%
                        </h3>
                    </div>
                    <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                        <i class="fas fa-calendar-check text-blue-600 text-xl"></i>
                    </div>
                </div>
                <div class="mt-2">
                    <p class="text-sm text-gray-600"><?php echo $present ?? 0; ?> present of <?php echo $total ?? 0; ?> activities</p>
                </div>
            </div>
        </div>

        <!-- Tabs -->
        <div class="flex flex-wrap gap-2 mb-8">
            <div class="tab active" onclick="showTab('fines')">
                <i class="fas fa-file-invoice-dollar mr-2"></i> Fines History
            </div>
            <div class="tab" onclick="showTab('payments')">
                <i class="fas fa-money-bill-wave mr-2"></i> Payment History
            </div>
            <div class="tab" onclick="showTab('attendance')">
                <i class="fas fa-calendar-alt mr-2"></i> Attendance Records
            </div>
            <div class="tab" onclick="showTab('details')">
                <i class="fas fa-info-circle mr-2"></i> Student Details
            </div>
        </div>

        <!-- Fines Tab -->
        <div id="finesTab" class="tab-content">
            <div class="card p-6">
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-xl font-bold text-gray-800">Fines History</h2>
                    <div class="text-sm text-gray-600">
                        Showing <?php echo $fines_result->num_rows; ?> fines
                    </div>
                </div>
                
                <?php if ($fines_result->num_rows > 0): ?>
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead>
                            <tr class="bg-gray-50 border-b border-gray-200">
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Activity</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Amount</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Paid</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Remaining</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Status</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Date</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($fine = $fines_result->fetch_assoc()): ?>
                            <?php 
                            $paid = $fine['paid_amount'] ?? 0;
                            $remaining = $fine['amount'] - $paid;
                            ?>
                            <tr class="border-b border-gray-100 hover:bg-gray-50">
                                <td class="py-3 px-4">
                                    <div class="font-medium text-gray-900"><?php echo htmlspecialchars($fine['activity_name'] ?? 'General Fine'); ?></div>
                                    <div class="text-sm text-gray-500"><?php echo ucfirst($fine['reason']); ?></div>
                                    <?php if ($fine['description']): ?>
                                    <div class="text-xs text-gray-400 mt-1"><?php echo htmlspecialchars($fine['description']); ?></div>
                                    <?php endif; ?>
                                </td>
                                <td class="py-3 px-4">
                                    <div class="font-bold text-gray-900">₱<?php echo number_format($fine['amount'], 2); ?></div>
                                </td>
                                <td class="py-3 px-4">
                                    <div class="text-green-600">₱<?php echo number_format($paid, 2); ?></div>
                                </td>
                                <td class="py-3 px-4">
                                    <div class="text-red-600">₱<?php echo number_format($remaining, 2); ?></div>
                                </td>
                                <td class="py-3 px-4">
                                    <?php 
                                    $status_colors = [
                                        'pending' => 'status-pending',
                                        'partial' => 'status-partial',
                                        'paid' => 'status-paid',
                                        'cancelled' => 'status-cancelled'
                                    ];
                                    ?>
                                    <span class="status-badge <?php echo $status_colors[$fine['status']] ?? 'status-pending'; ?>">
                                        <?php echo ucfirst($fine['status']); ?>
                                    </span>
                                </td>
                                <td class="py-3 px-4 text-sm text-gray-600">
                                    <?php echo date('M d, Y', strtotime($fine['created_at'])); ?>
                                </td>
                                <td class="py-3 px-4">
                                    <div class="flex space-x-2">
                                        <?php if ($fine['status'] !== 'paid' && $remaining > 0): ?>
                                        <button onclick="showPaymentModal(<?php echo $fine['fine_id']; ?>, <?php echo $remaining; ?>)" 
                                                class="px-3 py-1 bg-green-100 text-green-800 rounded text-sm font-medium hover:bg-green-200">
                                            <i class="fas fa-money-bill-wave mr-1"></i> Pay
                                        </button>
                                        <?php endif; ?>
                                        <a href="fine_payments.php?fine_id=<?php echo $fine['fine_id']; ?>" 
                                           class="px-3 py-1 bg-blue-100 text-blue-800 rounded text-sm font-medium hover:bg-blue-200">
                                            <i class="fas fa-history mr-1"></i> View
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div class="text-center py-12">
                    <i class="fas fa-check-circle text-green-500 text-5xl mb-4"></i>
                    <h3 class="text-xl font-bold text-gray-800 mb-2">No Fines Recorded</h3>
                    <p class="text-gray-600 mb-6">This student has no fine records.</p>
                    <button onclick="showAddFineModal()" class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
                        <i class="fas fa-plus-circle mr-2"></i> Add First Fine
                    </button>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Payments Tab -->
        <div id="paymentsTab" class="tab-content hidden">
            <div class="card p-6">
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-xl font-bold text-gray-800">Payment History</h2>
                    <div class="text-sm text-gray-600">
                        Showing <?php echo $payments_result->num_rows; ?> payments
                    </div>
                </div>
                
                <?php if ($payments_result->num_rows > 0): ?>
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead>
                            <tr class="bg-gray-50 border-b border-gray-200">
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Date</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Fine Reason</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Amount Paid</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Method</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Reference</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Received By</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($payment = $payments_result->fetch_assoc()): ?>
                            <tr class="border-b border-gray-100 hover:bg-gray-50">
                                <td class="py-3 px-4">
                                    <div class="font-medium text-gray-900"><?php echo date('M d, Y', strtotime($payment['payment_date'])); ?></div>
                                    <div class="text-sm text-gray-500"><?php echo date('h:i A', strtotime($payment['created_at'])); ?></div>
                                </td>
                                <td class="py-3 px-4">
                                    <div class="font-medium text-gray-900"><?php echo htmlspecialchars($payment['activity_name'] ?? 'General Fine'); ?></div>
                                    <div class="text-sm text-gray-500"><?php echo ucfirst($payment['reason']); ?></div>
                                </td>
                                <td class="py-3 px-4">
                                    <div class="font-bold text-green-600">₱<?php echo number_format($payment['amount_paid'], 2); ?></div>
                                    <div class="text-sm text-gray-500">of ₱<?php echo number_format($payment['fine_amount'], 2); ?></div>
                                </td>
                                <td class="py-3 px-4">
                                    <span class="px-2 py-1 bg-gray-100 text-gray-800 rounded text-sm">
                                        <?php echo ucfirst(str_replace('_', ' ', $payment['payment_method'])); ?>
                                    </span>
                                </td>
                                <td class="py-3 px-4 text-sm text-gray-600">
                                    <?php echo $payment['reference_no'] ?: 'N/A'; ?>
                                </td>
                                <td class="py-3 px-4">
                                    <div class="text-sm text-gray-900"><?php echo htmlspecialchars($payment['received_by_name']); ?></div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div class="text-center py-12">
                    <i class="fas fa-money-bill-wave text-gray-300 text-5xl mb-4"></i>
                    <h3 class="text-xl font-bold text-gray-800 mb-2">No Payments Recorded</h3>
                    <p class="text-gray-600">No payments have been made by this student yet.</p>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Attendance Tab -->
        <div id="attendanceTab" class="tab-content hidden">
            <div class="card p-6">
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-xl font-bold text-gray-800">Attendance Records</h2>
                    <div class="text-sm text-gray-600">
                        <?php echo $attendance_stats['total_activities'] ?? 0; ?> activities recorded
                    </div>
                </div>
                
                <?php if ($attendance_result->num_rows > 0): ?>
                <div class="mb-6 grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div class="bg-green-50 p-4 rounded-lg">
                        <div class="text-2xl font-bold text-green-700"><?php echo $attendance_stats['present_count'] ?? 0; ?></div>
                        <div class="text-sm text-green-600">Present</div>
                    </div>
                    <div class="bg-red-50 p-4 rounded-lg">
                        <div class="text-2xl font-bold text-red-700"><?php echo $attendance_stats['absent_count'] ?? 0; ?></div>
                        <div class="text-sm text-red-600">Absent</div>
                    </div>
                    <div class="bg-yellow-50 p-4 rounded-lg">
                        <div class="text-2xl font-bold text-yellow-700"><?php echo $attendance_stats['late_count'] ?? 0; ?></div>
                        <div class="text-sm text-yellow-600">Late</div>
                    </div>
                    <div class="bg-blue-50 p-4 rounded-lg">
                        <div class="text-2xl font-bold text-blue-700"><?php echo $attendance_stats['excused_count'] ?? 0; ?></div>
                        <div class="text-sm text-blue-600">Excused</div>
                    </div>
                </div>
                
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead>
                            <tr class="bg-gray-50 border-b border-gray-200">
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Activity</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Date</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Status</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Time In</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Time Out</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Late Minutes</th>
                                <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Checked By</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($attendance = $attendance_result->fetch_assoc()): ?>
                            <?php 
                            $attendance_colors = [
                                'Present' => 'attendance-present',
                                'Absent' => 'attendance-absent',
                                'Late' => 'attendance-late',
                                'Excused' => 'attendance-excused'
                            ];
                            ?>
                            <tr class="border-b border-gray-100 hover:bg-gray-50">
                                <td class="py-3 px-4">
                                    <div class="font-medium text-gray-900"><?php echo htmlspecialchars($attendance['activity_name']); ?></div>
                                </td>
                                <td class="py-3 px-4 text-sm text-gray-600">
                                    <?php echo date('M d, Y', strtotime($attendance['activity_date'])); ?>
                                </td>
                                <td class="py-3 px-4">
                                    <span class="status-badge <?php echo $attendance_colors[$attendance['status']] ?? ''; ?>">
                                        <?php echo ucfirst($attendance['status']); ?>
                                    </span>
                                </td>
                                <td class="py-3 px-4 text-sm text-gray-600">
                                    <?php echo $attendance['time_in'] ? date('h:i A', strtotime($attendance['time_in'])) : 'N/A'; ?>
                                </td>
                                <td class="py-3 px-4 text-sm text-gray-600">
                                    <?php echo $attendance['time_out'] ? date('h:i A', strtotime($attendance['time_out'])) : 'N/A'; ?>
                                </td>
                                <td class="py-3 px-4">
                                    <?php if ($attendance['late_minutes'] > 0): ?>
                                        <span class="px-2 py-1 bg-yellow-100 text-yellow-800 rounded text-sm">
                                            <?php echo $attendance['late_minutes']; ?> mins
                                        </span>
                                    <?php else: ?>
                                        <span class="text-gray-400">-</span>
                                    <?php endif; ?>
                                </td>
                                <td class="py-3 px-4">
                                    <div class="text-sm text-gray-900"><?php echo htmlspecialchars($attendance['checked_by_name'] ?? 'System'); ?></div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div class="text-center py-12">
                    <i class="fas fa-calendar-times text-gray-300 text-5xl mb-4"></i>
                    <h3 class="text-xl font-bold text-gray-800 mb-2">No Attendance Records</h3>
                    <p class="text-gray-600">This student has no attendance records yet.</p>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Student Details Tab -->
        <div id="detailsTab" class="tab-content hidden">
            <div class="card p-6">
                <h2 class="text-xl font-bold text-gray-800 mb-6">Student Details</h2>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="space-y-6">
                        <div>
                            <h3 class="text-lg font-semibold text-gray-700 mb-4 flex items-center">
                                <i class="fas fa-id-card mr-2"></i> Personal Information
                            </h3>
                            <div class="space-y-3">
                                <div class="flex justify-between border-b pb-2">
                                    <span class="text-gray-600">Full Name:</span>
                                    <span class="font-medium"><?php echo htmlspecialchars($student['full_name']); ?></span>
                                </div>
                                <div class="flex justify-between border-b pb-2">
                                    <span class="text-gray-600">Student Number:</span>
                                    <span class="font-medium"><?php echo htmlspecialchars($student['student_number']); ?></span>
                                </div>
                                <div class="flex justify-between border-b pb-2">
                                    <span class="text-gray-600">Email:</span>
                                    <span class="font-medium"><?php echo htmlspecialchars($student['email'] ?? 'N/A'); ?></span>
                                </div>
                                <div class="flex justify-between border-b pb-2">
                                    <span class="text-gray-600">Phone:</span>
                                    <span class="font-medium"><?php echo htmlspecialchars($student['phone'] ?? 'N/A'); ?></span>
                                </div>
                                <div class="flex justify-between border-b pb-2">
                                    <span class="text-gray-600">Status:</span>
                                    <span class="font-medium px-2 py-1 bg-green-100 text-green-800 rounded text-sm">
                                        <?php echo ucfirst($student['status']); ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                        
                        <div>
                            <h3 class="text-lg font-semibold text-gray-700 mb-4 flex items-center">
                                <i class="fas fa-school mr-2"></i> Academic Information
                            </h3>
                            <div class="space-y-3">
                                <div class="flex justify-between border-b pb-2">
                                    <span class="text-gray-600">Campus:</span>
                                    <span class="font-medium"><?php echo htmlspecialchars($student['campus_name']); ?></span>
                                </div>
                                <div class="flex justify-between border-b pb-2">
                                    <span class="text-gray-600">Course/Year:</span>
                                    <span class="font-medium"><?php echo htmlspecialchars($student['course_year'] ?? 'N/A'); ?></span>
                                </div>
                                <div class="flex justify-between border-b pb-2">
                                    <span class="text-gray-600">Section:</span>
                                    <span class="font-medium"><?php echo htmlspecialchars($student['section'] ?? 'N/A'); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="space-y-6">
                        <div>
                            <h3 class="text-lg font-semibold text-gray-700 mb-4 flex items-center">
                                <i class="fas fa-chart-bar mr-2"></i> Summary Statistics
                            </h3>
                            <div class="space-y-4">
                                <div class="bg-gray-50 p-4 rounded-lg">
                                    <div class="text-sm text-gray-600 mb-1">Total Fines Recorded</div>
                                    <div class="text-2xl font-bold text-gray-800"><?php echo $fines_stats['fines_count'] ?? 0; ?></div>
                                </div>
                                <div class="bg-yellow-50 p-4 rounded-lg">
                                    <div class="text-sm text-yellow-600 mb-1">Pending Balance</div>
                                    <div class="text-2xl font-bold text-yellow-700">₱<?php echo number_format($student['pending_amount'] ?? 0, 2); ?></div>
                                </div>
                                <div class="bg-green-50 p-4 rounded-lg">
                                    <div class="text-sm text-green-600 mb-1">Total Paid</div>
                                    <div class="text-2xl font-bold text-green-700">₱<?php echo number_format($payments_stats['total_paid_amount'] ?? 0, 2); ?></div>
                                </div>
                            </div>
                        </div>
                        
                        <div>
                            <h3 class="text-lg font-semibold text-gray-700 mb-4 flex items-center">
                                <i class="fas fa-calendar-check mr-2"></i> Attendance Summary
                            </h3>
                            <div class="space-y-2">
                                <div class="flex justify-between">
                                    <span class="text-gray-600">Total Activities:</span>
                                    <span class="font-medium"><?php echo $attendance_stats['total_activities'] ?? 0; ?></span>
                                </div>
                                <div class="flex justify-between">
                                    <span class="text-green-600">Present:</span>
                                    <span class="font-medium"><?php echo $attendance_stats['present_count'] ?? 0; ?></span>
                                </div>
                                <div class="flex justify-between">
                                    <span class="text-red-600">Absent:</span>
                                    <span class="font-medium"><?php echo $attendance_stats['absent_count'] ?? 0; ?></span>
                                </div>
                                <div class="flex justify-between">
                                    <span class="text-yellow-600">Late:</span>
                                    <span class="font-medium"><?php echo $attendance_stats['late_count'] ?? 0; ?></span>
                                </div>
                                <div class="flex justify-between">
                                    <span class="text-blue-600">Excused:</span>
                                    <span class="font-medium"><?php echo $attendance_stats['excused_count'] ?? 0; ?></span>
                                </div>
                                <div class="flex justify-between border-t pt-2 mt-2">
                                    <span class="text-gray-600">Attendance Rate:</span>
                                    <span class="font-bold">
                                        <?php 
                                        $total = $attendance_stats['total_activities'] ?? 0;
                                        $present = $attendance_stats['present_count'] ?? 0;
                                        echo $total > 0 ? number_format(($present / $total) * 100, 1) . '%' : '0%';
                                        ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="mt-8 pt-6 border-t border-gray-200">
                    <h3 class="text-lg font-semibold text-gray-700 mb-4 flex items-center">
                        <i class="fas fa-history mr-2"></i> Account Timeline
                    </h3>
                    <div class="space-y-3">
                        <div class="flex items-center text-sm text-gray-600">
                            <i class="fas fa-calendar-plus text-blue-500 mr-3"></i>
                            <span>Account created on <?php echo date('F j, Y', strtotime($student['created_at'])); ?></span>
                        </div>
                        <?php if ($student['updated_at'] && $student['updated_at'] != $student['created_at']): ?>
                        <div class="flex items-center text-sm text-gray-600">
                            <i class="fas fa-edit text-green-500 mr-3"></i>
                            <span>Last updated on <?php echo date('F j, Y', strtotime($student['updated_at'])); ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modals -->
        <!-- Add Fine Modal -->
        <div id="addFineModal" class="modal">
            <div class="modal-content">
                <div class="p-6">
                    <div class="flex justify-between items-center mb-6">
                        <h3 class="text-xl font-bold text-gray-800">Add New Fine</h3>
                        <button onclick="closeModal('addFineModal')" class="text-gray-400 hover:text-gray-600">
                            <i class="fas fa-times text-xl"></i>
                        </button>
                    </div>
                    
                    <form method="POST" action="">
                        <input type="hidden" name="action" value="add_fine">
                        
                        <div class="space-y-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Activity (Optional)</label>
                                <select name="activity_id" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                    <option value="">General Fine (No specific activity)</option>
                                    <?php foreach ($activities as $activity): ?>
                                    <option value="<?php echo $activity['activity_id']; ?>">
                                        <?php echo htmlspecialchars($activity['activity_name']); ?> - <?php echo date('M d, Y', strtotime($activity['activity_date'])); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Reason</label>
                                <select name="reason" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                    <option value="absence">Absence</option>
                                    <option value="tardiness">Tardiness</option>
                                    <option value="violation">Violation</option>
                                    <option value="damage">Damage to Property</option>
                                    <option value="other">Other</option>
                                </select>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Amount</label>
                                <div class="relative">
                                    <span class="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">₱</span>
                                    <input type="number" name="amount" min="0" step="0.01" 
                                           class="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                           placeholder="0.00" required>
                                </div>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Description (Optional)</label>
                                <textarea name="description" rows="3" 
                                          class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                          placeholder="Enter description or details about this fine"></textarea>
                            </div>
                        </div>
                        
                        <div class="flex justify-end gap-3 mt-8">
                            <button type="button" onclick="closeModal('addFineModal')" 
                                    class="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
                                Cancel
                            </button>
                            <button type="submit" 
                                    class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
                                <i class="fas fa-plus-circle mr-2"></i> Add Fine
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Payment Modal -->
        <div id="paymentModal" class="modal">
            <div class="modal-content">
                <div class="p-6">
                    <div class="flex justify-between items-center mb-6">
                        <h3 class="text-xl font-bold text-gray-800">Record Payment</h3>
                        <button onclick="closeModal('paymentModal')" class="text-gray-400 hover:text-gray-600">
                            <i class="fas fa-times text-xl"></i>
                        </button>
                    </div>
                    
                    <form method="POST" action="">
                        <input type="hidden" name="action" value="record_payment">
                        <input type="hidden" name="fine_id" id="paymentFineId">
                        
                        <div class="space-y-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Fine ID</label>
                                <input type="text" id="fineIdDisplay" 
                                       class="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-50" readonly>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Remaining Amount</label>
                                <div class="relative">
                                    <span class="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">₱</span>
                                    <input type="text" id="remainingAmount" 
                                           class="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg bg-gray-50" readonly>
                                </div>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Amount to Pay</label>
                                <div class="relative">
                                    <span class="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">₱</span>
                                    <input type="number" name="amount_paid" id="amountToPay" min="0" step="0.01" 
                                           class="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                           placeholder="0.00" required>
                                </div>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Payment Method</label>
                                <select name="payment_method" 
                                        class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                    <option value="cash">Cash</option>
                                    <option value="gcash">GCash</option>
                                    <option value="bank_transfer">Bank Transfer</option>
                                    <option value="check">Check</option>
                                    <option value="online">Online Payment</option>
                                </select>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Reference Number (Optional)</label>
                                <input type="text" name="reference_no" 
                                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                       placeholder="Enter reference or transaction number">
                            </div>
                        </div>
                        
                        <div class="flex justify-end gap-3 mt-8">
                            <button type="button" onclick="closeModal('paymentModal')" 
                                    class="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
                                Cancel
                            </button>
                            <button type="submit" 
                                    class="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                                <i class="fas fa-money-bill-wave mr-2"></i> Record Payment
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Tab functionality
        function showTab(tabName) {
            // Hide all tabs
            document.querySelectorAll('.tab-content').forEach(tab => {
                tab.classList.add('hidden');
            });
            
            // Remove active class from all tabs
            document.querySelectorAll('.tab').forEach(tab => {
                tab.classList.remove('active');
            });
            
            // Show selected tab
            document.getElementById(tabName + 'Tab').classList.remove('hidden');
            
            // Add active class to selected tab
            event.target.classList.add('active');
        }
        
        // Modal functionality
        function showAddFineModal() {
            document.getElementById('addFineModal').classList.add('active');
        }
        
        function showPaymentModal(fineId, remainingAmount) {
            document.getElementById('paymentFineId').value = fineId;
            document.getElementById('fineIdDisplay').value = 'FINE-' + fineId.toString().padStart(4, '0');
            document.getElementById('remainingAmount').value = remainingAmount.toFixed(2);
            document.getElementById('amountToPay').max = remainingAmount;
            document.getElementById('paymentModal').classList.add('active');
        }
        
        function closeModal(modalId) {
            document.getElementById(modalId).classList.remove('active');
        }
        
        // Close modal when clicking outside
        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('click', function(e) {
                if (e.target === this) {
                    this.classList.remove('active');
                }
            });
        });
        
        // Format currency inputs
        document.addEventListener('DOMContentLoaded', function() {
            const currencyInputs = document.querySelectorAll('input[type="number"]');
            currencyInputs.forEach(input => {
                input.addEventListener('blur', function() {
                    if (this.value) {
                        this.value = parseFloat(this.value).toFixed(2);
                    }
                });
            });
            
            // Auto-focus on amount field in payment modal
            document.getElementById('amountToPay')?.addEventListener('focus', function() {
                this.select();
            });
        });
        
        // Validate payment amount
        document.getElementById('amountToPay')?.addEventListener('input', function() {
            const remaining = parseFloat(document.getElementById('remainingAmount').value);
            const toPay = parseFloat(this.value);
            
            if (toPay > remaining) {
                this.setCustomValidity(`Amount cannot exceed ₱${remaining.toFixed(2)}`);
            } else {
                this.setCustomValidity('');
            }
        });
    </script>
</body>
</html>