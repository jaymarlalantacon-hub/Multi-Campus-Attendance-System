<?php
session_start();
require_once 'db.php';

// Check if user is logged in and has permission
if (!isset($_SESSION['user_id']) || ($_SESSION['user_type'] !== 'coordinator' && $_SESSION['user_type'] !== 'admin')) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['full_name'];
$user_type = $_SESSION['user_type'];
$campus_id = $_SESSION['campus_id'] ?? null;

// Check if fine ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: fines.php');
    exit();
}

$fine_id = intval($_GET['id']);

// First, let's check what columns the fines table has
$check_columns = $conn->query("SHOW COLUMNS FROM fines");
$fines_columns = [];
while ($col = $check_columns->fetch_assoc()) {
    $fines_columns[] = $col['Field'];
}

// Check if user_id column exists in fines table
$has_user_id = in_array('user_id', $fines_columns);
$has_student_id = in_array('student_id', $fines_columns);
$has_attendance_id = in_array('attendance_id', $fines_columns);

// Build the query based on available columns
if ($has_user_id) {
    // If fines table has user_id column
    $fine_query = "SELECT f.*, 
                   u.full_name, u.email, u.username, u.user_type, u.campus_id, u.phone,
                   a.activity_name, a.activity_date, a.campus_id as activity_campus_id,
                   c.campus_name
                   FROM fines f
                   JOIN users u ON f.user_id = u.user_id
                   LEFT JOIN activities a ON f.activity_id = a.activity_id
                   LEFT JOIN campuses c ON u.campus_id = c.campus_id
                   WHERE f.fine_id = ?";
} elseif ($has_student_id) {
    // If fines table has student_id column (assuming student_id is the same as user_id)
    $fine_query = "SELECT f.*, 
                   u.full_name, u.email, u.username, u.user_type, u.campus_id, u.phone,
                   a.activity_name, a.activity_date, a.campus_id as activity_campus_id,
                   c.campus_name
                   FROM fines f
                   JOIN users u ON f.student_id = u.user_id
                   LEFT JOIN activities a ON f.activity_id = a.activity_id
                   LEFT JOIN campuses c ON u.campus_id = c.campus_id
                   WHERE f.fine_id = ?";
} elseif ($has_attendance_id) {
    // If fines table has attendance_id, we need to join through attendance table
    $fine_query = "SELECT f.*, 
                   u.full_name, u.email, u.username, u.user_type, u.campus_id, u.phone,
                   a.activity_name, a.activity_date, a.campus_id as activity_campus_id,
                   att.user_id as linked_user_id,
                   c.campus_name
                   FROM fines f
                   LEFT JOIN attendance att ON f.attendance_id = att.attendance_id
                   LEFT JOIN users u ON att.user_id = u.user_id
                   LEFT JOIN activities a ON f.activity_id = a.activity_id OR att.activity_id = a.activity_id
                   LEFT JOIN campuses c ON u.campus_id = c.campus_id
                   WHERE f.fine_id = ?";
} else {
    // Try to get user info from activity if available
    $fine_query = "SELECT f.*, 
                   a.activity_name, a.activity_date, a.campus_id as activity_campus_id,
                   c.campus_name
                   FROM fines f
                   LEFT JOIN activities a ON f.activity_id = a.activity_id
                   LEFT JOIN campuses c ON a.campus_id = c.campus_id
                   WHERE f.fine_id = ?";
}

$fine_stmt = $conn->prepare($fine_query);
$fine_stmt->bind_param("i", $fine_id);
$fine_stmt->execute();
$fine_result = $fine_stmt->get_result();
$fine = $fine_result->fetch_assoc();

// Check if fine exists
if (!$fine) {
    header('Location: fines.php');
    exit();
}

// Get user information separately if not joined in the main query
if (!isset($fine['full_name']) && isset($fine['user_id'])) {
    $user_query = "SELECT full_name, email, username, user_type, campus_id, phone FROM users WHERE user_id = ?";
    $user_stmt = $conn->prepare($user_query);
    $user_stmt->bind_param("i", $fine['user_id']);
    $user_stmt->execute();
    $user_result = $user_stmt->get_result();
    if ($user_data = $user_result->fetch_assoc()) {
        $fine = array_merge($fine, $user_data);
    }
}

// Get campus name if not already joined
if (!isset($fine['campus_name']) && isset($fine['campus_id'])) {
    $campus_query = "SELECT campus_name FROM campuses WHERE campus_id = ?";
    $campus_stmt = $conn->prepare($campus_query);
    $campus_stmt->bind_param("i", $fine['campus_id']);
    $campus_stmt->execute();
    $campus_result = $campus_stmt->get_result();
    if ($campus_data = $campus_result->fetch_assoc()) {
        $fine['campus_name'] = $campus_data['campus_name'];
    }
}

// Check if user has permission to edit this fine
if ($user_type === 'coordinator') {
    // Coordinator can only edit fines for their campus
    $user_campus_id = $fine['campus_id'] ?? $fine['activity_campus_id'] ?? null;
    if ($user_campus_id != $campus_id) {
        die("Access denied: You don't have permission to edit this fine.");
    }
}

// Handle form submission
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'update_fine') {
        $amount = floatval($_POST['amount']);
        $status = $_POST['status'];
        $due_date = $_POST['due_date'];
        $reason = trim($_POST['reason']);
        $notes = trim($_POST['notes']);
        $payment_method = $_POST['payment_method'] ?? '';
        $transaction_id = trim($_POST['transaction_id'] ?? '');
        
        // Validation
        $errors = [];
        
        if ($amount <= 0) {
            $errors[] = "Amount must be greater than 0.";
        }
        
        if (empty($due_date)) {
            $errors[] = "Due date is required.";
        }
        
        if (empty($reason)) {
            $errors[] = "Reason is required.";
        }
        
        if ($status === 'paid' && empty($payment_method)) {
            $errors[] = "Payment method is required when marking as paid.";
        }
        
        if (empty($errors)) {
            // Build update query based on available columns
            $update_fields = [
                'amount' => $amount,
                'status' => $status,
                'due_date' => $due_date,
                'reason' => $reason,
                'notes' => $notes
            ];
            
            // Add optional fields if they exist in the table
            if (in_array('payment_method', $fines_columns)) {
                $update_fields['payment_method'] = $payment_method;
            }
            
            if (in_array('transaction_id', $fines_columns)) {
                $update_fields['transaction_id'] = $transaction_id;
            }
            
            if (in_array('updated_at', $fines_columns)) {
                $update_fields['updated_at'] = date('Y-m-d H:i:s');
            }
            
            if (in_array('updated_by', $fines_columns)) {
                $update_fields['updated_by'] = $user_id;
            }
            
            // Build the SET clause
            $set_clause = [];
            $params = [];
            $types = "";
            
            foreach ($update_fields as $field => $value) {
                $set_clause[] = "$field = ?";
                $params[] = $value;
                $types .= is_int($value) ? "i" : (is_float($value) ? "d" : "s");
            }
            
            $params[] = $fine_id;
            $types .= "i";
            
            $update_query = "UPDATE fines SET " . implode(", ", $set_clause) . " WHERE fine_id = ?";
            $update_stmt = $conn->prepare($update_query);
            $update_stmt->bind_param($types, ...$params);
            
            if ($update_stmt->execute()) {
                $success_message = "Fine updated successfully!";
                
                // Update fine data for display
                foreach ($update_fields as $field => $value) {
                    $fine[$field] = $value;
                }
                
            } else {
                $error_message = "Failed to update fine. Please try again.";
            }
        } else {
            $error_message = implode("<br>", $errors);
        }
        
    } elseif ($action === 'add_payment') {
        // Add partial payment
        $payment_amount = floatval($_POST['payment_amount']);
        $payment_method = $_POST['payment_method'];
        $transaction_id = trim($_POST['transaction_id'] ?? '');
        $notes = trim($_POST['payment_notes'] ?? '');
        
        if ($payment_amount <= 0) {
            $error_message = "Payment amount must be greater than 0.";
        } elseif ($payment_amount > $fine['amount']) {
            $error_message = "Payment amount cannot exceed fine amount.";
        } else {
            // Check if payments table exists
            $check_payments_table = $conn->query("SHOW TABLES LIKE 'payments'");
            
            if ($check_payments_table->num_rows > 0) {
                // Calculate new status
                $total_paid = getTotalPaid($fine_id) + $payment_amount;
                $new_status = ($total_paid >= $fine['amount']) ? 'paid' : 'partial';
                
                // Record payment
                $payment_query = "INSERT INTO payments (fine_id, amount, payment_method, transaction_id, notes, received_by, payment_date) 
                                  VALUES (?, ?, ?, ?, ?, ?, NOW())";
                $payment_stmt = $conn->prepare($payment_query);
                $payment_stmt->bind_param("idsssi", $fine_id, $payment_amount, $payment_method, $transaction_id, $notes, $user_id);
                
                if ($payment_stmt->execute()) {
                    // Update fine status
                    $update_query = "UPDATE fines SET status = ? WHERE fine_id = ?";
                    if (in_array('updated_at', $fines_columns)) {
                        $update_query = "UPDATE fines SET status = ?, updated_at = NOW() WHERE fine_id = ?";
                    }
                    $update_stmt = $conn->prepare($update_query);
                    $update_stmt->bind_param("si", $new_status, $fine_id);
                    $update_stmt->execute();
                    
                    // Update fine data for display
                    $fine['status'] = $new_status;
                    
                    $success_message = "Payment recorded successfully! Amount: ₱" . number_format($payment_amount, 2);
                    
                } else {
                    $error_message = "Failed to record payment.";
                }
            } else {
                // If payments table doesn't exist, just update the fine status
                $new_status = ($payment_amount >= $fine['amount']) ? 'paid' : 'partial';
                
                $update_query = "UPDATE fines SET status = ?, payment_method = ?, transaction_id = ? WHERE fine_id = ?";
                if (in_array('updated_at', $fines_columns)) {
                    $update_query = "UPDATE fines SET status = ?, payment_method = ?, transaction_id = ?, updated_at = NOW() WHERE fine_id = ?";
                }
                
                $update_stmt = $conn->prepare($update_query);
                $update_stmt->bind_param("sssi", $new_status, $payment_method, $transaction_id, $fine_id);
                
                if ($update_stmt->execute()) {
                    $fine['status'] = $new_status;
                    $fine['payment_method'] = $payment_method;
                    $fine['transaction_id'] = $transaction_id;
                    
                    $success_message = "Payment recorded successfully! Amount: ₱" . number_format($payment_amount, 2);
                } else {
                    $error_message = "Failed to record payment.";
                }
            }
        }
        
    } elseif ($action === 'waive_fine') {
        $waiver_reason = trim($_POST['waiver_reason']);
        
        if (empty($waiver_reason)) {
            $error_message = "Please provide a reason for waiving the fine.";
        } else {
            // Update fine status to waived
            $update_query = "UPDATE fines SET 
                            status = 'waived', 
                            notes = CONCAT(IFNULL(notes, ''), '\nWaived: ', ?)
                            WHERE fine_id = ?";
            
            if (in_array('updated_at', $fines_columns)) {
                $update_query = "UPDATE fines SET 
                                status = 'waived', 
                                notes = CONCAT(IFNULL(notes, ''), '\nWaived: ', ?),
                                updated_at = NOW()
                                WHERE fine_id = ?";
            }
            
            $update_stmt = $conn->prepare($update_query);
            $update_stmt->bind_param("si", $waiver_reason, $fine_id);
            
            if ($update_stmt->execute()) {
                $success_message = "Fine waived successfully!";
                $fine['status'] = 'waived';
                $fine['notes'] = ($fine['notes'] ?? '') . "\nWaived: " . $waiver_reason;
                
            } else {
                $error_message = "Failed to waive fine.";
            }
        }
        
    } elseif ($action === 'delete_fine') {
        // Check if fine has payments
        $has_payments = false;
        $check_payments_table = $conn->query("SHOW TABLES LIKE 'payments'");
        
        if ($check_payments_table->num_rows > 0) {
            $check_payments = $conn->prepare("SELECT COUNT(*) as count FROM payments WHERE fine_id = ?");
            $check_payments->bind_param("i", $fine_id);
            $check_payments->execute();
            $payment_count = $check_payments->get_result()->fetch_assoc()['count'];
            $has_payments = $payment_count > 0;
        }
        
        if ($has_payments) {
            $error_message = "Cannot delete fine that has payment records. Please mark it as paid or waived instead.";
        } else {
            // Delete the fine
            $delete_query = "DELETE FROM fines WHERE fine_id = ?";
            $delete_stmt = $conn->prepare($delete_query);
            $delete_stmt->bind_param("i", $fine_id);
            
            if ($delete_stmt->execute()) {
                header("Location: fines.php?deleted=1");
                exit();
            } else {
                $error_message = "Failed to delete fine.";
            }
        }
    }
}

// Get payment history for this fine if payments table exists
$payments = [];
$total_paid = 0;

$check_payments_table = $conn->query("SHOW TABLES LIKE 'payments'");
if ($check_payments_table->num_rows > 0) {
    $payment_query = "SELECT p.*, u.full_name as received_by_name 
                      FROM payments p
                      LEFT JOIN users u ON p.received_by = u.user_id
                      WHERE p.fine_id = ?
                      ORDER BY p.payment_date DESC";
    $payment_stmt = $conn->prepare($payment_query);
    $payment_stmt->bind_param("i", $fine_id);
    $payment_stmt->execute();
    $payment_result = $payment_stmt->get_result();
    while ($payment = $payment_result->fetch_assoc()) {
        $payments[] = $payment;
    }
    
    // Calculate total paid
    $total_paid = getTotalPaid($fine_id);
} else {
    // If no payments table, check if payment details are in fines table
    if (isset($fine['payment_amount']) && $fine['payment_amount'] > 0) {
        $total_paid = $fine['payment_amount'];
    }
}

// Get activity details if associated
$activity_details = null;
if (isset($fine['activity_id']) && $fine['activity_id']) {
    $activity_query = "SELECT activity_name, activity_date, venue FROM activities WHERE activity_id = ?";
    $activity_stmt = $conn->prepare($activity_query);
    $activity_stmt->bind_param("i", $fine['activity_id']);
    $activity_stmt->execute();
    $activity_result = $activity_stmt->get_result();
    $activity_details = $activity_result->fetch_assoc();
}

// Fine status options
$status_options = [
    'pending' => 'Pending',
    'partial' => 'Partial Payment',
    'paid' => 'Paid',
    'waived' => 'Waived',
    'cancelled' => 'Cancelled'
];

// Payment methods
$payment_methods = [
    'cash' => 'Cash',
    'gcash' => 'GCash',
    'bank_transfer' => 'Bank Transfer',
    'paypal' => 'PayPal',
    'credit_card' => 'Credit Card',
    'debit_card' => 'Debit Card',
    'check' => 'Check'
];

// Helper function to get total paid
function getTotalPaid($fine_id) {
    global $conn;
    $query = "SELECT COALESCE(SUM(amount), 0) as total FROM payments WHERE fine_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $fine_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc()['total'];
}

// Helper function to send payment notification
function sendPaymentNotification($fine, $amount, $payment_method) {
    // This is a placeholder function for email notification
    // In a real application, you would implement actual email sending
    if (isset($fine['email'])) {
        $to = $fine['email'];
        $subject = "Fine Payment Receipt - Multi-Campus Attendance System";
        $message = "Dear " . $fine['full_name'] . ",\n\n";
        $message .= "Your fine payment has been recorded.\n\n";
        $message .= "Payment Details:\n";
        $message .= "Amount: ₱" . number_format($amount, 2) . "\n";
        $message .= "Payment Method: " . $payment_method . "\n";
        $message .= "Transaction Date: " . date('F j, Y') . "\n\n";
        $message .= "Thank you for your payment.\n\n";
        $message .= "Sincerely,\nMulti-Campus Attendance System";
        
        // For now, we'll just log it
        error_log("Payment notification would be sent to: " . $to);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Fine | Multi-Campus Attendance System</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #3b82f6;
            --secondary-color: #8b5cf6;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
        }
        
        body {
            font-family: 'Segoe UI', 'Inter', system-ui, -apple-system, sans-serif;
            background: linear-gradient(135deg, #f6f9fc 0%, #edf2f7 100%);
            min-height: 100vh;
        }
        
        .card {
            background: white;
            border-radius: 1rem;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            border: 1px solid #e5e7eb;
        }
        
        .card:hover {
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
        }
        
        .fine-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
            border-radius: 1rem;
            box-shadow: 0 10px 30px rgba(59, 130, 246, 0.3);
        }
        
        .btn {
            padding: 0.75rem 1.5rem;
            border-radius: 0.75rem;
            font-weight: 600;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(59, 130, 246, 0.3);
        }
        
        .btn-success {
            background: var(--success-color);
            color: white;
        }
        
        .btn-danger {
            background: var(--danger-color);
            color: white;
        }
        
        .btn-warning {
            background: var(--warning-color);
            color: white;
        }
        
        .badge {
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        
        .badge-pending { background: #fef3c7; color: #92400e; }
        .badge-partial { background: #dbeafe; color: #1e40af; }
        .badge-paid { background: #d1fae5; color: #065f46; }
        .badge-waived { background: #e5e7eb; color: #374151; }
        .badge-cancelled { background: #fee2e2; color: #991b1b; }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }
        
        .modal.active {
            display: flex;
        }
        
        .modal-content {
            background: white;
            border-radius: 1rem;
            width: 90%;
            max-width: 500px;
            max-height: 90vh;
            overflow-y: auto;
        }
        
        .amount-display {
            font-size: 2.5rem;
            font-weight: 700;
            color: #ef4444;
        }
        
        .payment-progress {
            height: 10px;
            background: #e5e7eb;
            border-radius: 5px;
            overflow: hidden;
        }
        
        .payment-progress-bar {
            height: 100%;
            background: linear-gradient(135deg, var(--success-color) 0%, #34d399 100%);
            transition: width 0.3s ease;
        }
        
        .input-group {
            margin-bottom: 1rem;
        }
        
        .input-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: #374151;
        }
        
        .input-group .label-required::after {
            content: " *";
            color: #ef4444;
        }
        
        .input-group input,
        .input-group select,
        .input-group textarea {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 1px solid #d1d5db;
            border-radius: 0.5rem;
            font-size: 1rem;
            transition: all 0.3s ease;
        }
        
        .input-group input:focus,
        .input-group select:focus,
        .input-group textarea:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        
        .tab {
            padding: 0.75rem 1.5rem;
            border-radius: 0.75rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .tab.active {
            background: var(--primary-color);
            color: white;
        }
        
        .tab:hover:not(.active) {
            background: #f3f4f6;
        }
        
        .tab-pane {
            display: none;
        }
        
        .tab-pane.active {
            display: block;
        }
        
        .payment-item {
            border-left: 4px solid var(--success-color);
            padding-left: 1rem;
        }
        
        .amount-due {
            font-size: 1.5rem;
            font-weight: 700;
            color: #ef4444;
        }
    </style>
</head>
<body class="min-h-screen p-4 md:p-8">
    <!-- Header -->
    <div class="max-w-6xl mx-auto">
        <div class="fine-header p-6 mb-8">
            <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <div class="flex items-center gap-3 mb-2">
                        <h1 class="text-3xl font-bold">Edit Fine</h1>
                        <span class="badge badge-<?php echo $fine['status'] ?? 'pending'; ?>">
                            <?php echo $status_options[$fine['status'] ?? 'pending'] ?? ucfirst($fine['status'] ?? 'pending'); ?>
                        </span>
                    </div>
                    <div class="flex flex-wrap items-center gap-2">
                        <?php if (isset($fine['full_name'])): ?>
                        <span class="text-white/90">
                            <i class="fas fa-user mr-2"></i>
                            <?php echo htmlspecialchars($fine['full_name']); ?>
                        </span>
                        <?php endif; ?>
                        <?php if (isset($fine['campus_name'])): ?>
                        <span class="text-white/90">
                            <i class="fas fa-school mr-2"></i>
                            <?php echo htmlspecialchars($fine['campus_name']); ?>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="flex flex-wrap gap-2">
                    <a href="fines.php" class="btn bg-white/20 hover:bg-white/30 text-white">
                        <i class="fas fa-arrow-left"></i> Back to Fines
                    </a>
                    <?php if (isset($fine['user_id'])): ?>
                    <a href="user_details.php?id=<?php echo $fine['user_id']; ?>" class="btn bg-green-500/80 hover:bg-green-600/80 text-white">
                        <i class="fas fa-eye mr-2"></i> View User
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Messages -->
        <?php if ($success_message): ?>
        <div class="mb-6 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-xl flex items-center">
            <i class="fas fa-check-circle mr-3 text-green-600"></i>
            <span><?php echo $success_message; ?></span>
        </div>
        <?php endif; ?>
        
        <?php if ($error_message): ?>
        <div class="mb-6 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl flex items-center">
            <i class="fas fa-exclamation-circle mr-3 text-red-600"></i>
            <span><?php echo $error_message; ?></span>
        </div>
        <?php endif; ?>
        
        <!-- Fine Overview -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div class="card p-6">
                <div class="text-center">
                    <div class="amount-display mb-2">₱<?php echo number_format($fine['amount'] ?? 0, 2); ?></div>
                    <div class="text-gray-600">Fine Amount</div>
                </div>
            </div>
            
            <div class="card p-6">
                <div class="text-center">
                    <div class="amount-display text-green-600 mb-2">₱<?php echo number_format($total_paid, 2); ?></div>
                    <div class="text-gray-600">Total Paid</div>
                </div>
            </div>
            
            <div class="card p-6">
                <div class="text-center">
                    <div class="amount-due mb-2">₱<?php echo number_format(($fine['amount'] ?? 0) - $total_paid, 2); ?></div>
                    <div class="text-gray-600">Amount Due</div>
                </div>
            </div>
        </div>
        
        <!-- Payment Progress -->
        <?php if ($fine['amount'] > 0): ?>
        <div class="mb-8">
            <div class="flex justify-between items-center mb-2">
                <span class="text-sm font-medium text-gray-700">Payment Progress</span>
                <span class="text-sm font-medium text-gray-700">
                    <?php echo round(($total_paid / $fine['amount']) * 100, 1); ?>%
                </span>
            </div>
            <div class="payment-progress">
                <div class="payment-progress-bar" style="width: <?php echo min(100, ($total_paid / $fine['amount']) * 100); ?>%"></div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Tabs -->
        <div class="flex flex-wrap gap-2 mb-8">
            <button id="tab-details" class="tab active" onclick="showTab('details')">
                <i class="fas fa-edit mr-2"></i> Edit Details
            </button>
            <button id="tab-payments" class="tab" onclick="showTab('payments')">
                <i class="fas fa-money-bill-wave mr-2"></i> Payments
            </button>
            <button id="tab-info" class="tab" onclick="showTab('info')">
                <i class="fas fa-info-circle mr-2"></i> Fine Information
            </button>
            <button id="tab-actions" class="tab" onclick="showTab('actions')">
                <i class="fas fa-cog mr-2"></i> Actions
            </button>
        </div>
        
        <!-- Tab Content -->
        <div class="tab-content">
            <!-- Edit Details Tab -->
            <div id="details-content" class="tab-pane active">
                <div class="card p-6">
                    <h2 class="text-xl font-bold text-gray-800 mb-6 flex items-center">
                        <i class="fas fa-edit text-blue-600 mr-2"></i> Fine Details
                    </h2>
                    
                    <form method="POST" action="" class="space-y-6">
                        <input type="hidden" name="action" value="update_fine">
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <!-- Left Column -->
                            <div>
                                <h3 class="font-bold text-gray-800 mb-4 border-b pb-2">Fine Information</h3>
                                
                                <div class="input-group">
                                    <label for="amount" class="label-required">Amount (₱)</label>
                                    <input type="number" 
                                           id="amount" 
                                           name="amount" 
                                           value="<?php echo number_format($fine['amount'] ?? 0, 2); ?>"
                                           step="0.01"
                                           min="0"
                                           required
                                           class="w-full">
                                </div>
                                
                                <div class="input-group">
                                    <label for="status" class="label-required">Status</label>
                                    <select id="status" name="status" required class="w-full" onchange="togglePaymentFields()">
                                        <?php foreach ($status_options as $value => $label): ?>
                                        <option value="<?php echo $value; ?>" 
                                                <?php echo ($fine['status'] ?? 'pending') === $value ? 'selected' : ''; ?>>
                                            <?php echo $label; ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <div class="input-group">
                                    <label for="due_date" class="label-required">Due Date</label>
                                    <input type="date" 
                                           id="due_date" 
                                           name="due_date" 
                                           value="<?php echo $fine['due_date'] ?? date('Y-m-d'); ?>"
                                           required
                                           class="w-full">
                                </div>
                            </div>
                            
                            <!-- Right Column -->
                            <div>
                                <h3 class="font-bold text-gray-800 mb-4 border-b pb-2">Payment Details</h3>
                                
                                <div class="input-group" id="payment_method_group" style="<?php echo ($fine['status'] ?? 'pending') === 'paid' ? '' : 'display: none;'; ?>">
                                    <label for="payment_method">Payment Method</label>
                                    <select id="payment_method" name="payment_method" class="w-full">
                                        <option value="">-- Select Payment Method --</option>
                                        <?php foreach ($payment_methods as $value => $label): ?>
                                        <option value="<?php echo $value; ?>" 
                                                <?php echo ($fine['payment_method'] ?? '') === $value ? 'selected' : ''; ?>>
                                            <?php echo $label; ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <div class="input-group" id="transaction_id_group" style="<?php echo ($fine['status'] ?? 'pending') === 'paid' ? '' : 'display: none;'; ?>">
                                    <label for="transaction_id">Transaction ID/Reference</label>
                                    <input type="text" 
                                           id="transaction_id" 
                                           name="transaction_id" 
                                           value="<?php echo htmlspecialchars($fine['transaction_id'] ?? ''); ?>"
                                           placeholder="e.g., GCASH123456"
                                           class="w-full">
                                </div>
                                
                                <div class="input-group">
                                    <label for="reason" class="label-required">Reason for Fine</label>
                                    <textarea id="reason" 
                                              name="reason" 
                                              rows="3"
                                              required
                                              class="w-full"><?php echo htmlspecialchars($fine['reason'] ?? ''); ?></textarea>
                                </div>
                                
                                <div class="input-group">
                                    <label for="notes">Additional Notes</label>
                                    <textarea id="notes" 
                                              name="notes" 
                                              rows="3"
                                              class="w-full"><?php echo htmlspecialchars($fine['notes'] ?? ''); ?></textarea>
                                </div>
                            </div>
                        </div>
                        
                        <div class="pt-6 border-t border-gray-200 flex justify-end gap-3">
                            <a href="fines.php" class="btn bg-gray-100 text-gray-700 hover:bg-gray-200">
                                Cancel
                            </a>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save mr-2"></i> Save Changes
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Payments Tab -->
            <div id="payments-content" class="tab-pane hidden">
                <div class="card p-6">
                    <div class="flex justify-between items-center mb-6">
                        <h2 class="text-xl font-bold text-gray-800 flex items-center">
                            <i class="fas fa-money-bill-wave text-green-600 mr-2"></i> Payment History
                        </h2>
                        <button onclick="openAddPaymentModal()" 
                                class="btn bg-green-500 hover:bg-green-600 text-white"
                                <?php echo ($fine['status'] ?? 'pending') === 'paid' || ($fine['status'] ?? 'pending') === 'waived' ? 'disabled' : ''; ?>>
                            <i class="fas fa-plus mr-2"></i> Add Payment
                        </button>
                    </div>
                    
                    <?php if (count($payments) > 0): ?>
                        <div class="space-y-4">
                            <?php foreach ($payments as $payment): ?>
                            <div class="payment-item bg-white border border-gray-200 rounded-lg p-4">
                                <div class="flex justify-between items-start">
                                    <div>
                                        <div class="font-medium text-gray-900">₱<?php echo number_format($payment['amount'], 2); ?></div>
                                        <div class="text-sm text-gray-600">
                                            <?php echo $payment_methods[$payment['payment_method']] ?? ucfirst($payment['payment_method']); ?>
                                        </div>
                                        <?php if ($payment['transaction_id']): ?>
                                        <div class="text-sm text-gray-500">Ref: <?php echo htmlspecialchars($payment['transaction_id']); ?></div>
                                        <?php endif; ?>
                                        <?php if ($payment['notes']): ?>
                                        <div class="text-sm text-gray-500 mt-1"><?php echo htmlspecialchars($payment['notes']); ?></div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="text-right">
                                        <div class="text-sm text-gray-600">
                                            <?php echo date('M d, Y', strtotime($payment['payment_date'])); ?>
                                        </div>
                                        <div class="text-xs text-gray-500">
                                            <?php echo date('h:i A', strtotime($payment['payment_date'])); ?>
                                        </div>
                                        <?php if ($payment['received_by_name']): ?>
                                        <div class="text-sm text-gray-600 mt-1">
                                            Received by: <?php echo htmlspecialchars($payment['received_by_name']); ?>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-8 text-gray-500">
                            <i class="fas fa-money-bill-wave text-4xl mb-4 text-gray-300"></i>
                            <p>No payment records found for this fine.</p>
                            <?php if (($fine['status'] ?? 'pending') !== 'paid' && ($fine['status'] ?? 'pending') !== 'waived'): ?>
                            <button onclick="openAddPaymentModal()" class="btn bg-green-500 hover:bg-green-600 text-white mt-4">
                                <i class="fas fa-plus mr-2"></i> Record First Payment
                            </button>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Fine Information Tab -->
            <div id="info-content" class="tab-pane hidden">
                <div class="card p-6">
                    <h2 class="text-xl font-bold text-gray-800 mb-6 flex items-center">
                        <i class="fas fa-info-circle text-blue-600 mr-2"></i> Fine Information
                    </h2>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <!-- User Information -->
                        <div>
                            <h3 class="font-bold text-gray-800 mb-4 border-b pb-2">Fine Details</h3>
                            
                            <div class="space-y-3">
                                <div>
                                    <label class="text-sm font-medium text-gray-500">Fine ID</label>
                                    <p class="text-gray-900">#<?php echo $fine_id; ?></p>
                                </div>
                                
                                <?php if (isset($fine['full_name'])): ?>
                                <div>
                                    <label class="text-sm font-medium text-gray-500">Student Name</label>
                                    <p class="text-gray-900"><?php echo htmlspecialchars($fine['full_name']); ?></p>
                                </div>
                                <?php endif; ?>
                                
                                <?php if (isset($fine['email'])): ?>
                                <div>
                                    <label class="text-sm font-medium text-gray-500">Email</label>
                                    <p class="text-gray-900"><?php echo htmlspecialchars($fine['email']); ?></p>
                                </div>
                                <?php endif; ?>
                                
                                <?php if (isset($fine['username'])): ?>
                                <div>
                                    <label class="text-sm font-medium text-gray-500">Username</label>
                                    <p class="text-gray-900"><?php echo htmlspecialchars($fine['username']); ?></p>
                                </div>
                                <?php endif; ?>
                                
                                <?php if (isset($fine['phone'])): ?>
                                <div>
                                    <label class="text-sm font-medium text-gray-500">Phone</label>
                                    <p class="text-gray-900"><?php echo htmlspecialchars($fine['phone']); ?></p>
                                </div>
                                <?php endif; ?>
                                
                                <?php if (isset($fine['user_type'])): ?>
                                <div>
                                    <label class="text-sm font-medium text-gray-500">User Type</label>
                                    <p class="text-gray-900"><?php echo ucfirst($fine['user_type']); ?></p>
                                </div>
                                <?php endif; ?>
                                
                                <?php if (isset($fine['campus_name'])): ?>
                                <div>
                                    <label class="text-sm font-medium text-gray-500">Campus</label>
                                    <p class="text-gray-900"><?php echo htmlspecialchars($fine['campus_name']); ?></p>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <!-- Fine Details -->
                        <div>
                            <h3 class="font-bold text-gray-800 mb-4 border-b pb-2">Fine Information</h3>
                            
                            <div class="space-y-3">
                                <div>
                                    <label class="text-sm font-medium text-gray-500">Created Date</label>
                                    <p class="text-gray-900"><?php echo date('F j, Y', strtotime($fine['created_at'] ?? date('Y-m-d'))); ?></p>
                                </div>
                                
                                <div>
                                    <label class="text-sm font-medium text-gray-500">Due Date</label>
                                    <p class="text-gray-900"><?php echo date('F j, Y', strtotime($fine['due_date'] ?? date('Y-m-d'))); ?></p>
                                </div>
                                
                                <?php if (isset($fine['updated_at'])): ?>
                                <div>
                                    <label class="text-sm font-medium text-gray-500">Last Updated</label>
                                    <p class="text-gray-900"><?php echo date('F j, Y', strtotime($fine['updated_at'])); ?></p>
                                </div>
                                <?php endif; ?>
                                
                                <?php if ($activity_details): ?>
                                <div>
                                    <label class="text-sm font-medium text-gray-500">Related Activity</label>
                                    <p class="text-gray-900"><?php echo htmlspecialchars($activity_details['activity_name']); ?></p>
                                    <p class="text-sm text-gray-600"><?php echo date('F j, Y', strtotime($activity_details['activity_date'])); ?></p>
                                    <?php if ($activity_details['venue']): ?>
                                    <p class="text-sm text-gray-600">Venue: <?php echo htmlspecialchars($activity_details['venue']); ?></p>
                                    <?php endif; ?>
                                </div>
                                <?php endif; ?>
                                
                                <?php if (isset($fine['notes']) && !empty($fine['notes'])): ?>
                                <div>
                                    <label class="text-sm font-medium text-gray-500">Notes</label>
                                    <p class="text-gray-900 whitespace-pre-wrap"><?php echo htmlspecialchars($fine['notes']); ?></p>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Actions Tab -->
            <div id="actions-content" class="tab-pane hidden">
                <div class="card p-6">
                    <h2 class="text-xl font-bold text-gray-800 mb-6 flex items-center">
                        <i class="fas fa-cog text-gray-600 mr-2"></i> Additional Actions
                    </h2>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <!-- Add Payment (for partial payments) -->
                        <div class="border border-gray-200 rounded-xl p-5">
                            <div class="flex items-center mb-4">
                                <div class="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center mr-4">
                                    <i class="fas fa-money-bill-wave text-green-600"></i>
                                </div>
                                <h3 class="font-bold text-gray-800">Add Payment</h3>
                            </div>
                            <p class="text-gray-600 text-sm mb-4">
                                Record a partial payment for this fine. Useful when paying in installments.
                            </p>
                            <button onclick="openAddPaymentModal()" 
                                    class="btn bg-green-500 hover:bg-green-600 text-white w-full"
                                    <?php echo ($fine['status'] ?? 'pending') === 'paid' || ($fine['status'] ?? 'pending') === 'waived' ? 'disabled' : ''; ?>>
                                <i class="fas fa-plus mr-2"></i> Add Payment
                            </button>
                        </div>
                        
                        <!-- Waive Fine -->
                        <div class="border border-gray-200 rounded-xl p-5">
                            <div class="flex items-center mb-4">
                                <div class="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center mr-4">
                                    <i class="fas fa-hand-holding-heart text-gray-600"></i>
                                </div>
                                <h3 class="font-bold text-gray-800">Waive Fine</h3>
                            </div>
                            <p class="text-gray-600 text-sm mb-4">
                                Waive this fine. This action cannot be undone and requires a reason.
                            </p>
                            <button onclick="openWaiveModal()" 
                                    class="btn bg-gray-500 hover:bg-gray-600 text-white w-full"
                                    <?php echo ($fine['status'] ?? 'pending') === 'paid' || ($fine['status'] ?? 'pending') === 'waived' ? 'disabled' : ''; ?>>
                                <i class="fas fa-hand-holding-heart mr-2"></i> Waive Fine
                            </button>
                        </div>
                        
                        <!-- Delete Fine -->
                        <div class="border border-gray-200 rounded-xl p-5">
                            <div class="flex items-center mb-4">
                                <div class="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center mr-4">
                                    <i class="fas fa-trash text-red-600"></i>
                                </div>
                                <h3 class="font-bold text-gray-800">Delete Fine</h3>
                            </div>
                            <p class="text-gray-600 text-sm mb-4">
                                <span class="text-red-600 font-bold">Warning:</span> This will permanently delete the fine record.
                            </p>
                            <form method="POST" action="" id="deleteForm">
                                <input type="hidden" name="action" value="delete_fine">
                                <button type="button" 
                                        onclick="confirmDelete()"
                                        class="btn bg-red-500 hover:bg-red-600 text-white w-full">
                                    <i class="fas fa-trash mr-2"></i> Delete Fine
                                </button>
                            </form>
                        </div>
                        
                        <!-- Generate Receipt -->
                        <div class="border border-gray-200 rounded-xl p-5">
                            <div class="flex items-center mb-4">
                                <div class="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-4">
                                    <i class="fas fa-receipt text-blue-600"></i>
                                </div>
                                <h3 class="font-bold text-gray-800">Generate Receipt</h3>
                            </div>
                            <p class="text-gray-600 text-sm mb-4">
                                Generate and print a receipt for this fine. Includes all payment details.
                            </p>
                            <a href="generate_receipt.php?fine_id=<?php echo $fine_id; ?>" 
                               target="_blank"
                               class="btn bg-blue-500 hover:bg-blue-600 text-white w-full">
                                <i class="fas fa-print mr-2"></i> Generate Receipt
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Add Payment Modal -->
    <div id="addPaymentModal" class="modal">
        <div class="modal-content">
            <div class="p-6">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-lg font-bold text-gray-800">Add Payment</h3>
                    <button onclick="closeModal('addPaymentModal')" class="text-gray-500 hover:text-gray-700">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                
                <div class="mb-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <div class="flex items-center">
                        <i class="fas fa-info-circle text-blue-600 mr-3"></i>
                        <div>
                            <p class="text-blue-800 font-medium">Remaining Balance: ₱<?php echo number_format(($fine['amount'] ?? 0) - $total_paid, 2); ?></p>
                        </div>
                    </div>
                </div>
                
                <form method="POST" action="" class="space-y-4">
                    <input type="hidden" name="action" value="add_payment">
                    
                    <div class="input-group">
                        <label for="payment_amount" class="label-required">Amount (₱)</label>
                        <input type="number" 
                               id="payment_amount" 
                               name="payment_amount" 
                               step="0.01"
                               min="0.01"
                               max="<?php echo ($fine['amount'] ?? 0) - $total_paid; ?>"
                               value="<?php echo ($fine['amount'] ?? 0) - $total_paid; ?>"
                               required
                               class="w-full">
                    </div>
                    
                    <div class="input-group">
                        <label for="payment_method" class="label-required">Payment Method</label>
                        <select id="payment_method_modal" name="payment_method" required class="w-full">
                            <option value="">-- Select Payment Method --</option>
                            <?php foreach ($payment_methods as $value => $label): ?>
                            <option value="<?php echo $value; ?>"><?php echo $label; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="input-group">
                        <label for="transaction_id">Transaction ID/Reference</label>
                        <input type="text" 
                               id="transaction_id_modal" 
                               name="transaction_id" 
                               placeholder="e.g., GCASH123456"
                               class="w-full">
                    </div>
                    
                    <div class="input-group">
                        <label for="payment_notes">Notes</label>
                        <textarea id="payment_notes" 
                                  name="payment_notes" 
                                  rows="3"
                                  placeholder="Optional notes about this payment..."
                                  class="w-full"></textarea>
                    </div>
                    
                    <div class="flex justify-end gap-3 mt-6">
                        <button type="button" 
                                onclick="closeModal('addPaymentModal')" 
                                class="btn bg-gray-100 text-gray-700 hover:bg-gray-200">
                            Cancel
                        </button>
                        <button type="submit" class="btn bg-green-500 hover:bg-green-600 text-white">
                            Record Payment
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Waive Fine Modal -->
    <div id="waiveModal" class="modal">
        <div class="modal-content">
            <div class="p-6">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-lg font-bold text-gray-800">Waive Fine</h3>
                    <button onclick="closeModal('waiveModal')" class="text-gray-500 hover:text-gray-700">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                
                <div class="mb-6 bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                    <div class="flex items-center">
                        <i class="fas fa-exclamation-triangle text-yellow-600 mr-3"></i>
                        <div>
                            <p class="text-yellow-800 font-medium">Warning: This action cannot be undone.</p>
                            <p class="text-yellow-700 text-sm mt-1">Fine amount: ₱<?php echo number_format(($fine['amount'] ?? 0) - $total_paid, 2); ?> will be waived.</p>
                        </div>
                    </div>
                </div>
                
                <form method="POST" action="" class="space-y-4">
                    <input type="hidden" name="action" value="waive_fine">
                    
                    <div class="input-group">
                        <label for="waiver_reason" class="label-required">Reason for Waiver</label>
                        <textarea id="waiver_reason" 
                                  name="waiver_reason" 
                                  rows="4"
                                  placeholder="Please provide a detailed reason for waiving this fine..."
                                  required
                                  class="w-full"></textarea>
                    </div>
                    
                    <div class="flex justify-end gap-3 mt-6">
                        <button type="button" 
                                onclick="closeModal('waiveModal')" 
                                class="btn bg-gray-100 text-gray-700 hover:bg-gray-200">
                            Cancel
                        </button>
                        <button type="submit" 
                                class="btn bg-yellow-500 hover:bg-yellow-600 text-white"
                                onclick="return confirm('Are you sure you want to waive this fine? This action cannot be undone.')">
                            <i class="fas fa-hand-holding-heart mr-2"></i> Waive Fine
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script>
        // Tab switching
        function showTab(tabName) {
            // Hide all tab content
            document.querySelectorAll('.tab-pane').forEach(tab => {
                tab.classList.add('hidden');
                tab.classList.remove('active');
            });
            
            // Remove active class from all tabs
            document.querySelectorAll('.tab').forEach(tab => {
                tab.classList.remove('active');
            });
            
            // Show selected tab content
            const content = document.getElementById(tabName + '-content');
            if (content) {
                content.classList.remove('hidden');
                content.classList.add('active');
            }
            
            // Activate selected tab
            const tab = document.getElementById('tab-' + tabName);
            if (tab) {
                tab.classList.add('active');
            }
        }
        
        // Modal functions
        function openAddPaymentModal() {
            document.getElementById('addPaymentModal').classList.add('active');
        }
        
        function openWaiveModal() {
            document.getElementById('waiveModal').classList.add('active');
        }
        
        function closeModal(modalId) {
            document.getElementById(modalId).classList.remove('active');
        }
        
        // Toggle payment fields based on status
        function togglePaymentFields() {
            const status = document.getElementById('status').value;
            const paymentMethodGroup = document.getElementById('payment_method_group');
            const transactionIdGroup = document.getElementById('transaction_id_group');
            
            if (status === 'paid') {
                if (paymentMethodGroup) paymentMethodGroup.style.display = 'block';
                if (transactionIdGroup) transactionIdGroup.style.display = 'block';
            } else {
                if (paymentMethodGroup) paymentMethodGroup.style.display = 'none';
                if (transactionIdGroup) transactionIdGroup.style.display = 'none';
            }
        }
        
        // Initialize payment fields on load
        document.addEventListener('DOMContentLoaded', function() {
            togglePaymentFields();
            
            // Set max payment amount
            const paymentAmountInput = document.getElementById('payment_amount');
            if (paymentAmountInput) {
                const remainingBalance = <?php echo ($fine['amount'] ?? 0) - $total_paid; ?>;
                paymentAmountInput.max = remainingBalance;
                paymentAmountInput.value = remainingBalance;
            }
        });
        
        // Delete confirmation
        function confirmDelete() {
            if (confirm('WARNING: This will permanently delete this fine record.\n\n' +
                       'This action cannot be undone.\n\n' +
                       'Are you absolutely sure?')) {
                document.getElementById('deleteForm').submit();
            }
        }
        
        // Close modal when clicking outside
        window.addEventListener('click', function(e) {
            if (e.target.classList.contains('modal')) {
                e.target.classList.remove('active');
            }
        });
    </script>
</body>
</html>