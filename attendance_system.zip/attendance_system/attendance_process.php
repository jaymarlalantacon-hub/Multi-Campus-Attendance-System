<?php
// attendance_process.php - COMPLETE VERSION WITH SCAN_TYPE
session_start();
require_once 'db.php';

header('Content-Type: application/json');

// Check authentication
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['user_type'], ['admin', 'coordinator'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);
$student_code = isset($data['student_code']) ? trim($data['student_code']) : '';
$activity_id = isset($data['activity_id']) ? intval($data['activity_id']) : 0;
$scan_type = isset($data['scan_type']) ? $data['scan_type'] : 'checkin';
$activity_type = isset($data['activity_type']) ? $data['activity_type'] : 'whole_day';
$scan_frequency = isset($data['scan_frequency']) ? $data['scan_frequency'] : '2x';

if (!$student_code || !$activity_id) {
    echo json_encode(['success' => false, 'message' => 'Missing required data']);
    exit();
}

// Log the incoming request for debugging
error_log("Attendance Request: student_code=$student_code, activity_id=$activity_id, scan_type=$scan_type");

try {
    // 1. Get student information
    $stmt = $conn->prepare("SELECT s.*, c.campus_name 
                           FROM students s 
                           LEFT JOIN campuses c ON s.campus_id = c.campus_id 
                           WHERE s.student_number = ? AND s.status = 'active'");
    $stmt->bind_param("s", $student_code);
    $stmt->execute();
    $student_result = $stmt->get_result();
    
    if ($student_result->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'Student not found or inactive']);
        exit();
    }
    
    $student = $student_result->fetch_assoc();
    
    // 2. Get activity information
    $stmt = $conn->prepare("SELECT a.*, c.campus_name 
                           FROM activities a 
                           LEFT JOIN campuses c ON a.campus_id = c.campus_id 
                           WHERE a.activity_id = ?");
    $stmt->bind_param("i", $activity_id);
    $stmt->execute();
    $activity_result = $stmt->get_result();
    
    if ($activity_result->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'Activity not found']);
        exit();
    }
    
    $activity = $activity_result->fetch_assoc();
    
    // 3. Validate student belongs to activity campus
    if ($activity['campus_id'] && $student['campus_id'] != $activity['campus_id']) {
        echo json_encode(['success' => false, 'message' => 'Student is not enrolled in this campus']);
        exit();
    }
    
    // 4. Check if this scan type already exists for today
    $today = date('Y-m-d');
    $stmt = $conn->prepare("SELECT * FROM attendance 
                           WHERE student_id = ? AND activity_id = ? 
                           AND scan_type = ? AND DATE(time_in) = ?");
    $stmt->bind_param("iiss", $student['student_id'], $activity_id, $scan_type, $today);
    $stmt->execute();
    $existing_result = $stmt->get_result();
    
    if ($existing_result->num_rows > 0) {
        $existing = $existing_result->fetch_assoc();
        echo json_encode([
            'success' => false, 
            'message' => 'Already scanned',
            'details' => "This student has already been marked for " . formatScanType($scan_type) . 
                        " at " . date('h:i A', strtotime($existing['time_in']))
        ]);
        exit();
    }
    
    // 5. Calculate if late
    $is_late = false;
    $late_minutes = 0;
    $current_time = date('Y-m-d H:i:s');
    
    if (in_array($scan_type, ['checkin', 'checkin_am'])) {
        // For check-in, check against activity start time
        $activity_time = strtotime($activity['activity_time']);
        $current_timestamp = time();
        $grace_period = 30 * 60; // 30 minutes grace period
        
        if ($current_timestamp > ($activity_time + $grace_period)) {
            $is_late = true;
            $late_minutes = round(($current_timestamp - $activity_time) / 60);
        }
    } elseif ($scan_type === 'checkin_pm') {
        // For PM check-in, check against 1:00 PM
        $expected_pm = strtotime(date('Y-m-d') . ' 13:00:00');
        $current_timestamp = time();
        $grace_period = 15 * 60; // 15 minutes grace period
        
        if ($current_timestamp > ($expected_pm + $grace_period)) {
            $is_late = true;
            $late_minutes = round(($current_timestamp - $expected_pm) / 60);
        }
    }
    
    // 6. Determine time_in/time_out
    $time_in = $current_time;
    $time_out = null;
    
    // For checkout scans, we can optionally set time_out
    if (in_array($scan_type, ['checkout', 'checkout_am', 'checkout_pm'])) {
        $time_out = $current_time;
        
        // For checkout, we need to find the corresponding check-in
        $corresponding_checkin = str_replace('out', 'in', $scan_type);
        
        $stmt = $conn->prepare("SELECT time_in FROM attendance 
                               WHERE student_id = ? AND activity_id = ? 
                               AND scan_type = ? AND DATE(time_in) = ?");
        $stmt->bind_param("iiss", $student['student_id'], $activity_id, $corresponding_checkin, $today);
        $stmt->execute();
        $checkin_result = $stmt->get_result();
        
        if ($checkin_result->num_rows > 0) {
            // Use the check-in time from earlier
            $checkin_data = $checkin_result->fetch_assoc();
            $time_in = $checkin_data['time_in'];
        }
    }
    
    // 7. Insert attendance record
    $status = $is_late ? 'Late' : 'Present';
    
    $stmt = $conn->prepare("INSERT INTO attendance 
                           (student_id, activity_id, scan_type, time_in, time_out, 
                            status, is_late, late_minutes, checked_by) 
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    
    $stmt->bind_param("iissssiis", 
        $student['student_id'], 
        $activity_id, 
        $scan_type,
        $time_in,
        $time_out,
        $status,
        $is_late,
        $late_minutes,
        $_SESSION['user_id']
    );
    
    if ($stmt->execute()) {
        $attendance_id = $stmt->insert_id;
        
        // 8. Get completed scans count
        $completed_scans = getCompletedScans($conn, $student['student_id'], $activity_id, $today);
        $total_scans = getTotalRequiredScans($activity['scan_frequency']);
        
        // 9. Determine if attendance is complete
        $attendance_status = $status;
        if (count($completed_scans) >= $total_scans) {
            $attendance_status = 'Complete';
            
            // Update all records for this student/activity to show complete
            $update_stmt = $conn->prepare("UPDATE attendance SET status = 'Complete' 
                                          WHERE student_id = ? AND activity_id = ? AND DATE(time_in) = ?");
            $update_stmt->bind_param("iis", $student['student_id'], $activity_id, $today);
            $update_stmt->execute();
        }
        
        // 10. Log the action
        logScanAction($conn, $student, $activity, $scan_type, $attendance_status, $is_late);
        
        // 11. Check and remove fines for mandatory activities
        if ($activity['mandatory'] == 1 && $attendance_status === 'Complete') {
            checkAndRemoveFine($conn, $student['student_id'], $activity_id);
        }
        
        // 12. Return success response
        echo json_encode([
            'success' => true,
            'message' => 'Attendance recorded successfully',
            'student_id' => $student['student_id'],
            'student_name' => $student['full_name'],
            'student_number' => $student['student_number'],
            'campus' => $student['campus_name'],
            'activity' => [
                'id' => $activity['activity_id'],
                'name' => $activity['activity_name'],
                'type' => $activity['activity_type'],
                'frequency' => $activity['scan_frequency']
            ],
            'scan_type' => formatScanType($scan_type),
            'status' => $attendance_status,
            'is_late' => $is_late,
            'late_minutes' => $late_minutes,
            'completed_scans' => count($completed_scans),
            'total_scans' => $total_scans,
            'time_in' => $time_in,
            'time_out' => $time_out,
            'attendance_id' => $attendance_id
        ]);
        
    } else {
        throw new Exception("Failed to insert attendance record: " . $stmt->error);
    }
    
} catch (Exception $e) {
    error_log("Attendance Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}

/**
 * Get completed scans for a student
 */
function getCompletedScans($conn, $student_id, $activity_id, $date) {
    $stmt = $conn->prepare("SELECT scan_type FROM attendance 
                           WHERE student_id = ? AND activity_id = ? 
                           AND DATE(time_in) = ?");
    $stmt->bind_param("iis", $student_id, $activity_id, $date);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $scans = [];
    while ($row = $result->fetch_assoc()) {
        $scans[] = $row['scan_type'];
    }
    
    return $scans;
}

/**
 * Get total required scans based on frequency
 */
function getTotalRequiredScans($scan_frequency) {
    return $scan_frequency === '4x' ? 4 : 2;
}

/**
 * Format scan type for display
 */
function formatScanType($scan_type) {
    $formatted = [
        'checkin' => 'Check-in',
        'checkout' => 'Check-out',
        'checkin_am' => 'AM Check-in',
        'checkout_am' => 'AM Check-out',
        'checkin_pm' => 'PM Check-in',
        'checkout_pm' => 'PM Check-out'
    ];
    
    return $formatted[$scan_type] ?? ucfirst(str_replace('_', ' ', $scan_type));
}

/**
 * Log scan action
 */
function logScanAction($conn, $student, $activity, $scan_type, $status, $is_late) {
    $details = json_encode([
        'student_id' => $student['student_id'],
        'student_number' => $student['student_number'],
        'activity_id' => $activity['activity_id'],
        'activity_name' => $activity['activity_name'],
        'scan_type' => $scan_type,
        'status' => $status,
        'is_late' => $is_late,
        'activity_type' => $activity['activity_type'],
        'scan_frequency' => $activity['scan_frequency']
    ]);
    
    $stmt = $conn->prepare("INSERT INTO scan_logs 
                           (student_id, student_code, action, user_id, user_type, details, created_at) 
                           VALUES (?, ?, ?, ?, ?, ?, NOW())");
    
    $action = 'attendance_scanned';
    $user_id = $_SESSION['user_id'];
    $user_type = $_SESSION['user_type'];
    
    $stmt->bind_param("ississ", 
        $student['student_id'],
        $student['student_number'],
        $action,
        $user_id,
        $user_type,
        $details
    );
    
    $stmt->execute();
}

/**
 * Check and remove fine
 */
function checkAndRemoveFine($conn, $student_id, $activity_id) {
    $stmt = $conn->prepare("SELECT fine_id FROM fines 
                           WHERE student_id = ? AND activity_id = ? AND status = 'pending'");
    $stmt->bind_param("ii", $student_id, $activity_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $fine = $result->fetch_assoc();
        $update_stmt = $conn->prepare("UPDATE fines SET status = 'removed' WHERE fine_id = ?");
        $update_stmt->bind_param("i", $fine['fine_id']);
        $update_stmt->execute();
    }
}
?>