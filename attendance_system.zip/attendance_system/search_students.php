<?php
session_start();
require_once 'db.php';

$campus_id = intval($_GET['campus'] ?? 0);
$search_term = $_GET['q'] ?? '';

$query = "SELECT student_id, student_number, full_name, course_year 
          FROM students 
          WHERE campus_id = ? 
          AND status = 'active'
          AND (full_name LIKE ? OR student_number LIKE ?)
          ORDER BY full_name
          LIMIT 10";

$stmt = $conn->prepare($query);
$search_pattern = "%" . $search_term . "%";
$stmt->bind_param("iss", $campus_id, $search_pattern, $search_pattern);
$stmt->execute();
$result = $stmt->get_result();

$students = [];
while ($row = $result->fetch_assoc()) {
    $students[] = $row;
}

header('Content-Type: application/json');
echo json_encode($students);
?>