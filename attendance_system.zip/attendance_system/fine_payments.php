<?php
session_start();
require_once 'db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['full_name'];
$user_type = $_SESSION['user_type'];
$campus_id = $_SESSION['campus_id'] ?? null;

// Get filter parameters
$status_filter = $_GET['status'] ?? 'all';
$payment_method = $_GET['payment_method'] ?? 'all';
$date_from = $_GET['date_from'] ?? date('Y-m-01'); // First day of current month
$date_to = $_GET['date_to'] ?? date('Y-m-d');
$search_query = $_GET['search'] ?? '';
$student_id = $_GET['student_id'] ?? null;

// Get campuses for filter (admin only)
$campuses = [];
if ($user_type === 'admin') {
    $campus_query = "SELECT * FROM campuses WHERE status = 'active' ORDER BY campus_name";
    $campus_result = $conn->query($campus_query);
    while ($campus = $campus_result->fetch_assoc()) {
        $campuses[] = $campus;
    }
}

// Build the query
$where = [];
$params = [];
$types = "";

// Base query
$query = "SELECT 
            fp.payment_id,
            fp.fine_id,
            fp.amount_paid,
            fp.payment_date,
            fp.payment_method,
            fp.reference_no,
            fp.notes,
            fp.received_by,
            fp.created_at,
            
            f.amount as fine_amount,
            f.reason,
            f.status as fine_status,
            
            s.student_id,
            s.student_number,
            s.full_name as student_name,
            s.course_year,
            s.section,
            s.campus_id,
            
            c.campus_name,
            
            u.full_name as received_by_name
            
          FROM fine_payments fp
          JOIN fines f ON fp.fine_id = f.fine_id
          JOIN students s ON f.student_id = s.student_id
          LEFT JOIN campuses c ON s.campus_id = c.campus_id
          LEFT JOIN users u ON fp.received_by = u.user_id
          WHERE 1=1";

// Add campus filter for coordinators
if ($user_type === 'coordinator' && $campus_id) {
    $where[] = "s.campus_id = ?";
    $params[] = $campus_id;
    $types .= "i";
}

// Add status filter
if ($status_filter !== 'all') {
    $where[] = "f.status = ?";
    $params[] = $status_filter;
    $types .= "s";
}

// Add payment method filter
if ($payment_method !== 'all') {
    $where[] = "fp.payment_method = ?";
    $params[] = $payment_method;
    $types .= "s";
}

// Add date range filter
if (!empty($date_from)) {
    $where[] = "DATE(fp.payment_date) >= ?";
    $params[] = $date_from;
    $types .= "s";
}

if (!empty($date_to)) {
    $where[] = "DATE(fp.payment_date) <= ?";
    $params[] = $date_to;
    $types .= "s";
}

// Add search filter
if (!empty($search_query)) {
    $where[] = "(s.full_name LIKE ? OR s.student_number LIKE ? OR fp.reference_no LIKE ?)";
    $search_term = "%{$search_query}%";
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
    $types .= "sss";
}

// Add student filter
if (!empty($student_id)) {
    $where[] = "s.student_id = ?";
    $params[] = $student_id;
    $types .= "i";
}

// Combine WHERE conditions
if (!empty($where)) {
    $query .= " AND " . implode(" AND ", $where);
}

// Add ordering
$query .= " ORDER BY fp.payment_date DESC, fp.created_at DESC";

// Execute query
$stmt = $conn->prepare($query);
if ($params) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$payments_result = $stmt->get_result();
$payments = $payments_result->fetch_all(MYSQLI_ASSOC);

// Get payment statistics
$stats_query = "SELECT 
                COUNT(*) as total_payments,
                SUM(fp.amount_paid) as total_amount,
                COUNT(DISTINCT fp.fine_id) as fines_paid,
                COUNT(DISTINCT s.student_id) as students_paid,
                AVG(fp.amount_paid) as average_payment
                FROM fine_payments fp
                JOIN fines f ON fp.fine_id = f.fine_id
                JOIN students s ON f.student_id = s.student_id
                WHERE 1=1";

if ($user_type === 'coordinator' && $campus_id) {
    $stats_query .= " AND s.campus_id = $campus_id";
}

if (!empty($date_from)) {
    $stats_query .= " AND DATE(fp.payment_date) >= '$date_from'";
}

if (!empty($date_to)) {
    $stats_query .= " AND DATE(fp.payment_date) <= '$date_to'";
}

$stats_result = $conn->query($stats_query);
$stats = $stats_result->fetch_assoc();

// Get payment methods statistics
$methods_query = "SELECT 
                  payment_method,
                  COUNT(*) as count,
                  SUM(amount_paid) as total_amount
                  FROM fine_payments fp
                  JOIN fines f ON fp.fine_id = f.fine_id
                  JOIN students s ON f.student_id = s.student_id
                  WHERE 1=1";

if ($user_type === 'coordinator' && $campus_id) {
    $methods_query .= " AND s.campus_id = $campus_id";
}

if (!empty($date_from)) {
    $methods_query .= " AND DATE(fp.payment_date) >= '$date_from'";
}

if (!empty($date_to)) {
    $methods_query .= " AND DATE(fp.payment_date) <= '$date_to'";
}

$methods_query .= " GROUP BY payment_method ORDER BY total_amount DESC";
$methods_result = $conn->query($methods_query);
$payment_methods_stats = $methods_result->fetch_all(MYSQLI_ASSOC);

// Handle delete payment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_payment'])) {
    $payment_id = $_POST['payment_id'];
    
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Get payment details first
        $get_payment = $conn->prepare("SELECT fine_id, amount_paid FROM fine_payments WHERE payment_id = ?");
        $get_payment->bind_param("i", $payment_id);
        $get_payment->execute();
        $payment_details = $get_payment->get_result()->fetch_assoc();
        
        if ($payment_details) {
            // Delete the payment
            $delete_stmt = $conn->prepare("DELETE FROM fine_payments WHERE payment_id = ?");
            $delete_stmt->bind_param("i", $payment_id);
            $delete_stmt->execute();
            
            // Recalculate fine status
            $recalc_query = "SELECT 
                            COALESCE(SUM(amount_paid), 0) as total_paid,
                            f.amount as fine_amount
                            FROM fines f
                            LEFT JOIN fine_payments fp ON f.fine_id = fp.fine_id
                            WHERE f.fine_id = ?
                            GROUP BY f.fine_id";
            
            $recalc_stmt = $conn->prepare($recalc_query);
            $recalc_stmt->bind_param("i", $payment_details['fine_id']);
            $recalc_stmt->execute();
            $recalc_result = $recalc_stmt->get_result()->fetch_assoc();
            
            // Update fine status
            if ($recalc_result) {
                $total_paid = $recalc_result['total_paid'];
                $fine_amount = $recalc_result['fine_amount'];
                
                if ($total_paid >= $fine_amount) {
                    $new_status = 'paid';
                } elseif ($total_paid > 0) {
                    $new_status = 'partial';
                } else {
                    $new_status = 'pending';
                }
                
                $update_fine = $conn->prepare("UPDATE fines SET status = ? WHERE fine_id = ?");
                $update_fine->bind_param("si", $new_status, $payment_details['fine_id']);
                $update_fine->execute();
            }
            
            $conn->commit();
            $success_message = "Payment record deleted successfully!";
            
            // Refresh page to show updated data
            header("Location: fine_payments.php?" . http_build_query($_GET));
            exit();
        }
    } catch (Exception $e) {
        $conn->rollback();
        $error_message = "Failed to delete payment: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fine Payments | Multi-Campus Attendance System</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --primary-color: #3b82f6;
            --secondary-color: #8b5cf6;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
        }
        
        body {
            font-family: 'Segoe UI', 'Inter', system-ui, -apple-system, sans-serif;
            background: linear-gradient(135deg, #f6f9fc 0%, #edf2f7 100%);
            min-height: 100vh;
        }
        
        .card {
            background: white;
            border-radius: 1rem;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            border: 1px solid #e5e7eb;
        }
        
        .card:hover {
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
        }
        
        .stat-card {
            background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
            border-radius: 0.75rem;
            padding: 1.25rem;
            text-align: center;
        }
        
        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            line-height: 1;
        }
        
        .stat-label {
            color: #6b7280;
            font-size: 0.875rem;
            margin-top: 0.5rem;
        }
        
        .badge {
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        
        .badge-success {
            background: #d1fae5;
            color: #065f46;
        }
        
        .badge-warning {
            background: #fef3c7;
            color: #92400e;
        }
        
        .badge-info {
            background: #dbeafe;
            color: #1e40af;
        }
        
        .badge-danger {
            background: #fee2e2;
            color: #991b1b;
        }
        
        .tab {
            padding: 0.75rem 1.5rem;
            border-radius: 0.75rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .tab.active {
            background: var(--primary-color);
            color: white;
        }
        
        .tab:hover:not(.active) {
            background: #f3f4f6;
        }
        
        .btn {
            padding: 0.75rem 1.5rem;
            border-radius: 0.75rem;
            font-weight: 600;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(59, 130, 246, 0.3);
        }
        
        .btn-success {
            background: var(--success-color);
            color: white;
        }
        
        .btn-danger {
            background: var(--danger-color);
            color: white;
        }
        
        .input-group {
            margin-bottom: 1rem;
        }
        
        .input-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: #374151;
        }
        
        .input-group input,
        .input-group select {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 1px solid #d1d5db;
            border-radius: 0.5rem;
            font-size: 1rem;
            transition: all 0.3s ease;
        }
        
        .input-group input:focus,
        .input-group select:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        
        .payment-method-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 0.5rem;
            font-size: 0.75rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 0.25rem;
        }
        
        .method-cash { background: #d1fae5; color: #065f46; }
        .method-gcash { background: #dbeafe; color: #1e40af; }
        .method-bank { background: #fef3c7; color: #92400e; }
        .method-check { background: #f3e8ff; color: #7c3aed; }
        .method-online { background: #fce7f3; color: #be185d; }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }
        
        .modal.active {
            display: flex;
        }
        
        .modal-content {
            background: white;
            border-radius: 1rem;
            width: 90%;
            max-width: 500px;
            max-height: 90vh;
            overflow-y: auto;
        }
    </style>
</head>
<body class="min-h-screen p-4 md:p-8">
    <!-- Header -->
    <div class="max-w-7xl mx-auto">
        <div class="card p-6 mb-8">
            <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h1 class="text-3xl font-bold text-gray-900 mb-2">
                        <i class="fas fa-money-bill-wave text-green-600 mr-2"></i>Fine Payments
                    </h1>
                    <div class="flex flex-wrap items-center gap-2">
                        <span class="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                            <i class="fas fa-user mr-1"></i> <?php echo htmlspecialchars($user_name); ?>
                        </span>
                        <span class="px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm font-medium">
                            <i class="fas fa-shield-alt mr-1"></i> <?php echo ucfirst($user_type); ?>
                        </span>
                    </div>
                </div>
                <div class="flex flex-wrap gap-2">
                    <a href="<?php echo $user_type === 'admin' ? 'admin_dashboard.php' : 'coordinator_dashboard.php'; ?>" 
                       class="btn">
                        <i class="fas fa-arrow-left"></i> Dashboard
                    </a>
                    <a href="scan_fines.php" class="btn btn-success">
                        <i class="fas fa-qrcode mr-2"></i> Scan Payment
                    </a>
                    <button onclick="showPaymentReport()" class="btn btn-primary">
                        <i class="fas fa-chart-bar mr-2"></i> Generate Report
                    </button>
                </div>
            </div>
        </div>
        
        <!-- Messages -->
        <?php if (isset($success_message)): ?>
        <div class="mb-6 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-xl flex items-center">
            <i class="fas fa-check-circle mr-3 text-green-600"></i>
            <span><?php echo $success_message; ?></span>
        </div>
        <?php endif; ?>
        
        <?php if (isset($error_message)): ?>
        <div class="mb-6 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl flex items-center">
            <i class="fas fa-exclamation-circle mr-3 text-red-600"></i>
            <span><?php echo $error_message; ?></span>
        </div>
        <?php endif; ?>
        
        <!-- Statistics Cards -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
            <div class="stat-card">
                <div class="stat-value text-blue-600"><?php echo number_format($stats['total_payments'] ?? 0); ?></div>
                <div class="stat-label">Total Payments</div>
            </div>
            <div class="stat-card">
                <div class="stat-value text-green-600">₱<?php echo number_format($stats['total_amount'] ?? 0, 2); ?></div>
                <div class="stat-label">Total Collected</div>
            </div>
            <div class="stat-card">
                <div class="stat-value text-purple-600"><?php echo number_format($stats['fines_paid'] ?? 0); ?></div>
                <div class="stat-label">Fines Paid</div>
            </div>
            <div class="stat-card">
                <div class="stat-value text-orange-600"><?php echo number_format($stats['students_paid'] ?? 0); ?></div>
                <div class="stat-label">Students Paid</div>
            </div>
            <div class="stat-card">
                <div class="stat-value text-red-600">₱<?php echo number_format($stats['average_payment'] ?? 0, 2); ?></div>
                <div class="stat-label">Average Payment</div>
            </div>
        </div>
        
        <!-- Filters Section -->
        <div class="card p-6 mb-8">
            <h2 class="text-xl font-bold text-gray-800 mb-4 flex items-center">
                <i class="fas fa-filter text-blue-600 mr-2"></i> Filter Payments
            </h2>
            <form method="GET" action="" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <!-- Date Range -->
                <div class="input-group">
                    <label>Date From</label>
                    <input type="date" name="date_from" value="<?php echo htmlspecialchars($date_from); ?>">
                </div>
                <div class="input-group">
                    <label>Date To</label>
                    <input type="date" name="date_to" value="<?php echo htmlspecialchars($date_to); ?>">
                </div>
                
                <!-- Status Filter -->
                <div class="input-group">
                    <label>Fine Status</label>
                    <select name="status">
                        <option value="all" <?php echo $status_filter === 'all' ? 'selected' : ''; ?>>All Status</option>
                        <option value="paid" <?php echo $status_filter === 'paid' ? 'selected' : ''; ?>>Paid</option>
                        <option value="partial" <?php echo $status_filter === 'partial' ? 'selected' : ''; ?>>Partial</option>
                        <option value="pending" <?php echo $status_filter === 'pending' ? 'selected' : ''; ?>>Pending</option>
                    </select>
                </div>
                
                <!-- Payment Method Filter -->
                <div class="input-group">
                    <label>Payment Method</label>
                    <select name="payment_method">
                        <option value="all" <?php echo $payment_method === 'all' ? 'selected' : ''; ?>>All Methods</option>
                        <option value="cash" <?php echo $payment_method === 'cash' ? 'selected' : ''; ?>>Cash</option>
                        <option value="gcash" <?php echo $payment_method === 'gcash' ? 'selected' : ''; ?>>GCash</option>
                        <option value="bank_transfer" <?php echo $payment_method === 'bank_transfer' ? 'selected' : ''; ?>>Bank Transfer</option>
                        <option value="check" <?php echo $payment_method === 'check' ? 'selected' : ''; ?>>Check</option>
                        <option value="online" <?php echo $payment_method === 'online' ? 'selected' : ''; ?>>Online Payment</option>
                    </select>
                </div>
                
                <!-- Search -->
                <div class="input-group">
                    <label>Search</label>
                    <input type="text" name="search" value="<?php echo htmlspecialchars($search_query); ?>" 
                           placeholder="Student name, ID, or reference">
                </div>
                
                <!-- Campus Filter (Admin only) -->
                <?php if ($user_type === 'admin'): ?>
                <div class="input-group">
                    <label>Campus</label>
                    <select name="campus">
                        <option value="">All Campuses</option>
                        <?php foreach ($campuses as $campus): ?>
                        <option value="<?php echo $campus['campus_id']; ?>" 
                                <?php echo isset($_GET['campus']) && $_GET['campus'] == $campus['campus_id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($campus['campus_name']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php endif; ?>
                
                <!-- Action Buttons -->
                <div class="flex items-end gap-3">
                    <button type="submit" class="btn btn-primary flex-1">
                        <i class="fas fa-filter mr-2"></i> Apply Filters
                    </button>
                    <a href="fine_payments.php" class="btn flex-1">
                        <i class="fas fa-redo mr-2"></i> Reset
                    </a>
                </div>
            </form>
        </div>
        
        <!-- Charts Section -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <!-- Payment Methods Chart -->
            <div class="card p-6">
                <h2 class="text-xl font-bold text-gray-800 mb-4 flex items-center">
                    <i class="fas fa-chart-pie text-blue-600 mr-2"></i> Payment Methods Distribution
                </h2>
                <div class="h-64">
                    <canvas id="paymentMethodsChart"></canvas>
                </div>
            </div>
            
            <!-- Daily Collection Chart -->
            <div class="card p-6">
                <h2 class="text-xl font-bold text-gray-800 mb-4 flex items-center">
                    <i class="fas fa-chart-line text-green-600 mr-2"></i> Daily Collection Trend
                </h2>
                <div class="h-64">
                    <canvas id="dailyCollectionChart"></canvas>
                </div>
            </div>
        </div>
        
        <!-- Payments Table -->
        <div class="card p-6">
            <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                <div>
                    <h2 class="text-xl font-bold text-gray-800 flex items-center">
                        <i class="fas fa-list text-gray-600 mr-2"></i> Payment Records
                    </h2>
                    <p class="text-gray-600"><?php echo count($payments); ?> payments found</p>
                </div>
                <div class="flex gap-3">
                    <button onclick="exportPayments()" class="btn">
                        <i class="fas fa-download mr-2"></i> Export
                    </button>
                    <button onclick="printPayments()" class="btn">
                        <i class="fas fa-print mr-2"></i> Print
                    </button>
                </div>
            </div>
            
            <?php if (!empty($payments)): ?>
            <div class="overflow-x-auto">
                <table id="paymentsTable" class="w-full">
                    <thead>
                        <tr class="bg-gray-50 border-b border-gray-200">
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Student</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Payment Date</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Amount</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Method</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Reference</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Fine Status</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Received By</th>
                            <th class="py-3 px-4 text-left text-sm font-semibold text-gray-700">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($payments as $payment): ?>
                        <?php 
                        $method_class = 'method-' . str_replace('_', '-', $payment['payment_method']);
                        $status_class = $payment['fine_status'] === 'paid' ? 'badge-success' : 
                                       ($payment['fine_status'] === 'partial' ? 'badge-warning' : 'badge-danger');
                        ?>
                        <tr class="border-b border-gray-100 hover:bg-gray-50">
                            <td class="py-3 px-4">
                                <div class="font-medium text-gray-900"><?php echo htmlspecialchars($payment['student_name']); ?></div>
                                <div class="text-sm text-gray-500"><?php echo htmlspecialchars($payment['student_number']); ?></div>
                                <div class="text-xs text-gray-400">
                                    <?php echo htmlspecialchars($payment['course_year'] ?? 'N/A'); ?> • 
                                    <?php echo htmlspecialchars($payment['section'] ?? 'N/A'); ?>
                                </div>
                            </td>
                            <td class="py-3 px-4">
                                <div class="font-medium text-gray-900">
                                    <?php echo date('M d, Y', strtotime($payment['payment_date'])); ?>
                                </div>
                                <div class="text-sm text-gray-500">
                                    <?php echo date('h:i A', strtotime($payment['created_at'])); ?>
                                </div>
                            </td>
                            <td class="py-3 px-4">
                                <div class="font-bold text-green-600">₱<?php echo number_format($payment['amount_paid'], 2); ?></div>
                                <div class="text-sm text-gray-500">
                                    Fine: ₱<?php echo number_format($payment['fine_amount'], 2); ?>
                                </div>
                            </td>
                            <td class="py-3 px-4">
                                <span class="payment-method-badge <?php echo $method_class; ?>">
                                    <?php 
                                    $method_icons = [
                                        'cash' => 'fas fa-money-bill-wave',
                                        'gcash' => 'fas fa-mobile-alt',
                                        'bank_transfer' => 'fas fa-university',
                                        'check' => 'fas fa-file-invoice',
                                        'online' => 'fas fa-globe'
                                    ];
                                    $icon = $method_icons[$payment['payment_method']] ?? 'fas fa-money-bill-wave';
                                    ?>
                                    <i class="<?php echo $icon; ?>"></i>
                                    <?php echo ucfirst(str_replace('_', ' ', $payment['payment_method'])); ?>
                                </span>
                            </td>
                            <td class="py-3 px-4">
                                <?php if (!empty($payment['reference_no'])): ?>
                                <div class="font-mono text-sm bg-gray-100 p-2 rounded">
                                    <?php echo htmlspecialchars($payment['reference_no']); ?>
                                </div>
                                <?php else: ?>
                                <span class="text-gray-400 text-sm">N/A</span>
                                <?php endif; ?>
                            </td>
                            <td class="py-3 px-4">
                                <span class="badge <?php echo $status_class; ?>">
                                    <?php echo ucfirst($payment['fine_status']); ?>
                                </span>
                            </td>
                            <td class="py-3 px-4">
                                <div class="text-sm text-gray-900"><?php echo htmlspecialchars($payment['received_by_name']); ?></div>
                                <div class="text-xs text-gray-500">
                                    <?php echo date('M d, Y', strtotime($payment['created_at'])); ?>
                                </div>
                            </td>
                            <td class="py-3 px-4">
                                <div class="flex space-x-2">
                                    <button onclick="viewPaymentDetails(<?php echo $payment['payment_id']; ?>)" 
                                            class="px-3 py-1 bg-blue-100 text-blue-800 rounded text-sm font-medium hover:bg-blue-200">
                                        <i class="fas fa-eye mr-1"></i> View
                                    </button>
                                    <?php if ($user_type === 'admin' || $user_id == $payment['received_by']): ?>
                                    <button onclick="showDeleteModal(<?php echo $payment['payment_id']; ?>, '<?php echo htmlspecialchars($payment['student_name']); ?>', <?php echo $payment['amount_paid']; ?>)" 
                                            class="px-3 py-1 bg-red-100 text-red-800 rounded text-sm font-medium hover:bg-red-200">
                                        <i class="fas fa-trash mr-1"></i> Delete
                                    </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <div class="mt-6 flex justify-between items-center">
                <div class="text-sm text-gray-600">
                    Showing <?php echo count($payments); ?> payments
                </div>
                <div class="flex gap-3">
                    <a href="fines.php" class="btn">
                        <i class="fas fa-file-invoice-dollar mr-2"></i> View Fines
                    </a>
                    <a href="payment_report.php?<?php echo http_build_query($_GET); ?>" 
                       target="_blank" class="btn btn-primary">
                        <i class="fas fa-file-pdf mr-2"></i> Detailed Report
                    </a>
                </div>
            </div>
            
            <?php else: ?>
            <div class="text-center py-12">
                <i class="fas fa-money-check-alt text-gray-300 text-5xl mb-4"></i>
                <h3 class="text-xl font-bold text-gray-700 mb-2">No Payment Records Found</h3>
                <p class="text-gray-600 mb-6">
                    <?php 
                    if (!empty($search_query) || $status_filter !== 'all' || $payment_method !== 'all') {
                        echo "Try adjusting your filters or search criteria.";
                    } else {
                        echo "No payments have been recorded yet.";
                    }
                    ?>
                </p>
                <div class="flex gap-3 justify-center">
                    <a href="scan_fines.php" class="btn btn-success">
                        <i class="fas fa-qrcode mr-2"></i> Record Payment
                    </a>
                    <a href="fines.php" class="btn btn-primary">
                        <i class="fas fa-list mr-2"></i> View Fines
                    </a>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" class="modal">
        <div class="modal-content">
            <div class="p-6 border-b border-gray-200">
                <h3 class="text-xl font-bold text-gray-900 flex items-center">
                    <i class="fas fa-trash-alt text-red-600 mr-2"></i> Delete Payment
                </h3>
            </div>
            <form method="POST" action="" class="p-6">
                <input type="hidden" name="payment_id" id="deletePaymentId">
                <input type="hidden" name="delete_payment" value="1">
                
                <div class="mb-6">
                    <div class="text-lg font-semibold text-gray-900 mb-2" id="deleteStudentName"></div>
                    <div class="text-red-600 font-bold text-xl mb-2" id="deleteAmount"></div>
                    <p class="text-gray-700">
                        Are you sure you want to delete this payment record? This action cannot be undone and will affect the fine's payment status.
                    </p>
                </div>
                
                <div class="flex justify-end gap-3">
                    <button type="button" onclick="hideDeleteModal()" class="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                        Cancel
                    </button>
                    <button type="submit" class="btn btn-danger">
                        <i class="fas fa-trash mr-2"></i> Delete Payment
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- View Payment Details Modal -->
    <div id="viewModal" class="modal">
        <div class="modal-content">
            <div class="p-6 border-b border-gray-200">
                <h3 class="text-xl font-bold text-gray-900 flex items-center">
                    <i class="fas fa-file-invoice-dollar text-blue-600 mr-2"></i> Payment Details
                </h3>
            </div>
            <div id="paymentDetails" class="p-6">
                <!-- Details will be loaded via AJAX -->
            </div>
        </div>
    </div>
    
    <!-- Payment Report Modal -->
    <div id="reportModal" class="modal">
        <div class="modal-content">
            <div class="p-6 border-b border-gray-200">
                <h3 class="text-xl font-bold text-gray-900 flex items-center">
                    <i class="fas fa-chart-bar text-green-600 mr-2"></i> Generate Payment Report
                </h3>
            </div>
            <div class="p-6">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    <div>
                        <label class="block mb-2 text-sm font-medium text-gray-700">Report Type</label>
                        <select id="reportType" class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                            <option value="summary">Summary Report</option>
                            <option value="detailed">Detailed Report</option>
                            <option value="monthly">Monthly Collection</option>
                            <option value="student">Student Payment History</option>
                        </select>
                    </div>
                    <div>
                        <label class="block mb-2 text-sm font-medium text-gray-700">Format</label>
                        <select id="reportFormat" class="w-full px-4 py-2 border border-gray-300 rounded-lg">
                            <option value="pdf">PDF</option>
                            <option value="excel">Excel</option>
                            <option value="csv">CSV</option>
                        </select>
                    </div>
                </div>
                
                <div class="flex justify-end gap-3">
                    <button type="button" onclick="hideReportModal()" class="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                        Cancel
                    </button>
                    <button onclick="generateReport()" class="btn btn-primary">
                        <i class="fas fa-download mr-2"></i> Generate Report
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Initialize DataTable
        $(document).ready(function() {
            $('#paymentsTable').DataTable({
                "pageLength": 25,
                "order": [[1, 'desc']], // Sort by payment date
                "language": {
                    "search": "Search payments:",
                    "lengthMenu": "Show _MENU_ payments per page",
                    "info": "Showing _START_ to _END_ of _TOTAL_ payments",
                    "paginate": {
                        "first": "First",
                        "last": "Last",
                        "next": "Next",
                        "previous": "Previous"
                    }
                }
            });
        });
        
        // Payment Methods Chart
        const paymentMethodsData = <?php echo json_encode($payment_methods_stats); ?>;
        const methodsCtx = document.getElementById('paymentMethodsChart').getContext('2d');
        
        const methodsChart = new Chart(methodsCtx, {
            type: 'pie',
            data: {
                labels: paymentMethodsData.map(item => item.payment_method),
                datasets: [{
                    data: paymentMethodsData.map(item => item.total_amount),
                    backgroundColor: [
                        '#10b981', // Green for cash
                        '#3b82f6', // Blue for GCash
                        '#f59e0b', // Yellow for bank
                        '#8b5cf6', // Purple for check
                        '#ec4899'  // Pink for online
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.parsed;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = Math.round((value / total) * 100);
                                return `${label}: ₱${value.toFixed(2)} (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });
        
        // Daily Collection Chart
        // This would typically come from an AJAX call, but we'll initialize with empty data
        const dailyCtx = document.getElementById('dailyCollectionChart').getContext('2d');
        const dailyChart = new Chart(dailyCtx, {
            type: 'line',
            data: {
                labels: [], // Will be populated via AJAX
                datasets: [{
                    label: 'Daily Collection',
                    data: [],
                    borderColor: '#10b981',
                    backgroundColor: 'rgba(16, 185, 129, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: true
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '₱' + value.toFixed(2);
                            }
                        }
                    }
                }
            }
        });
        
        // Load daily collection data
        function loadDailyCollection() {
            const dateFrom = '<?php echo $date_from; ?>';
            const dateTo = '<?php echo $date_to; ?>';
            
            fetch(`get_daily_collection.php?date_from=${dateFrom}&date_to=${dateTo}`)
                .then(response => response.json())
                .then(data => {
                    dailyChart.data.labels = data.labels;
                    dailyChart.data.datasets[0].data = data.values;
                    dailyChart.update();
                });
        }
        
        // Load daily collection on page load
        loadDailyCollection();
        
        // Modal functions
        function showDeleteModal(paymentId, studentName, amount) {
            document.getElementById('deletePaymentId').value = paymentId;
            document.getElementById('deleteStudentName').textContent = studentName;
            document.getElementById('deleteAmount').textContent = '₱' + amount.toFixed(2);
            document.getElementById('deleteModal').classList.add('active');
        }
        
        function hideDeleteModal() {
            document.getElementById('deleteModal').classList.remove('active');
        }
        
        function viewPaymentDetails(paymentId) {
            fetch(`get_payment_details.php?id=${paymentId}`)
                .then(response => response.text())
                .then(html => {
                    document.getElementById('paymentDetails').innerHTML = html;
                    document.getElementById('viewModal').classList.add('active');
                });
        }
        
        function hideViewModal() {
            document.getElementById('viewModal').classList.remove('active');
        }
        
        function showPaymentReport() {
            document.getElementById('reportModal').classList.add('active');
        }
        
        function hideReportModal() {
            document.getElementById('reportModal').classList.remove('active');
        }
        
        // Export payments to CSV
        function exportPayments() {
            const params = new URLSearchParams(window.location.search);
            window.open(`export_payments.php?${params.toString()}`, '_blank');
        }
        
        // Print payments
        function printPayments() {
            window.print();
        }
        
        // Generate report
        function generateReport() {
            const reportType = document.getElementById('reportType').value;
            const reportFormat = document.getElementById('reportFormat').value;
            const params = new URLSearchParams(window.location.search);
            
            params.append('report_type', reportType);
            params.append('format', reportFormat);
            
            window.open(`generate_payment_report.php?${params.toString()}`, '_blank');
            hideReportModal();
        }
        
        // Close modals when clicking outside
        document.addEventListener('click', function(e) {
            if (e.target.classList.contains('modal')) {
                e.target.classList.remove('active');
            }
        });
        
        // Close modals with escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                document.querySelectorAll('.modal.active').forEach(modal => {
                    modal.classList.remove('active');
                });
            }
        });
        
        // Auto-refresh data every 30 seconds (for real-time updates)
        setInterval(function() {
            // Only refresh if no modal is open
            if (!document.querySelector('.modal.active')) {
                // Update statistics (you could implement AJAX refresh here)
                console.log('Auto-refresh triggered');
            }
        }, 30000);
    </script>
</body>
</html>
<?php
$conn->close();
?>