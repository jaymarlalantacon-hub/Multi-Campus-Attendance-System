<?php
// clear_logs.php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('HTTP/1.1 403 Forbidden');
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit();
}

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);
$days = isset($data['days']) ? intval($data['days']) : 90;
$confirm = isset($data['confirm']) ? boolval($data['confirm']) : false;

if (!$confirm) {
    echo json_encode(['success' => false, 'message' => 'Confirmation required']);
    exit();
}

// Delete logs older than specified days
$delete_query = "DELETE FROM scan_logs WHERE timestamp < DATE_SUB(NOW(), INTERVAL ? DAY)";
$delete_stmt = $conn->prepare($delete_query);
$delete_stmt->bind_param("i", $days);
$delete_stmt->execute();
$deleted_rows = $delete_stmt->affected_rows;

echo json_encode([
    'success' => true,
    'deleted' => $deleted_rows,
    'message' => "Successfully deleted $deleted_rows log entries older than $days days."
]);

$conn->close();
?>